"""Render what the chart will show, using the same Python reference the MQL5 mirrors."""
import sys, json, urllib.request
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
sys.path.insert(0,'tests')
from spa_structure_ref import atr_sma
from spa_signal_ref import find_fvg_zones, compress_runs

def load(sym,iv,rng,keep=600):
    url=f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}?interval={iv}&range={rng}"
    r=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0"})
    d=json.load(urllib.request.urlopen(r,timeout=25))["chart"]["result"][0]
    q=d["indicators"]["quote"][0]; O,H,L,C=[],[],[],[]
    for i in range(len(q["close"])):
        o,h,l,c=q["open"][i],q["high"][i],q["low"][i],q["close"][i]
        if None in (o,h,l,c): continue
        O.append(o);H.append(h);L.append(l);C.append(c)
    return O[-keep:],H[-keep:],L[-keep:],C[-keep:]

def dead(z,H,L):
    # touched at all, counted from the bar after the gap candle (engine's origin)
    return any(L[b]<=z.top and H[b]>=z.bottom for b in range(z.gap_idx+1,len(H)))

sym,tf,iv,rng,win = "GBPUSD=X","M15","15m","1mo",160
O,H,L,C=load(sym,iv,rng); a=atr_sma(H,L,C,14); n=len(C)
raw=find_fvg_zones(H,L,C,O,a,0.10)
comp=compress_runs(raw,H,L,C)
live=[z for z in comp if not dead(z,H,L)]
off=n-win
fig,ax=plt.subplots(figsize=(16,8)); fig.set_facecolor("#000"); ax.set_facecolor("#000")
for i in range(off,n):
    x=i-off; up=C[i]>=C[i-1] if i else True; col="#2f9e5a" if up else "#a84040"
    ax.plot([x,x],[L[i],H[i]],color=col,lw=1.0,zorder=6)
    ax.plot([x-.32,x+.32],[H[i],H[i]],color=col,lw=1.0,zorder=6)
    ax.plot([x-.32,x+.32],[L[i],L[i]],color=col,lw=1.0,zorder=6)
shown=0
for z in live:
    x0=z.ob_idx-off
    if x0<0 or x0>win-1: continue
    x1=min(x0+40,win-1); clr="#0a7a0a" if z.bullish else "#b01818"
    ax.add_patch(Rectangle((x0,z.bottom),x1-x0,z.top-z.bottom,facecolor="none",edgecolor=clr,lw=1.6,zorder=3)); shown+=1
ax.set_title(f"v0.17.0  -  one move = one block: {shown} block(s) on {sym} {tf}, from {len(raw)} raw detections",
             color="#e9eff6",fontsize=11.5,loc="left",pad=12)
ax.tick_params(colors="#6b7684",labelsize=8)
for sp in ax.spines.values(): sp.set_color("#1b222b")
ax.grid(color="#0e1319",lw=.6)
ax.legend(handles=[Line2D([0],[0],color="#0a7a0a",lw=1.6,label="demand"),
                   Line2D([0],[0],color="#b01818",lw=1.6,label="supply")],
          facecolor="#0b0f14",edgecolor="#222a34",labelcolor="#b9c4d0",fontsize=9,loc="upper left")
plt.tight_layout(); plt.savefig("workspace_docs/sorted_blocks.png",dpi=115,facecolor=fig.get_facecolor())
print("shown",shown,"raw",len(raw))
