#!/usr/bin/env python3
"""
build_single_file.py — flatten the modular EA into ONE .mq5 file.

Why this exists
---------------
MQL5 EAs are authored as one .mq5 that #includes several .mqh libraries.
That is the right way to develop (small files, easy review, no merge pain),
but it means you have to keep a folder structure together when you move the
EA between machines or hand it to a VPS.

This script inlines every local #include into a single self-contained .mq5,
so you get both: maintainable sources AND one file you can drop anywhere.

Usage
-----
    python3 tools/build_single_file.py
    python3 tools/build_single_file.py --root experts/SovereignPA/SovereignPA.mq5 \
                                       --out  release/SovereignPA_single.mq5

Rules
-----
  * Only quoted includes ("...") are inlined. Angle-bracket includes <...> are
    MQL5 standard library and are left untouched (MetaEditor resolves them).
  * Include guards are stripped from the inlined text; each file is inlined
    ONCE no matter how many times it is referenced.
  * The banner comment at the top of each inlined file is preserved so you can
    still see which module you are reading.
"""

from __future__ import annotations

import argparse
import os
import re
import sys

INCLUDE_RE = re.compile(r'^\s*#include\s+"([^"]+)"\s*$')
GUARD_DEF_RE = re.compile(r'^\s*#ifndef\s+__[A-Z0-9_]+_MQH__\s*$')
GUARD_END_RE = re.compile(r'^\s*#endif\s*//\s*__[A-Z0-9_]+_MQH__\s*$')
ANY_GUARD_IFNDEF = re.compile(r'^\s*#ifndef\s+__\w+_MQH__\s*$')
ANY_GUARD_ENDIF = re.compile(r'^\s*#endif\s*//\s*__\w+_MQH__\s*$')

BANNER = """//+------------------------------------------------------------------+
//|  GENERATED FILE — DO NOT EDIT BY HAND                            |
//|  Built by tools/build_single_file.py                             |
//|  Source  : {root}
//|  Modules : {count}
//|                                                                   |
//|  Edit the modular sources in experts/SovereignPA/ and re-run the  |
//|  build. Hand-edits to this file are lost on the next build.       |
//+------------------------------------------------------------------+
"""


def resolve_include(current_file: str, target: str) -> str:
    base = os.path.dirname(os.path.abspath(current_file))
    return os.path.normpath(os.path.join(base, target))


def flatten(path: str, seen: set, out: list, depth: int = 0) -> None:
    abspath = os.path.abspath(path)
    if abspath in seen:
        return
    seen.add(abspath)

    try:
        with open(abspath, "r", encoding="utf-8") as f:
            lines = f.read().split("\n")
    except OSError as e:
        raise SystemExit(f"cannot read {abspath}: {e}")

    rel = os.path.relpath(abspath, os.getcwd())

    # keep the file's own banner (first contiguous //+---+ block) as a marker
    out.append("")
    out.append("//==========================================================================")
    out.append(f"//  BEGIN MODULE: {rel}")
    out.append("//==========================================================================")

    for i, line in enumerate(lines):
        m = INCLUDE_RE.match(line)
        if m:
            child = resolve_include(abspath, m.group(1))
            if not os.path.exists(child):
                raise SystemExit(f"{rel}: include not found -> {m.group(1)}")
            flatten(child, seen, out, depth + 1)
            continue

        # drop include guards (they are meaningless once flattened)
        if ANY_GUARD_IFNDEF.match(line) or ANY_GUARD_ENDIF.match(line):
            continue

        out.append(line)

    out.append(f"//  END MODULE: {rel}")
    out.append("")



# ---------------------------------------------------------------------------
# Dependency-order check.
#
# MQL5 resolves #include textually, so a module that takes `CSpaStructure &`
# parameters MUST be preceded by the module that declares CSpaStructure.
# Getting it wrong produces a wall of "declaration without type" errors that
# all point at the same handful of lines and hide the real cause - one wrong
# #include line.
#
# This check reads the FINISHED file and reports any type used before it is
# declared. It is a build-time guard, not a lint: on failure the build fails.
# ---------------------------------------------------------------------------
DECL_RE = re.compile(r'^\s*(?:class|struct)\s+([A-Za-z_]\w*)\s*(?:\{|$)')


def check_dependency_order(path: str) -> list:
    lines = open(path, encoding="utf-8").read().splitlines()

    declared_at = {}
    for i, line in enumerate(lines):
        m = DECL_RE.match(line)
        if m:
            declared_at.setdefault(m.group(1), i)

    problems = []
    for name, decl_line in declared_at.items():
        for i, line in enumerate(lines):
            if i >= decl_line:
                break
            # skip comments and the declaration's own forward mentions
            stripped = line.strip()
            if stripped.startswith("//") or stripped.startswith("|"):
                continue
            if re.search(r'\b' + re.escape(name) + r'\b', line):
                problems.append((name, i + 1, decl_line + 1, stripped[:100]))
                break
    return problems

def main() -> int:
    ap = argparse.ArgumentParser(description="Flatten a modular MQL5 EA into one file.")
    ap.add_argument("--root", default="experts/SovereignPA/SovereignPA.mq5")
    ap.add_argument("--out", default="release/SovereignPA_single.mq5")
    args = ap.parse_args()

    if not os.path.exists(args.root):
        print(f"error: root file not found: {args.root}", file=sys.stderr)
        return 1

    seen: set = set()
    body: list = []
    flatten(args.root, seen, body)

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(BANNER.format(root=args.root, count=len(seen)))
        f.write("\n".join(body))

    n_lines = sum(1 for _ in open(args.out, encoding="utf-8"))
    problems = check_dependency_order(args.out)
    print(f"built {args.out}")
    print(f"  modules inlined : {len(seen)}")
    print(f"  output lines    : {n_lines}")
    for s in sorted(seen):
        print(f"    - {os.path.relpath(s, os.getcwd())}")

    if problems:
        print("", file=sys.stderr)
        print("DEPENDENCY ORDER BROKEN - the compiler will reject this file:", file=sys.stderr)
        for name, used, decl, snippet in problems:
            print(f"  {name} used at line {used} but declared at line {decl}", file=sys.stderr)
            print(f"    {snippet}", file=sys.stderr)
        print("  Fix the #include order in the root .mq5.", file=sys.stderr)
        return 2
    print("  dependency order: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# --- Always verify every identifier we reference actually exists. A text edit
# --- that silently matches nothing produces a file with the right brace count,
# --- the right dependency order and the right format strings, and still fails
# --- to compile. That happened at v0.6.5; this is the check that catches it.
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import check_identifiers
    _problems = []
    for _t in ["release/SovereignPA_single.mq5"]:
        _problems += check_identifiers.check(Path(_t))
    if _problems:
        print("  !! undeclared identifiers:")
        for _p in _problems:
            print("     " + _p)
        raise SystemExit(1)
    print("  identifiers: OK")
except ImportError:
    pass
