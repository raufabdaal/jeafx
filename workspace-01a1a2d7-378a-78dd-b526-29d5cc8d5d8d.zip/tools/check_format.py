#!/usr/bin/env python3
"""
Static check for StringFormat / PrintFormat / Print calls in the MQL5 sources.

Counts conversion specifiers in the format string (ignoring %%) and compares
them with the number of arguments actually supplied. A mismatch is a hard
compile error in MQL5, so this runs before every build.
"""
import re, sys, glob

CALLS = re.compile(r'\b(StringFormat|PrintFormat)\s*\(')

def parse_call(s, start):
    """Return (format_string, arg_count) for the call opening at `start`."""
    i = s.index('(', start) + 1
    depth, args, cur, in_str = 1, [], [], False
    fmt = None
    while i < len(s):
        ch = s[i]
        if in_str:
            if ch == '\\':
                cur.append(s[i:i+2]); i += 2; continue
            if ch == '"':
                in_str = False
                if fmt is None:
                    fmt = ''.join(cur)
                cur.append('"')
                i += 1; continue
            cur.append(ch); i += 1; continue
        if ch == '"':
            in_str = True; i += 1; continue
        if ch in '([{':
            depth += 1
        elif ch in ')]}':
            depth -= 1
            if depth == 0:
                args.append(''.join(cur)); break
        elif ch == ',' and depth == 1:
            args.append(''.join(cur)); cur = []
            i += 1; continue
        cur.append(ch); i += 1
    n_args = max(len([a for a in args if a.strip()]), 1) - 1   # minus the format string
    return fmt, n_args

def specifiers(fmt):
    if fmt is None:
        return 0
    count = 0
    i = 0
    while i < len(fmt):
        if fmt[i] == '%':
            if i + 1 < len(fmt) and fmt[i+1] == '%':
                i += 2; continue
            count += 1
        i += 1
    return count

def main(paths):
    bad = 0
    for path in paths:
        s = open(path, encoding='utf-8', errors='replace').read()
        for m in CALLS.finditer(s):
            try:
                fmt, n_args = parse_call(s, m.start())
            except Exception:
                continue
            if fmt is None:
                continue
            want = specifiers(fmt)
            if want != n_args:
                line = s[:m.start()].count('\n') + 1
                print(f"{path}:{line}: {m.group(1)} has {want} specifier(s) but {n_args} argument(s)")
                print(f"    {fmt[:90]}")
                bad += 1
    print(f"\n{bad} mismatch(es) across {len(paths)} file(s)")
    return 1 if bad else 0

if __name__ == '__main__':
    files = sys.argv[1:] or ["release/SovereignPA_single.mq5"]
    sys.exit(main(files))
