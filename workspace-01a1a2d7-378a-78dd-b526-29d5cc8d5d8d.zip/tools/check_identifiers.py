#!/usr/bin/env python3
"""
Catch the class of bug that produced the v0.6.5 compile failure.

An input declaration was inserted with a text replace that silently matched
nothing (two extra spaces in the anchor). The code then referenced
`InpZoneAudit`, `InpAuditMax` and `InpAuditRejected`, which were never
declared, and the user's compiler reported ten "undeclared identifier" errors.

Every other check we run - brace balance, format-string arity, dependency
order - passed, because a missing declaration changes none of them. This
script answers one question: does every identifier we own actually exist?

Prefixes checked are ours by convention: Inp*, g_*, SPA_*, Spa*, CSpa*,
ENUM_SPA_*. MQL5 built-ins (clr*, PERIOD_*, OBJ_*, STYLE_*, PRICE_*, ...)
are deliberately out of scope.
"""
import re
import sys
from pathlib import Path

PREFIXES = ("Inp", "g_", "SPA_", "Spa", "CSpa", "ENUM_SPA_")
TYPE_WORDS = (
    r"CSpa\w*", r"Spa\w*", r"ENUM_SPA_\w*",
    "double", "int", "bool", "string", "datetime", "color",
    "long", "ulong", "uint", "short", "ushort", "char", "uchar", "float", "void",
)


def ours(name):
    return any(name.startswith(p) for p in PREFIXES)


def blank(m):
    """Replace a match with spaces, preserving newlines so line numbers hold."""
    return "".join("\n" if ch == "\n" else " " for ch in m.group(0))


def strip_noise(src):
    """Comments, string literals, char literals and #include paths can never
    be identifier references. Blank them out, keeping line numbering."""
    src = re.sub(r'#include\s*[<"][^>"]*[>"]', blank, src)
    src = re.sub(r"//[^\n]*", blank, src)
    src = re.sub(r"/\*.*?\*/", blank, src, flags=re.S)
    src = re.sub(r'"(?:\\.|[^"\\])*"', blank, src)
    src = re.sub(r"'(?:\\.|[^'\\])*'", blank, src)
    return src


def check(path):
    src = strip_noise(path.read_text())
    defined = set()

    defined |= set(re.findall(r"#define[ \t]+(\w+)", src))
    # [ \t]+ not \s+: \s crosses newlines and swallows the NEXT line's
    # "input" keyword, which silently lost every declaration after an
    # "input group" line.
    defined |= set(re.findall(r"\b(?:input|sinput)[ \t]+\w+[ \t]+(\w+)", src))
    defined |= set(re.findall(r"\b(?:struct|class|enum)\s+(\w+)", src))
    defined |= set(re.findall(r"\benum\s+(\w+)\s*\{", src))
    for body in re.findall(r"\benum\s*\w*\s*\{([^}]*)\}", src, flags=re.S):
        defined |= set(re.findall(r"[A-Za-z_]\w*", body))

    type_group = "|".join(TYPE_WORDS)

    # comma-separated declarations: "double best = -1.0, g_low = 0.0;"
    # captured line by line, because a single regex only ever sees the first.
    for line in src.split("\n"):
        m = re.match(r"\s*(?:static[ \t]+)?(?:const[ \t]+)?(?:%s)[ \t]+(.+?);"
                     % type_group, line)
        if not m:
            continue
        for part in m.group(1).split(","):
            nm = re.match(r"\s*&?\s*(\w+)", part)
            if nm:
                defined.add(nm.group(1))
    defined |= set(re.findall(
        r"(?:^|\n)\s*(?:static\s+)?(?:const\s+)?(?:%s)\s+(&?\w+)" % type_group, src))
    defined |= set(re.findall(r"(?:%s)[ \t]*&[ \t]*(\w+)" % type_group, src))

    # ---- struct member access -------------------------------------------
    # `z.leg_end` where SpaZone has no such field is a compile error that no
    # identifier check sees: both `z` and `leg_end` exist, just not together.
    structs = {}
    for m in re.finditer(r"\bstruct\s+(\w+)\s*\{(.*?)\};", src, flags=re.S):
        name, body = m.group(1), m.group(2)
        structs[name] = set(re.findall(r"(?:^|\n)\s*[A-Za-z_]\w*\s+(\w+)\s*(?:\[[^\]]*\])?\s*;", body))

    # A name can be declared as more than one struct in different scopes
    # (`p` is a SpaPivot in one loop and a SpaProfile in another). Only check
    # names with a single unambiguous binding, or the check cries wolf.
    bindings = {}
    for t, v in re.findall(r"\b(Spa\w+)\s+(&?\w+)\s*[;,\)]", src):
        if t in structs:
            bindings.setdefault(v.lstrip("&"), set()).add(t)
    vars_of_type = {v: next(iter(ts)) for v, ts in bindings.items() if len(ts) == 1}

    member_problems = []
    for m in re.finditer(r"\b(\w+)\.(\w+)\b", src):
        var, field = m.group(1), m.group(2)
        t = vars_of_type.get(var)
        if t is None or field in structs[t]:
            continue
        declared = ", ".join(sorted(structs[t])) or "nothing"
        member_problems.append(
            "%s:%d: '%s.%s' - %s has no field '%s' (has: %s)"
            % (path.name, src.count("\n", 0, m.start()) + 1, var, field, t, field, declared))

    used = {}
    for m in re.finditer(r"\b[A-Za-z_]\w*\b", src):
        name = m.group(0)
        if ours(name) and name not in used:
            used[name] = src.count("\n", 0, m.start()) + 1

    missing = [(n, ln) for n, ln in used.items() if n not in defined]
    out = ["%s:%d: '%s' is used but never declared" % (path.name, ln, n)
           for n, ln in sorted(missing, key=lambda x: x[1])]
    seen = set()
    for mp in member_problems:
        if mp not in seen:
            seen.add(mp)
            out.append(mp)
    return out


def check_array_bounds(src, label="file"):
    """A local array sized from a #define, indexed past its size, is a
    guaranteed runtime crash - and it killed the EA inside OnInit at v0.7.0,
    leaving the panel frozen at "SPA initialising..." with no error shown."""
    out = []
    macros = {n: int(v) for n, v in re.findall(r"#define\s+(\w+)\s+(\d+)\b", src)}
    for var, macro in re.findall(r"ArrayResize\(\s*(\w+)\s*,\s*(\w+)\s*\)", src):
        if macro not in macros:
            continue
        limit = macros[macro]
        for m in re.finditer(r"\b%s\s*\[\s*(\d+)\s*\]" % re.escape(var), src):
            idx = int(m.group(1))
            if idx >= limit:
                line = src.count("\n", 0, m.start()) + 1
                out.append("%s:%d: '%s[%d]' is out of range - %s is %d"
                           % (label, line, var, idx, macro, limit))
    return out


def check_forward_decls(src, label="file"):
    """A forward declaration with the wrong return type fails to compile with
    'function already defined and has different return type'. Cheap to catch."""
    out = []
    types = {}
    for m in re.finditer(r"^\s*(void|string|int|double|bool|datetime|color|long|uint|short|char|float)\s+"
                         r"(\w+)\s*\([^;{]*\)\s*[;{]", src, re.M):
        rt, name = m.group(1), m.group(2)
        if name in ("if", "for", "while", "switch", "return", "else"):
            continue
        if name in types and types[name] != rt:
            line = src.count("\n", 0, m.start()) + 1
            out.append("%s:%d: '%s' declared as %s here, but earlier as %s"
                       % (label, line, name, rt, types[name]))
        types[name] = rt
    return out


def check_call_arity(src, label="file"):
    """MQL5 will not compile a call with the wrong number of arguments, and we
    have no compiler here. After a refactor that changes a signature, a stale
    call site is the most likely break - this caught DrawCleanOne still being
    called with 3 arguments after it became 5.

    Only file-scope definitions are considered (column 0). Class methods are
    indented and are skipped; calls through an object are skipped too."""
    def count_args(text):
        text = text.strip()
        if not text:
            return 0
        d, n = 0, 1
        for ch in text:
            if ch in "([{":
                d += 1
            elif ch in ")]}":
                d -= 1
            elif ch == "," and d == 0:
                n += 1
        return n

    def grab(text, open_idx):
        d, i = 0, open_idx
        while i < len(text):
            if text[i] == "(":
                d += 1
            elif text[i] == ")":
                d -= 1
                if d == 0:
                    return text[open_idx + 1:i], i
            i += 1
        return None, open_idx

    allowed = {}
    for m in re.finditer(r"^(?:void|string|int|double|bool|datetime|color|long|uint|short|char|float)"
                         r"[ \t]+(\w+)[ \t]*\(", src, re.M):
        params, _ = grab(src, m.end() - 1)
        if params is None:
            continue
        if params.strip() in ("", "void"):
            allowed.setdefault(m.group(1), set()).add(0)
            continue
        parts = params.split(",")
        req = sum(1 for q in parts if "=" not in q)
        allowed.setdefault(m.group(1), set()).update(range(req, len(parts) + 1))

    out = []
    for m in re.finditer(r"\b(\w+)[ \t]*\(", src):
        name = m.group(1)
        if name not in allowed:
            continue
        pre = src[:m.start()].rstrip()
        if pre.endswith(".") or pre.endswith("::"):
            continue
        args, _ = grab(src, m.end() - 1)
        if args is None:
            continue
        n = count_args(args)
        if n not in allowed[name]:
            line = src.count("\n", 0, m.start()) + 1
            out.append("%s:%d: '%s' called with %d argument(s), defined with %s"
                       % (label, line, name, n, sorted(allowed[name])))
    return out


MQL5_BUILTIN = set("""
ArrayCopy ArrayFill ArrayFree ArrayInsert ArrayMaximum ArrayMinimum ArrayPrint
ArrayRange ArrayResize ArraySetAsSeries ArraySize ArraySort Bars ChartRedraw
ChartIndicatorAdd ChartSaveTemplate ColorToARGB Comment CopyBuffer CopyClose
CopyHigh CopyLow CopyOpen CopyRates CopyTickVolume CopyTime DebugBreak
Digits DoubleToString EnumToString EventChartCustom EventKillTimer EventSetMillisecondTimer
EventSetTimer ExpertRemove FileClose FileOpen FileReadString FileWriteString
GetLastError GetPointer GetTickCount GlobalVariableGet GlobalVariableSet
HistorySelect IndicatorRelease IntegerToString IsStopped MathAbs MathArccos
MathArcsin MathArctan MathCeil MathCos MathExp MathFloor MathLog MathMax MathMin
MathMod MathPow MathRand MathRound MathSin MathSqrt MathSrand MathTan NormalizeDouble
ObjectCreate ObjectDelete ObjectFind ObjectGetDouble ObjectGetInteger
ObjectGetString ObjectGetTimeByValue ObjectGetValueByTime ObjectSetDouble
ObjectSetInteger ObjectSetString ObjectsDeleteAll ObjectsTotal OnDeinit OnTick
OnInit OnTimer OnChartEvent OnCalculate Period PeriodSeconds PlaySound
PlotIndexSetDouble PlotIndexSetInteger Print PrintFormat ResetLastError
SetIndexBuffer SetSymbolPeriod Sleep StringAdd StringBufferLen StringCompare
StringConcatenate StringFill StringFind StringFormat StringGetCharacter
StringInit StringLen StringSetCharacter StringSubstr StringToDouble StringToInteger
StringToLower StringToUpper StringTrimLeft StringTrimRight Symbol SymbolInfoDouble
SymbolInfoInteger SymbolInfoString SymbolSelect TerminalInfoInteger
TimeCurrent TimeDay TimeDayOfWeek TimeGMT TimeHour TimeLocal TimeMinute
TimeMonth TimeSeconds TimeToString TimeYear TimeTradeServer ZeroMemory
datetime color long ulong uint short ushort uchar char float double bool int string void
""".split())


def _strip_noise(src):
    """Remove // and /* */ comments and string literals so prose is not
    mistaken for code. Without this the checker reports words like 'engine (
    v0.14.0)' from a comment header as undefined functions."""
    out = []
    i, n = 0, len(src)
    while i < n:
        if src.startswith("//", i):
            j = src.find("\n", i)
            i = n if j < 0 else j
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2)
            i = n if j < 0 else j + 2
        elif src[i] == '"':
            i += 1
            while i < n and src[i] != '"':
                i += 2 if src[i] == "\\" else 1
            i += 1
            out.append('""')
        elif src[i] == "'":
            i += 1
            while i < n and src[i] != "'":
                i += 2 if src[i] == "\\" else 1
            i += 1
            out.append("''")
        else:
            out.append(src[i])
            i += 1
    return "".join(out)


MQL5_BUILTIN = set("""
AccountInfoDouble AccountInfoInteger AccountInfoString ArrayCopy ArrayFill
ArrayFree ArrayInsert ArrayMaximum ArrayMinimum ArrayPrint ArrayRange
ArrayRemove ArrayResize ArraySetAsSeries ArraySize ArraySort Bars ChartRedraw
ChartSaveTemplate ColorToARGB Comment CopyBuffer CopyClose CopyHigh CopyLow
CopyOpen CopyRates CopyTickVolume CopyTime Digits DoubleToString EnumToString
EventChartCustom EventKillTimer EventSetMillisecondTimer EventSetTimer
ExpertRemove FileClose FileIsEnding FileOpen FileReadString FileWriteString
GetLastError GetPointer GetTickCount GlobalVariableGet GlobalVariableSet
HistorySelect IndicatorRelease IntegerToString MQLInfoInteger MathAbs MathCos
MathExp MathFloor MathLog MathMax MathMin MathMod MathPow MathRand MathRound
MathSin MathSqrt MathSrand MathTan MathCeil MathArcsin MathArccos MathArctan
MathArcsinh NormalizeDouble ObjectCreate ObjectDelete ObjectFind
ObjectGetDouble ObjectGetInteger ObjectGetString ObjectSetDouble
ObjectSetInteger ObjectSetString ObjectsDeleteAll ObjectsTotal OrderCalcMargin
Period PeriodSeconds PlaySound Print PrintFormat ResetLastError SetIndexBuffer
SetSymbolPeriod Sleep StringAdd StringBufferLen StringCompare StringConcatenate
StringFill StringFind StringFormat StringGetCharacter StringInit StringLen
StringSetCharacter StringSplit StringSubstr StringToDouble StringToInteger
StringToLower StringToUpper StringTrimLeft StringTrimRight Symbol
SymbolInfoDouble SymbolInfoInteger SymbolInfoString SymbolSelect
TerminalInfoInteger TimeCurrent TimeDay TimeDayOfWeek TimeGMT TimeHour
TimeLocal TimeMinute TimeMonth TimeSeconds TimeToString TimeTradeServer TimeYear
ZeroMemory if for while switch return else do sizeof new delete
iTime iOpen iHigh iLow iClose iATR iMA iRSI iBands iStochastic iCustom
iBarShift iHighest iLowest iVolume iSpread iMomentum iMACD iCCI
""".split())


def check_undefined_calls(src, label="file"):
    """A function that is called but never defined anywhere in the file does not
    compile. This is what a stale call site looks like after a refactor deletes
    a function body but leaves the caller - how DrawBiasZone went missing in
    v0.14.0 while every other gate passed."""
    code = _strip_noise(src)

    def grab(text, open_idx):
        d, i = 0, open_idx
        while i < len(text):
            if text[i] == "(":
                d += 1
            elif text[i] == ")":
                d -= 1
                if d == 0:
                    return text[open_idx + 1:i], i
            i += 1
        return None, open_idx

    # A definition is a name whose parameter list is followed by {, ; or a
    # constructor initialiser ':'. This does not care what the return type is,
    # so ENUM_TIMEFRAMES and custom types are handled too.
    defined = set()
    for m in re.finditer(r"\b(\w+)[ \t]*\(", code):
        if m.group(1) in ("if", "for", "while", "switch", "return"):
            continue
        _, close = grab(code, m.end() - 1)
        rest = code[close + 1:close + 60].lstrip()
        for word in ("const", "override", "final"):
            while rest.startswith(word):
                rest = rest[len(word):].lstrip()
        if rest[:1] in ("{", ":"):
            defined.add(m.group(1))
            continue
        if rest[:1] == ";":
            # only a PROTOTYPE if a return type precedes the name; a bare
            # `Foo();` is a call, not a declaration
            before = code[:m.start()].rstrip()
            if before and (before[-1].isalnum() or before[-1] in "_*&"):
                defined.add(m.group(1))
    for m in re.finditer(r"\bclass[ \t]+(\w+)", code):
        defined.add(m.group(1))

    out = []
    seen = set()
    for m in re.finditer(r"\b(\w+)[ \t]*\(", code):
        name = m.group(1)
        if name in defined or name in MQL5_BUILTIN or name in seen:
            continue
        # members, inputs and constants are not function calls
        if name.startswith(("m_", "g_", "Inp", "SPA_", "OBJ", "ANCHOR", "STYLE",
                            "CORNER", "PERIOD", "CHART", "CLR", "clr", "PRICE")):
            continue
        if name.isupper():
            continue
        pre = code[:m.start()].rstrip()
        if pre.endswith(".") or pre.endswith("::") or pre.endswith("#"):
            continue
        # a call sits at statement level or after an operator, never after a word
        if pre and (pre[-1].isalnum() or pre[-1] in "_"):
            continue
        seen.add(name)
        line = src.count("\n", 0, code.count("\n", 0, m.start())) + 1
        out.append("%s: '%s' is called but never defined" % (label, name))
    return out


def main():
    args = sys.argv[1:] or ["release/SovereignPA_single.mq5"]
    targets = [Path(p) for p in args]
    problems = []
    for t in targets:
        if not t.exists():
            print("missing file: %s" % t)
            return 2
        problems += check(t)
        problems += check_array_bounds(t.read_text(), t.name)
        problems += check_forward_decls(t.read_text(), t.name)
        problems += check_call_arity(t.read_text(), t.name)
        problems += check_undefined_calls(t.read_text(), t.name)

    if problems:
        for p in problems:
            print("  " + p)
        print("\n%d problem(s) - this will NOT run correctly" % len(problems))
        return 1
    print("identifiers: OK (%s)" % ", ".join(str(t) for t in targets))
    return 0


if __name__ == "__main__":
    sys.exit(main())
