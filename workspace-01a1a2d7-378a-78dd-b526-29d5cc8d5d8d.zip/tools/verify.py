#!/usr/bin/env python3
"""
verify.py — the one command that must pass before anything is handed over.

Order matters: build first (so the checks see the released file), then every
gate. Each gate exists because something got past us once:

  build       flatten includes into release/SovereignPA_single.mq5
  identifiers every Inp*/g_*/SPA_* reference has a declaration   [v0.6.5]
  format      StringFormat placeholders match their arguments    [earlier]
  tests       21 symbol/risk + 24 structure + 32 signal
  balance     braces and parentheses
  version     SPA_VERSION matches what the panel will claim

Usage:  python3 tools/verify.py
Exit 0 = safe to hand over. Anything else = do not ship.
"""
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RELEASE = ROOT / "release" / "SovereignPA_single.mq5"
TARGET_VERSION = "0.18.0"

failures = []


def run(label, cmd, cwd=ROOT, expect_zero=True):
    r = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True)
    ok = (r.returncode == 0) == expect_zero
    tail = (r.stdout or r.stderr).strip().splitlines()
    tail = tail[-1] if tail else "(no output)"
    print(("  PASS  " if ok else "  FAIL  ") + label + " :: " + tail)
    if not ok:
        failures.append(label)
    return r


print("== build ==")
run("build single file", [sys.executable, "tools/build_single_file.py"])

print("== gates ==")
run("identifiers declared", [sys.executable, "tools/check_identifiers.py"])
run("format strings", [sys.executable, "tools/check_format.py"])

total = 0
for t in ("test_symbol_math.py", "test_structure.py", "test_signal.py"):
    r = run(t, [sys.executable, t], cwd=ROOT / "tests")
    m = re.search(r"Ran (\d+) tests", r.stderr + r.stdout)
    if m:
        total += int(m.group(1))
print("  tests run: %d" % total)

src = RELEASE.read_text()
braces = src.count("{") - src.count("}")
parens = src.count("(") - src.count(")")
ok = braces == 0 and parens == 0
print(("  PASS  " if ok else "  FAIL  ") + "brace/paren balance :: braces=%d parens=%d" % (braces, parens))
if not ok:
    failures.append("balance")

m = re.search(r'#define\s+SPA_VERSION\s+"([^"]+)"', src)
found = m.group(1) if m else "?"
ok = found == TARGET_VERSION
print(("  PASS  " if ok else "  FAIL  ") + "version :: SPA_VERSION=%s expected=%s" % (found, TARGET_VERSION))
if not ok:
    failures.append("version")

print("\n  lines: %d" % src.count("\n"))

if failures:
    print("\nDO NOT SHIP - failed: " + ", ".join(failures))
    sys.exit(1)
print("\nALL GATES PASSED - %s is ready to hand over" % RELEASE.name)
