## [DOC] — 2026-11-03 — `workspace_docs/HANDOVER.md`

The user asked for everything to be logged so any agent can pick this up immediately:
*"if anything ever happened to you I want to be able to pick up right away with any agent,
because we're onto something very important."*

`HANDOVER.md` now holds: the locked block definition (§3) with the user's verbatim words
and dates, the working agreement (§2), the architecture map, the build/ship protocol, all
twelve traps that have already cost a release, the eight-phase roadmap, and a
vocabulary table translating his words into code.

**Read it first. Update it last.**

# Changelog — Sovereign Price-Action EA

Format: [Keep a Changelog](https://keepachangelog.com/) + Semantic Versioning.
All times Africa/Nairobi (EAT, UTC+3).

---

## [0.18.0] — 2026-11-03 — *Touched means filled*

### Your rule
> "if price dipped partway or even tapped a box, it's automatically invalid,
> because then we know that was already retested. It doesn't necessarily mean the
> box has to be filled all the way — the moment the box is touched the imbalance
> is already filled."

This **reverses** the earlier reading (D-F: used up only when price crosses the
whole of it). The engine now drops any block price has come back into at all,
partly or fully. `z.retested` is the display filter.

### The bug this uncovered
My first measurement said the rule left **zero** blocks on an M15 chart. That
was not the rule — it was my measurement. It scanned from the block candle
forward, so the **middle candle of the 3-bar gap**, which normally dips back
through the block's range, was being counted as a retest:

```
bars from block to "first touch":  1 bar -> 153 blocks of 184
```

A block can only be retested **after the gap candle closes**. With the scan
corrected, the real numbers (600 bars):

| | raw | one-move-per-block | drawn |
|---|---|---|---|
| GBP/USD M15 | 185 | 83 | **8** |
| GBP/USD M5 | 235 | 89 | **11** |

3–4 live blocks in a 150-bar window. Sparse, but a chart, not a blank.

Note that `retested`, `gap_filled` and `fresh` in the engine were **always**
scanned from `k+1` — correct. Only the side-measurement was wrong. No engine
logic changed for this.

### Compiler warnings — fixed
`possible use of uninitialized variable 'run'` ×2, in `CompressRuns()`.
`ZeroMemory(run)` after the declaration. **0 errors, 0 warnings** expected now.

### Verified
identifiers OK, undefined calls OK, array bounds OK, forward decls OK, call
arity OK, format OK, 52 tests.

## [0.17.0] — 2026-11-03 — *A wick is not a pullback*

### What you marked
Image 1: a tick on the lower block of a pair, an X on the higher one that starts
later. Image 2: an X on a block price had come back through. Image 3: both.

### Why the pair survived in 0.16.0
I ended a "move" as soon as price **touched** back into the block. A single wick
poking in was enough to split one move into two, and both blocks were drawn. That
is the X you drew.

### The fix
A move now ends only when a candle **closes** back inside the block. A wick
through it does not end the move; a body does.

| | blocks drawn in a 160-bar M15 window | |
|---|---|---|
| GBP/USD before (wick splits the move) | 13 | |
| **GBP/USD now** | **5** | |
| EUR/USD before | 19 | |
| **EUR/USD now** | **11** | |

### Tests
52. The new one is the exact case you drew:
`test_a_wick_back_in_does_not_end_the_move` — a wick into the block with a close
back above it must leave **one** block, not two.

### Still guarded
The block itself is untouched. Top = the high of the block candle, bottom = its
low, wick to wick, block = the candle before the displacement. The sorting pass
runs after detection and does not alter any geometry.

### Verified
identifiers OK, undefined calls OK, array bounds OK, forward decls OK, call
arity OK, format OK, 52 tests, 3,526 lines.

## [0.16.0] — 2026-11-03 — *One move, one block*

### The rule you gave
> "we cannot get the last candle before the impulse again immediately after it...
> we are going to be considering the extreme, the last candle at the top, which
> brought all of these inefficient candles... unless there is a break of
> structure, maybe **a pullback**, after that pullback we can consider that also."

### What the engine does now
A **run** is a sequence of same-direction blocks with no retest between them.
Inside a run only the **extreme** survives — the highest top for supply, the
lowest bottom for demand. A retest, a direction change or a pullback ends the run
and a new one may begin.

`CompressRuns()` runs immediately after the blocks are found, so everything
downstream (drawing, §3.3, and later the sweep/MSS engine) sees the sorted list,
not the raw one.

Measured on GBP/USD M5, 600 bars: **247 raw → 151 sorted (61%)**.

### The wording that decided the filter
You said: *"remove the candles that had already been retested, **if they had
already passed through them in the past**."*

I built the strict reading first — "never touched" — and measured it:

| filter | blocks left in an M15 window |
|---|---|
| never **touched** | **1** |
| never **passed through** | **13–20** |

One is a blank chart. Thirteen to twenty is what you mark. **The engine uses
"passed through".** This is the third time your exact wording has been more
precise than my paraphrase of it; I should stop paraphrasing.

### Result
On GBP/USD M15 over 160 bars: **13 blocks** from 543 raw detections, candles
fully visible, no dotted clutter.

### Tests
51 signal tests. Five new for the sorting rule: one move collapses to the
extreme, demand keeps the lowest, a retest splits the run, a direction change
splits the run, and a retested block is flagged.

### Verified
identifiers OK, undefined calls OK, array bounds OK, forward decls OK, call
arity OK, format OK, 3,522 lines.

## [0.15.0] — 2026-11-02 — *I make the setting; you look at the chart*

### The problem was mine, not yours
I asked you to find `InpFvgMinATR` in the properties dialog and read a line out of
an Experts tab that prints an entry every 30 seconds on five charts. You are the
one who reads the chart; I am the one who reads the settings. That was a bad
division of labour and I should not have asked.

### The change, made for you
`InpFvgMinATR` default **0.50 → 0.10**. No input to edit, no log to read.

Measured on GBP/USD M5, 600 bars:

| threshold | blocks kept | in a 300-bar window |
|---|---|---|
| 0.50 x ATR (before) | 150 | 71 |
| **0.10 x ATR (now)** | **245** | **124** |

77% of detections were being thrown away by that one number. They are not thrown
away now.

### The panel is your feedback channel
The compact panel now reads plainly:

```
24 blocks on this M5 chart
```

That number is the whole conversation. If it looks like what you would mark, the
finding step is finished. If it is too many, it is one number on my side and I
change it — you never touch it.

### Note on the rule book
D-06 said 0.5 x ATR. Your instruction said a sliver counts. I have gone with your
instruction. The rule book needs correcting on this point, not the code.

### Verified
identifiers OK, undefined calls OK, array bounds OK, forward decls OK, call
arity OK, format OK, 46 tests, 3,438 lines.

## [0.14.4] — 2026-11-02 — *The log was burying the answer*

### What you saw
The Experts tab was a wall of `[DIAG]` blocks, one every 30 seconds, repeated
across five attached charts. The single line that answers the zone question was
scrolled out of sight.

### What changed (logging only)
- The periodic `[DIAG]` block is **off by default** (`InpLogDiag = false`).
- The two findings that matter are now marked so they are findable in a filter:

```
== ZONE == M5: 13 shown of 31 known | found=138  ok=31  too-small=107  atr=0.00041  bars=600  lookback=300
== REFINE == 3 demand zone(s) with an open imbalance, none in this leg
```

Nothing about detection, drawing or the engine changed.

### Still open
`found=138  ok=31  too-small=107` — 77% of imbalances rejected by the
0.5 x ATR size filter. Waiting on the `InpFvgMinATR` 0.50 -> 0.10 test.

### Verified
identifiers OK, undefined calls OK, array bounds OK, forward decls OK, call
arity OK, format OK, 46 tests, 3,438 lines.

## [0.14.3] — 2026-11-02 — *The geometry is confirmed; the count is not*

### Your answer settled one thing
The two lines you draw are **the high and the low of the candle, wick to wick** —
the top wick where it stops and the bottom wick where it stops. That is exactly
what the engine stores (`top = high[block]`, `bottom = low[block]`). **The box
shape was never wrong.** I had guessed they might be zone bands; they are not.

### The number that does not add up
Your log:

```
[ZONE] CURRENT: 9 block(s) shown of 32 known; structure bars=600 lookback=150
```

Same 600 bars, same GBP/USD M5, same 0.5 x ATR rule, computed independently:

| | count |
|---|---|
| imbalances found in 600 bars | **261** |
| pass the 0.5 x ATR test | **154** |
| blocks the EA knows | **32** |

The engine is losing about **120 blocks between "imbalance found" and "block
kept"**, and nothing visible in the scan code explains it.

### So: a diagnostic, not a change
```
[ZONE] M5: N shown of M known | imbalances found=X  ok=Y  too-small=Z  atr=...  bars=600  lookback=300
```

`found` tells me whether the imbalances are never detected. `too-small` tells me
whether the 0.5 x ATR filter is eating them. `ok` is what survives. One line
separates the two possibilities, and I am not changing detection until it is
answered — that is the rule I set after breaking it twice.

### Also
Default `InpZoneLookbackBars` raised 150 → 300, so more of the known blocks are
actually on screen.

### Verified
identifiers OK, undefined calls OK, array bounds OK, forward decls OK, call
arity OK, format OK, 46 tests, 3,432 lines.

## [0.14.2] — 2026-11-02 — *Why the Daily chart showed nothing*

### The bug
```cpp
int nb = Bars(_Symbol,PERIOD_CURRENT);   // the TERMINAL's bar count
...
if(z.ob_idx < nb-InpZoneLookbackBars) continue;
```
`z.ob_idx` is an index into the **structure's** arrays, which hold
`InpStructBars = 600` bars. `Bars()` returns what the terminal has loaded, which
on GBP/USD Daily is about 7,500.

```
cutoff = 7500 - 150 = 7350     every block (index 0..599) rejected
cutoff =  600 - 150 =  450     correct: the last 150 bars kept
```

The lookback window was measured in the wrong units, so on any timeframe where
the terminal holds far more history than the structure does, **nothing is drawn**.
That is exactly what you saw: a Daily chart, no boxes.

Now measured against `g_chart.Bars()` — the array the indices actually point into.

Verified on GBP/USD Daily, 600 structure bars:

| window | blocks drawn |
|---|---|
| 150 bars | 16 |
| 300 bars | 29 |

### The panel was lying too
It read `ZONES on PERIOD_M15 found=22` while drawing Daily blocks. It now says
what is actually on the chart:

```
BLOCKS on D1  found=16  shown up to 40  window 150 bars
```

### Verified
identifiers OK, undefined calls OK, array bounds OK, forward decls OK, call
arity OK, format OK, 46 tests, 3,426 lines.

## [0.14.1] — 2026-11-02 — *DrawBiasZone was deleted by my own edit*

### The compile error
```
SovereignPA_single (5).mq5   2711: undeclared identifier 'DrawBiasZone'
                             2711: ')' - expression expected
```
When I replaced `DrawClean()` in v0.14.0, the cut ran from `void DrawClean()`
to `void DrawZones()` — and `DrawBiasZone()` sat in between. I deleted it and
left the call behind.

**v0.14.0 never compiled.** Restored; the blue higher-timeframe marker is back.

### Why every gate passed while the file could not compile
`check_identifiers` verified that every *input* was declared. It never checked
whether a called function still existed. That is the fourth compile failure in a
row caused by editing a region and losing something inside it.

New gate: **`check_undefined_calls`**. It strips comments and string literals,
finds every name that is followed by a parameter list, works out which of those
are real definitions (body, prototype, constructor), and reports any call whose
function does not exist.

Validated the only way that counts — against the real fault:

```
bias_bug.mq5: 'DrawBiasZone' is called but never defined
```

and against the clean build: **zero findings.** Getting there took three passes
(comments were being read as code, class constructors were missed, and `Foo();`
was mistaken for a prototype), which is itself the lesson: a checker that cries
wolf is worse than none.

### Verified
identifiers OK, undefined calls OK, array bounds OK, forward decls OK, call
arity OK, format OK, 46 tests, 3,421 lines.

## [0.14.0] — 2026-11-02 — *Every block, not one per direction*

### The bug you found
The chart drew **one block per direction** — the newest. That was my rule, not
yours, and it hid the most significant zone in your last image: the block at the
top of the range that price tapped cleanly and then sold off.

### What the chart shows now
**Every last candle before the impulse in the window**, both directions:

| pair | TF | blocks in a 150-bar window |
|---|---|---|
| EUR/USD | M15 | 20 |
| EUR/USD | H1 | 9 |
| GBP/USD | M15 | 22 |
| GBP/USD | H1 | 7 |

Nothing is filtered. Valid blocks are **solid outlines**; blocks price has
already traded through are **dotted outlines** — same direction colour, because
the colour says buy or sell and must never say anything else. The block the
engine currently ranks highest (§3.3) is the only **filled** one.

### Why nothing is filtered any more
I had been dropping blocks that were consumed or whose imbalance was used up.
That left **3 of 192** EUR/USD M15 blocks. You can see twenty on that chart with
your eyes; the engine was showing three. Hiding them is what made the chart look
like it was missing the obvious zone.

### Unchanged
The engine's own decisions did not move. Geometry is still the block candle,
wick to wick. The validity flags from v0.13.1 are exactly as they were. This
release changes **what is drawn**, nothing else.

### Inputs
`InpZoneLookbackBars` (150) — how far back to show. Lower it if the chart gets
busy; raise it to see more history.

### Verified
identifiers OK, array bounds OK, forward decls OK, call arity OK, format OK,
46 tests, 3,360 lines.

## [0.13.1] — 2026-11-02 — *I broke the zones. Reverted.*

### What I did wrong
v0.13.0 did not just change *when a zone is valid*. It rewrote **the box
itself**, shrinking it to "the part of the block price has not reached". That
moved every zone on the chart. You were right: the last candle before the impulse
was wrong, the imbalance was wrong, and it looked scrambled.

**The shrink was my invention.** You said "shift it to the top candle" about
*which* block is the live one, not about cutting a block in half.

### Reverted
The box is the block candle again — **wick to wick, high to low, exactly as
v0.12.0**, which you approved. Verified on live data:

```
zones = 192
boxes not equal to their block candle: 0
```

### What is still different from v0.12.0 (validity only)
| | v0.12.0 | now |
|---|---|---|
| gap used up | any wick into it | price crosses the whole gap |
| block consumed | any overlap | price crosses the whole block |

The two flags changed. **The geometry did not.** Nothing else in the engine moved.

### The second bug: the word "Label"
Twenty rows of the panel were printing the word `Label` down the left side.
An empty string does not clear an MT5 `OBJ_LABEL` — the object falls back to its
default description. A single space clears it. Fixed.

### New regression test
`test_the_box_is_always_the_block_candle` fails if any future change makes the
box disagree with its block candle. That is the specific mistake this release
undoes, so it is now impossible to make silently.

### Verified
46 tests, identifiers OK, format OK, 3,369 lines.

## [0.13.0] — 2026-11-02 — *An imbalance is used up, not touched*

### The correction
You showed a supply block whose wick had retested most of the gap, leaving a
sliver. Our engine called that zone dead. You called it valid:

> "when an imbalance is there, it's there ... a tiny bit of an imbalance that the
> wick of the blue candle did not really get retested. So that zone is still
> valid, and then **we shift the last candle before the impulse to the top
> candle** ... if that was our zone, the trade would have entered very well and
> it cleanly gone into our favour without stopping us out."

### What changed
Two rules, both replaced:

| | was | now |
|---|---|---|
| the gap | a wick enters it → filled | price **crosses the whole gap** → used up |
| the block | any overlap → dead | the block is **eaten from the side price arrives on** |

The zone is now **the part of the block price has not reached**:

- **supply** → price comes up from below, so the bottom is eaten and what
  survives is the **top** — exactly your "shift it to the top candle"
- **demand** → price comes down from above, so the top is eaten and what
  survives is the **bottom**

A block that price has crossed completely is dropped entirely.

### What it does to the numbers

| pair | TF | zones alive at once | median width | §3.3 candidates |
|---|---|---|---|---|
| EUR/USD | M15 | 6.9 | 1.02 × ATR | 60.2% |
| EUR/USD | H1 | 3.7 | 1.15 × ATR | 66.7% |
| GBP/USD | M15 | 12.4 | 0.96 × ATR | 66.1% |
| GBP/USD | H1 | 8.5 | 1.13 × ATR | 63.9% |

Before this change, EUR/USD M15 had **2 untouched zones** in the whole history.
Now about 7 are alive at any moment, all under 1.2 ATR wide, and a ranked
candidate exists on roughly two bars in three.

### A contradiction you should rule on
Rule book **3.2** says: *"The moment a price wick touches or enters the boundary
of a zone, its status changes to Used/Invalid."* That is the rule I had built.
Your correction on 2026-11-02 says the opposite. **I have followed the
correction** — it is later, it is yours, and it produces better entries. But the
rule book still says the old thing, and if 3.2 was meant for a different case I
need to know which.

### Tests
45 signal tests. The old `test_a_wick_into_the_gap_fills_it` was **rewritten, not
deleted** — it now documents the reversal, with your sentence in the docstring.

### Verified
identifiers OK, array bounds OK, forward decls OK, call arity OK, format OK,
3,383 lines.

## [0.12.0] — 2026-11-02 — *Refinement: the engine now chooses a zone*

### Rule book §3.3, implemented literally
```
"If multiple valid zones exist within a single swing leg, the algorithm ranks
 them by proximity to the swing extreme. The bot selects the Extreme Zone (the
 furthest valid zone from the current market price that still possesses an
 Unfilled Imbalance)."
```
Three filters, then **furthest wins — not nearest**:

| filter | test | source |
|---|---|---|
| valid | price has not been back into the block | 3.2 |
| unfilled | no wick has entered the gap | 3.3 |
| in leg | the block was born after the swing extreme | 3.3 |
| winner | greatest distance from current price | 3.3 |

### It always says why
The selection returns a sentence, not just an index:

- `no fresh demand zone yet`
- `7 fresh demand zone(s), every imbalance already filled`
- `3 demand zone(s) with an open imbalance, none in this leg`
- `9 valid, 3 with an open imbalance, 2 in this leg - extreme demand chosen`

That sentence goes to the panel, the log (`[REFINE]`), and is available to the
engine. **No silent decisions.**

### How often it has something to choose
Measured as-of each bar (zones rebuilt from data available at that moment):

| pair | timeframe | bars with a ranked zone |
|---|---|---|
| EUR/USD | M15 | 30.5% |
| EUR/USD | H1 | 40.0% |
| GBP/USD | M15 | 39.0% |
| GBP/USD | H1 | 63.9% |

Selective, not dead. My first measurement said 0% for EUR/USD M15 — it was wrong
because it used each zone's *final* freshness instead of its freshness at that
bar. Worth recording: a backtest that builds zones once and looks backwards will
systematically under-count.

### Panel: compact by default
Six lines, then a `MORE` button:

```
SOVEREIGN PA  v0.12.0
EURUSD M15   BIAS DOWN   regime TREND
47 M15 zone(s) on this chart
9 valid, 3 with an open imbalance, 2 in this leg - extreme demand chosen
candidate M15 SUPPLY  at 2026.10.30 13:45
click MORE for the full readout
```

Click `MORE` for the old full dump, `LESS` to put it away. `InpPanelStartFull`
opens it expanded.

### Not sacrificed
Drawing is unchanged from v0.11.0. The refinement affects **the engine's
choice**, not the picture. Adding it costs no chart objects and no readability.

### Tests
44 signal tests (6 new for §3.3): furthest wins, filled imbalance skipped, tapped
block invalid, previous-leg block excluded, direction respected, empty list.

### Verified
identifiers OK, array bounds OK, forward decls OK, call arity OK, format OK,
3,347 lines.

## [0.11.0] — 2026-11-02 — *One timeframe at a time, plus where the bias came from*

### What you asked for
1. Remove the imbalance lines — they were the "small lines getting in the way".
2. Stop showing three timeframes at once. Show **the timeframe you are looking
   at**: go to M1, see M1 zones; go to H1, see H1 zones.
3. But never lose the higher timeframe you took the bias from.

### What the chart does now
- **Filled boxes = the chart's own timeframe.** The EA builds a structure on
  whatever timeframe the chart is on, so this works for M1, M30, H2 — not just
  the three configured ones.
- **One blue outline box = the bias timeframe.** That is the block the bias came
  from, labelled `H4`, in its own colour so it never reads as a trade zone. On an
  M15 chart it is the H4 block you would otherwise lose sight of.
- **No imbalance boxes at all.** Removed.

### Why the blue box is one box, not several
You said it: *"this is where the bias is, this is the last candle before the
impulse, it's here up for the 4-hour where we got our bias from."* So it marks
one thing — the single block behind the bias — and nothing else.

### Inputs
- `InpMTF` now defaults **false** (all timeframes at once is still available)
- `InpShowBiasZone` (true) — the blue marker
- `InpColBias` — its colour

### Cost to watch
The chart timeframe is rebuilt when **its** bar closes, not only when H4/M15/M5
close. On an M1 chart that is every minute. If the EA feels heavy on very low
timeframes, raise `InpStructBars` down or stay on M5+.

### Verified
83/83 tests, identifiers OK, array bounds OK, forward decls OK, call arity OK,
format OK.

## [0.10.3] — 2026-11-02 — *Quiet: one filled box, everything else a thin line*

You said the chart was getting complicated, the colours blocked the wicks, and
the labels were noise. All three were true.

### The constraint that forced the design
**MQL5 rectangles have no transparency.** There is no alpha, no opacity, nothing.
A "faint box" is therefore not a lighter fill — it is either a darker colour or
no fill at all. Every earlier attempt to make the boxes gentle failed because it
was chasing something the platform does not have.

So the rule is now structural:

| element | treatment |
|---|---|
| **the timeframe you chose** | filled box, dark colour, reaches the live bar |
| every other timeframe | **outline only**, 1px, stops 40 bars after its block |
| an imbalance | **dashed outline, no fill, no words** |
| label | the timeframe alone — `H1`, `M15`, `M5`, inside the box, vertically centred |

### Removed
- `imbalance  <- this block's gap` — gone. The dashes say it.
- `M15 ZONE` — now just `M15`.
- The gold target line — `InpShowTarget` defaults to **false**. That was the
  yellow line across the bottom.
- Filled imbalance blocks — these were the white slabs. Now dashed outlines.

### Colours
Defaults moved from bright to dark: `clrDarkGreen` / `clrDarkRed` / `clrDimGray`.
Label text stays readable in `clrMediumSeaGreen` / `clrIndianRed` because text
has no fill to darken.

### The flaw I found in my own render
`M5`, `M15` and `M5` labels piled on top of each other where two boxes sat at the
same price. Labels are now centred vertically **inside** the box instead of
sitting on its top edge.

### New input
`InpZoneBoxBars` (default 40) — how far an outline box runs to the right.

### Verified
83/83 tests, identifiers OK, array bounds OK, forward decls OK, call arity OK,
format OK.

## [0.10.0] — 2026-11-02 — *Multi-timeframe: the whole inventory, on one chart*

### What it does
The chart now shows the zones of **every structure timeframe at once**, each
labelled with its own timeframe:

- `H4 ZONE`, `M15 ZONE`, `M5 ZONE` — read the label, no guessing.
- The timeframe you chose (`InpZoneTF`) is **filled**.
- The other timeframes are **outline only**.

That last part matters: three filled boxes at once buries the candles, and the
candles staying readable is a standing rule. Hierarchy instead of a slab.

### What it does NOT do
The extra timeframes are **drawn only**. Signals still come from the one primary
set, so adding timeframes cannot change what would be traded. That separation is
deliberate — display and decision are different steps.

### New input
`InpMTF` (default true) — draw every structure timeframe. Turn it off and you get
the single-timeframe chart from v0.9.x.

### Compile faults fixed on the way
1. `TFShort` forward declaration with the wrong return type (your screenshot).
2. Two **stale copies** of `DrawAllImbalances` and `DrawClean` left behind by the
   refactor, still calling `DrawCleanOne` with 3 arguments after it became 5.

### Two new gates, both proven against those real faults
- `check_forward_decls` — same name declared twice with different return types:
  ```
  tfshort_bug.mq5:2450: 'TFShort' declared as void here, but earlier as string
  ```
- `check_call_arity` — call site with the wrong argument count:
  ```
  dupe_bug.mq5:2679: 'DrawCleanOne' called with 3 argument(s), defined with [5]
  ```
  Zero false positives on the clean build.

### Verified
83/83 tests, identifiers OK, array bounds OK, forward decls OK, call arity OK,
format OK, 3,165 lines.

## [0.9.3] — 2026-11-02 — *Compile fix, and I stop claiming a choice I haven't made*

### The compile error
```
'SovereignPA_single (22).mq5'  2451  function 'TFShort' already defined
                                     and has different return type
```
I added a forward declaration `void TFShort();` in front of a function that
returns `string TFShort()`. Deleted. **v0.9.2 never compiled** — anything you saw
from it was v0.9.1 still running.

New gate: `check_forward_decls` reports any name declared twice with different
return types. Proven on the real fault:

```
tfshort_bug.mq5:2450: 'TFShort' declared as void here, but earlier as string
```

### The claim I withdrew
The selected imbalance was labelled `<- this is the zone`. That asserts a
selection. There is no selection rule yet — the EA takes the newest block per
direction. It now reads `<- this block's gap`, which is a fact, not a decision.

**Nothing else about the step changed.** We are still on *finding zones*.

### Verified
83/83 tests, identifiers OK, array bounds OK, forward decls OK, format OK.

## [0.9.2] — 2026-11-02 — *Imbalances are the inventory; the zone is the choice*

Your green arrow made the model explicit: there is more than one imbalance on the
chart, and the zone is **one chosen from that list**. The EA was drawing only the
imbalance belonging to the block it had already picked, so the others were
invisible.

### What the chart shows now
- **Every unfilled imbalance** in the lookback window, faint, labelled
  `imbalance`. Measured on live data there are only **1–3 at a time**
  (EUR/USD M15: 1, EUR/USD H1: 2, XAU/USD M15: 3, XAU/USD H1: 1) — so listing all
  of them costs no readability.
- **The one the EA selected** carries the extra words `<- this is the zone`.
- **The zone itself** stays the coloured block box, labelled `M15 ZONE`.

Filled imbalances disappear. An imbalance is a candidate only while price has not
traded into it.

### Selection rule as it stands
Newest block per direction. That is a placeholder, not a decision — see the open
question in the message.

### New input
`InpImbalanceLookback` (default 200 bars); `InpColImbalance` sets their colour.

### Verified
83/83 tests, identifiers OK, array bounds OK, format OK.

## [0.9.1] — 2026-11-02 — *Off by one: I was marking the displacement candle itself*

### What you saw
A red box 13 pips tall — about 3.5 × ATR — with a green box and a grey imbalance
band stacked inside it, all stretched to the right edge. Unreadable.

### Root cause
In a 3-candle imbalance the candles are `k-2, k-1, k`. The **middle candle
`k-1` is the displacement** — the candle that "has the imbalance". The block is
the quiet candle *in front of it*, which is **`k-2`**.

I used `k-1`. So I was marking the displacement candle as the block, and a
displacement candle is by definition much larger than a normal one.

Measured on M15, block = `k-1` versus block = `k-2`:

| pair | block = k−1 (was) | block = k−2 (now) |
|---|---|---|
| EUR/USD median zone width | 1.97 × ATR | **1.19 × ATR** |
| EUR/USD blocks wider than 1.5 ATR | 74% | **45%** |
| XAU/USD median width | 1.71 × ATR | **0.93 × ATR** |
| XAU/USD blocks wider than 1.5 ATR | 63% | **17%** |

Gold is now under one ATR on average. That is the difference between a band you
can place an order in and a wall.

### Second fix — used zones stop where they died
The box reached the current bar for every zone, so a dead zone from two days ago
still painted a band across the whole chart. Now:

- **live zone** → reaches the current bar (the area being watched)
- **used zone** → stops 20 bars after its block
- **imbalance** → stops 25 bars after the gap

### Verified
83/83 tests updated for the corrected index, identifiers OK, array bounds OK,
format OK.

## [0.9.0] — 2026-11-02 — *Copied your sketch instead of my idea of it*

You went to TradingView and drew the answer. So the EA now draws what you drew:

- **One box per zone, from the block candle forward to the live bar.** I had
  narrowed it to a single candle, which is why it stopped reading as a zone. Its
  left edge is the last candle before the impulse; the box marks the price area
  being watched.
- **The imbalance is a separate box**, its own colour, its own faint fill, with
  a small `imbalance` label. I had hidden it completely; you want to see it, just
  not confused with the zone.
- **Labels say what things are**: `M15 ZONE` on the zone, `imbalance` on the gap.
  The timeframe is in the label, so an M5 chart showing M15 blocks is no longer
  a mystery.
- Entry, stop and target stay as thin dotted levels (`InpShowTarget` turns the
  target off).

### New inputs
`InpColImbalance` (default silver), `InpShowTarget` (true).

### Still not done
**Zones for several timeframes at once.** v0.9.0 labels the timeframe but still
draws one timeframe's blocks (whatever `InpZoneTF` says). Drawing the chart's own
timeframe *plus* the higher one is the next build and the last piece of your
three-part request.

### Verified
83/83 tests, identifiers OK, array bounds OK, format OK.

## [0.8.4] — 2026-11-02 — *The EA has been dead since v0.7.0*

### What you saw
"SPA initialising..." in the corner, forever. Nothing updating. Charts that
never changed after attaching.

### Root cause — array out of range
```cpp
#define SPA_PANEL_ROWS 23     // the panel array
...
rows[23] = ...                // written since v0.7.0
rows[24] = ...                // written since v0.7.0
```
Writing past the end of a fixed-size array is a **runtime crash**. It happened
inside `OnInit`, *after* the zones were drawn and *before* the heartbeat, so:

- the boxes appeared (drawn first),
- the comment stayed on "SPA initialising...",
- `OnTick` never ran at all.

**Every chart since v0.7.0 was a dead snapshot.** No live updating, no panel, no
log. That is why nothing on screen ever made sense: it was never running.

Fixed: `SPA_PANEL_ROWS` → 26, with three rows of headroom.

### New gate
`check_identifiers.py` now statically checks array bounds: any `ArrayResize(x,
MACRO)` followed by `x[N]` where `N >= MACRO` is reported. Proven against the
real fault — re-running it on the broken build reports:

```
panel_bug.mq5:2758: 'rows[23]' is out of range - SPA_PANEL_ROWS is 23
panel_bug.mq5:2760: 'cols[23]' is out of range - SPA_PANEL_ROWS is 23
panel_bug.mq5:2761: 'rows[24]' is out of range - SPA_PANEL_ROWS is 23
```

### Timeframe tag
Each block now carries its timeframe in small text at the box: `M15`. You asked
for this three times; it is done.

### Verified
83/83 tests, identifiers OK, array bounds OK, format OK.

## [0.8.3] — 2026-11-02 — *The engine was right; the drawing lied about it*

Your annotated chart settled it. The two green lines the EA drew **do start at
the last candle before the impulse** — the same candle you marked. Detection was
correct. The drawing made it unreadable, for two specific reasons:

### 1. The box was grey
`DrawClean()` passed `InpColUsed` (grey) whenever a block was not fresh. A grey
box says nothing about direction — you cannot tell a buy from a sell. The box is
now **always** the direction colour: green for demand, red for supply.

### 2. The box was five bars wide
It stretched from the block across the impulse candle, so it looked like it was
marking **the impulse** rather than the quiet candle in front of it. It now
covers **exactly one candle** — the block itself.

### 3. One word, so there is no doubt
`BUY` or `SELL` in small text at the end of the entry line. No numbers, no
times, no other text.

### Chained blocks — your second point
> "After that gray candle, there is another blue candle, which is tall... this
> blue candle also left an imbalance, so we could mark the candle before it."

The engine already does this. One block is produced per imbalance, so a move
that leaves several gaps produces several blocks in sequence. Nothing to change.

### How to verify in one glance
The log now prints the exact candle time of each block:
```
[ZONE] clean: found=315  BUY block=2026.11.01 23:15  SELL block=2026.11.01 20:00
```
Compare that line against the candle you would mark. If they differ, it is an
off-by-one and I will know exactly where.

### Verified
83/83 tests, identifiers OK, format OK.

## [0.8.2] — 2026-11-02 — *Blank chart: "fresh only" hid everything*

### What you saw
Chart cleared, but no boxes and no levels — only arrows.

### Root cause
`DrawClean()` skipped every block that was not fresh:

```cpp
if(!z.fresh)
   continue;
```

On EUR/USD M15 only about **2 blocks in 315 are untouched at any moment**. So
almost every refresh both picks came back empty and nothing was drawn. The
chart was blank not because detection failed but because the display required a
condition that is rare by nature.

This is the third time a display filter has blanked the chart, and all three
were the same error in different clothes: using a *quality* condition to decide
whether to show something at all.

### Fixed
- Prefer a fresh block; **fall back to the newest block per direction**. The
  colour says which you are looking at (bright = fresh, grey = already used).
- A log line now reports the decision every refresh:
  `[ZONE] clean: found=315 freshD=1 freshS=0 -> drew demand=311 supply=309`
  If the chart is ever empty again, that line says why in one glance.

### Also worth knowing
MT5 **remembers input values per chart**. New inputs take their defaults, but
existing ones keep whatever you last set — which is why swing arrows are still
on your chart even though v0.8.1 changed the default. Set `InpDrawStructure =
false` in the Inputs tab if you want them gone.

### Verified
83/83 tests, identifiers OK, format OK.

## [0.8.1] — 2026-11-02 — *Clean mode: the trade only*

### What went wrong
I left the audit layer switched on by default. Every refused imbalance printed
two dashed lines **and a sentence**, and the audit view drew dozens of zones.
On your chart that produced a screen full of white dashes and text. That is not
the engine being useful; it is the engine showing its working when you asked for
its answer.

### CLEAN mode (`InpClean = true`, now the default)
The chart shows exactly four things per trade, and nothing else:

1. a **faint box** on the order block — green for demand, red for supply
2. a **dotted level at the near edge** — where you enter
3. a **dotted level at the far edge** — your stop
4. a **dotted gold level** — the target, taken from the opposing block

Newest fresh block per direction. **No labels. No numbers. No imbalances. No
refusals. No swing arrows.**

### Now off by default
`InpZoneAudit` → false, `InpAuditRejected` → false, `InpDrawStructure` (swing
arrows) → false. All still available if you ever want to verify the engine
again, but the chart is quiet unless asked otherwise.

### Verified
83/83 tests, identifiers OK, format OK, 2979 lines.

## [0.8.0] — 2026-11-02 — *The block is the candle immediately before the imbalanced candle*

### Your correction
> "When there is a candle that has an imbalance, the candle before that candle is what I would call the last candle before an impulse."

That is not what I built. I was taking the last candle against the move at a
swing, or the extreme of a ZigZag leg. Both are derived from *structure*. Yours
is derived from the *imbalance*, which is why it finds blocks where mine found
nothing.

### The engine now starts from the gap
1. Find every 3-candle imbalance, **wick to wick**.
2. The order block is **the candle immediately before the imbalanced candle**.
3. The zone is that candle's wick-to-wick range.

The swing/ZigZag dependency is gone entirely. A block now exists wherever price
left a gap — which is exactly where you point at the chart.

Two side effects worth noting:
- The 45% "wild bar" problem disappeared by construction. The block is the quiet
  candle *before* the impulse, not the impulse candle, so it is rarely a
  news spike. No filter invented; the definition fixed it.
- Your fill rule is now the rule: **a wick touching the gap fills it**, not a
  body closing through it.

### Drawing — clean, and much less of it
- **Faint box + two levels.** The box is drawn in the background (`OBJPROP_BACK`)
  so candles stay fully visible, and carries the exact top and bottom as levels.
- **The imbalance is a faint gold box with no label**, and only while untouched.
  Once filled it comes off the chart.
- **Labels cut to `M15 DEMAND` / `M15 SUPPLY`**, plus `tapped` when used. The
  leg/gap/age text is gone.
- Only the newest `InpDrawZonesMax` (8) zones are drawn. On EUR/USD M15 the
  engine finds **315 blocks a month** — showing them all is the clutter problem,
  not a detection problem.

### Measured
| pair / TF | blocks | untouched | median width |
|---|---|---|---|
| EUR/USD M15 | 315 | 2 | 2.05 × ATR |
| GBP/USD M15 | 351 | 16 | 2.20 × ATR |
| XAU/USD M15 | 89 | 2 | 1.65 × ATR |

An untouched gap is genuinely rare: price usually returns. The fresh blocks are
the signal, and there are few of them — which is correct, not a bug.

### Inputs removed / added
Removed `InpMinLegATR`, `InpObScan` (no longer meaningful without swings).
Added `InpZoneFill` (draw the faint box as well as the levels). `InpDrawZonesMax`
default 4 → 8.

### Verified
83/83 tests (38 signal), identifiers OK, format OK, 2882 lines.

## [0.7.2] — 2026-11-02 — *No more boxes; and the LuxAlgo study*

### Drawing: zones are now two horizontal levels
MQL5 has **no alpha on `OBJ_RECTANGLE`** — there is no `OBJPROP_ALPHA`. Their
boxes look light because Pine's `color.new(c, 70)` is 70% transparent. In MT5 a
filled box is opaque by definition: it hides the candles or is hidden by them,
never washes over them. That is why ours were heavy and theirs were not.

So the correct translation of a transparent box into MT5 is **not a box**: each
zone is now two horizontal levels (top and bottom of the block), no fill, no
border, and therefore no vertical edge to read as a line. The imbalance is two
dotted levels inside the impulse. Rejected blocks are two short dashed levels.
`OBJ_RECTANGLE` no longer appears anywhere in the file.

### The LuxAlgo study — `workspace_docs/luxalgo_reference.md`
Both scripts are **CC BY-NC-SA 4.0**: studied for method, re-implemented in
MQL5, never transcribed. Notes cover FVG detection, thresholding, both
mitigation conventions, their order-block selection, the `parsed` volatility
trick, leg/BOS/CHoCH structure, strong/weak highs, EQH/EQL and premium/discount.

### What the study proved wrong in our engine
1. **Their close-confirmation rule is not the missing precision.** Verified:
   98–100% of our gaps already satisfy it. I expected it to be the answer; it is
   not, and that is now recorded so no further round is spent on it.
2. **The real problem is zone width.** Measured on EUR/USD M15: median zone
   width **1.97 × ATR**, p90 **3.93**, widest 11.67; **91% of zones are wider
   than 1 ATR**; **45% of the blocks we select are "wild bars"** (range ≥ 2 × ATR).
3. **They filter wild bars; we do not.** LuxAlgo's `parsed` high/low swap makes
   any bar with range ≥ 2 × volatility impossible to select as a block. We have
   no equivalent, and nearly half our blocks are exactly those bars.

### Not changed yet — deliberately
Zone geometry (wick vs body, width cap, wild-bar exclusion) is left alone until
you answer three questions recorded at the end of the reference file. All three
change what gets drawn, and the numbers are now there to make the choice once.

### Verified
80/80 tests, identifiers OK, format OK, dependency order OK, 2901 lines,
`OBJ_RECTANGLE` count 0.

## [0.7.1] — 2026-11-02 — *Two compile errors: a private method and a field that never existed*

### What you saw
```
'CSpaZones::FindImpulse' - cannot access private member function   x3
undeclared identifier 'leg_end'
4 errors, 0 warnings
```

### Root causes
1. **Private method.** `FindImpulse()` was inserted immediately *before* the `public:` label in `CSpaZones`, which put it at the end of the private section. It is now declared public, where the EA calls it from.
2. **A field I imagined.** `DrawZones()` used `z.leg_end`, but `SpaZone` stores the end of the impulse in `break_idx` — I added `leg_atr` and `pivot_idx` to the struct and then wrote a field name that was never added. Now `z.break_idx`.

### The gate was extended, not just the code
Neither error was visible to `check_identifiers.py`, because **a member access and an access modifier are not identifiers**. So the checker now also parses every `struct` body and validates `variable.field` against it. On a copy of the broken build it reports:

```
member_bug.mq5:2364: 'z.leg_end' - SpaZone has no field 'leg_end'
                    (has: age, bottom, break_idx, demand, entry, fresh, gap_atr,
                     gap_filled, gap_high, gap_idx, gap_low, leg_atr, ob_idx,
                     pivot_idx, stop_ref, t_gap, t_ob, top)
```

It only checks names with a **single unambiguous struct binding** — `p` and `out` are reused for different structs in different scopes, and the first version of the check produced 42 false positives by ignoring that.

### What the gates still cannot see
**Access modifiers.** Whether a method sits in a `public:` or `private:` section is a semantic question about the class layout, not a symbol lookup. I have not built a parser for that, and I do not want to pretend the gates now replace your compiler. They replace the *specific* mistakes that have actually cost you builds.

### Verified
80/80 tests, identifiers OK (now including struct members), format OK, dependency order OK, 2947 lines.

## [0.7.0] — 2026-11-02 — *Impulse-first order blocks: the thing you told me to nail first*

### Your instruction
> "First of all, we should first nail that thing of identifying the last candles before the impulses, because those are where we enter from. Then later, we shall add on the swing high, the swing low, the bias."

That reordered the whole engine, and you were right to reorder it.

### What was structurally wrong
The old engine started from a **structural break** and searched backwards for a candle. So an order block could only exist where a BOS happened — and most impulses never break structure. The entry object was a by-product of a filter instead of the primary object. That is why zones were missing all over your charts.

The engine now works forwards, the way you read a chart:

1. **Find the impulse** — a leg between two confirmed swings travelling at least `InpMinLegATR` (1.5) × ATR.
2. **The order block is the last candle against the move** at the swing that started it (`InpObScan`, 6 bars).
3. **The imbalance is searched across the whole leg**, not within a few bars of the block.

### The second bug: the gap was in the wrong place
I had required the gap within 3 bars of the order block. Measured on EUR/USD M15:

| gap search | impulses with a valid gap |
|---|---|
| within 3 bars of the block (**old**) | **8 of 162** |
| anywhere inside the leg (**new**) | **109 of 162** |

The gap forms *inside* the impulse, exactly where you drew your two green lines — several candles into the move, not beside the block. That single window was rejecting the gaps you could see with your eyes ("the gap is too big").

Which means your rule book's **0.5 × ATR** threshold now works, and it is restored as the default (`InpFvgMinATR = 0.5`, was 0.15 as a workaround). The threshold was never the problem; the window was. Zones found:

| pair / TF | impulse blocks | with valid gap |
|---|---|---|
| EUR/USD M15 | 162 | 109 |
| GBP/USD M15 | 174 | 120 |
| EUR/USD H1 | 47 | 32 |
| XAU/USD M15 | 51 | 34 |

### Drawing — no vertical lines
- **Filled boxes only.** A hollow rectangle is literally two vertical lines with a gap between them; that is what you were seeing. Every zone is now a filled block.
- **The box is the block and the impulse it created** (capped at 22 bars), not a band stretched to the current bar. Stretching to "now" buried the chart under ten overlapping bands — probably the biggest source of the confusion.
- Colours are now **inputs**, so you can recolour without a rebuild: `InpColFresh`, `InpColUsed`, `InpColSupply`, `InpColGap`.
- Label: `PERIOD_M15 DEMAND OB 2026.10.28 18:15  leg 6.3x gap 0.71x  age 12  FRESH - armed`.

### New inputs
`InpMinLegATR` (1.5), `InpObScan` (6), `InpFvgMinATR` (0.5, rule book), plus the four colour inputs. `InpFvgWindow` is gone — the gap is no longer windowed.

### Also
`tools/check_identifiers.py` caught three problems before this build left the workspace: two real (a stale `InpFvgWindow` reference) and one limitation in the checker itself (comma-separated declarations). The gate is doing its job.

### Verified
80/80 tests (35 signal), identifiers OK, format OK, dependency order OK, 2942 lines.

## [0.6.6] — 2026-11-02 — *Ten compile errors, and the silence that caused them*

### What you saw
```
undeclared identifier 'InpZoneAudit'      x3
undeclared identifier 'InpAuditMax'       x2
undeclared identifier 'InpAuditRejected'  x2
10 errors, 0 warnings
```

### Root cause
I inserted three input declarations with a text replace that searched for

```
InpDrawZonesMax    = 4;
```

while the file contained

```
InpDrawZonesMax      = 4;
```

Two extra spaces. The replace matched nothing, changed nothing, and **reported success**. The three inputs were never written, but the code that used them was. v0.6.5 never had a chance of compiling.

Every gate I ran passed, and that is the part worth fixing. Brace balance: fine. Format strings: fine. Dependency order: fine. 77 tests: fine. **None of them can see a missing declaration**, because a missing declaration changes none of those things.

### Fixed
- The three inputs are declared: `InpZoneAudit`, `InpAuditMax`, `InpAuditRejected`.

### New gate — `tools/check_identifiers.py`
Walks the released file and proves that **every `Inp*`, `g_*`, `SPA_*`, `Spa*`, `CSpa*`, `ENUM_SPA_*` identifier that is referenced has a declaration**. It strips comments, string literals and `#include` paths first, and understands `#define`, `input`, `sinput`, struct/class/enum bodies and typed globals.

Verified against the real failure, not a hypothetical one — re-running it on v0.6.5 reports:

```
broken.mq5:2108: 'InpZoneAudit' is used but never declared
broken.mq5:2173: 'InpAuditMax' is used but never declared
broken.mq5:2291: 'InpAuditRejected' is used but never declared
```

The same errors, at the same line numbers your MetaEditor showed.

### New gate — `tools/verify.py`
One command, and it is now the only way anything reaches you:

```
== build ==   build single file ..................... dependency order OK
== gates ==   identifiers declared .................. OK
              format strings ........................ 0 mismatches
              test_symbol_math / structure / signal . 77 tests
              brace + paren balance ................. 0 / 0
              version ............................... SPA_VERSION=0.6.6
ALL GATES PASSED
```

It exits non-zero and prints **DO NOT SHIP** if any gate fails.

### Also fixed
The scanner had its own bug on the first attempt: `\s+` in the declaration regex crossed newlines, so an `input group` line swallowed the `input` keyword of the line below it and every declaration after it went unseen. `[ \t]+` throughout.

### Verified
v0.6.6 passes all gates; `check_identifiers.py` fails correctly when a declaration is removed and passes when restored.

## [0.6.5] — 2026-11-02 — *Audit mode: show the whole reading of the chart, including the refusals*

### What you asked for
> "I want the expert advisor to mark the zones... even in the past. So that even though they are not available, maybe we could change the colors... so that I can verify, does it really understand what zones are there?"

Right — `found=0` on your chart is unreadable. Either the market has no zones or the engine is blind, and nothing on screen distinguishes the two.

### A design error the counters exposed
Adding "why was this rejected" counters immediately showed **44 of 102 candidates rejected as "gap filled"**. That was wrong in a way that mattered: for a demand zone the gap sits directly above the box, so **price coming back to retest the zone is exactly what fills the gap**. Requiring an unfilled gap *as a test of validity* deleted every zone the moment it was tapped — the precise history you asked to see.

Validity is now judged **at birth**: was there a real, adequately-sized gap when the impulse broke structure? Whether price closed it afterwards is the zone's *freshness*, shown as state, not a reason to erase it.

| Pair / TF | candidates | no gap | gap too small | gap closed by impulse | zones |
|---|---|---|---|---|---|
| EUR/USD M15 | 81 | 0 | 55 | 1 | **25** |
| GBP/USD M15 | 65 | 0 | 30 | 0 | **35** |
| EUR/USD H1 | 12 | 0 | 6 | 0 | **6** |
| XAU/USD M15 | 21 | 0 | 14 | 0 | **7** |

### New — three visual states and the rejection log
- **FRESH — solid, filled, 3px**, bright green/red: untouched since the impulse.
- **TAPPED / USED — dotted, hollow, 1px, dim**: price has been back. The label says which.
- **REJECTED ORDER BLOCKS** (`InpAuditRejected`): every candidate the engine refused, drawn as a short grey marker at the candle, labelled with the reason — `gap too small`, `gap closed by the impulse`, `no 3-candle gap`.
- The validating imbalance is drawn for every zone: `IMBALANCE 0.31x ATR (open)` / `(closed)`.

### New panel lines
```
ZONES on PERIOD_M15  found=22  fresh=2  AUDIT: showing up to 60 in history
ORDER BLOCKS  candidates=81  -> no gap=0  gap too small=55  gap closed=1  accepted=25
gap must be >= 0.15x ATR of PERIOD_M15 and sit within 3 bars of the OB - rejected OBs drawn silver/dotted
```

### Inputs added
`InpZoneAudit` (default **true** — verification mode), `InpAuditMax` (60), `InpAuditRejected` (true), `InpFvgMinATR` (0.15), `InpFvgWindow` (3).

Audit changes **what is drawn, never what would be traded.** `InpZoneAudit=false` restores the strict latest-only view.

### Verified
77/77 tests (21 + 24 + **32**), 0 format mismatches, dependency order OK.

## [0.6.4] — 2026-11-02 — *A gap is now an actual gap (D-06 was never implemented)*

### What you caught
You looked at the marked demand zone and said: *"I also do not see an imbalance after that candle… the market here is all efficient."* You were right. And you described the one you would mark instead: the top candle with no lower wick, the impulse below it, and **a gap that has not been filled**.

### Root cause — a spec I had already written and then ignored
`has_imbalance()` accepted a gap that was:
1. **any size** — including a 0.1-pip sliver, so perfectly efficient price action qualified;
2. **anywhere within 20 bars** of the order block, so the gap did not have to belong to the impulse at all;
3. **already filled** — once price traded back through it, it still counted.

Your own rule book had the answer the whole time. **D-06:** `Low[3] − High[1] ≥ 0.5 × ATR14`. The threshold was in SPEC-001 and never reached the code. That is exactly the silent divergence the Supervisor audit exists to prevent, and it slipped through because the unit test only asked *whether* a gap existed, never *how big*, *where*, or *whether it survived*.

### Fixed — `FindImbalance()` replaces `HasImbalance()`
| Rule | Implementation |
|---|---|
| **Size** | `gap ≥ InpFvgMinATR × ATR` of the zone timeframe |
| **Place** | the gap must sit within `InpFvgWindow` (3) bars of the order block — it belongs to the displacement, not to an unrelated bar later |
| **Fill** | price must not have traded back **through** the gap. A filled gap is history |

The EA now **draws the imbalance** as a dotted gold band with its size: `IMBALANCE 0.31x ATR`. If the gap isn't on the chart, the zone has no business being there either.

### The uncomfortable measurement — and a decision I need from you
Zones surviving on real data, by minimum gap size:

| Pair / TF | 0.0×ATR | 0.15×ATR | 0.25×ATR | **0.5×ATR (rule book)** |
|---|---|---|---|---|
| EUR/USD M15 | 1 | 1 | 1 | **0** |
| GBP/USD M15 | 4 | 4 | 4 | **2** |
| XAU/USD M15 | 1 | 1 | 1 | 1 |
| EUR/USD H1 | 2 | 2 | 1 | **0** |
| GBP/USD H1 | 3 | 1 | 1 | **0** |
| XAU/USD H1 | 0 | 0 | 0 | 0 |

**At the rule book's 0.5×ATR the system finds essentially nothing on FX.** The gap in the live example above measures **0.31×ATR** — a clearly visible imbalance that 0.5 would reject. I have shipped the default at **0.15** and left it as one input (`InpFvgMinATR`) precisely because this is your call, not mine: 0.5 is what your documents say, 0.15 is what your chart shows. Say the word and I will set it to either.

### Verified
- **76/76 tests** (21 symbol/risk + 24 structure + **31 signal**), including 3 new imbalance tests for size, placement and fill, and the MQL5/Python parity harness.
- 0 format mismatches; dependency order OK; 2616 lines.

## [0.6.3] — 2026-11-02 — *Empty chart: a tapped zone is information, not silence*

### What you saw
`ZONES on PERIOD_M15  found=2  fresh=0  drawn<=4` — and an empty chart.

### Root cause
`DrawZones()` skipped any zone that was not fresh:

```cpp
if(!z.fresh)
   continue;        // <- the bug
```

So the EA found the two newest zones, correctly decided neither was tradeable, and then drew **nothing at all**. The display filter was accidentally the same as the trade filter. That is the worst possible combination: the chart goes blank exactly when the market is doing something worth watching, and gives no clue why.

It also inverted the story. A zone is "tapped" the moment price returns to it — which is the entry you were waiting for. So the zone disappeared at the instant it became interesting.

### Fixed
- **Every zone is drawn now**, not just the armed one. State is carried by the box itself:
  - **ARMED** — solid, filled, 2px, sits behind the candles.
  - **already tapped** — dashed outline, unfilled, 1px, drawn over the candles so it is still legible.
  - Label on every box: `PERIOD_M15 SUPPLY  OB 30 Oct 14:15  age 42 bars  ARMED`.
- **Reason codes are translated for the screen.** The panel used to print `WAITING: REJ_NO_FRESH_ZONE`; it now prints `NO TRADE: newest zones already tapped - wait for the next impulse  [REJ_NO_FRESH_ZONE]` — plain meaning first, code second (the code still goes to the log).
- Panel footer now reads the real version instead of a hard-coded `v0.6.0`.

### Deliberate constraint
Only colour constants **already proven to compile on your build** are used (`clrMediumSeaGreen`, `clrIndianRed`). The armed/tapped distinction is carried by fill, width, dash style and label text — not by a new colour name. After the `iSpread` incident, no unproven identifier goes into this file.

### Verified
73/73 tests green; 0 format mismatches; dependency order OK; 2522 lines; braces/parens balanced. Full list of colour constants in the build audited: `clrDeepSkyBlue, clrGold, clrIndianRed, clrLime, clrMediumSeaGreen, clrOrangeRed, clrSilver, clrWhite` — all previously compiled.

### Still open
Zones are zones. Sweep + MSS confirmation before entry is v0.7.0.


## [0.6.2] — 2026-11-02 — *The right zone: newest impulse, higher timeframe*

### What you saw, and why it was wrong
Screenshot review of v0.6.1 on EUR/USD: `ZONES found=10 fresh=1`, and the one zone drawn was **old and far from price**. Your words: "there have been more zones that have come and gone after that… we don't just wait for it to come down that far."

Two separate faults, both mine:

1. **Wrong zone kept.** The engine collected a zone from *every* structural break it could find and then drew whichever happened to be untouched. Every zone the market had already used was discarded, so the survivor was whatever ancient level had never been revisited — which is precisely the level the market has walked past. **Untouched is not the same as relevant.**
2. **Zones built on the exec timeframe.** "It's too fine… too precise." M5 order blocks are micro-structure. The zone you described is the last candle before the impulse on a *higher* timeframe.

### Changed — D-E
- **Only the newest impulse per direction is live.** After a break, the zone from that impulse replaces the previous one in the same direction. This is your own description: *"another pullback, it retests the last candle before the impulse… then it goes down to our zone."* On EUR/USD M15 that turns 34 historical zones into **2** — the newest demand and the newest supply.
- **`InpZoneTF`** (EXEC / **CONFIRM** / BIAS, default CONFIRM). Zones now come from the timeframe above the entry, not from the entry timeframe itself. On your EUR/USD profile that is M15; set it to BIAS for H4 zones.
- **Spent zones are shown, dimmed and dashed**, labelled `already tapped` — so you can see what was skipped rather than wondering why the chart is empty.
- **Every zone is labelled on the chart**: timeframe, DEMAND/SUPPLY, the order-block timestamp, and its age in bars. The box no longer runs into empty future space; it ends at the current candle.

### Verified
- 73/73 tests green (21 symbol/risk + 24 structure + **28 signal**), including 2 new recency tests and the MQL5/Python parity harness over 33 series.
- Real data, EUR/USD: EXEC 34 zones / 2 live, CONFIRM 34 / 2, BIAS 5 / 1.
- 0 format mismatches; dependency order OK; single file 2495 lines.

### Still open (v0.7.0)
Sweep + MSS confirmation. Until that exists, a zone is a zone — not yet a trade.


## [0.6.1] — 2026-11-02 — *Compile blocker: module order (58 errors, one cause)*

### Symptom
`58 errors, 6 warnings` in MetaEditor. Every message pointed at one of six lines and none of them was the actual fault:

```
742 35  declaration without type
742 49  comma expected
765 27  declaration without type / redefinition of parameter 'CSpaStructure'
959 54  redefinition of parameter 'CSpaStructure'
750 24  undeclared identifier 'st'
1892 17 int CSpaZones::Find(int)
```

### Root cause
**One wrong `#include` line.** `SPA_Zones.mqh` was included *before* `SPA_Structure.mqh`:

```cpp
#include "Include/SPA_Symbol.mqh"
#include "Include/SPA_Zones.mqh"     // <-- uses CSpaStructure&
#include "Include/SPA_Structure.mqh" // <-- declares CSpaStructure
```

MQL5 resolves includes **textually**, so at the point the compiler read `CSpaZones`, the types `CSpaStructure` and `SpaPivot` did not exist yet. An unknown type token makes the compiler read `CSpaStructure &st` as an unnamed parameter, which is why it then reported `int CSpaZones::Find(int)` and a cascade of "undeclared identifier 'st'" — the parameter had been discarded. **None of the 58 messages named the real problem.**

The tell was `int CSpaZones::Find(int)`: the compiler's own rendering of the signature shows the parameter count is wrong, not the body.

### Fix
Include order corrected to `Config → Symbol → Structure → Zones`, with a comment stating that this is a **dependency order, not a style choice**.

### Prevention
`tools/build_single_file.py` now runs a **dependency-order check** on the finished file: for every `class`/`struct` it declares, it verifies no line references that type before its declaration. On failure the build **exits 2** and names the offender:

```
DEPENDENCY ORDER BROKEN - the compiler will reject this file:
  CSpaStructure used at line 746 but declared at line 1123
  SpaPivot     used at line 783 but declared at line 1113
  Fix the #include order in the root .mq5.
```

Verified by deliberately reintroducing the bad order and confirming the build refuses, then restoring it. The check immediately found a **second** victim of the same line (`SpaPivot`) that the compiler had also been reporting at line 784.

### Verified
- 71/71 tests green; 0 format-specifier mismatches; flattened declaration order now `SpaPivot → CSpaStructure → SpaZone → SpaPlan → CSpaZones`; 2421 lines; braces/parens balanced.
- Panel row indices 0–22 complete, no gaps or duplicates.

### Lesson
A wall of compiler errors that all point at *different* lines can still have exactly one cause. When several unrelated functions report "declaration without type", stop reading the messages and check what is declared when — the error is upstream of everything being reported.


## [0.6.0] — 2026-11-02 — *Zone engine: the EA now finds the trade it would take*

### Scope
**Still places no orders.** v0.6.0 computes the complete trade — zone, entry, stop, target, lots, R:R — and **draws it on the chart**. Nothing is sent to the broker. This is deliberate: the entry logic gets tested by your eyes before it gets your money.

### Decisions recorded (your answers, 2026-11-02)
| # | Decision | Consequence in code |
|---|---|---|
| **D-A** | "the last candle before the impulse, but this candle has to have a clear imbalance that comes after it" | The order block is **mandatory** and the imbalance is a **filter**. Neither alone is a zone. |
| **D-B** | "we usually put the order at the first touch" | Entry at the **near edge** of the zone. Deep-fill is a parameter to test later, not a default. |
| **D-C** | "skip this for now but it's very helpful" | The momentum gate is **not** coded yet. Flagged for v0.6.2. |
| **D-D** | "hybrid… overall TP bias structural, but trailing on reasonable areas" | Target is structural; 50% off at 2R + stop to breakeven; the remainder trails behind structure (v0.7.0). |

### Added
- **`SPA_Zones.mqh`** — order-block detection, imbalance filter, freshness, zone age, first-obstacle selection, and trade planning with explicit reason codes (`REJ_NO_TREND`, `REJ_NO_ZONE`, `REJ_NO_FRESH_ZONE`, `REJ_NO_TARGET`, `REJ_RR`, `REJ_SL_TOO_TIGHT`, `REJ_NO_LOT`).
- **`CSpaStructure` bar accessors** — `BarOpen/High/Low/Close/Time`. The zone module reads the structure engine's already-copied arrays instead of running its own `Copy*` calls.
- **Chart drawing** — fresh zones as filled rectangles (green = demand, red = supply) with the exact order printed beside the entry zone.
- **Panel rows** — zones found/fresh, the live signal line, and `v0.6.0 DRAWS THE TRADE ONLY - NO ORDERS ARE SENT`.

### Three defects caught by the pre-flight on real data (not by the unit tests)
1. **The target was fiction.** "First obstacle" was taken from the bias timeframe alone, so XAU/USD's target was the nearest H4/H1 swing — 5% away — producing a **21R** trade. A 21R target is not a good trade, it is a mis-specified one. **Fix:** the obstacle is now the nearer of the **confirm** and **bias** timeframes, because a target is only honest if it is the first thing in the way.
2. **The stop could be inside the noise.** Order blocks are often narrower than one average bar, giving a 2–3 pip stop that any normal bar removes. **Fix:** `InpMinRiskATR = 0.5` — a zone whose total stop distance is under 0.5 × ATR is **skipped, never widened**. Widening the stop would violate the invalidation rule.
3. **A zone could be "fresh" and two days old.** Freshness only means price has not returned to it. One AUD/USD trade was being planned from a zone **522 bars old**, i.e. untouched for two days of M5. **Fix:** `InpZoneMaxAge = 200` bars — an untouched zone eventually expires; the order flow that created it has gone.

### Verified
- **71/71 tests green** (21 symbol/risk + 24 structure + 26 signal), including 2 MQL5/Python parity tests over 33 series and 5 tests on the defect fixes above.
- Full chain exercised on **12 real pairs** (EUR/USD, GBP/USD, USD/JPY, GBP/JPY, XAU/USD, AUD/USD, EUR/JPY, USD/CAD, NZD/USD, EUR/GBP, USD/CHF, GBP/AUD). Exactly **one** qualified on that snapshot: USD/CHF BUY at 3.99R. Everything else was rejected with a named reason.
- 0 format-specifier mismatches; single-file rebuild **2417 lines**, braces/parens balanced.

### Not done
- Sweep + MSS confirmation gating (v0.6.1). Until then the entry is the zone itself, so the stop sits at the **order-block far edge**, not at the sweep low.
- Momentum-into-zone filter (D-C, deferred by request).
- Order placement (v0.7.0).


## [0.5.1] — 2026-11-02 — *Higher-timeframe rendering fixes (arrows accepted on M5)*

### Acceptance
User reviewed v0.5.0 across W1, D1, H4, H1, M15 and M5 charts. **The M5 chart was accepted**: "clear highs and lows", and on arrow quality in general: "we're up there regarding arrows". Remaining complaint was "a bit of scrambling in the higher timeframes" — traced to two separate defects below, neither of which is in the swing detector.

### Fixed — arrows piled up on charts coarser than the structure timeframes
- **Root cause:** the EA computes bias/confirm/exec structure from *fixed* profile timeframes (H4/M15/M5) regardless of which chart it is attached to. It then drew all three onto that chart. On a Weekly chart, twelve M5 pivots — a few hours of price action — collapse into a single candle, producing the cluster of gold/blue/silver arrows seen in review.
- **Fix:** `ShouldDrawTF()` — a timeframe's swings are drawn only when it is **at or above the chart's own timeframe**. M5 chart: all three (unchanged, the normal case). H4 chart: gold only. D1/W1: none, and the panel says so explicitly instead of leaving a confusing pile.

### Fixed — the panel printed "Label" three times and collided with the heartbeat
- **Root cause 1:** MT5 renders an `OBJ_LABEL` whose `OBJPROP_TEXT` is an empty string using the object's default caption, which is literally `Label`. The three spacer rows (`rows[8]`, `rows[13]`, `rows[15]`) were `""`. Now they are a single space.
- **Root cause 2:** the heartbeat `Comment()` and panel row 0 were both rendering around y≈22, so "SOVEREIGN PA v0.5.0" and "…| swings B:10 C:16 E:63 |" printed over each other on the same line. The panel now starts at `InpPanelY + 22`.

### Changed
- Panel row 16 now reads `swings detected: bias=10 conf=16 exec=63 (arrows:34)` — the old wording said "swings drawn", which was wrong whenever arrows were capped at `InpDrawMaxPivots` or suppressed by chart timeframe.

### Verified
45/45 tests green; 0 format-specifier mismatches; single-file rebuild 1895 lines, braces/parens balanced. Detector unchanged from v0.5.0 — only rendering decisions changed.


## [0.5.0] — 2026-11-02 — *Significant structure: the ATR-ZigZag swing detector*

### Why
The user reviewed v0.4.3 on a live chart and reported arrows "in not significant places, like on every wick", present inconsistently, with colour coding nobody had explained. The panel numbers agreed with him:

| TF | pivots | bars | one swing every |
|----|--------|------|-----------------|
| bias | 161 | ~600 | 3.7 bars |
| confirm | 164 | ~600 | 3.7 bars |
| exec | 147 | ~600 | 4.1 bars |

A pivot every four bars is not structure — it is every minor wiggle. A `k=2` fractal fires on **any** local extremum in a 5-bar window and never asks whether the move was large enough to matter.

### Changed — D-08b replaces the fractal (breaking)
- **ATR-ZigZag swing detection** in `SPA_Structure.mqh`. A swing is emitted only after price retraces at least `InpMinSwingATR × ATR` from the extreme. The still-running extreme is never emitted, so the detector remains **non-repainting** but now also **significance-filtered**.
- **Wilder ATR is computed in-module** from the already-copied closed-bar series. No `iATR()` handle, no new standard-library dependency of any kind — the same hardening that closed C-003.
- **`InpSwingK` removed**, replaced by `InpMinSwingATR` (default **4.0**). `k` was the single most influential parameter in the system and it controlled *tightness*, not *meaning*; a significance measure is the correct control.

### Changed — visual defects from the screenshot review
- **Arrow stacking fixed.** All three timeframes previously drew at the exact pivot price, so a bar where bias + confirm + exec all swung showed three arrows on top of each other. Each slot is now displaced vertically along the direction the arrow points: BIAS `2 × InpArrowSpreadATR`, CONFIRM `1 ×`, EXEC `0` (closest to price, because it is the timeframe actually traded). All three offsets use the **exec** ATR so the gaps are visually equal.
- **Colour coding now explained on the panel.** New rows: `LEGEND  gold = BIAS TF   blue = CONFIRM TF   silver = EXEC TF` and `Arrow up = swing LOW   Arrow down = swing HIGH`.
- Panel structure row reads `STRUCTURE (swing >= 4.00x ATR)` instead of `(k=2)`.

### Measured — real-data density, not guesswork
The threshold default was set from measurement, not taste. Bars per swing on real data (Yahoo, 2026-11), fractal `k=2` versus ATR-ZigZag at several multipliers — **bigger number = fewer arrows**:

| Symbol | TF | bars | fractal k=2 | 3.0× | **4.0×** | 5.0× | 6.0× |
|--------|----|------|-------------|------|----------|------|------|
| EUR/USD | M5 | 1124 | 277 (**4.1**) | 6.5 | **12.1** | 16.3 | 26.1 |
| EUR/USD | M15 | 1983 | 536 (**3.7**) | 12.9 | **20.4** | 33.6 | 48.4 |
| EUR/USD | H1 | 1548 | 415 (**3.7**) | 19.8 | **41.8** | 70.4 | 110.6 |
| GBP/JPY | M5 | 1124 | 282 (**4.0**) | 10.3 | **22.9** | 33.1 | 46.8 |
| GBP/JPY | M15 | 1985 | 532 (**3.7**) | 16.5 | **33.1** | 58.4 | 90.2 |
| XAU/USD | M5 | 1039 | 264 (**3.9**) | 14.8 | **28.9** | 37.1 | 57.7 |
| XAU/USD | M15 | 1935 | 509 (**3.8**) | 19.0 | **29.8** | 55.3 | 101.8 |

Two findings worth keeping:

1. **1.5×ATR is worse than the fractal it replaced.** In quiet conditions ATR shrinks, the threshold shrinks with it, and the detector follows wiggles *more* closely than a fixed 5-bar window does. The first genuinely useful multiplier is ≈3×.
2. **2.5×ATR is still not enough on M5** — measured at 4.5 bars per swing against the fractal's 4.1, i.e. no improvement at all. The default was therefore raised to **4.0×**, which lands at 12 bars/swing on M5 (≈1 hour) and 20–42 bars on M15/H1. That is the density at which a human would agree the marks are *structure*.

### Verified
- **45/45 tests green** (21 symbol/risk + 24 structure), including 6 new significance tests and a **MQL5/Python parity test** that transliterates `BuildPivotsZigZag()` line-for-line and compares it against `find_pivots_zigzag()` over 40 random series × 5 multipliers.
- New `tools/check_format.py` — 0 format specifier/argument mismatches.
- Single-file rebuild: **1857 lines**, braces/parens balanced.

### Still not done
No order logic. v0.5.0 remains a structure-visualisation build; the entry engine (zones, sweep, MSS, limits) is v0.5.1.


## [0.4.3] — 2026-11-01 — *iSpread dependency removed (compile blocker fixed)*

### Fixed
- **C-002 CLOSED.** `wrong parameters count  SovereignPA_single.mq5  1598  17`. Column 17 resolves precisely to the `iSpread` identifier in `g_h_spread = iSpread(_Symbol,PERIOD_M1);`. `iATR` two lines above compiled without error, proving the build itself was fine and that `iSpread` specifically is unavailable/incompatible on the user's MetaEditor build.

### Changed
- **`iSpread()` removed entirely.** The spread-regime diagnostic no longer depends on an indicator that may not exist on every build.
- **Replaced with self-calibration:** the EA samples the live spread once per M1 bar into a rolling 1440-sample buffer (24h) and takes the median. Advantages beyond portability:
  - it measures the spread **this account actually pays**, not a nominal series;
  - it needs no history download;
  - `regime` now reports `CALIBRATING (n/30)` until it has enough samples, instead of lying with a ratio computed from one observation.
- **`ArrayRemove()` also removed** in favour of a manual 1440-iteration shift — one fewer built-in whose availability has to be assumed.

### Verified
- Compiler reported exactly **one** error, which confirms every other construct in the file compiled — `iATR`, `iTime`, `CopyHigh/Low/Open/Close/Time`, all `Object*` functions, `ObjectsDeleteAll(0,prefix)`, and the full format-string set. The earlier automated specifier/argument audit (0 mismatches) is now corroborated by the compiler.
- 38/38 tests green. Static pre-flight clean. Single-file rebuild: 1743 lines.


## [0.4.2] — 2026-11-01 — *Build Robustness + Single-File Route*

### Context
User reported `wrong parameters count SovereignPA.mq5 451 17`. A `%%`-aware audit of every `StringFormat`/`PrintFormat` call across all four source files found **0 specifier/argument mismatches**, 0 brace/paren imbalance and 0 non-ASCII characters. The reported line does not match any construct in the audited tree, pointing to build skew (mixed file versions) or a mangled paste rather than a source defect.

### Changed
- **All `Comment(StringFormat(...))` call sites rewritten** as `string s = StringFormat(...); Comment(s);` (3 sites). Zero functional change; removes a construct that could conceivably trip a stricter parser.
- **Single-file build promoted to a first-class delivery route.** `release/SovereignPA_single.mq5` needs no `Include` folder, so mixed-version errors become impossible.

### Docs
- SETUP_GUIDE 2.6 — reading a compiler error (file · line · column), copying the **full** error list, jumping to the offending line, error-to-cause table, and a hard warning: **download source files, never copy-paste them out of a browser** (browser text can mangle characters and invalidate line numbers).
- SETUP_GUIDE 2.7 — single-file install in 7 steps.

### Verification
- 38/38 tests green (unchanged; no logic touched).
- Static pre-flight clean on both the modular `.mq5` and the 1710-line single-file build.


## [0.4.1] — 2026-11-01 — *Observability: no more silent failure*

### Why
User reported: *"I don't see anything on the charts yet."* That report could mean four very different things (not compiled / init failed / no history / drawing failed) and the build gave no way to tell them apart. That is an observability defect, not a user error.

### Added
- **Heartbeat via `Comment()`.** A single line rendered by the terminal itself, independent of the chart-object subsystem:
  `SPA v0.4.1 ALIVE | EURUSDz | swings B:12 C:9 E:14 | arrows:35 | ticks:1841 | NO TRADING`
  If this line is visible the EA is running — full stop. It does not depend on the panel, on objects, or on Algo Trading being enabled (`OnInit` runs regardless).
- **`FatalComment()`** — every `INIT_FAILED` branch now writes the reason **onto the chart**, not only into the Experts tab. All 6 failure paths converted.
- **`[HIST]` diagnostics** at init: bars loaded per timeframe vs the number required for swing detection, plus the specific likely cause when a timeframe yields zero pivots.
- **`[OBJ]` logging**: every arrow drawn is counted and reported (`[OBJ] 35 swing arrows drawn (bias=12/12 conf=9/12 exec=14/12)`); every `ObjectCreate` / `ObjectSet*` failure logs its name and error code instead of vanishing.
- Initial `Comment("...initialising...")` so attaching the EA produces immediate feedback before any heavy work runs.

### Fixed
- **Stale arrows.** Arrow object names are positional (`SPA_SW_<tf>_<i>`), so when a pivot list shifted, old arrows survived at the wrong prices. `DrawAllSwings()` now clears the prefix before redrawing.
- **Redraw responsiveness.** Swings previously redrew only on a new *bias* bar; lower timeframes could sit stale for hours. Now redraws when **any** of the three timeframes closes a bar.
- **Panel position.** `InpPanelY` default moved 22 -> 44 so the heartbeat line and the panel cannot overlap.

### Not changed
- No detection logic altered. The structure engine is byte-identical to the version covered by 17 passing tests.


## [0.4.0] — 2026-11-01 — *Structure Engine*

### Added
- **`experts/SovereignPA/Include/SPA_Structure.mqh`** — the market-structure engine. Implements D-08 (fractal pivots), D-09 (BOS by body close), D-10 (liquidity sweep), D-14 (internal-structure filter) and RB 2.1 (HH/HL vs LL/LH trend + consolidation suspension).
  - Copies price data **chronologically** (index 0 = oldest closed bar), excluding the forming bar at copy time — this is what makes the engine non-repainting.
  - Recomputation is cached per timeframe bar, so the engine costs nothing on tick.
  - `ResolveLevel()` returns the **first** thing that happened to a level: `BOS`, `SWEEP`, or `NONE`. A level resolves exactly once.
- **`tests/spa_structure_ref.py`** — Python twin of the engine, byte-for-byte semantically equivalent. Exists so detection logic is proven before it reaches MetaEditor.
- **`tests/test_structure.py`** — 17 unit tests against hand-built price series: pivots, plateaus, alternation, labels, trend, BOS-vs-sweep, the D-14 filter, consolidation, and non-repainting.
- **EA v0.4.0** — wires in three structure engines (bias/confirm/exec), draws every detected swing on the chart as an arrow (233 = low, 234 = high), extends the panel with a per-timeframe structure row, and logs a structure report on every new bias bar.

### Fixed (found during the Python→MQL5 port, before any code shipped)
- **D-003 — alternation was silently deleting lower highs and manufacturing false shifts.** See `debug_log.md`. Alternation ("collapse consecutive same-type pivots to the more extreme") is now a **presentation-only** view used for drawing legs. All signal logic consumes **raw pivots**. Regression test: `TestAlternationMustNotAffectSignals`.

### Verification
- 38/38 tests green — 21 symbol/risk arithmetic, 17 structure.
- Static pre-flight: brace/paren balance 0, zero non-ASCII, class definitions precede all global instances in the merged single-file build.
- **No orders are placed by this build.** Structure detection is display + logging only.

### Not yet implemented
- Zone engine (supply/demand construction, freshness, extreme-zone ranking).
- Entry state machine, order execution, position management.
- R-14 correlated-basket cap, R-15 volatility-scaled risk, Dynamic Liquidity Window.


## [0.3.3] — 2026-11-01 — *Live On-Chart Panel + Clarity Fix*

### Why this release exists
User attached the EA, saw the config block, and reported: *"I haven't seen anything happening... I don't know how to execute it... I haven't seen the agent do anything yet."* Nothing was broken. Two real communication failures on my side, addressed here and in the docs.

### Added
- **Live on-chart status panel** (`InpShowPanel`, 14 lines, colour-coded). Shows symbol, resolved profile, server/GMT clock, tick counter, bid/ask, spread + regime, ATR, both spread gates with PASS/BLOCK in green/red, lot preview, and a standing reminder that this build places no orders.
  - Purpose: make "is it alive?" a question with a visible answer. A moving clock and a rising tick counter are proof of life that requires no interpretation of the log.
  - Implemented as `OBJ_LABEL` objects (not `Comment()`) so BLOCK lines can be red. A blocked risk gate should look different from a passing one at a glance.
- **Tick counter** in both panel and log — an independent liveness signal.
- Panel objects are cleaned up in `OnDeinit` and are `SELECTABLE=false` / `HIDDEN=true` so they never interfere with chart interaction.

### Clarified (the 15% question)
- The user recalled "maybe 8%" and saw "15.0%". Both are correct and measure different things:
  - **~7.5%** was my worked example of the *measured* spread cost (1.5-pip spread vs a 20-pip stop).
  - **15.0%** is the *ceiling* — the maximum permitted.
  - The log line printed both numbers with no labelling of which was which. Fixed: the panel and log now read `R-10b of risk PASS  4.0% of 20p SL (limit 15.0%)`, and an explicit note states which is the ceiling and which is the measurement.

### Not changed
- No risk parameter changed. This was a display and explanation defect, not a calibration one.


## [0.3.2] — 2026-11-01 — *Spread Regime Diagnostics*

### Context
User reported that on EURUSD, pip detection and lot sizing both looked correct, but flagged R-10b ("15.0% of SL distance") as suspicious. Journal timestamp `2026.11.02 00:29:04` resolves to **~21:29-22:29 GMT** — inside the daily swap/rollover window, when EURUSD spreads routinely widen 3-10x. Diagnosis is likely "correct behaviour, unlabelled context" rather than a defect. Rather than assert that, this release makes the EA prove it.

### Added
- **Spread regime line.** New `iSpread()` handle + `SpreadMedianPips()` computes the median M1 spread over the last 200 closed bars *for that symbol* and classifies the current spread as `NORMAL` (<1.5x), `ELEVATED` (<3x) or `BLOWOUT (rollover / news)` (>=3x).
  - Rationale: a raw spread figure is uninterpretable. 2.0 pips is catastrophic for EURUSD at 10:00 GMT and entirely normal at 22:00 GMT. Comparing an instrument against its own recent median removes judgement from the question and makes the diagnostic self-interpreting.
- **Clock line** printing broker server time alongside `TimeGMT()`, so the rollover window is visible at a glance and any server offset is obvious.
- **R-10b line now states its full arithmetic**: current % of risk, the SL distance used, and the profile limit — plus a three-line note clarifying that the SL in the preview is *illustrative* and that live SL comes from the structural zone.

### Changed
- `[DIAG] ATR14(...) | SL preview=... | lots=...` renamed to make explicit that the SL is illustrative.
- `iSpread()` failure is non-fatal (warns and disables the regime line) — diagnostics must never block initialisation.

### Not changed
- **The 15% R-10b threshold is unchanged.** No evidence yet that it is mis-calibrated; changing a risk parameter in response to a single observation is how systems get curve-fitted. It gets revisited only with regime data across several sessions.


## [0.3.1] — 2026-10-31 — *Build Warning Fix*

### Fixed
- **W-001: `warning: version '0.300' is incompatible with MQL5 Market, must be xxx.yyy`** on `SovereignPA.mq5` line 19.
  - **Cause:** MetaEditor validates `#property version` against the MQL5 Market string format `xxx.yyy` — three digits, dot, three digits. Semantic version `"0.300"` has one digit before the dot, so it fails validation. The property is optional metadata and does not affect compiled behaviour.
  - **Fix:** removed the directive rather than distorting the version into a Market-shaped lie (`"000.301"`). Authoritative version now lives in `#define SPA_VERSION "0.3.1"` and is printed at `OnInit`, so the running build is always identifiable in the Experts log. A comment in the source records the exact fix should we ever publish to Market (`#property version "001.000"`).
- **Preventive hardening** in `SPA_Symbol.mqh::TradingPermitted / FillingMode`: replaced implicit `long`→`bool` conversions with explicit `==0` comparisons, and cast the `SYMBOL_FILLING_MODE` bitmask to `int` before `&`. Neither had warned yet; both are the kind of thing that starts warning on a different compiler build.

### Verified
- Static pre-flight clean: brace/paren balance 0, zero non-ASCII in the `.mq5`, zero bare `long`-in-boolean checks remaining, 21/21 Python parity tests green.
- Build expectation: **0 errors, 0 warnings**.


## [0.3.0] — 2026-10-31 — *Pipeline Validation Build + Single-File Tooling*

### Verified
- **C-001 CLOSED.** User compiled `SPA_Config.mqh` and `SPA_Symbol.mqh` in MetaEditor: **0 errors, 0 warnings** on both (29 ms / 54 ms). The multi-asset foundation is compiler-verified on a real MT5 build.

### Added
- **`experts/SovereignPA/SovereignPA.mq5` v0.3.0** — first attachable EA. Loads the profile CSV, resolves the symbol profile, initialises metrics, creates the ATR handle, and prints a full configuration dump plus a periodic diagnostics block. **Places no orders by design.** Every figure it prints is the exact figure the trading engine will later use, so a wrong number is caught here instead of inside a live trade.
  - Input overrides for risk % and min RR that are **hard-clamped to the Rule Book** (rejects >1.0% risk and <3.0 RR at `OnInit`, `INIT_FAILED`).
  - Diagnostics interval, hypothetical SL distance for lot-size preview.
  - Fail-closed: any profile/symbol init failure returns `INIT_FAILED` with the reason in the Experts log.
- **`workspace_docs/SETUP_GUIDE.md`** — full install path map, compile steps, expected Experts-tab output, the definitive "did it save?" check, update procedure, and troubleshooting table keyed to actual error strings.
- **`tools/build_single_file.py`** — flattens the modular sources into one self-contained `.mq5` (recursive include inlining, dedup, guard stripping). Answered a legitimate user question: *"I thought it would be one file."*
- **`release/SovereignPA_single.mq5`** — generated single-file build (3 modules, 885 lines), for drop-in deployment.

### Decisions
- **Modular development + single-file deployment.** Sources stay split for reviewability and per-module Supervisor audit; the release artifact is one file. Editing the generated file is explicitly forbidden and its banner says so.
- **`symbol_profiles.csv` stays in `MQL5/Files`, not `Experts`.** It is a tuning sheet, not code: editable between backtests with no recompile.

### Fixed
- Removed `#property strict` (MQL4-ism) and the empty `#property link` from the `.mq5` — both are warning-risk on MQL5 and the user's success criterion is a clean 0/0 build.
- `SPA_Config.mqh` error string no longer calls `GetLastError()` twice (second call always returned the same stale code) and now names the correct destination folder.

### Open
- Structure engine (`SPA_Structure.mqh`) — next.
- R-14 correlated-basket cap, R-15 volatility-scaled risk, Dynamic Liquidity Window, order execution layer — all specified, none implemented.


## [0.2.0] — 2026-10-31 — *Decisions Resolved / Multi-Asset Foundation*

### Decisions resolved (SPEC §11)
- **Q1 — Instrument scope: MULTI-ASSET.** All FX pairs + XAUUSD + BTCUSD + indices. Implemented via an ATR-normalised core (§3.1) plus per-symbol profiles (§7.3), so one parameter set generalises and only instrument-specific facts live in the CSV.
- **Q2 — Detection: HYBRID.** JeaFX base candle (D-05) as default, Rule Book FVG validator (D-06) as the imbalance requirement. Both switchable for A/B.
- **Q3 — Session filter: SUPERSEDED** by the **Dynamic Liquidity Window** (§7.2). The fixed London/NY windows are replaced by an empirical per-instrument hour-of-day volume percentile plus spread and dead-market guards. Fixed windows retained only as an off-by-default A/B mode. *This is an explicit, user-authorised deviation from Rule Book §4.1 and is recorded as such.*
- **Q4 — Entry: transcript-faithful.** Entry at the LTF zone boundary created by the confirmation. `MIDPOINT` retained as a test mode. Rule Book §4.4 direct-limit **permanently disabled**.

### Added
- `data/symbol_profiles.csv` — 17 profiles (11 FX/metal enabled, crypto/indices staged disabled), 18 columns, most-specific-wins wildcard resolution.
- `experts/SovereignPA/Include/SPA_Config.mqh` — profile struct, safe defaults (fail-closed, `enabled=false`), CSV loader with shared-then-local folder fallback, specificity-ranked resolver, TF string parser.
- `experts/SovereignPA/Include/SPA_Symbol.mqh` — the single market choke-point. Pip auto-derivation (3/5-digit vs 4/2-digit vs explicit), spread, tick-value money maths, `LotsForRisk` (floors to volume step, **rejects rather than silently taking min lot**), `FitToFreeMargin`, broker permission and filling-mode detection.
- `tests/test_symbol_math.py` — 21 tests, all green. Mirrors the MQL5 arithmetic for offline verification.

### Fixed
- **D-002 (critical):** spread gate was formulated as a fraction of ATR and would have rejected **every FX pair** under normal conditions while passing gold/index spreads. Replaced with a two-stage gate: R-10a coarse pip ceiling + **R-10b cost-of-risk** (`spread ≤ max_spread_of_risk × SL_distance`).
- CSV column 8 renamed `spread_atr_ceiling` → `max_spread_of_risk`; headline spread ratios re-derived per asset class.

### Process
- **PM-001 rule adopted:** no threshold enters a module without a paired test proving it passes under normal conditions and rejects under stress. Honour-system tuning is now a Supervisor rejection.

### Known open items
- C-001: MQL5 modules not compiler-verified (no MetaEditor in this environment). **User must compile before the next module is built on top of these.**
- R-14 correlated-basket cap and R-15 volatility-scaled risk are specified but not implemented.
- Dynamic Liquidity Window (§7.2) specified, not implemented.

---


## [0.1.0] — 2026-10-31 — *Project Initiation / Discovery*

### Added
- **Reference corpus ingested.** Full parse of both source documents:
  - `sovereign_price_action_rule_book.md` — 125 lines, 9,144 bytes (formal numeric spec, v1.0)
  - `The_Complete_Price_Action_Course_4_Hours.md` — 22,109 lines / 87,590 words / 507 KB (JeaFX raw transcripts, multiple concatenated videos incl. *Ultimate Supply & Demand Masterclass* and *Bootcamp Ep.16 — BoS or Liquidity Sweep*)
- **`workspace_docs/strategy_spec.md` (SPEC-001 v0.1.0)** created:
  - 15 objective definitions (D-01…D-15) expressed as pure, unit-testable functions
  - 3-layer timeframe hierarchy (H4 → M15 → M5) with fractal-safe implementation
  - Zone lifecycle state machine (CREATED / VALID / DEAD_IMBALANCE / DEAD_TAPPED / DEAD_BIAS / DEAD_STALE)
  - 6-state entry machine (IDLE → ARMED → SWEPT → SHIFTED → PENDING → ORDER_PLACED → IN_TRADE)
  - 13 binding risk rules (R-01…R-13)
  - 8 Quant Supervisor acceptance gates (G-1…G-8)
  - Full Rule Book ↔ Transcript crosswalk (§10)
- **Workspace scaffolding:** `/workspace_docs`, `/experts/SovereignPA`, `/tests`, `/data`
- **`workspace_docs/debug_log.md`** initialised with corpus data-quality findings.
- **`workspace_docs/changelog.md`** (this file) initialised.

### Analysis findings recorded
- **5 methodology conflicts** identified between the Rule Book and the source transcript → logged as blocking decisions **Q1–Q4** (SPEC §11).
- **1 outright contradiction** flagged: Rule Book §4.4 (direct limit, no LTF confirmation) is explicitly contradicted by the transcript (*"we don't generally want to just sell straight into the market. It's better to see a confirmation."*). Resolution: implemented flag-gated and **default OFF**.
- **Session filter is a user-imposed overlay**, not part of the JeaFX methodology — no session rules appear anywhere in the 87,590-word corpus. Recorded as such so it is never mistaken for doctrine.

### Risk / architecture notes
- Flagged that the confluence stack (session window + fresh imbalanced zone + sweep + MSS + ≥3R net) is structurally **low-frequency** (est. 2–8 trades/symbol/week). Recorded in SPEC §9 as a known characteristic, not a defect, to prevent later knee-jerk de-restriction of risk rules.

### Not yet built
- No MQL5 source written. Deliberate: 4 blocking decisions (Q1–Q4) must be resolved first per the collaborative-iteration protocol.
