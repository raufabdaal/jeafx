# SovereignPA — Project Handover

**Read this before touching anything.** It is written so that an agent with no memory of
this work can continue it correctly. If you are that agent: read §0–§3 twice. §3 took two
weeks and five broken versions to get right; do not "improve" it.

Last updated: **2026-11-03** · Version: **0.18.0** · Owner: the user (trader) · Author: agent

---

## 0. In one paragraph

We are building an MT5 Expert Advisor that trades the user's own price-action method
("Sovereign Price Action" + a JeaFX transcript): top-down bias across three timeframes,
a liquidity sweep, a market structure shift, then a limit order back at the last candle
before the impulse, with a hard stop and strict risk. The hard part was never the code —
it was **defining, in a way that survives contact with a real chart, exactly which candle
that is**. That definition is now settled and locked behind tests. Everything else is
ordinary engineering.

---

## 1. Status right now

| | |
|---|---|
| Release file | `release/SovereignPA_single.mq5` — v0.18.0, ~3,526 lines, **0 errors, 0 warnings** |
| Source | `experts/SovereignPA/` (5 modules) |
| Tests | `tests/` — **97 passing** (24 structure · 52 block · 21 symbol) |
| Gates | `python3 tools/verify.py` → `ALL GATES PASSED` · compile: 0 errors, 0 warnings |
| Sends orders | **No.** It draws. `NO ORDERS ARE SENT` is in the panel. |
| User-confirmed | Structure, bias, and — as of 2026-11-03 — **the block definition** |
| Next | **Phase 5: sweep + MSS** (needs the user's plain-language approval first) |

The EA is not an indicator and not a toy: it computes the whole decision chain. It simply
does not place the order yet, because the user's standing rule is *no orders until the
mechanics are approved in plain language*.

---

## 2. How to work with this user — read before your first message

These are not preferences. They were stated explicitly and several were stated after I
got them wrong.

1. **He compiles; he does not configure.** His words: *"I'm more of the logical person and
   you're the technical one. I'm not so good with tweaking settings, I can compile new code
   but anything looking through stuff I get confused."*
   → **Never** ask him to change an input, find one in the Properties dialog, read a log
   line, or filter the Experts tab. If a number needs to change, change it in code and
   change the default.

2. **His feedback channel is a screenshot with hand marks.** Ticks = right, X = wrong.
   He draws with warm orange/brown. Read his marks out of the pixels (see §7.9); do not
   ask him to explain again.

3. **His exact wording is more precise than your paraphrase.** This has been true three
   separate times. Quote him, then implement the quote, not your summary of it. If your
   implementation of his sentence produces a blank chart or a silly number, the
   disagreement is information — measure it, show him the number, and ask.

4. **No rule change without plain language approval first.** *"We need to keep this engine
   secure… I don't want it to be scrambled."* State the rule in one sentence, get a yes,
   then code.

5. **He does not want to grind one thread forever.** *"We don't have to be on one thing all
   the time."* It is fine to open a second thread in parallel.

6. **Visuals serve his eyes; they never weaken the engine.** Simplifying the drawing must
   not change what is computed. A blank chart is a bug, not a signal.

7. **He wants everything logged** *(2026-11-03)*: *"if anything ever happened to you I want
   to be able to pick up right away with any agent, because we're onto something very
   important."* That is why this file exists. Keep it current at the end of every session.

---

## 3. THE BLOCK — the definition this whole project turned on

**Guest vocabulary.** He says *"imbalance"* when he means **the last candle before the
impulse**. When he says *"the candle"*, he means the block. Read his sentence twice.

### 3.1 What it is

> *"The top wick where the top wick stops, then where the bottom wick stops… if a candle
> doesn't have a top or bottom wick it stays on the body. It's not for a full zone or
> something like that. It's the candle itself, the high and the low of the candle with its
> wick."* — 2026-11-02

> *"The impulse is that imbalanced candle."* — 2026-11-02

So: in a three-candle imbalance `k-2, k-1, k`, the **impulse candle is `k`**, and the
**block is `k-2`** — the candle immediately before the displacement.

```
top    = high[k-2]
bottom = low[k-2]
```

Wick to wick. **No shrink, no band, no "live remainder", no zone stretching.** Every attempt
to be clever here was wrong and was reverted (v0.13.1).

### 3.2 How it is found

```python
for k in 2 .. n-1:
    bullish = low[k]  > high[k-2]          # gap up
    bearish = high[k] < low[k-2]           # gap down
    width   = (gap_low - gap_high)          # gap size, in price
    reject if width < InpFvgMinATR * atr14  # 0.10 by default (see §3.6)
    block   = k-2
```

Lives in `SPA_Zones.mqh :: FindFVGZones()`, mirrored exactly by
`tests/spa_signal_ref.py :: find_fvg_zones()`.

### 3.3 The sorting rule — "one move, one block"

> *"we cannot get the last candle before the impulse again immediately after it… we are
> going to be considering the extreme, the last candle at the top, which brought all of
> these inefficient candles at the bottom… unless there is a break of structure, maybe a
> pullback, after that pullback we can consider that also."* — 2026-11-03

A rising move contains many imbalances. They are **one block**, not many. Only the
**extreme** survives:

- demand run → keep the **lowest** bottom
- supply run → keep the **highest** top

A run ends when **a candle CLOSES back inside the run's block**. A wick poking back in does
**not** end it (v0.17.0 — that wick was his X on sheet 1). Direction change also ends it.

Lives in `SPA_Zones.mqh :: CompressRuns()`, mirrored by
`tests/spa_signal_ref.py :: compress_runs()`. Runs immediately after detection, so
everything downstream sees the sorted list.

### 3.4 The death rule — "touched means filled"

> *"if price dipped partway or even tapped a box, it's automatically invalid, because then
> we know that was already retested. It doesn't necessarily mean the box has to be filled
> all the way — the moment the box is touched the imbalance is already filled."* — 2026-11-03

This **reverses** the older rule (2026-11-02: "used up only when price crosses the whole of
it"). The newer statement wins. A block price has come back into **at all** is spent and
leaves the chart.

**Critical detail — the scan origin.** A block can only be retested *after the gap candle
closes*:

```python
lo_since = min(low[gap_idx+1 : ])   # NOT ob_idx+1
hi_since = max(high[gap_idx+1 : ])
```

Scanning from `ob_idx+1` marks **153 of 184 blocks** as touched one bar after they form,
because the middle candle of the gap normally dips back through the block's range. That is
the imbalance being *born*, not a retest. The engine has always used `k+1`; only a
side-measurement script got this wrong (v0.18.0) and produced a false "the chart is empty"
alarm. Do not reintroduce it.

### 3.5 What must NEVER change without his explicit word

- the block index (`k-2`) and the wick-to-wick geometry
- one-move-one-block sorting, with a close (not a wick) ending a run
- touched = dead
- the minimum gap size **defaults** (he cannot see inputs; I own the number)

### 3.6 The size gate, and why it is not in the rule book

`InpFvgMinATR` default is **0.10**, not the 0.50 in rule book D-06.

Reason: his instruction *"any move that leaves an imbalance, we consider it to be an
imbalance"* contradicted D-06 in practice. At 0.50, **77 % of detected blocks were being
thrown away** by that single number. At 0.10: 245 blocks per 600 M5 bars instead of 150.

This is a **threshold default**, not a detection rule — that is why it could be changed
under §2.1 without a rule approval. If he ever says the chart is too busy, this is the
first dial, and I turn it, not him.

---

## 4. What else is already built

| Module | What it does | State |
|---|---|---|
| `SPA_Symbol.mqh` | Symbol profiles (pip value, spread ratio, ATR ratio), spread sampling & median, margin maths, lot sizing | done |
| `SPA_Config.mqh` | Profile CSV loading, per-symbol enable/disable, overrides, risk %/minRR per profile | done |
| `SPA_Structure.mqh` | ATR-ZigZag swing detection (min swing 4.0×ATR), alternation, HH/HL/LH/LL labelling, trend UP/DOWN/RANGE, consolidation, Wilder ATR | done |
| `SPA_Zones.mqh` | The block engine (§3), validity flags, §3.3 ranking (`SelectExtreme`), drawing primitives | done |
| `SovereignPA.mq5` | `OnInit/OnTick`, 3-timeframe structure + bias, drawing, panel, signal text, diagnostics | done |
| Entry state machine | IDLE → ARMED → SWEPT → SHIFTED → PENDING → ORDER | **not built** (Phase 5–6) |
| Order sending | limit at near edge, SL at far edge, RR ≥ 3, 2R partial, BE, daily breaker | **not built** |

### The decision chain the finished EA will run

```
G-1 Context   bias TF is UP or DOWN, not RANGE, not consolidating      [built]
G-2 Zone      a live block exists in the trend direction               [built]
G-3 Approach  price returns to it with weak momentum                   [deferred]
G-4 Sweep     price sweeps a liquidity level, closes back inside       [NEXT]
G-5 MSS       body close beyond the last swing, break is not corrective[NEXT]
G-6 Reward    target distance ≥ 3 × stop distance                      [built, inactive]
```

Every gate is a hard pass/fail and must print a reason code on the chart. He must always
be able to see *why there is or is not a trade* — silence is a bug.

---

## 5. Architecture map

```
experts/SovereignPA/
  SovereignPA.mq5          entry point, drawing, panel, signal text
  Include/
    SPA_Config.mqh         profiles, enablement, overrides
    SPA_Symbol.mqh         pip/spread/margin/lots
    SPA_Structure.mqh      swings, labels, trend, ATR
    SPA_Zones.mqh          the block engine + ranking + draw helpers

tools/
  build_single_file.py     concatenates the 5 sources in dependency order -> release/
  verify.py                the gate runner; TARGET_VERSION must match SPA_VERSION
  check_identifiers.py     undefined identifiers & undefined function calls
  check_format.py          printf/format arity
  plot_blocks.py           renders what the chart should show, from the Python reference

tests/
  spa_structure_ref.py     Python mirror of the structure engine
  spa_signal_ref.py        Python mirror of the block engine  <- the source of truth to compare against
  test_structure.py        structure tests
  test_signal.py           52 tests incl. every block rule (the ones that matter)
  test_symbol_math.py      lot/margin maths

workspace_docs/
  HANDOVER.md              <- this file
  changelog.md             every version, in the user's language
  strategy_spec.md         the living technical spec
  entry_engine_design.md   the six gates in plain language
```

**Delivery protocol** (every time, no exceptions):
download `release/SovereignPA_single.mq5` → `MQL5\Experts\` (delete older
`SovereignPA_single*.mq5`) → F4 → Refresh → double-click → **F7**. Panel must read the new
version. The user compiles; you do not touch his terminal.

---

## 6. Build, verify, ship

```bash
python3 tools/build_single_file.py     # -> release/SovereignPA_single.mq5
python3 tools/verify.py                # must print ALL GATES PASSED
cd tests && python3 test_signal.py && python3 test_structure.py && python3 test_symbol_math.py
```

Bumping a version means **three** edits, and forgetting one has already burned a release:

1. `#define SPA_VERSION "x.y.z"` in `experts/SovereignPA/SovereignPA.mq5`
2. `TARGET_VERSION = "x.y.z"` in `tools/verify.py`
3. a new entry at the top of `workspace_docs/changelog.md`

Then rebuild and re-verify **before** presenting the file.

---

## 7. Traps — every one of these has already happened

1. **Do not re-open the block geometry.** Settled 2026-11-02, confirmed 2026-11-03.
2. **Never route work through an input name or a log line.** It failed twice and he refused
   it explicitly (§2.1).
3. **`[DIAG]` output on a 30 s timer across 5 charts buried the only useful line.** Default
   is `false` and stays false.
4. **An empty string does not clear an MT5 `OBJ_LABEL`** — use `" "`.
5. **Slice-refactoring by index deletes neighbouring functions.** `grep -c` every function
   name after any slice edit. This deleted `DrawBiasZone()` once (v0.14.1).
6. **`python3` regex edits silently no-op** when the source has alignment spaces
   (`InpFvgMinATR        = 0.5;`). Always `grep -n "name\s*="` afterwards.
7. **MQL5 rectangles have no alpha** → outline + a bar cap (`InpZoneBoxBars`).
8. **Backtest trap:** rebuild the block inventory as of each bar; never build once and look
   backward.
9. **Reading his screenshots:** panel text and his handwriting are also "warm orange".
   Restrict mark detection to the chart area (x > 580) and to y inside the plot; ignore
   clusters that are letters.
10. **A measurement script is not the engine.** The v0.18.0 "zero blocks" scare was a bug in
    the measurement (`ob_idx+1` instead of `gap_idx+1`), not in the engine. When a number is
    absurd, suspect the instrument first.
11. **Filtering used/consumed blocks out of the display once hid the most important zone.**
    The current rule (§3.4) is deliberate and his; do not "restore" dimming without his word.
12. **Two `SpaZone` locals named `run`** caused `possible use of uninitialized variable`
    warnings; `ZeroMemory(run)` after declaration fixes it. Warnings are not acceptable —
    he reads the compiler tab.

---

## 8. The roadmap — the whole mission, and where we are

| # | Phase | Purpose | State |
|---|---|---|---|
| 0 | Foundation: profiles, risk, spread, lots, panel | the EA must never size a trade wrongly or fail silently | **done** |
| 1 | Structure: ATR-ZigZag swings, HH/HL/LH/LL, trend | we need honest, sparse swings — the frame everything hangs on | **done** |
| 2 | Three-timeframe bias (H4 / M15 / M5) | he trades top-down: you only take what the higher timeframe allows | **done** |
| 3 | **The block** (§3) | the entry point. The reason this project exists | **done & locked 2026-11-03** |
| 4 | **Sweep + MSS** (G-4, G-5) | a block alone is not a trade. Liquidity must be taken and structure must shift | **← NEXT** |
| 5 | Orders: limit at near edge, stop at far edge, RR≥3 | turning the reading into a position | not started |
| 6 | Trade management: 2R partial, BE, daily loss breaker, expiry | survive the days the method is wrong | not started |
| 7 | Backtest protocol, walk-forward | prove it on 2 years before a cent of real money | not started |
| 8 | Live hardening, journal, reconciliation | run it unattended without surprises | not started |

**Deliberately deferred:** G-3 momentum filter; far-edge entry (D-B); trailing (D-D);
strong/weak highs; EQH/EQL.

### Why phases 0–3 had to come first

You cannot test a strategy whose vocabulary is undefined. Phases 0–2 are the *frame* — which
candles matter. Phase 3 is the *object* the whole method revolves around. Phases 4–8 all
consume that object. If the object is wrong, everything built on top is wrong in a way no
amount of backtesting reveals — it just produces a different strategy that looks plausible.
That is why this took long, and why it was worth it.

---

## 9. Open questions waiting for his word

1. Does the current block count on his live chart look right? (M15 ≈ 8 per 600 bars, M5 ≈ 11;
   3–4 live in a 150-bar window.)
2. Sweep + MSS wording — to be put to him in plain language before any code.
3. Which liquidity level counts as "the" sweep: session high/low, prior day, or the last
   significant swing? (rule book says internal/session extreme)
4. MSS on which timeframe is authoritative: exec (M5) or confirm (M15)?

---

## 10. Vocabulary — his words to code

| He says | Means | In code |
|---|---|---|
| imbalance | the last candle before the impulse | `SpaZone` / "block" |
| the block | same | `SpaZone.top/bottom`, `ob_idx` |
| impulse | the displacement candle that leaves the gap | `gap_idx` (= k) |
| retested / used / tapped | price came back into the block at all | `z.retested` |
| fresh | not yet touched | `!z.retested` |
| one move | a run of imbalances with no closing pullback | `CompressRuns()` |
| extreme | topmost supply / bottommost demand in a move | the survivor of a run |
| significant swing | swing ≥ 4.0 × ATR | `InpMinSwingATR` |
| zone | the block we would actually trade | `g_zonesChart`, `SelectExtreme()` |

---

*If you are the next agent: the single most valuable thing in this repository is not the
code, it is §3. Read it, keep its tests green, and do not let a paraphrase of the user's
words replace the words themselves.*
