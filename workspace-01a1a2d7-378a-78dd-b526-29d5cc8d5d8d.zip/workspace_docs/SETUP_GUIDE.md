# SETUP GUIDE — Sovereign Price-Action EA

**Audience:** you, at the keyboard, with MT5 open.
**Purpose:** eliminate every "did it save? where does it go? which one do I click?" question.
**Current version:** v0.8.1 (structure visualisation build — **places no trades**)

---

## 0. The one-paragraph answer

You compile **one file**: `SovereignPA.mq5`. The other files are libraries that get pulled into it automatically — you never compile them separately, and you never have to keep track of them beyond leaving them in the right folder. If you'd rather carry a single file around, use the generated `release/SovereignPA_single.mq5` instead (§5).

---

## 1. The map — what exists and where it goes

```
MT5 Data Folder/
└── MQL5/
    ├── Experts/
    │   └── SovereignPA/
    │       ├── SovereignPA.mq5          ◄── COMPILE THIS ONE (F7)
    │       └── Include/
    │           ├── SPA_Config.mqh       ◄── library, do not compile
    │           └── SPA_Symbol.mqh       ◄── library, do not compile
    └── Files/
        └── symbol_profiles.csv          ◄── DATA, not code. Goes in Files/, not Experts/
```

**Why `symbol_profiles.csv` lives in `Files/`:** it's not code, it's your tuning sheet. Keeping it there means you can edit it in Notepad between backtests without recompiling anything. That is the "document where this pair has these parameters" you asked for.

**File extensions matter:**
- `.mq5` = an Expert Advisor source. MetaEditor produces an `.ex5` from it.
- `.mqh` = an include file. It has no `OnTick`. It cannot be run. It is only ever *text that gets pasted into* whichever `.mq5` includes it.

You compile `.mqh` files by pressing F7 on them — that only syntax-checks them. It does **not** create an EA. That's fine as a sanity check, but it's not the finish line.

---


> ## ⚠️ F7 MEANS TWO DIFFERENT THINGS — read this once, never lose time again
>
> There are **two separate programs** and the same key does different things in each:
>
> | Where you are | What F7 does |
> |---|---|
> | **MT5 terminal** (the trading platform, where the charts are) | Opens the **Expert Advisor properties dialog** — the box with "Allow Algo Trading". This does **NOT** compile anything. |
> | **MetaEditor** (the code editor, dark window, opened with **F4**) | **Compiles** the file you are looking at. This is the only place F7 builds your EA. |
>
> **If pressing F7 showed you a dialog with an "Allow Algo Trading" checkbox, you were in the terminal and nothing was compiled.** You are still running whatever `.ex5` was built last time.
>
> The chain is: **F4 → open the .mq5 → F7 → read "0 errors, 0 warnings" → back to MT5 → re-attach.**
> Four steps. If you skip one, the chart shows the old build and you will think the code is broken when it is simply not there yet.

## 2. First-time install (10 steps)

1. In MT5: **File → Open Data Folder** (or `Ctrl+Shift+D`). A Windows Explorer window opens.
2. Open `MQL5\Experts\`. Create a new folder named exactly `SovereignPA`.
3. Inside `SovereignPA`, create a folder named exactly `Include`.
4. Copy the three files into place **exactly as the tree in §1 shows**:
   - `SovereignPA.mq5` → `MQL5\Experts\SovereignPA\`
   - `SPA_Config.mqh` → `MQL5\Experts\SovereignPA\Include\`
   - `SPA_Symbol.mqh` → `MQL5\Experts\SovereignPA\Include\`
5. Copy `symbol_profiles.csv` → `MQL5\Files\`
6. Back in MT5, press **F4**. This opens **MetaEditor** — a *different window*, dark, with code in it. If no new window opened, you are still in the terminal.
7. In MetaEditor's **Navigator** panel (left): right-click **Expert Advisors → Refresh**.
8. Expand `SovereignPA` and **double-click `SovereignPA.mq5`** so it opens in the editor.
9. **Now** press **F7**. A message bar appears at the bottom: `0 errors, 0 warnings, 951 ms elapsed`.
10. If you instead got a dialog with an "Allow Algo Trading" checkbox — you are in the terminal, not MetaEditor. Press F4 and start again at step 6.

### Success looks exactly like this

```
0 errors, 0 warnings, 412 ms elapsed, cpu='AVX2 + FMA3'
```

### Then attach it

1. Back in MT5, make sure the **Algo Trading** toolbar button is green.
2. Navigator panel → **Expert Advisors** → right-click → **Refresh**.
3. Drag `SovereignPA` onto any chart.
4. Tick **Allow Algo Trading** in the dialog → OK.
5. Open **Toolbox → Experts** tab.


---

## 2.5 Verifying you are actually running the NEW build

Every version puts its number in two places. Check one of them **before** concluding anything is broken:

1. The **heartbeat line** at the very top-left of the chart:
   `SPA v0.4.1 ALIVE | EURUSDz | swings B:12 C:9 E:14 | arrows:35 | ticks:1841 | NO TRADING`
2. The **panel header**: `SOVEREIGN PA v0.4.1`

If either says **0.3.x**, the chart is running an old compiled build and none of the new code exists yet. That is not a bug — it is an uncompiled file.

### The four states you can be in

| What you see | Meaning | Fix |
|---|---|---|
| Nothing at all — no heartbeat, no panel | EA not attached, or `OnInit` failed | Check chart top-right for a ☹ icon; open Toolbox → Experts |
| Text starting `SPA v... INITIALISATION FAILED` | Init failed; the reason is printed right there on the chart | Follow the reason (usually the CSV location) |
| Heartbeat says **0.3.x** | Old `.ex5` — the new source was never compiled | F4 → open .mq5 → F7 |
| Heartbeat says **0.4.1** | You are running this build | Anything missing is a real bug — report it |


---

## 2.6 If the compiler shows an error

An error line looks like this:

```
wrong parameters count      SovereignPA.mq5     451     17
```

Read it as: **file · line number · column**. Nothing else. It is telling you *where*, not *what to do*.

### Get the full list — this is the single most useful thing you can send me

1. In MetaEditor, click in the **Errors** panel at the bottom.
2. Press **Ctrl+A** then **Ctrl+C**.
3. Paste the whole thing. If there are 6 errors, I need all 6 — the first one is often a side-effect of another.

### Jump straight to the offending line

**Double-click the error line** in the Errors panel. MetaEditor jumps the cursor to that exact line. Copy that line and paste it — one line is enough for me to identify it.

### Most common causes, in order

| Error | Usual cause |
|---|---|
| `cannot open program file ... .mqh` | A file from `Include\` is missing — you copied `SovereignPA.mq5` but not the library files |
| `wrong parameters count` | Either a half-copied / edited file, or a text-mangling paste |
| `'X' - undeclared identifier` | Same: a partial copy, or files from two different versions mixed together |
| `'OnInit' - function already defined` | Two copies of the same EA pasted into one file |

### ⚠️ Download the file — do not copy-paste it out of the browser

If you open a source file in the workspace viewer and select-all / copy / paste into MetaEditor, the browser can mangle characters (smart quotes, line wraps, dropped characters). The result compiles with errors that **do not exist** in the real file, and the line numbers no longer match anything I can check.

**Save the file to disk from the download button, then move it into the MT5 folder.** This one habit removes an entire category of phantom bugs.

---

## 2.7 The single-file route (recommended if you keep hitting file errors)

This removes every `Include` problem at once. There is exactly one file and nothing else to keep in sync.

1. Download **`release/SovereignPA_single.mq5`**.
2. Save it as `MQL5\Experts\SovereignPA_single.mq5` — the **top level** of `Experts`, *not* inside the `SovereignPA` folder.
3. `symbol_profiles.csv` still goes in `MQL5\Files\` — that file is data, not code.
4. MT5 → **F4** → Navigator → right-click **Expert Advisors → Refresh**.
5. Double-click `SovereignPA_single.mq5`.
6. **F7**. Expect `0 errors, 0 warnings`.
7. Drag `SovereignPA_single` onto a chart.

The `SovereignPA` folder with its `Include` subfolder becomes irrelevant — you can leave it or delete it. The single file is generated from the same sources, so the behaviour is identical.

---

## 3. What you should see in the Experts tab

```
==================================================================
[SPA] SovereignPA v0.3.3 - PIPELINE VALIDATION BUILD (no trading)
==================================================================
[SPA] Chart symbol      : EURUSDz
[SPA] Profile matched   : EURUSD*  (asset class: FX_MAJOR)
[SPA] Profile enabled   : YES
[SPA] Timeframes        : bias=PERIOD_H4  confirm=PERIOD_M15  exec=PERIOD_M5
[SPA] Symbol metrics    : EURUSDz [FX_MAJOR] digits=5 point=1e-05 pip=0.0001 ...
[SPA] Risk              : 0.75% per trade | min RR 3.00 : 1
[SPA] Spread ceilings   : R-10a 1.50 pips | R-10b 15.0% of SL distance
[SPA] SL construction   : 2.00 x spread + 0.10 x ATR(exec)
[SPA] Entry mode        : BOUNDARY (JeaFX)
==================================================================
[DIAG] ... spread=0.80 pips (8e-05)
[DIAG] Spread regime  : NORMAL  (x1.05 vs 200-bar M1 median = 0.76 pips)
[DIAG] Clock          : server 14:22 | GMT 12:22
[DIAG] ATR14(PERIOD_M15)=0.00024 | illustrative SL=20 pips | lots@that SL=0.37
[DIAG] R-10a coarse  : PASS
[DIAG] R-10b of risk : PASS  (spread is 4.0% of the 20-pip SL; limit 15.0%)
[DIAG] Broker perms : OK
[DIAG] Tick counter : 1043
[SPA] READY. This build does not trade. Watch the on-chart panel:
[SPA] the clock and tick counter must keep advancing. Nothing else should happen.
```

### Read the R-10b line like this

```
R-10b of risk : PASS  (spread is 4.0% of the 20-pip SL; limit 15.0%)
                                 ^^^              ^^^^^^^^^^^
                                 MEASURED         CEILING
```

**4.0% is what is happening now. 15.0% is the maximum allowed.** They are two different quantities on one line, and conflating them is easy — the earlier build printed them without saying which was which, which is what caused the confusion. The trade is rejected when the *measured* value exceeds the *ceiling*.

The intuition: a 0.8-pip spread against a 20-pip stop means you hand the broker 4% of what you're risking. At 25% the spread alone eats a quarter of your edge and a 3R target becomes fiction.

---

## 3.5 "Is it actually doing anything?" — the honest answer

**Right now: no, and that is correct.** This build is a *measurement instrument*, not a trading robot. It reads your broker and reports. There is no entry logic, no stop loss, no position management — they arrive in v0.8.1.

This is deliberate. Every lot size, stop distance and target the trading engine will later compute **derives from the numbers this build prints**. A wrong `pip=` here is silently wrong in every future trade. We prove the instruments read correctly *before* we let them drive.

### How to see that it's alive

Attach the EA, then look at the **top-left corner of the chart**. You should see a colour-coded panel:

```
SOVEREIGN PA  v0.3.3
VALIDATION BUILD - PLACES NO ORDERS
EURUSDz   profile EURUSD* (FX_MAJOR)   enabled:YES
server 14:22   GMT 12:22   ticks 1043        <-- THESE TWO MUST KEEP RISING
bid 1.08321   ask 1.08329
spread 0.80 pips   regime NORMAL (x1.05 vs median 0.76)
ATR14(PERIOD_M15) 0.00024
R-10a coarse  PASS
R-10b of risk PASS  4.0% of 20p SL (limit 15.0%)
broker perms  OK
lots @ 20p SL  0.37   risk 0.75%  minRR 3.0:1

Waiting for: structure engine (v0.5.1) then entry logic (v0.6.0)
This screen updates on every tick. Moving clock = EA is alive.
```

**The proof of life is the clock and the tick counter.** If `ticks` is climbing, the EA is running perfectly and has nothing to trade with yet. If it is frozen, the EA is not attached or Algo Trading is off.

### Nothing else should happen — and that is not a fault

| What you might expect | What actually happens in v0.3.3 |
|---|---|
| Trades appear on the chart | **No.** No entry logic exists yet. |
| Arrows / lines drawn on price | **No.** Only the status panel. |
| Errors in the Journal tab | **No**, unless something is mis-installed. |
| The panel clock ticking | **Yes.** This is the whole point. |

---

## 4. "Did it actually save?"

This is the question that wastes the most time, so here is the definitive check:

| Signal | Meaning |
|---|---|
| Tab in MetaEditor shows **`SovereignPA.mq5*`** (with an asterisk) | **Unsaved changes.** Press `Ctrl+S`. The asterisk disappears. |
| Compile says `0 errors` but behaviour didn't change | You compiled an older buffer. `Ctrl+S`, then `F7`. |
| File timestamp on `SovereignPA.ex5` is from *now* | Proof the compile actually wrote a new binary. |
| `symbol_profiles.csv` edited in Notepad | No recompile needed. But **re-attach the EA** (or recompile), because the file is only read in `OnInit()`. |

**The rule: the compiler only ever sees what's on disk.** Save first, compile second. Always.

---

## 5. One file or many? (the honest trade-off)

Your instinct — "I thought it would be one script" — is reasonable, and both options are legitimate. Here's the real trade-off:

### Modular (what we're developing)
```
SovereignPA.mq5  +  Include/SPA_Config.mqh  +  Include/SPA_Symbol.mqh  +  ...
```
- **Pro:** each file stays small enough to actually read and audit. When a bug hides in the risk maths, you open one 350-line file, not a 4,000-line wall.
- **Pro:** we can rewrite one module without touching the other eleven.
- **Pro:** the Quant Supervisor review is meaningful per-module.
- **Con:** you must move the whole folder, not one file.

### Single file (auto-generated for you)
```
release/SovereignPA_single.mq5   ← 885 lines right now, ~4,000 when complete
```
- **Pro:** one file. Drag and drop. Nothing else to keep track of.
- **Pro:** genuinely easier for a VPS or for showing someone your EA.
- **Con:** it's **generated**. Hand-edits are destroyed on the next build. Never edit it.

**My recommendation:** keep developing modular, and treat `SovereignPA_single.mq5` as your deployment artifact. You get reviewability during development and a single file when you need one.

### Using the single file

```bash
# regenerate after any source change
python3 tools/build_single_file.py
```

Then drop `release/SovereignPA_single.mq5` into `MQL5\Experts\` — **no `Include` folder needed** — and press F7.

> **Important:** even the single file still needs `symbol_profiles.csv` in `MQL5\Files\`. That file is *data you tune*, not code. It is the one file you'll actually be editing yourself, so it's a feature that it's separate.

---

## 6. Updating to a new version (every future release)

1. I hand you the changed files and say which version.
2. **Replace** the corresponding files in your folders. Don't create `SovereignPA_v2.mq5` — replace in place, so your chart settings don't fragment.
3. `Ctrl+S` → `F7` on `SovereignPA.mq5`.
4. Check `workspace_docs/changelog.md` for what changed and whether the CSV needs new columns.
5. If the CSV changed, replace it too and **re-attach the EA** (profile is read once, in `OnInit`).

> Keep a copy of your own `symbol_profiles.csv` before any CSV update — your calibrations against your broker's spreads are worth more than my defaults.

---

## 7. Troubleshooting

| Message in Experts tab | Cause | Fix |
|---|---|---|
| `FATAL: cannot open 'symbol_profiles.csv' (err 5004)` | CSV not in `MQL5\Files\` | Move it there. **Not** into the Experts folder. |
| `FATAL: no profile row matched 'EURUSDm'` | Broker uses suffixes/prefixes | Edit the CSV pattern for that class to `EURUSD*` (already the default) or add an explicit row `EURUSDm`. |
| `FATAL: SYMBOL_TRADE_TICK_VALUE<=0` | Symbol has no tick data yet | Open the chart, let a few ticks arrive, re-attach. |
| `FATAL: risk override X% exceeds the 1.0% ceiling` | The override input is above the Rule Book limit | Working as designed. Lower it to ≤1.0. |
| `FATAL: min RR override X is below the 3.0 floor` | Same — hard floor enforced in code | Working as designed. |
| `lots=0.00` with a NOTE | Risk budget < broker minimum lot at that stop distance | Not a bug. The EA refuses rather than oversizing. Use a larger account or a wider stop. |
| Nothing at all in Experts tab | Algo Trading off, or 60 s hasn't elapsed | Enable Algo Trading; the first diagnostic prints immediately at init. |
| `Profile enabled : NO` | That symbol's row has `enabled=0` | Intentional — BTCUSD and indices ship disabled until calibrated. Set `1` in the CSV to test. |

---

## 7.5 Verifying the structure engine (v0.5.0)

This is the first version that *reads* the market. It still places no orders.

### What you will see

Arrows on the chart marking the swings the EA has detected:
- **233 (diagonal up arrow)** = swing **low**
- **234 (diagonal down arrow)** = swing **high**

Colour tells you which timeframe: **gold = bias (H4)**, **deep sky blue = confirm (M15)**, **silver = exec (M5)**.
The panel now prints that legend too, so you never have to remember it:

```
LEGEND  gold = BIAS TF   blue = CONFIRM TF   silver = EXEC TF
Arrow up = swing LOW (buyers defended)   Arrow down = swing HIGH
```

**Height means timeframe.** A gold arrow sits highest above a high (and lowest below a low), silver sits right on the candle, blue in between. That is deliberate: on a bar where all three timeframes swung, the arrows used to print on top of each other and you could not tell them apart. Now they are stacked with a visible gap.

And the panel gains three structure rows:

```
STRUCTURE  (swing >= 4.00x ATR)
BIAS  UP     HH 1.08420  HL 1.07900  cons:no  brk:-
CONF  UP     HH 1.08610  HL 1.08240  cons:no  brk:-
EXEC  RANGE  HH 1.08610  HL 1.08480  cons:YES brk:-
BIAS DIRECTIONAL - waiting for entry engine (v0.6.0)
```

### The test that matters

**Look at the chart and check whether you'd have marked the same swing highs and lows.** This is not a formality — it is the whole release. If the EA still marks swings you don't agree with, change `InpMinSwingATR` (see the table above) or tell me which specific swing it got wrong and I will fix the definition *now*, while no money is involved.

### The one knob that controls how many arrows you see

`InpMinSwingATR` — **a swing only counts if price moved at least this many ATR away from the high/low before turning.**

Read it as: *"how far must price go before we call it a swing?"*

| Value | What you will see | Measured: bars per swing |
|---|---|---|
| 1.5 | too busy — **worse than v0.4.3**; ATR shrinks in quiet markets and the detector follows the wiggles | ~2.7 (M5) |
| 2.5 | still barely better than the old build | ~4.5 (M5) |
| 3.0 | the turns are real but there are still many | 6.5 (M5), 12.9 (M15) |
| **4.0 (default)** | structure a human would also mark — roughly one swing per hour on M5 | **12 (M5), 20 (M15), 42 (H1)** |
| 6.0 | only the major structural turns | 26 (M5), 48 (M15) |

Change it in MetaEditor (`F4` → `SovereignPA_single.mq5` → the line `input double InpMinSwingATR = 4.0;`), then `F7`, then **remove the EA from the chart and drag it back on** — inputs are only read when the EA starts.

> Why not just keep raising the old `InpSwingK`? Because `k` controlled how many bars around a point to look at, not whether the move was worth anything. A tight 5-bar window on a quiet market still calls a 2-pip wiggle a "swing". `InpMinSwingATR` measures the move itself, which is what "significant" actually means.

### Which chart should you attach it to?

**M5 (or M15).** That is the only place the arrows mean anything, because the structure timeframes are fixed by the profile — bias H4, confirm M15, exec M5 — and the EA draws a timeframe's swings **only when that timeframe is at or above the chart's own**.

| Chart you attach it to | What you see |
|---|---|
| M5, M15 | all three: gold + blue + silver — **this is the intended view** |
| H1, H4 | gold only (the H4 bias swings) |
| D1, W1 | no arrows, and the panel says `ARROWS HIDDEN - this PERIOD_D1 chart is coarser than every structure TF` |

That is not a fault. Twelve M5 swings cover a few hours; on a Daily chart they would all land inside one candle and print as a pile. The panel tells you which charts to open instead.

Two things that are **correct** and may look wrong at first:

| What you observe | Why it happens | Is it a bug? |
|---|---|---|
| An arrow appears a few bars **after** the swing forms | A swing cannot be confirmed until price has retraced away from it. Confirming earlier means reading an unclosed bar, which repaints. | **No — by design** (C-004, D-08b) |
| H4 arrows are very far apart on an M5 chart | Different timeframes, different scale. That is the hierarchy working. | **No** |

### Interpretation of the structure rows

- `HH` / `HL` = higher high / higher low → the signature of an uptrend
- `LH` / `LL` = lower high / lower low → downtrend
- `cons:YES` = no new extreme for 20+ bars → **RB 2.1 suspends trading** in this state
- `brk:` = the D-14 filter. `BEAR` means a bearish shift is structurally valid (a higher high printed, *then* the low broke on a body close). Blank means the break — if any — is inside a corrective leg and must not be traded.

---


## 7.6 The zone engine (v0.6.0) — it now shows you the trade

This build finds the trade, prices it, and **draws it**. It does not send it.

### What you will see

- A **shaded box** on the chart where the engine sees an order block with an imbalance behind it. **Green = demand (a buy zone)**, **red = supply (a sell zone)**.
- Each box is **labelled with what it is and how old it is**: `SUPPLY  OB 30 Oct 14:15  age 42 bars`. A **solid** box is live; a **dashed, faded** box reading `already tapped` is one the market has used — shown so you can see it was considered and rejected.
- Beside the winning zone, the exact order it would place:
  `BUY LIMIT 0.82153  SL 0.82083  TP 0.82432  1.07 lots  3.99R`
- Two new panel rows:
  ```
  ZONES  found=7  fresh=2  drawn<=4
  BUY LIMIT 0.82153  SL 0.82083  TP 0.82432  1.07 lots  3.99R
  v0.6.0 DRAWS THE TRADE ONLY - NO ORDERS ARE SENT
  ```

### Expect to see nothing most of the time

That is the system working, not failing. On a scan of twelve pairs at one moment, **one** qualified. When there is no trade the panel names the reason instead of going blank:

| Reason shown | What it means |
|---|---|
| `REJ_NO_TREND` | The bias timeframe is in a range. Stand aside — this is the most common and the most correct. |
| `REJ_NO_ZONE` | No order block with an imbalance exists in the recent history. |
| `REJ_NO_FRESH_ZONE` | Zones exist, but all have already been traded back into, or are older than 200 bars. |
| `REJ_RR` | The first structural level ahead is closer than 3× the risk. **This is the rule doing its job** — the trade is skipped, not reshaped. |
| `REJ_SL_TOO_TIGHT` | The order block is so small the stop would sit inside a normal bar's range. |

### The three settings that shape it

| Input | Default | Meaning |
|---|---|---|
| `InpZoneTF` | CONFIRM | Which timeframe's structure creates the zone. **CONFIRM (M15 on your profile)** is right for normal use; set BIAS for H4 zones, EXEC for the old fine-grained behaviour. |
| `InpZonesLatestOnly` | true | Only the newest impulse per direction. Turn this **off** if you want to see every historical zone — useful for study, wrong for trading. |
| `InpMinRiskATR` | 0.5 | Minimum stop distance, in multiples of the exec timeframe's ATR. Raise to 0.75–1.0 for fewer, safer trades. |
| `InpZoneMaxAge` | 200 | Bars after which an untouched zone is abandoned. |
| `InpDrawZonesMax` | 4 | How many zones are drawn. |

### What is still missing

The zone is the entry, but the **confirmation** is not wired in yet — no sweep of liquidity and no market-structure shift are required before the limit is placed. That is v0.6.1, and it is the step that turns this from "a zone exists" into "an institution left a footprint here". Do not judge the win rate of this build; judge whether the zones it marks are the zones you would mark.

## 8. What this build does NOT do

To be unambiguous: **v0.3.1 places no orders.** There is no entry logic, no stop loss, no position management. It reads your broker, validates every number the trading engine will depend on, and reports.

That is deliberate. Every future lot size, stop distance and reward target is computed from the values printed on this screen. If `pip=` or `lots=` is wrong here, it is silently wrong in every trade afterwards — which is precisely the class of bug that empties accounts without ever throwing an error.

**Next release (v0.4.0)** adds `SPA_Structure.mqh`: swing detection, HH/HL trend classification, body-close-only break of structure, and the internal-structure filter that prevents selling inside an unfinished correction.

## Audit mode (v0.8.1)

To check that the EA reads the chart the way you do, leave these on:

| Input | Default | What it does |
|---|---|---|
| `InpZoneAudit` | true | Draws **every** zone in history, not only the tradeable one. Display only — it never changes what would be traded. |
| `InpAuditMax` | 60 | How many historical zones / rejected blocks to draw. |
| `InpAuditRejected` | true | Draws order blocks the engine **refused**, as a short grey marker labelled with the reason. |
| `InpFvgMinATR` | 0.15 | Minimum imbalance size as a multiple of ATR of the zone timeframe. |
| `InpFvgWindow` | 3 | The gap must sit within this many bars of the order block. |

**Reading the boxes**

| Look | Meaning |
|---|---|
| Solid, filled, thick, bright | **FRESH** — untouched since the impulse, the only tradeable state |
| Dotted, hollow, thin, dim + `TAPPED` | Price has been back into it |
| Dotted, dim + `USED` | Price closed the imbalance too — the move is spent |
| Small grey marker + `REJECTED: <reason>` | The engine saw this order block and refused it |
| Gold dotted band | The imbalance that validated the zone, with its size in ATR |

Set `InpZoneAudit = false` to return to the strict view (newest zone per direction only).

## How a zone is found (v0.8.1 — impulse first)

1. **An impulse** is a leg between two confirmed swings that travels at least `InpMinLegATR` × ATR.
2. **The order block** is the last candle *against* the move at the swing where the impulse started.
3. **The imbalance** is the largest untraded gap anywhere inside that impulse, at least `InpFvgMinATR` × ATR.

If no such gap exists, the block is still drawn — grey, labelled `REJECTED` with the reason — so you can see what the engine looked at.

## Reading the chart (clean mode, default)

Four things per trade, nothing else:

| Look | Meaning |
|---|---|
| **Faint green box** | Demand block — the last candle before an up imbalance |
| **Faint red box** | Supply block — the last candle before a down imbalance |
| **Dotted level, near edge** | Entry |
| **Dotted level, far edge** | Stop |
| **Dotted gold level** | Target — the opposing block |

Newest fresh block per direction. No labels, no numbers, no imbalances, no
refusals, no swing arrows.

To inspect the engine again, switch on `InpZoneAudit` / `InpAuditRejected`.
