# Reference Index — `The_Complete_Price_Action_Course_4_Hours.md`

Character offsets are into the **flattened** token stream (CRLF→space, whitespace collapsed → 87,590 words).
Reproduce the flat stream with:

```python
import re
t = re.sub(r'\r\n', ' ', open('uploads/The_Complete_Price_Action_Course_4_Hours.md').read())
t = re.sub(r'\s+', ' ', t)   # -> 87,590 words
# then: t.find('<anchor>')
```

**Note:** offsets are approximate locators into a lossy ASR transcript — they point you at the right region, they are not citation-grade quotes.

| # | Topic | Char offset | Word offset (~) |
|---|---|---|---|
| 1 | Philosophy / three-phase process (context-confirmation-execution) | 418576 | 76997 |
| 2 | Candlestick taxonomy: impulsive vs reversal vs indecision | 36357 | 6614 |
| 3 | Market structure: HH/HL, LL/LH, consolidation | 42850 | 7814 |
| 4 | Impulse vs correction; why we buy corrective legs | 52433 | 9557 |
| 5 | Body close only — never trust wicks for BOS | 102941 | 18774 |
| 6 | Liquidity sweep vs reversal (lower low that never closed) | 101883 | 18577 |
| 7 | Internal structure trap / invalid internal break | 103357 | 18844 |
| 8 | Supply & demand: last candle before the impulse | 119158 | 21787 |
| 9 | One-tap rule / brick wall analogy | 129026 | 23625 |
| 10 | Zone must have imbalance to be valid | 133782 | 24525 |
| 11 | Market efficiency: premium vs discount, imbalance as magnet | 145231 | 26658 |
| 12 | Liquidity: internal range liquidity sweeps | 200802 | 36880 |
| 13 | Liquidity: never buy above equal lows / never sell below equal highs | 204441 | 37537 |
| 14 | Trend-line liquidity trap | 204783 | 37602 |
| 15 | Momentum on the approach into the zone | 248966 | 45654 |
| 16 | Recap of the full standard-trade process | 248197 | 45513 |
| 17 | Fractal nature of timeframes | 250854 | 46002 |
| 18 | Top-down analysis: start weekly -> daily -> H4 | 255183 | 46794 |
| 19 | Entry / SL / TP doctrine: SL at invalidation point | 415302 | 76376 |
| 20 | Setup selection: reject trades with insufficient RR | 414563 | 76243 |
| 21 | BoS vs Liquidity Sweep — differentiation by context | 419318 | 77120 |
| 22 | How I personally find trades (2 things) | 281975 | 51801 |
