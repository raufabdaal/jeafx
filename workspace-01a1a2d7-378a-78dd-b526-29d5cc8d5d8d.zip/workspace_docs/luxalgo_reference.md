# Reference notes — LuxAlgo Fair Value Gap & Smart Money Concepts

**Purpose.** You gave me two Pine Script indicators (© LuxAlgo) to study so the
engine can look at gaps and order blocks the way a trained eye does. This file
records what they actually do, line by line, so the next build does not start
from guesswork.

## Licensing — read this once, then forget it

Both files carry **CC BY-NC-SA 4.0 (Attribution-NonCommercial-ShareAlike)**.

- **Research and method study is fine.** Algorithms and ideas are not protected
  by copyright in the way source text is.
- **Copying their code into this EA is not fine**, especially if SovereignPA is
  ever sold or distributed commercially. NonCommercial forbids that, and
  ShareAlike would force the whole EA to carry the same licence.
- **What we do instead:** read the method, write our own MQL5, credit the idea.
  Every algorithm below is re-expressed, not transcribed. Where the numbers are
  theirs (2× volatility filter, 80% transparency) those are functional
  parameters, not creative expression.

If you ever want their exact behaviour, the correct route is a licence from
LuxAlgo, not a copy-paste.

---

# 1. Fair Value Gap — what the detector actually tests

Their detection predicate, simplified to plain logic:

```
threshold = auto ?  (cumulative mean of (high-low)/low over all bars)
                  :  Threshold% / 100

bull_fvg =  low    > high[2]                       // (1) a gap exists
        and close[1] > high[2]                    // (2) displacement confirmed
        and (low - high[2]) / high[2] > threshold // (3) big enough, as % of price

bear_fvg =  high   < low[2]
        and close[1] < low[2]
        and (low[2] - high) / high > threshold
```

Three separate ideas are bundled there, and **we only implement one of them.**

| # | Condition | We have it? |
|---|---|---|
| 1 | the geometry gap `low > high[2]` | ✅ yes |
| 2 | **the middle candle must CLOSE beyond the gap** | ❌ **no — this is the missing precision** |
| 3 | size threshold | ✅ yes, but as a multiple of **ATR**, they use a **% of price** |

### Condition 2 is the important one

`close[1] > high[2]` says: the candle in the middle of the three did not merely
trade above the gap, it **closed** above it. That is the difference between a
gap that was created by real displacement and a gap that exists because three
candles happened to line up while price drifted. It is very likely why some of
our blocks look valid to the code and pointless to your eye.

### Threshold: ATR vs percent of price

- **ATR multiple** (ours): adapts to volatility, but changes per timeframe and
  per pair, so one number never means the same thing twice. 0.5 × ATR on M15
  EUR/USD is ~4 pips; on M15 XAU/USD it is ~390 cents.
- **Percent of price** (theirs): scale-free. The same 0.05% works on EUR/USD and
  on gold without retuning.
- **Auto** (theirs): threshold = the running average of `(high-low)/low` over
  every bar — i.e. the instrument's own typical candle range expressed as a
  fraction of price. This is self-calibrating and needs no input at all.

**Decision to make later:** whether `InpFvgMinATR` becomes `InpFvgMinPct`, or
gains an "auto" mode. Both are cheap to add. Ours is currently 0.5 × ATR.

---

# 2. Mitigation — two different conventions, both used

A gap or block dies when price comes back. There are two possible definitions
and **LuxAlgo uses a different one in each script**:

| Script | Rule | Meaning |
|---|---|---|
| Fair Value Gap indicator | `close < gap.min` (bullish) | dies on the **close** beyond the far edge |
| SMC indicator | `low < gap.bottom` (bullish) | dies on the **wick** touching the far edge |

Ours currently uses the wick rule (`low[j] <= gap_low`).

This matters more than it looks. The wick rule kills a zone the first time
price pokes the gap — which is exactly the *entry*. The close rule keeps the
zone alive until the move is genuinely invalidated. **This is very likely part
of why zones keep disappearing just as they become interesting.**

**Decision to make:** expose `InpMitigation = WICK | CLOSE`. Default should
probably be CLOSE for tracking a live opportunity, WICK for judging history.

---

# 3. How they draw it (and why it looked wrong on our chart)

Their FVG box is created with:

```
box.new(..., bgcolor = bullCss)                      // bullCss = color.new(#089981, 70)
```

- **`color.new(c, 70)`** = the colour at **70% transparency** — a wash, not a
  block.
- **`border_color = na`** in the SMC order blocks — **no border at all**. No
  border means no left or right vertical edge. This is precisely the "vertical
  lines" problem: our rectangles had borders.
- The FVG is drawn as **two stacked boxes** (upper half, lower half) meeting at
  the midpoint. Purely cosmetic, lets the gap read as a gradient.
- Order blocks are drawn from the block's bar forward to the current bar,
  always, and are **deleted when mitigated**.

**MQL5 cannot do alpha on an `OBJ_RECTANGLE`.** There is no `OBJPROP_ALPHA`.
So a filled box in MT5 is opaque — it will either hide the candles or be hidden
by them, never wash over them. That is the entire reason our boxes looked heavy
while theirs look light. **The correct MT5 translation of "transparent box" is
not a box at all: it is a pair of horizontal levels.** That is the fix.

---

# 4. Order blocks — how the SMC script picks the candle

This is the part I got wrong, and their method is worth understanding.

```
storeOrderBlock(pivotPoint, bias):
    if bias == BEARISH:
        slice  = parsedHighs[pivot.barIndex .. current]
        index  = pivot.barIndex + indexOf(slice.max())
    else:
        slice  = parsedLows[pivot.barIndex .. current]
        index  = pivot.barIndex + indexOf(slice.min())

    orderBlock = { parsedHighs[index], parsedLows[index], times[index], bias }
```

So the order block is **the candle with the most extreme point between the
swing and the break** — the candle at the *origin* of the move, not merely the
last candle that closed against it.

| Method | Quantity |
|---|---|
| ours: last candle closing against the move, scanning back ≤ 6 bars | one specific candle |
| theirs: the candle holding the extreme low/high of the whole leg | one specific candle |
| both | the block is one candle's range |

Neither is obviously "right"; they are different answers to "which candle
started the move". Worth testing ours against theirs on your screenshots.

### The `parsed` trick — a genuine precision idea

Before any of that, every bar is pushed into two arrays:

```
volatilityMeasure = ATR(200)       or  cumulative mean of true range
highVolatilityBar = (high - low) >= 2 * volatilityMeasure

parsedHigh = highVolatilityBar ? low  : high      // SWAPPED on wild bars
parsedLow  = highVolatilityBar ? high : low       // SWAPPED on wild bars
```

A bar whose range is more than **twice** the volatility measure gets its
high and low swapped. The effect is not to measure it differently — it is to
make it **impossible to select**. A news candle can never become an order
block, because its "parsed high" is tiny and its "parsed low" is huge, so it
never wins the max/min search.

**This is a cheap, high-value filter for us.** Our zones currently use the full
high/low of the block candle including wicks, which is a large part of
"too far / too fine". Two candidate uses:

1. never select a wild bar as the block (`range < 2 × ATR`), and
2. measure the block from **body** extremes rather than wick extremes.

---

# 5. Structure — how they define legs, BOS and CHoCH

```
leg(size):
    newLegHigh = high[size] > highest(high, size)
    newLegLow  = low[size]  < lowest(low, size)
    if newLegHigh: leg = BEARISH   // a high means the up-leg just ended
    elif newLegLow: leg = BULLISH
```

A pivot is simply **the start of a new leg** (`ta.change(leg) != 0`). No ATR
retracement requirement — it is a pure fractal with a lookback. Coarser and
simpler than our ATR-ZigZag, and it produces pivots far more often.

Structure events:
- `crossover(close, pivotHigh)` → if previous bias was BEARISH, this is a
  **CHoCH**; otherwise a **BOS**. Mirror for the downside.
- The pivot is then marked `crossed` so it only fires once.

### Strong / weak highs and lows — useful for later

```
trailing.top    = max(high, trailing.top)      // keeps updating
trailing.bottom = min(low,  trailing.bottom)

if swingTrend == BEARISH: label trailing.top    as "Weak High"
else:                    label trailing.top    as "Strong High"
```

A **strong high** is the last high in the direction of the trend (price has not
yet taken it); a **weak high** is the opposite one, already tested. This is
exactly the vocabulary you use for the liquidity targets, and it is a small,
well-defined thing to implement when we get to the draw-on-liquidity stage.

### Equal highs / lows

```
if abs(previousPivotLevel - currentLevel) < threshold * ATR(200):
    draw EQH / EQL          // threshold default 0.1
```

Two swing points within 10% of an ATR of each other are "equal" — a liquidity
pool. Cheap to add, directly useful for the sweep logic in v0.8.0.

### Premium / discount

Trailing range split at equilibrium: the top 5% is Premium, the bottom 5% is
Discount, the middle band is Equilibrium. Simple and testable.

---

# 6. What I propose we adopt, in order

| # | Idea | Why | Cost |
|---|---|---|---|
| **A1** | Middle candle must **close** beyond the gap | the missing precision filter | small |
| **A2** | **No filled boxes.** Two horizontal levels per zone | fixes the mess, matches their look in MT5 terms | small |
| **A3** | Wild bars (range ≥ 2 × ATR) can never be the block | removes news-spike blocks | small |
| **B1** | `InpMitigation = WICK \| CLOSE` | decides whether a zone survives its own entry | small |
| **B2** | Optionally measure the block from body, not wick | narrower, more precise zones | small |
| **C1** | Strong/weak high & low | liquidity targets for v0.8.0 | medium |
| **C2** | EQH/EQL liquidity pools | sweep candidates | medium |
| **D1** | Percent-of-price or auto threshold | one number that works on gold and FX | small |

## What I would NOT copy

- **Their order-block trigger is a structure break.** We just removed that
  dependency at your instruction — the impulse is primary. Their blocks only
  exist at BOS/CHoCH; that is the thing that made our zones scarce.
- **`request.security` with `lookahead_on`.** Fine in Pine for a chart study;
  absolutely not acceptable in an EA, where it is look-ahead bias and will
  produce a backtest that cannot be traded.
- **Their box model.** No alpha in MQL5; a filled box is opaque by definition.
- **`ta.cum(...)/bar_index` for the auto threshold** is a whole-history average
  that changes as history grows. If we do auto, it should be a rolling window,
  not all bars.

---

# 7. Answers received — 2026-11-02

1. **The block is the candle immediately before the imbalanced candle.** Not the
   swing, not the extreme of the leg, not "the last candle against the move".
   *"When there is a candle that has an imbalance, the candle before that candle
   is what I would call the last candle before an impulse."*
   → Implemented in v0.8.0. This is now the origin point of the whole engine.
2. **Wick to wick** for the block's range.
3. **A wick touching the imbalance fills it.** *"Even a wick taps into that
   imbalanced area, that is already filled. It doesn't necessarily need to be a
   body."* → touch-based fill, implemented.

Also from the same conversation: the imbalance is not itself the object of
interest. It should be a **faint box** proving the engine understands gaps. The
object of interest is **the block**.

---

# 7b. Original open questions (answered above)

1. **Is the middle-candle *close* confirmation something you actually apply?**
   When you look at a gap, are you checking that the middle candle closed past
   it, or only that the space is empty?
2. **When does a gap stop being a gap to you** — when a wick touches the far
   edge, or when a candle closes through it?
3. **Is the block the last candle against the move, or the candle at the very
   extreme of the leg?** On your 28 Oct screenshot both interpretations point
   at the same candle, so it has not yet cost us — but it will.

Answer those three and the next build can be precise instead of approximate.

---

# 8. Measurements taken after reading both scripts

Run on real data the day these notes were written. These numbers are the
reason several of my assumptions were wrong.

## 8.1 Their "middle candle must close past the gap" rule changes almost nothing

| pair / TF | geometry only | + middle candle must CLOSE | survive |
|---|---|---|---|
| EUR/USD M15 | 106 | 105 | 99% |
| EUR/USD H1 | 34 | 34 | 100% |
| GBP/USD M15 | 112 | 110 | 98% |
| XAU/USD M15 | 40 | 40 | 100% |

In a genuine impulse the middle candle closes beyond the gap anyway. The rule is
sound and costs nothing to adopt, but **it is not the source of the
imprecision.** I expected it to be, and I was wrong. Recorded so we do not spend
another round on it.

## 8.2 The actual problem is how wide a zone is

| | EUR/USD M15 | XAU/USD M15 |
|---|---|---|
| zones found | 110 | 40 |
| median zone width (wick to wick) | **1.97 × ATR** | 1.32 × ATR |
| p90 width | 3.93 × ATR | 3.30 × ATR |
| widest | 11.67 × ATR | 5.38 × ATR |
| zones wider than 1.0 ATR | **91%** | 65% |
| blocks that are "wild bars" (range ≥ 2 × ATR) | **45%** | 22% |

A zone whose median width is **two average candles** is not a zone you can place
a limit order in — the entry and the stop are 2 ATR apart before anything has
happened. That is exactly "too far / too fine", and now it has a number.

Two independent causes:

1. **We measure blocks wick-to-wick.** Median 1.97 × ATR. The body
   (open→close) is 1.18 × ATR — still wide, but 40% narrower.
2. **45% of the blocks we select are wild bars.** Nearly half of all blocks are
   candles whose range is more than twice the average. LuxAlgo's `parsed`
   filter exists specifically to stop those being selected, and we have no
   equivalent.

## 8.3 What this implies for the next build

- Adopting the wild-bar exclusion alone removes ~45% of zones — and those are
  the wide ones, so the median width should fall sharply.
- A width cap (`max zone width ≤ InpMaxZoneATR × ATR`, default ~1.0) would make
  every drawn zone something you could actually place an order inside, at the
  cost of dropping the widest ~90% unless the block is re-measured.
- Measuring from the body instead of the wick is the cheapest width reduction.

These three are **geometry decisions**, not bug fixes, and they are yours. The
numbers are here so the choice can be made once, precisely, instead of tuned by
guesswork over several rounds.
