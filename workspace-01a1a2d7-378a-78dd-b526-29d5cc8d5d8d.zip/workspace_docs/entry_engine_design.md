# Entry Engine — Design for v0.6.0

**Status:** proposal, awaiting your sign-off on 4 decisions (§7).
**Sources:** rule book §4 + JeaFX transcript (offsets 415302, 248197, 248966, 102941, 103357).
**Scope:** how the EA decides a trade exists. v0.6.0 draws it and does **not** trade it.

---

## 1. Where the two documents disagree, and which wins

You already ruled on this, and the transcript is decisive:

| Question | Rule book says | Transcript says | **We follow** |
|---|---|---|---|
| Where is the entry? | 50% midpoint of the LTF order block | "the demand or supply zone that your confirmation created. That is it. It's that simple." | **Transcript** — the zone, not its midpoint |
| Can we skip LTF confirmation? | Yes, if price arrives at an extreme HTF zone in peak hours | "we don't generally usually want to just sell straight into the market. It's better to see a confirmation." | **Transcript** — no exception |
| Session window | Fixed London/NY killzone | Trade when the setup is there | **Your Q3** — Dynamic Liquidity Window |

Where the rule book is more specific and the transcript is silent (lot maths, daily loss limit, SL buffer), the rule book stands.

---

## 2. The six gates a trade must pass

Every gate is a hard pass/fail. A fail at any gate stops the chain and prints a reason code on the chart, so you always see *why* there is no trade — never a silent nothing.

| # | Gate | Test | Fail code |
|---|---|---|---|
| **G-1** | Context | Bias timeframe trend is UP or DOWN (not RANGE), and not consolidating for 20+ bars | `REJ_NO_TREND` |
| **G-2** | Zone | A fresh supply/demand zone exists in the direction of the trend, that contains an unfilled imbalance | `REJ_NO_ZONE` |
| **G-3** | Approach | Price is returning to the zone with **weak** momentum, not a violent drive | `REJ_MOMENTUM` |
| **G-4** | Sweep | On the exec timeframe, price **swept** a liquidity level (wick beyond, close back inside) | `REJ_NO_SWEEP` |
| **G-5** | Shift (MSS) | A **body close** beyond the last exec-timeframe swing, and the D-14 filter says the break is structurally valid (not a corrective leg) | `REJ_NO_MSS` |
| **G-6** | Reward | Distance from entry to the structural target ≥ 3× the stop distance | `REJ_RR` |

Then the execution gates already built: spread (R-10a/R-10b), session activity, daily loss breaker, correlation cap.

---

## 3. What exactly happens, in order

1. **G-1 — Direction.** The H4 structure engine already tells us UP / DOWN / RANGE. On RANGE we stop. (You can see this on the panel today.)
2. **G-2 — The zone.** We take the last opposing candle before the displacement leg — the "last candle before the impulse" — and check it left an imbalance behind it. Fresh means untouched since it formed.
3. **G-3 — The approach.** Price must come back into the zone **slowly**. The transcript is specific: "the only caveat... if we were to see an incredibly strong drive up, then this would be a trade we would not take." A violent return means the zone is being defeated, not respected.
4. **G-4 — The sweep.** Before we can buy, price must take out a low and close back above it. That is the institution leaving a footprint — stops collected, no follow-through.
5. **G-5 — The shift.** Price must then **close** above the last exec swing high. Wick above is not enough — that is a sweep, not a shift. And the D-14 filter must agree the break is meaningful (a higher high printed first).
6. **G-6 — The target.** The target is set by **context, before the setup** — the opposing zone up ahead. If that zone is closer than 3× our risk, we do not take the trade. We do not stretch the target to make a trade work.

---

## 4. Stop loss — "only stop me out if I'm wrong"

The transcript's rule is the one that survives: the stop goes where the trade becomes **invalid** — under the low whose break would prove the confirmation failed.

The rule book adds a mechanical buffer so a spread spike does not knock us out of a correct trade:

```
Long :  SL = low_of_confirmation − (2.0 × spread + 2.0 pips)
Short:  SL = high_of_confirmation + (2.0 × spread + 2.0 pips)
```

`low_of_confirmation` = the low of the sweep wick (the lowest point of the move that created the confirmation). This is why the SL distance varies trade to trade instead of being a fixed 20 pips — and it is why the lot size varies with it.

**Never moved wider. Ever.**

---

## 5. A worked example, in full

EUR/USD. Account **$10,000**. Risk **0.75%** per trade.

1. **Risk in money:** 0.75% of $10,000 = **$75**. That is the most this trade may lose.
2. **The stop:** entry 1.11500, sweep low 1.11310, spread 1.0 pip.
   SL = 1.11310 − (2×1.0 + 2.0 pips) = 1.11310 − 0.00040 = **1.11270**.
3. **Risk in pips:** 1.11500 − 1.11270 = **23.0 pips**.
4. **Lot size:** on EUR/USD one lot is $10 per pip. $75 ÷ (23.0 × $10) = **0.32 lots** (rounded down).
5. **Target:** the opposing supply zone sits at 1.12350 → 85 pips away.
6. **Reward test:** 85 ÷ 23.0 = **3.70R** — passes the 3R minimum. Take it.
7. **Half off at 2R** (46 pips, 1.11960) and stop to breakeven, the rest runs to 1.12350.

If that supply zone had been at 1.11900 instead — 40 pips — the trade would be **rejected**: 40 ÷ 23 = 1.7R. No amount of conviction overrides this.

---

## 6. How you will see it (v0.6.0, no orders)

This is the part I think matters most for you. The EA will draw, live on the chart:

- a **shaded box** for the zone it is watching, with the reason it was chosen;
- a **small marker** on the sweep wick;
- a **line** at the swing that closed through (the MSS), labelled `MSS`;
- a **box labelling the trade it *would* take**: `BUY LIMIT 1.11500 · SL 1.11270 · TP 1.12350 · 0.32 lots · 3.7R`;
- and when a gate fails, the **reason code** in the panel — `WAITING: REJ_NO_SWEEP`, never a blank chart.

**No order is sent.** You watch it call trades for a few days and tell me if it is seeing what you would see. Only when you are satisfied does v0.7.0 switch the orders on.

I am proposing this staged approach rather than "build it and go live" because it is the only way to test the decision logic with your eyes rather than my assumptions — and because the first live trade should not be the first time anyone has seen the logic work.

---

## 7. The four decisions I need from you

**D-A. What is "the zone the confirmation created"?**
The displacement leg that broke structure leaves two footprints: the **order block** (the last candle against the move, before the impulse) and the **imbalance/FVG** (the gap the impulse left). Which one is the entry zone?
→ *My recommendation: the order block, falling back to the FVG when no order block exists.* This matches "the last candle before the impulse" and the "one-tap rule".

**D-B. Where inside the zone do we place the limit?**
The **near edge** (first touch, fills more often, worse price) or the **far edge** (deeper fill, better R:R, more trades missed)?

**D-C. How do we measure "not an incredibly strong drive into the zone"?**
Needs a number, or it cannot be coded. Proposal: measure the **last leg into the zone** — if it travelled more than `4 × ATR` and contains fewer than 5 candles, the approach is violent → reject.

**D-D. Is the target strictly structural?**
I read the transcript as: target = the opposing zone that context already identified, and if that is under 3R, **skip the trade** rather than shrink the target. Confirm — or should the EA fall back to a fixed 3R target when no structural target exists?

---

## 8. What this does NOT do

- No Martingale, no averaging down, no adding to losers. Not now, not ever.
- No trading against the bias timeframe.
- No trade without every one of G-1…G-6 passing.
- No moving stops wider, no widening risk to "give a trade room".
