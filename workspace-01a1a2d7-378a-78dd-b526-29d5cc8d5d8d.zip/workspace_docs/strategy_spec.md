# Sovereign Price-Action EA — Living Technical Specification
**Document ID:** SPEC-001
**Version:** 0.4.0 (STRUCTURE ENGINE IMPLEMENTED)
**Last updated:** 2026-10-31
**Owner:** ApexQuant-Engine (Quant Supervisor sign-off required before code release)
**Status:** 🟢 Q1–Q4 resolved. Foundation + structure engine built and tested (38/38).
**Architecture:** multi-asset, symbol-agnostic core + per-symbol parameter profiles.

**Source authority order:**
1. `sovereign_price_action_rule_book.md` (v1.0) — **contractual**. Numerical thresholds and risk limits are binding.
2. `The_Complete_Price_Action_Course_4_Hours.md` (JeaFX raw transcript, ~87,600 words) — **methodological**. Defines *what the concepts actually mean* and how they are sequenced.
3. This spec — reconciliation layer. Where 1 and 2 conflict, the conflict is logged in §11 and **resolved by explicit user decision**, never silently.

---

## 1. Trading Philosophy (non-negotiable orientation)

The system is a **context → confirmation → execution** machine, not a signal generator.

> "So, if you ask me what makes a perfect entry, it's these three things... the actual route of creating those results is going to be through the context, confirmation and execution." — JeaFX, *Perfect Entry* episode

Consequences for the codebase:

- **No indicator-stack crossovers.** Trend is read from *real price structure* (direction of swing highs/lows), never from moving averages.
- **Wicks never confirm anything.** Only **candle-body closes** validate breaks, shifts, reversals and continuations. This is the single most repeatedly emphasised rule in the source material.
- **We buy discount, we sell premium.** Entries are placed only on corrective legs, never on the impulsive extension.
- **The edge is probability, not certainty.** The EA optimises for *selectivity* (trade rejection) far more than for signal count.

---

## 2. Objective Definitions (implemented as pure functions, unit-tested)

All definitions operate on a *closed-bar* data model: **bar 0 = current forming bar; all logic reads bar 1 and older** (see §8.4 no-repaint rule).

| ID | Concept | Formula / Rule | Source |
|----|---------|----------------|--------|
| D-01 | ATR | ATR(14) on the reference timeframe | RB 1.1 |
| D-02 | Impulsive candle | `abs(Close-Open) >= 1.8 × ATR14` | RB 1.2 |
| D-03 | Impulsive leg | ≥ 2 consecutive same-direction candles **with at least one D-02 candle**, closing beyond the origin of the leg | RB 1.2 + transcript |
| D-04 | Indecision candle (strict) | `body <= 35% of (High-Low)` **AND** `upperWick >= 25%` **AND** `lowerWick >= 25%` of range | RB 1.3 |
| D-05 | Indecision candle (JeaFX / default-candidate) | "the last candle before the impulse" — **no shape filter applied** | transcript, S&D Masterclass |
| D-06 | Imbalance — ICT FVG mode | **IMPLEMENTED 2026-11-02** as `FindImbalance()`: size ≥ `InpFvgMinATR × ATR` (default 0.15, see measurement note), gap within 3 bars of the order block, and **not yet filled**. Bull: `Low[3] - High[1] >= threshold`. Bear: `High[3] - Low[1] >= 0.5 × ATR14`. Filled when any later wick overlaps the gap. | RB 1.4 |
| D-07 | Imbalance — JeaFX range mode | Open, unretraced price range between the POI candle's **extreme wick** and the furthest point of the impulse. Filled when price trades back through any part of that range. | transcript, *Market Efficiency* |
| D-08 | Structural swing high/low (legacy) | Fractal pivot with `k` bars either side. **SUPERSEDED by D-08b in v0.5.0** — retained only because the D-14 tests exercise it directly. A fractal never asks whether the move was large enough to matter, and on M5 it produced a pivot every ~4 bars. | derived |
| D-08b | **Significant** swing high/low — ATR-ZigZag (current) | A swing is emitted only after price retraces at least `InpMinSwingATR × ATR14` from the extreme; the still-running extreme is **never** emitted. Output strictly alternates H/L. Wilder ATR is computed inside the module from the closed-bar series — no indicator handle, no new library dependency. **Default `InpMinSwingATR = 4.0`**, chosen from measured density on real M5/M15/H1 bars (see changelog [0.5.0]): 12 bars/swing on M5, 20 on M15, 42 on H1. 1.5× was measurably *worse than the fractal* it replaced, and 2.5× was no better than it on M5. Lower to 3.0 for more granularity, raise to 6.0 for major swings only. Non-repainting by construction. | derived; supersedes D-08 |
| D-09 | BOS / MSS | **Body close** beyond the prior structural swing high (bullish) or low (bearish). A wick through the level is **not** a BOS — it is a **liquidity sweep**. | RB 1.5 + transcript *BoS vs Liquidity Sweep* |
| D-10 | Liquidity sweep | Wick pierces swing high/low or equal highs/lows, then **closes back inside** the prior range | RB 1.5 |
| D-11 | Equal highs/lows | Two or more swings within `tol = 0.15 × ATR14` of each other | derived (needs confirmation) |
| D-12 | Valid (fresh) zone | Zero touches since creation; invalidated on the **first** wick touch. Never re-used. | RB 3.2 |
| D-13 | Zone boundaries | Extreme High→Low **including all wicks** of the base candle(s) | RB 3.1 |
| D-14 | Internal-structure caveat | A break of an *internal* low is only tradable if a **higher high was printed first**, then the low broke on a **body close** (HH → LL sequence). A break inside an unfinished corrective leg is **noise** and must be filtered. **IMPLEMENTED** in `SPA_Structure::IsValidShift()`. | transcript, *Market Structure* |
| D-15 | Session extremes (sweep targets) | Asia range high/low, previous-day high/low, session open — optional sweep pool | derived |

---

## 3. Timeframe Hierarchy

Timeframes are **per-symbol parameters**, not constants (Decision Q1). Defaults are suggested per asset class in `data/symbol_profiles.csv`.

| Layer | Default (FX / Gold) | Responsibility |
|-------|---------------------|----------------|
| HTF / Bias | **H4** (H1 fallback) | Directional bias, major S/D zones, unfilled imbalances, extreme-zone ranking |
| Intermediate | **M15** | Monitor approach to HTF POI; confirm internal/session liquidity sweep |
| Execution | **M5** (M1 optional) | MSS body close → LTF order-block marking → limit placement |

Fractal principle: the same detection functions run on every layer. **No layer may be hard-coded to a specific timeframe string** — all TF-dependent logic takes a `timeframe` argument. Crypto (BTCUSD) may run H4→M15→M5 unchanged; indices may prefer H1→M5→M1 (profile-driven).

### 3.1 Cross-asset normalisation principle (critical)
Every threshold in this system is expressed as a **multiple of ATR14 on the frame it is evaluated on**, never in raw points/pips. ATR is scale-free, so one parameter set generalises across EURUSD, XAUUSD, USDJPY and BTCUSD. The **only** instrument-specific values allowed are those in the symbol profile (§7.3): pip definition, cost ceilings, and liquidity gate strength. Any new parameter proposed in raw pips during development must be justified or converted to ATR units before it is accepted.

---

## 4. Zone Construction & Selection Engine

### 4.1 Zone creation
A **Demand** zone is created when a base candle (§2, D-04 or D-05 depending on Decision **Q2**) is immediately followed by a bullish impulsive leg (D-03). **Supply** is the mirror.

Boundaries = base candle extreme high/low **including wicks** (D-13).

### 4.2 Validity filter (all must hold)
1. **Direction agreement** — demand only in HTF uptrend, supply only in HTF downtrend. Counter-trend zones are discarded at creation, not at entry.
2. **Imbalance present** — per D-06 or D-07 (Decision **Q2**). This is a *creation-time* filter: once the imbalance fills, the zone dies even if never tapped.
3. **Freshness** — 0 touches (D-12).
4. **Zone width sanity** — `width <= 1.5 × ATR14` (rejects runaway/consolidation blobs). *(New guard, not in rule book — Supervisor addition, §9.)*

### 4.3 Extreme-zone priority
Among valid zones in the same swing leg, rank by distance from current price; select the **furthest valid zone that still holds an unfilled imbalance** (RB 3.3). This enforces "better price" and maximises RR — the transcript's core argument for buying corrective legs.

### 4.4 Zone lifecycle (explicit state machine)
```
CREATED ──► VALID ──► (imbalance filled) ──► DEAD_IMBALANCE
                     └► (wick touch) ─────► DEAD_TAPPED
                     └► (HTF bias flip) ──► DEAD_BIAS
                     └► (age > N bars) ───► DEAD_STALE   (configurable, default off)
```

---

## 5. Entry State Machine (the heart of the EA)

```
IDLE
 └─ HTF bias resolved & not consolidating ────────────────► ARMED
ARMED  (price within approach_distance × ATR of a VALID HTF POI)
 └─ confirmation-TF sweep of internal/session extreme ────► SWEPT
SWEPT  (validity window: W bars, default 10 on M5-equivalent)
 └─ exec-TF MSS body close in bias direction ─────────────► SHIFTED
SHIFTED
 └─ mark LTF order block (last opposite-close / indecision candle
    preceding the MSS impulse) ──────────────────────────► PENDING
PENDING
 └─ pre-trade risk gate passes (all of §6) ───────────────► ORDER_PLACED
 └─ any gate fails ───────────────────────────────────────► REJECTED (logged)
ORDER_PLACED
 └─ fill ─────────────────────────────────────────────────► IN_TRADE
 └─ zone tapped earlier than limit / sweep low body-closed ─► CANCELLED
IN_TRADE ──► partial at 2R + SL→BE ──► runner to final target / BE stop
```

**Failure/abort conditions (must all be implemented):**
- MSS body close back through the sweep extreme ⇒ setup void, cancel pending.
- Zone becomes tapped by any other price action before the limit fills ⇒ cancel.
- Bias flips on HTF while pending ⇒ cancel.
- Session window closes ⇒ cancel pending orders (RB 4.1).
- Hard time-stop on pending order (`OrderExpiration`), default end of current session.

---

## 6. Risk Engine (binding — Supervisor will reject any deviation)

| ID | Rule | Value |
|----|------|-------|
| R-01 | Risk per trade | **0.5% default, 1.0% hard ceiling** of account equity |
| R-02 | Lot sizing | `Lots = (Equity × Risk%) / (SL_distance_price × TickValue / TickSize)`, rounded **down** to `LOT_STEP`, clamped to `[SYMBOL_VOLUME_MIN, min(SYMBOL_VOLUME_MAX, broker max)]` |
| R-03 | Hard SL | Mandatory, server-side, attached at order send. **Never** a virtual/mental stop. |
| R-04 | SL placement (long) | `zone_low − (2.0 × current spread + 2.0 pips)`; short mirrored |
| R-05 | SL widening | **Forbidden.** Loop asserts SL only ever moves favourably. |
| R-06 | Minimum RR | `(TP − Entry) / (Entry − SL) >= 3.0` **net of commission + expected slippage**; else reject trade |
| R-07 | 2R management | Close 50% at 2R; move SL to breakeven (entry) |
| R-08 | Final target | Opposite HTF POI / opposing equal highs-lows / major liquidity pool |
| R-09 | Daily circuit breaker | `realised_loss_today >= 3.0% equity_at_day_start` ⇒ suspend new entries 24h |
| R-10a | Spread guard — **coarse** (per tick) | `spread_price > profile.spread_pips_ceiling × pip` ⇒ no entry, no pending placement. Cheap pre-filter; catches news blow-outs and the Asian close. |
| R-10b | Spread guard — **cost of risk** (at placement) | `spread_price > profile.max_spread_of_risk × SL_distance` ⇒ reject. *This is the binding gate.* A 1.5-pip spread against a 20-pip stop costs 7.5% of risk and is fine; against a 6-pip stop it costs 25% and the 3R target becomes fiction. Symbol-agnostic because both terms are in price units. |
| R-11 | Concurrency | Max **1** open position per symbol; max **1** pending per zone; **global** open risk capped (default 3.0% across all symbols) |
| R-12 | **No Martingale. No grid. No averaging down. No hedging.** | Architecture must make these structurally impossible |
| R-13 | Broker min-stop respect | `SL_dist >= SYMBOL_TRADE_STOPS_LEVEL + SYMBOL_TRADE_FREEZE_LEVEL`; else widen *logically and re-size lot* rather than skip, then re-validate R-06 |
| R-14 | **Correlated-basket cap** | Symbols sharing a base/quote currency (EURUSD+GBPUSD+EURGBP) or benchmark (BTCUSD/ETHUSD) are treated as **one risk unit**: aggregate exposure across a correlated cluster ≤ 1× single-trade risk. Prevents six "independent" EUR shorts. |
| R-15 | **Volatility-scaled risk** | Optional: `risk_pct_eff = risk_pct × clamp(ATR14_current / ATR14_median_100, 0.5, 1.5)`. Guarded, capped, off by default pending IS evidence. |

---

## 7. Execution Constraints

### 7.1 Entry level arithmetic (Decision Q4 — transcript-faithful)
> *"The entry. This is simply going to go on the demand or supply zone that your confirmation created. That is it. It's that simple."* — JeaFX, *Perfect Entry*

- **Entry = the LTF zone boundary created by the confirmation leg** (proximal edge, i.e. the zone edge price reaches first). The zone is built from the last base candle preceding the MSS impulse, boundaries including wicks (D-13).
- `ENTRY_MODE` enum retained for testing: `BOUNDARY` (default, transcript-faithful) / `MIDPOINT` (50%, Rule Book §4.3 refinement) — but **BOUNDARY ships as default**.
- **Rule Book §4.4 (direct limit without LTF confirmation) is DISABLED permanently** and remains flag-gated `allow_direct_limit = false`. Rationale: the transcript explicitly rejects it — *"we don't generally want to just sell straight into the market. It's better to see a confirmation."* This one is not a preference; it is a documented contradiction of the mentor's method.
- **No market-order entry** at MSS close (default OFF): a market fill destroys the RR that the whole method is built on.

### 7.2 Dynamic Liquidity Window (Decision Q3 — replaces fixed session windows)
The Rule Book's fixed London/NY windows are **superseded** by user authorisation. The methodology contains no session rules, and a fixed window is wrong for a multi-asset basket (XAU moves on NY, USDJPY and AUD-crosses move in Asia, BTCUSD trades 24/7).

**The gate is "is this hour liquid *for this instrument*", evaluated empirically, not by clock arithmetic:**

```
LIQUID  IF  vol_percentile(hour_of_day) >= profile.liquidity_pct_min
        AND spread_cost <= profile ceiling                      (R-10)
        AND ATR14_exec >= profile.min_atr_floor                 (dead-market guard)
        AND abs(Close - Open) of last M15 >= profile.min_body_atr
```

- `vol_percentile(hour_of_day)` = percentile rank of the current clock-hour's mean tick-volume against the last `vol_lookback_days` (default 40) of the same instrument, computed once per day on the broker's own tick data. Signed against **broker server time**, so it self-corrects for DST and offset without a GMT resolver.
- This is strictly **more selective** than a fixed window, not less: it admits the Asian session for USDJPY when Tokyo is genuinely active, and excludes 08:00 GMT for an instrument that is asleep at that hour.
- **The fixed-window module is retained** as `session_mode = FIXED`, off by default, purely so Gate G-7 can A/B its contribution. If it doesn't earn its place, it gets deleted, not deprecated-in-perpetuity.
- **News blackout** (optional, default ON for FX/gold): no *new* entries within ±N minutes of high-impact calendar events. Held positions managed normally.

### 7.3 Symbol profile system (Decision Q1)
A single `.set` file per group, not per symbol, driven by `data/symbol_profiles.csv`:

| Column | Meaning |
|---|---|
| `symbol_pattern` | wildcard match, e.g. `EURUSD`, `USDJPY`, `XAU*`, `BTC*`, `US30` |
| `pip_size` | `0` = auto-derive (10×point for 3/5-digit FX); else explicit (XAU 0.1, BTC 1.0, indices 1.0) |
| `tf_bias / tf_confirm / tf_exec` | timeframe stack |
| `risk_pct` | per-trade risk |
| `spread_pips_ceiling` / `max_spread_of_risk` | R-10a coarse pip ceiling / R-10b cost-of-risk fraction |
| `min_atr_floor_atr` | dead-market guard (ATR14 / median ATR) |
| `liquidity_pct_min` | dynamic window strength (§7.2) |
| `swing_k` | fractal pivot strength |
| `sl_spread_mult` / `sl_buffer_atr` | R-04 |
| `min_rr` | R-06 |
| `max_zone_width_atr` | §4.2 sanity guard |
| `entry_mode` | `BOUNDARY` / `MIDPOINT` |
| `enabled` | master switch |

Precedence: **global defaults → csv row (wildcard, most-specific wins) → attached `.set` inputs**. Every value is visible and overridable in the EA's Inputs tab; nothing is hidden in code.

### 7.4 Order mechanics
- **Pending order type:** `BuyLimit`/`SellLimit`; `OrderExpiration` at the end of the current liquidity window.
- **Filling mode:** auto-detect `SYMBOL_FILLING_FOK/IOC/RETURN` before `OrderSend` (classic silent-failure source on MT5).
- **Slippage:** `Deviation` capped in points; requote/retry budget 3 × 250 ms; `SYMBOL_TRADE_EXECUTION` capability checked at init.
- **Magic number** namespaced per symbol+profile; positions reconciled by magic only.
- **Restart resilience:** all state rebuilt from chart history on `OnInit` — nothing lives only in RAM.

---

## 8. Engineering Standards

1. **Compile-clean target:** zero errors, zero warnings on MetaEditor build 4755+ (`#property strict` equivalent discipline: explicit casts, `const` refs, no implicit double→int).
2. **Modular layout** (no 3,000-line monolith):
   ```
   experts/SovereignPA/
     SovereignPA.mq5            // orchestrator: OnTick state machine only
     Include/SPA_Config.mqh     // validated input struct
     Include/SPA_Market.mqh     // symbol/TF/spread/pip/tick abstraction
     Include/SPA_Structure.mqh  // swings, BOS, sweeps, HH/LL trend, consolidation
     Include/SPA_Zones.mqh      // S/D zone engine + lifecycle + extreme-zone ranking
     Include/SPA_Imbalance.mqh  // FVG / range-imbalance detection & fill tracking
     Include/SPA_Risk.mqh       // lot size, RR gate, circuit breaker, SL/TP math
     Include/SPA_Execution.mqh  // order send/cancel/modify, filling modes, retries
     Include/SPA_Journal.mqh    // CSV trade journal + rejection log
   ```
3. **Deterministic & replayable:** identical bar history ⇒ identical decisions. No `Random`, no `TimeLocal()` inside logic paths.
4. **No repaint:** all decisions on **closed bars**; intrabar only for *pending-order placement* after a confirmed closed-bar MSS.
5. **Everything logged:** every rejected setup writes a reason code (e.g. `REJ_RR_LT_3`, `REJ_SPREAD`, `REJ_NO_IMBALANCE`) to CSV. This is what makes the post-mortem in `debug_log.md` possible.
6. **Python parity harness** (`tests/`) implementing D-01…D-14 identically on M1/M5 CSV so logic can be fuzzed offline and backtest results cross-checked against the EA. Divergence between Python and MQL5 = release blocker.

---

## 9. Quant Supervisor — Standing Acceptance Gates

No release leaves this workspace unless all pass.

| Gate | Metric | Threshold |
|------|--------|-----------|
| G-1 | Sharpe (annualised, on trade-return series) | **> 1.5** |
| G-2 | Profit Factor | **1.5 – 2.5** (>2.5 ⇒ suspect overfit/curve-fit; investigate) |
| G-3 | Max Drawdown | **< 10%** |
| G-4 | Min RR realised | ≥ 3.0 gross, ≥ 2.6 net of costs |
| G-5 | Trade count over test window | ≥ 100 (else statistically void) |
| G-6 | Spread/slippage stress | Results hold at **1.5× and 2×** modelled spread + 0.5 pip slippage |
| G-7 | Parameter sensitivity | ±20% on every threshold ⇒ no cliff-edge collapse in equity curve |
| G-8 | Static audit | Hard SL present 100% of trades; no averaging; session filter active; circuit breaker fires in test |

**Known architectural risks (logged, not hidden):**

1. The confluence stack (liquidity window + fresh imbalanced zone + sweep + MSS + ≥3R net) is *inherently* low-frequency. Per-symbol expectation is **2–8 trades/week**; across a 12-symbol basket that is a healthy 15–40 setups/week, which is the actual argument for going multi-asset (Q1).
2. **Multi-asset raises false-diversification risk.** Six correlated USD shorts is one trade with six commissions. R-14 (correlated-basket cap) is mandatory, not cosmetic — without it the 3% daily breaker can be tripped by a single macro move.
3. **Per-symbol profiles multiply the overfitting surface.** Twelve symbols × fourteen parameters is 168 knobs. Mitigation: parameters are ATR-normalised and shared by asset class (§3.1), and G-7 sensitivity is applied per asset class, not per symbol. If a symbol needs bespoke values to work, that is evidence against the symbol, not for the tuning.

---

## 10. Reference Crosswalk (Rule Book ↔ Transcript)

| Rule Book clause | Transcript teaching | Alignment | Action |
|---|---|---|---|
| 1.2 Impulse = 1.8×ATR14 | "large candle bodies with little to no wicks = clear control"; impulses are the structure-breaking moves | ✅ Compatible (numeric threshold is a formalisation) | Implement as-is |
| 1.3 Indecision = ≤35% body, ≥25%/25% wicks | "the last candle before the impulse" — explicitly **no shape filter**: *"I don't care what the candle looks like"* | ⚠️ CONFLICT | **RESOLVED** → D-05 default, D-04 as optional strict flag |
| 1.4 FVG = 3-candle, ≥0.5×ATR14 | Imbalance = *open unretraced range* from zone extreme to impulse terminus | ⚠️ CONFLICT (different objects) | **RESOLVED** → D-06 FVG validator, D-07 as alternate mode |
| 1.5 MSS = body close beyond swing | Body close only; wick beyond = liquidity sweep; internal breaks need HH→LL sequence | ✅ Compatible, transcript adds D-14 nuance | Implement both |
| 2.1 HH/HL & LL/LH, 20-candle consolidation filter | "If you don't get market structure right, everything else fails"; consolidation = do not trade | ✅ Compatible | Implement |
| 3.1 Zone = base candle, boundaries incl. wicks | Last candle before impulse; **extend box to the wick low** | ✅ Compatible | Implement D-13 |
| 3.2 One-tap freshness | "brick wall" analogy — every extra tap weakens; after first tap it's dead | ✅ Strong agreement | Implement |
| 3.3 Extreme-zone priority | Wait for the better price; RR is the point | ✅ Compatible | Implement |
| 4.1 London/NY session windows | **No session rules anywhere in 87,590 words** — JeaFX is timeframe/session agnostic | ⚠️ ADDED OVERLAY (user-imposed) | **SUPERSEDED** → Dynamic Liquidity Window (§7.2) |
| 4.2 Spread ≤ 1.5 pips | Only mentions raw-spread vs prop-firm spread in SL context; no entry filter | ⚠️ Overlay, symbol-dependent | **AMENDED** → dual pip/ATR ceiling (R-10) |
| 4.3 Entry at 50% of LTF OB | Entry = *the zone the confirmation created* | ⚠️ Partial conflict (50% is a refinement) | **RESOLVED** → BOUNDARY default; MIDPOINT configurable (§7.1) |
| 4.4 Direct limit, no confirmation | Explicitly: *"we don't generally want to just sell straight into the market. It's better to see a confirmation."* | ❌ **CONTRADICTS methodology** | **DISABLED** permanently (`allow_direct_limit = false`) |
| 5.3 SL = 2×spread + 2 pips beyond zone | "SL at the point the trade becomes invalid" — beyond the low/high, with spread allowance | ✅ Compatible | Implement |
| 5.4 TP 3R min, 50% at 2R, BE | Target = next HTF POI / opposing liquidity; "if RR isn't big enough, I wouldn't take the trade" | ✅ Compatible | Implement |
| 5.5 3% daily breaker | Not present in transcript | ➕ Supervisor/prudent addition | Implement |

---

## 11. DECISION LOG (resolved 2026-10-31)

| ID | Decision | Resolution | Deviation from Rule Book? |
|----|----------|-----------|---------------------------|
| **Q1** | Instrument scope | **Multi-asset**: all FX pairs + XAUUSD + BTCUSD + indices, via a symbol-agnostic ATR-normalised core and per-symbol profiles (§7.3) | ➕ Expanded scope; no conflict |
| **Q2** | Zone base + imbalance | **Hybrid, configurable**: JeaFX base candle (D-05, "last candle before the impulse") + Rule Book FVG validator (D-06, 3-candle ≥0.5×ATR14). Both switchable so the edge can be A/B tested | ⚠️ Partially overrides RB 1.3 (indecision shape filter becomes optional) |
| **Q3** | Session filter | **Replaced** by the **Dynamic Liquidity Window** (§7.2): empirical per-instrument hour-of-day volume percentile + spread + dead-market guards. Fixed windows retained as an off-by-default A/B mode | 🔴 **Supersedes RB 4.1** — explicitly authorised by user |
| **Q4** | Entry arithmetic | **Transcript-faithful**: entry at the LTF zone boundary created by the confirmation. `MIDPOINT` retained as a test mode. Rule Book §4.4 direct-limit **permanently disabled** | ⚠️ Overrides RB 4.3/4.4; aligns with source methodology |

**Standing rule:** any future deviation from either source document is recorded here with its justification before code is written. Silent divergence is a Supervisor rejection.

**Implemented 2026-11-01:** D-09, D-10, D-14, RB 2.1 (trend + consolidation) in `SPA_Structure.mqh`.
**Implemented 2026-11-02 (v0.5.0):** D-08b replaces D-08 — significance-filtered ATR-ZigZag swings, `InpMinSwingATR = 4.0`. 24 structure tests green, including a line-for-line MQL5/Python parity test.

**Still to be confirmed during the build (non-blocking):** swing `k` per asset class, sweep validity window `W`, zone max age, global risk cap (3.0% proposed, R-11), correlation-cluster definitions for R-14, news-blackout source (MT5 economic calendar vs manual CSV).

---

## 12. Backtest Protocol (defined before any test is run)

1. **Data:** broker-native M1 history, ≥ 3 years, with realistic spread model (variable, session-weighted) — not "every tick with fixed spread".
2. **IS/OOS split:** 60% in-sample / 25% out-of-sample / 15% walk-forward; OOS is opened **once**.
3. **Costs modelled:** commission + spread + 0.5 pip slippage + 1-bar delay on limit fills during high-volatility windows.
4. **Rejection:** If OOS Sharpe < 0.8 or DD > 12%, the parameter set is discarded — **not** re-optimised on OOS.
5. **Log:** every test appended to `debug_log.md` with symbol, date range, modelling quality, trade count, and the G-1…G-8 verdict.

---

*End of SPEC-001 v0.1.0 — awaiting decisions Q1–Q4.*

**Rendering rules (v0.5.1, binding):**
- **R-16** — structure from a timeframe **finer than the chart** is never drawn. One M5 swing inside a Weekly candle is invisible, not small; drawing it produces a pile of overlapping arrows. `ShouldDrawTF()` enforces `PeriodSeconds(structure_tf) >= PeriodSeconds(chart_tf)`.
- **R-17** — no chart object may be given an empty `OBJPROP_TEXT`; MT5 renders it as the default caption "Label". Use a single space for spacer rows.

## §12 Entry engine — v0.6.0 (decisions of 2026-11-02)

Recorded verbatim from the user, because these override the rule book:

- **D-A — the zone.** "the last candle before the impulse, but this candle has to have a clear imbalance that comes after it… there might be multiple of these in a zone… we use the zone with that magnet." → order block **mandatory**, imbalance **mandatory**, and when several zones qualify the one with the better structural target wins.
- **D-B — where in the zone.** "we usually put the order at the first touch." → entry at the **near edge**.
- **D-C — momentum into the zone.** "skip this for now but it's very helpful." → **not implemented**; the gate exists in the design (G-3) and is scheduled for v0.6.2.
- **D-D — the exit.** "hybrid… overall TP bias structural… trailing on reasonable areas." → structural target, 50% at 2R, stop to breakeven, remainder trails behind structure (trailing is v0.7.0, with orders).

New rules derived during the build:

| ID | Rule | Why |
|---|---|---|
| **R-18** | The target is the nearer of the **confirm** and **bias** first unresolved levels. | A target is only honest if it is the first thing in the way. Bias-only targets produced a 21R trade on gold — a mis-specified trade, not a good one. |
| **R-19** | A zone whose stop distance is under `InpMinRiskATR (0.5) × ATR` is **skipped, never widened**. | Order blocks are often smaller than one average bar. A stop inside the noise is a guaranteed loss. Widening it would break the invalidation rule. |
| **R-20** | A zone untouched for `InpZoneMaxAge (200)` bars expires. | Freshness (price has not returned) is not the same as currency. A 522-bar-old zone is abandoned, not fresh. |
| **R-21** | No bias direction → `REJ_NO_TREND`, not `REJ_NO_ZONE`. | The reason code must name the real cause, or the panel teaches the wrong lesson. |

**Rejection codes in use:** `REJ_NO_TREND`, `REJ_NO_ZONE`, `REJ_NO_FRESH_ZONE`, `REJ_NO_TARGET`, `REJ_RR`, `REJ_SL_TOO_TIGHT`, `REJ_NO_LOT`.

**Not yet implemented:** G-3 (momentum), G-4 (sweep) and G-5 (MSS) as *entry preconditions*. Until v0.6.1 the stop sits at the order-block far edge rather than the sweep low.
- **D-E — WHICH zone is live (2026-11-02).** "another pullback, it retests the last candle before the impulse… then it goes down to our zone." → **only the newest structural break in each direction produces a live zone.** An older untouched zone is not an opportunity; it is a level the market has already passed. Zones are built on the timeframe **above** the entry (`InpZoneTF`, default CONFIRM), never on the exec timeframe alone — M5 order blocks are micro-structure, not supply and demand.
- **D-06 threshold deviation (OPEN, awaiting user decision).** SPEC-001 says 0.5 × ATR14. Measured on real data, 0.5 finds essentially zero zones on FX M15/H1, and the clearly-visible gap in the live example measures 0.31 × ATR. Shipped default is **0.15**, exposed as `InpFvgMinATR`. This deviation is recorded here rather than silently applied.
