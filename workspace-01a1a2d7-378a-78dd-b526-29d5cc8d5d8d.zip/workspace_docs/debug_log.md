# Debug Log — Sovereign Price-Action EA

Purpose: compilation warnings, runtime faults, backtest errors, optimisation results, and **post-mortem analysis of losing trades**. One entry per event, newest last.

Log entry template:

```
### [YYYY-MM-DD] [TYPE] [ID]
Component:
Symptom:
Root cause:
Fix / Action:
Verification:
Status: OPEN | FIXED | WONTFIX
```

Types: `COMPILE` · `RUNTIME` · `BACKTEST` · `LOGIC` · `DATA` · `POST-MORTEM` · `OPTIMISATION`

---

## 2026-10-31

### [2026-10-31] [DATA] DQ-001 — Transcript corpus is multi-document and lossy
**Component:** reference corpus ingestion
**Symptom:** `The_Complete_Price_Action_Course_4_Hours.md` is not one course. It contains at least 20 concatenated auto-transcribed videos separated by TurboScribe boilerplate (`Transcribed by TurboScribe . Go Unlimited to remove this message.`), plus stray replacement characters (``). Text is CRLF-wrapped mid-sentence and exhibits heavy phrase duplication (e.g. *"we are going to be going through"* repeated across line breaks), which is an artefact of overlapping caption windows.
**Root cause:** machine transcription of a video series, concatenated without segmentation.
**Fix / Action:** normalised to a single flat token stream (`\r\n`→space, whitespace collapsed: 87,590 words) for semantic search. All spec citations to the transcript are recorded as **character offsets into the flattened stream**, not line numbers, so they remain reproducible.
**Verification:** keyword frequency confirms topical coverage — `liquidity` ×203, `imbalance` ×134, `supply and demand` ×80, `stop loss` ×82, `market structure` ×32, `top-down` ×15, `fair value gap` ×3, `order block` ×0.
**Status:** FIXED (workaround), corpus retained verbatim in `uploads/`.

### [2026-10-31] [LOGIC] L-001 — Terminology drift: no "order block" in source material
**Component:** SPEC §5 (entry state machine)
**Symptom:** The Rule Book (§4.3) instructs "Mark the new LTF Order Block created by the MSS impulse" and "place a Limit Order at the 50% Equilibrium level of the LTF OB". The transcript uses **"order block" zero times** and **"equilibrium" zero times**; its entry object is the **supply/demand zone created by the confirmation**.
**Root cause:** the Rule Book imports ICT vocabulary that JeaFX's framework does not use. The two should map to each other, but the construction rule differs (last-opposite-candle vs last-indecision-candle-before-impulse).
**Fix / Action:** treat "LTF order block" as **the same object as a supply/demand zone detected on the execution timeframe**, constructed with the *same* D-04/D-05 base-candle rule (pending Q2). Do not silently adopt ICT order-block construction (last down-candle before an up-move) — that would contradict both sources.
**Verification:** crosswalk row 3.1 / 4.3 in SPEC §10.
**Status:** OPEN — awaiting Q2/Q4.

### [2026-10-31] [LOGIC] L-002 — Internal-structure trap is not covered by the Rule Book
**Component:** SPEC D-09 / D-14
**Symptom:** Rule Book §1.5 defines MSS purely as "a candle-body close beyond the previous structural Swing High or Swing Low". Applied literally to *internal* structure, this produces false reversals inside an unfinished corrective leg — precisely the failure mode the transcript warns about: *"they will treat this break as a place to sell from... But it's not, because this in itself is still not a valid structural move. This all is just a correction lower."*
**Root cause:** the Rule Book does not distinguish **swing structure** from **internal/substructure**, and does not require the HH→LL sequence before validating a shift.
**Fix / Action:** D-14 added — an internal break is only tradable if a higher high was printed first, then the low broke. MSS evaluation must run against *swing* structure, not raw local pivots.
**Verification:** requires unit test `test_no_mss_inside_correction` (to be written with the structure module).
**Status:** OPEN — logic specified, not yet implemented.

### [2026-10-31] [LOGIC] L-003 — Session filter has no foundation in the source methodology
**Component:** SPEC §7
**Symptom:** Rule Book §4.1 mandates London 07:00–10:30 GMT and NY 12:30–16:00 GMT with no entries outside. The word "session" appears 3 times in 87,590 words and **never** in a time-of-day context; "London" and "New York" appear **zero** times.
**Root cause:** the session filter is a user/risk overlay layered on top of a session-agnostic methodology.
**Fix / Action:** implement as a **first-class, independently toggleable module** with DST-aware GMT conversion, not as a buried `if`. This locks in the ability to A/B the filter's contribution during backtesting (Gate G-7), which is the only way to prove it earns its place.
**Verification:** pending Q3.
**Status:** OPEN — awaiting Q3.

### [2026-10-31] [POST-MORTEM] PM-000 — Pre-registered failure hypotheses
**Component:** strategy as a whole
**Symptom:** N/A — pre-registration, not a live failure.
**Root cause / hypotheses to test first when the first backtest lands:**
1. **Wick-touch invalidation is too strict.** RB 3.2 kills a zone on *any* wick touch. In live EURUSD, 0.1-pip wicks will kill zones the market then respects. Prediction: raising the touch tolerance to ~0.1×ATR will materially improve trade count without degrading PF. Test only in IS.
2. **Limit at 50% of zone never fills on impulsive legs.** Counter-trend limits need a retrace; a strong leg may only ever touch the zone boundary. Prediction: 50% entry will cut fill rate ~40% vs boundary entry while raising RR ~1.4×. Must be measured, not assumed.
3. **3R-minimum interacts badly with the extreme-zone rule.** The furthest zone maximises RR *and* minimises fill probability. Prediction: silently zero-trade on quiet months — check trade-count distribution per month (Gate G-5).
4. **Server-side SL at "2×spread + 2 pips" is spread-dependent and therefore non-deterministic** across brokers/sessions. Prediction: identical signals producing different lot sizes across sessions. Mitigation candidate: `max(2×spread+2pips, 0.25×ATR14)`.
**Status:** OPEN — each hypothesis gets a dedicated test in the IS window.

---

### [2026-10-31] [LOGIC] D-002 — Spread gate formulated as an ATR ratio was structurally wrong
**Component:** `SPA_Symbol.mqh :: SpreadOK()` (superseded by `SpreadOKCoarse` + `SpreadOKAtRisk`)
**Symptom:** Python parity harness, `test_gold_normal_spread_passes`, failed: a normal $0.25 gold spread was rejected against a $10 ATR at a 12% ceiling. Investigation showed the problem was far larger than gold.
**Root cause:** the gate compared spread to ATR, but **spread/ATR differs by an order of magnitude between asset classes**:

| Symbol | typical spread / ATR(M15) |
|---|---|
| EURUSD | 0.32 |
| USDJPY | 0.33 |
| XAUUSD | 0.05 |
| BTCUSD | 0.30 |
| US30 | 0.03 |

The shipped ceilings of 0.10–0.12 therefore rejected **every FX pair under normal conditions** while waving through gold and index spreads that are far more costly relative to the risk actually taken.
**Fix / Action:** split the gate.
- **R-10a (coarse)** — pure pip ceiling, per symbol. Cheap per-tick pre-filter.
- **R-10b (binding)** — `spread ≤ max_spread_of_risk × SL_distance`. Cost is only meaningful relative to risk. Symbol-agnostic because both terms are price units.

Column 8 of `symbol_profiles.csv` renamed `spread_atr_ceiling` → `max_spread_of_risk`.
**Verification:** `tests/test_symbol_math.py` — 21 tests pass, including `TestEnabledProfilesSurviveNormalMarket`, a regression that walks every enabled CSV row and asserts it clears both gates under realistic conditions *and* rejects a 10× news spike. This test is the guard against the defect recurring.
**Status:** FIXED

### [2026-10-31] [POST-MORTEM] PM-001 — Why the defect survived to the harness
**Component:** development process
**Symptom:** A gate that rejects 100% of a whole asset class was written and shipped into a module without objection.
**Root cause:** thresholds were reasoned about in the abstract ("12% of ATR sounds prudent") instead of against representative numeric market conditions per instrument. Nothing forced the numbers to touch reality.
**Fix / Action:** standing rule adopted — **no threshold may enter a module without a test case that shows it (a) passing under normal market conditions and (b) rejecting under stressed conditions.** Declared constants without a paired test are now a Supervisor rejection, the same as a missing stop loss.
**Status:** FIXED (process rule)

### [2026-10-31] [COMPILE] C-001 — `SPA_Config.mqh` / `SPA_Symbol.mqh` not yet compiler-verified
**Component:** MQL5 modules
**Symptom:** No MetaEditor in this environment; the files are written to the MQL5 language reference but have not been compiled.
**Root cause:** sandbox limitation, not a code defect.
**Fix / Action:** arithmetic mirrored and unit-tested in Python (`tests/test_symbol_math.py`, 21/21 green). Structural risks remain: `struct` copies returned by value in `Profile()`, `const` method qualifiers, and `FileReadString` loop termination on `FILE_TXT`.
**Verification:** ✅ **CLOSED 2026-10-31.** User compiled both modules in MetaEditor:
- `SPA_Symbol.mqh` → **0 errors, 0 warnings**, 29 ms, cpu='AVX2 + FMA3'
- `SPA_Config.mqh` → **0 errors, 0 warnings**, 54 ms, cpu='AVX2 + FMA3'

Note: compiling an `.mqh` in MetaEditor is a *syntax check*, not an EA build. The real gate is compiling `SovereignPA.mq5` (v0.3.0), which is now the outstanding compile task.
**Status:** FIXED

### [2026-10-31] [PROCESS] P-001 — User uncertainty about file placement, saving and single-vs-multi file
**Component:** developer workflow / handover documentation
**Symptom:** After two clean compiles the user's response was *"I don't know if I have saved them or if they are not saved... I thought it would be one document, one file. Does it have to be multiple?"*
**Root cause:** Two genuine failures on my side.
1. **No delivery protocol.** I handed over files with no installation map, no compile-torun path, and no definition of "done". The user had to infer the workflow.
2. **No architecture rationale.** The modular layout was presented as a fait accompli rather than as a decision with a trade-off. A user who does not understand *why* the files are split cannot verify they are in the right place — and cannot judge later whether a change is safe.
**Fix / Action:**
- `workspace_docs/SETUP_GUIDE.md` written: exact folder tree, 10 install steps, the expected Experts-tab output with all three field checks, an explicit "did it save?" signal table, an update protocol for every future version, and a troubleshooting table keyed to real error strings.
- `tools/build_single_file.py` added so the legitimate "one file" preference is satisfied by a *generated* artifact (`release/SovereignPA_single.mq5`) rather than by degrading the source architecture.
- The `.mqh` vs `.mq5` distinction is now stated plainly: an `.mqh` has no `OnTick`, cannot run, and is never the file you click.
**Standing rule adopted:** every release now ships with (a) the file map, (b) the exact compile target, (c) the expected output, (d) what to do if it doesn't match. A code drop without these is an incomplete delivery.
**Status:** FIXED

### [2026-10-31] [COMPILE] W-001 — `#property version` rejected by Market format validator
**Component:** `SovereignPA.mq5` line 19
**Symptom:**
```
warning: version '0.300' is incompatible with MQL5 Market, must be xxx.yyy
SovereignPA.mq5  19  11
0 errors, 1 warnings, 951 ms elapsed
```
**Root cause:** MetaEditor validates `#property version` against the MQL5 Market string format `xxx.yyy` (exactly three digits, dot, exactly three digits). Our semantic version `"0.300"` is `d.ddd` and therefore fails. The check is a *publication* constraint applied at compile time; it has no effect on the generated `.ex5`.
**Fix / Action:**
1. Removed `#property version` from the source. It is an optional property.
2. Chose **not** to reformat to `"000.301"`. A version string exists to communicate a version; encoding `v0.3.1` as `000.301` makes the artifact lie in order to satisfy a validator. Worse, it would drift from `changelog.md` and the Python package convention, creating a second source of truth.
3. Version now lives in `#define SPA_VERSION "0.3.1"`, printed at `OnInit`. The Experts log therefore always states exactly which build is running — which is strictly more useful than a property only visible in the EA's Properties dialog.
4. Source comment records the Market-format requirement for future publication.
**Verification:** Static pre-flight — no active `#property version` directive remains (grep confirms only a `//---` comment references it); 0 brace/paren imbalance; 21/21 parity tests green.
**Status:** FIXED — awaiting user recompile confirmation.

### [2026-10-31] [COMPILE] W-002 — Preventive: implicit long->bool conversions
**Component:** `SPA_Symbol.mqh :: TradingPermitted()` / `FillingMode()`
**Symptom:** None observed. Hardened pre-emptively.
**Root cause:** `TerminalInfoInteger`, `MQLInfoInteger` and `AccountInfoInteger` return `long`; using them directly in `if(!x)` relies on implicit conversion. Likewise `(m_fill_flags & SYMBOL_FILLING_IOC)` mixes `long` with an enum. Both are warning candidates on stricter builds and on other MT5 versions.
**Fix / Action:** explicit `==0` comparisons; bitmask cast to `int` before `&`.
**Verification:** grep for `if(!(Terminal|MQL|Account|Symbol)InfoInteger` returns 0 matches.
**Status:** FIXED

### [2026-11-01] [DIAGNOSTIC] R-001 — R-10b reported as "the one with the problem" (EURUSD)
**Component:** `SovereignPA.mq5` diagnostics / R-10b gate
**Symptom:** User: *"pip is fine for eurusd, lots is 0.75%, i think the rb is the one with the problem"*, quoting the config line `R-10b 15.0% of SL distance`. Journal stamp `2026.11.02 00:29:04`.
**Analysis:**
- Local Kampala (UTC+3) 00:29 -> **21:29 GMT**. If the stamp is broker server time (GMT+2/+3) -> **21:29-22:29 GMT**. Both land inside the **daily swap/rollover window (~21:00-23:00 GMT)**, where EURUSD spreads widen 3-10x.
- Worked example, 20-pip illustrative SL: 0.8 pips -> 4.0% PASS (normal London). 8 pips -> 40% BLOCK (rollover). The gate is behaving as designed; the *context* was missing from the output.
- Secondary possibility: the user is reading "15.0%" as an arbitrary/incorrect ceiling rather than as a ratio limit.
**Root cause:** diagnostic output was insufficiently self-explanatory. It printed a raw percentage with no baseline, no clock context, and no statement that the SL was hypothetical. A number without its reference frame is not information.
**Fix / Action:** v0.3.2 adds the spread-regime classifier (current vs the symbol's own 200-bar M1 median), a server-vs-GMT clock line, and full arithmetic on the R-10b line plus an explicit "illustrative SL" note.
**Deliberately NOT done:** did not relax the 15% threshold. One observation inside a known pathological window is not evidence of miscalibration; relaxing a risk gate on that basis is how a system gets curve-fitted into unprofitability.
**Verification:** awaiting user re-run at a normal session hour with the new build.
**Status:** OPEN - pending data

### [2026-11-01] [PROCESS] P-002 - User could not tell the EA was running; mistook ceiling for measurement
**Component:** EA observability + documentation
**Symptom:** *"I haven't seen anything happening... I don't know how to execute it or anything like that... I haven't seen the agent do anything yet."* Also: *"you told me RB has to be maybe 8% or something... I went and I saw that RB is 8-something"* while the config line reads `R-10b 15.0%`.
**Root cause - two distinct failures:**
1. **No visible proof of life.** A validation build that logs to a text tab is indistinguishable from a dead EA to someone who does not yet know what to look for. "It doesn't trade" and "it isn't working" look identical on a chart with no output. The EA needs to *show* its state, not just record it.
2. **Two numbers, one line, no labels.** The log printed the measured ratio (~7.5% in my worked example) and the ceiling (15%) in a way that invited conflation. The user reasonably concluded one of them was wrong. My worked example said 1.5 pips against a 20-pip stop = 7.5% of risk; the ceiling is 15%. Both correct, different quantities.
**Fix / Action:**
- v0.3.3 adds a live colour-coded on-chart panel plus a tick counter, so liveness is observable at a glance without reading a log.
- Log and panel now read `4.0% of 20p SL (limit 15.0%)` with an explicit note distinguishing measurement from ceiling.
- SETUP_GUIDE gains a plain-language "what does running look like" section.
**Lesson recorded:** a diagnostic must answer *"is this thing working?"* in the same place the user is already looking. Directing someone to a log tab is not observability.
**Status:** FIXED

### [2026-11-01] [LOGIC] D-003 — Alternation deleted lower highs and manufactured false structure shifts
**Component:** structure engine (Python reference and MQL5 port)
**Symptom:** `test_bearish_shift_invalid_when_no_higher_high` failed. A series that printed a higher high, then a LOWER high, then broke the last low was being reported as a VALID bearish shift - precisely the trap the source methodology warns about.
**Root cause:** pipe order. `find_pivots()` applied `alternation()` before signal logic. Alternation keeps the *more extreme* of two consecutive same-type pivots:

```
raw:          H(12)  L(10)  H(13)  H(12.5)
after altern: H(12)  L(10)  H(13)          <- the 12.5 lower high is gone
```

With the 12.5 deleted, the engine saw an intact higher high (13 > 12) and validated a shift that never happened. The rendering rule was corrupting the analysis rule.
**Fix / Action:** raw pivots are now the input to every decision (labels, trend, extreme tracking, D-14). `alternation()` is retained but documented as PRESENTATION ONLY, used for drawing clean H-L-H-L legs. Regression test `TestAlternationMustNotAffectSignals` asserts both halves: the raw list must contain 12.5, the alternated list must not.
**Why this matters beyond the bug:** a visually cleaner chart and a correct analysis are not the same output, and "cleaner" is exactly the change a human is tempted to make. Any transform that improves rendering must be proven not to alter decisions.
**Status:** FIXED

### [2026-11-01] [DESIGN] D-004 — Swing detection lags by k bars (accepted, not a defect)
**Component:** structure engine
**Symptom:** None. Recorded deliberately because the user will observe it.
**Root cause:** a fractal pivot with strength k cannot be confirmed until k bars have closed to its right. With `InpSwingK = 2`, an arrow appears two bars after the swing forms.
**Decision:** accepted. Confirming a pivot at the moment it forms requires reading an unclosed bar, which repaints - and a repainting structure engine cannot be backtested honestly. The 2-bar lag is the price of a non-repainting system and is far cheaper than the alternative.
**Status:** WONTFIX (by design, documented for the user)

### [2026-11-01] [PROCESS] P-003 — "I don't see anything on the charts" was undiagnosable from the build
**Component:** EA observability (structure build v0.4.0)
**Symptom:** User reported an entirely blank chart after attaching v0.4.0. No further detail was obtainable because the build produced no on-chart signal at all in the failure case.
**Root cause:** four distinct failure modes were indistinguishable:
1. files not replaced / not compiled -> old build running
2. `OnInit` returned `INIT_FAILED` -> EA removed, chart blank, reason only in a log tab
3. structure history unavailable (`CopyHigh` returned 0 while MT5 downloaded) -> panel would read "no data", but zero pivots silently produced zero arrows
4. object creation failed -> errors were discarded because `ObjectCreate` return values were never checked
Every one of these displays as "nothing on the chart."
**Fix / Action (v0.4.1):**
- `Comment()` heartbeat: rendered by the terminal, independent of chart objects and of Algo Trading state. Presence = EA alive.
- `FatalComment()` on all 6 init failure paths: the reason appears **on the chart**.
- `[HIST]` block reporting bars loaded per timeframe and the specific likely cause of zero pivots.
- `[OBJ]` counter and per-object error logging; `ObjectCreate`/`ObjectSet*` return values now checked.
- Stale-arrow purge and redraw on any timeframe change.
**Standing rule adopted:** every module must answer "is it working?" *on the chart*, without opening a log. A diagnostic that requires the user to guess which tab to open is not a diagnostic.
**Status:** FIXED

### [2026-11-01] [PROCESS] P-004 — User pressed F7 in the MT5 terminal; nothing was compiled
**Component:** workflow / user onboarding
**Symptom:** *"i attached it to the chart ... when i pressed f7 it brought the dialogue of inputs where there is that thing where you check the box of allow algo trading then i pressed okay then nothing happened i did not even see the thing that says zero errors."*
**Root cause:** **F7 is bound to different actions in the two applications.**
- MT5 terminal -> opens the Expert Advisor properties dialog (the "Allow Algo Trading" box). Compiles nothing.
- MetaEditor -> compiles the open source file. This is the only place a build happens.
The user was in the terminal, so the chart continued running the previously compiled `.ex5`. `SPA_Structure.mqh` is a new include the old binary has never heard of, so no arrows, no panel change, no error — the new code simply was not there.
**Fix / Action:**
- SETUP_GUIDE gains a prominent callout: the F7 table (terminal vs MetaEditor), the 4-step chain (F4 -> open .mq5 -> F7 -> re-attach), and a "you are in the wrong window" tell (a dialog with an Algo Trading checkbox).
- New guide section 2.5: four observable states with the correct action for each, keyed off the version stamp in the heartbeat and panel header.
- v0.4.1 heartbeat and panel header both print `v0.4.1`, so "am I running the new build?" is answerable in one glance at the chart.
**Lesson recorded:** the delivery protocol needs to verify *which build is running*, not just whether files were copied. A version stamp visible on the chart closes that gap permanently.
**Status:** FIXED (documentation + version stamp)

### [2026-11-01] [COMPILE] C-002 — "wrong parameters count" at SovereignPA.mq5:451:17 (unresolved)
**Component:** build (user side)
**Symptom:** `wrong parameters count  SovereignPA.mq5  451  17`. Reported without the line text or the full error list.
**Investigation performed:**
- Automated audit of **every** `StringFormat` / `PrintFormat` call in all four source files: format specifiers counted with a correct `%%`-aware scanner vs. top-level argument count. Result: **0 mismatches**.
- Brace/paren balance 0 across all files; zero non-ASCII in the `.mq5`.
- Line 451 col 17 in **v0.4.1** resolves to `Comment(StringFormat("SPA v%s initialising...",SPA_VERSION));` — a call shape that is legal and that also appears at line 443 without erroring, which makes it an unlikely culprit in isolation.
**Leading hypotheses (ranked):**
1. **Build skew.** The line number does not match any construct in the audited source. The user may have compiled an older buffer, or a mixture of files from different versions (new `.mq5` with old `.mqh`, or vice versa).
2. **Text mangling.** If the file was copy-pasted out of a rendered browser view instead of downloaded, characters can be altered and line numbers become meaningless.
**Actions taken (v0.4.2):**
- All three `Comment(StringFormat(...))` call sites rewritten as `string s = StringFormat(...); Comment(s);` — removes that construct from the codebase entirely at zero functional cost.
- Single-file build (`release/SovereignPA_single.mq5`) promoted to a first-class route: one file, no `Include` folder, no version skew possible.
- SETUP_GUIDE 2.6: how to copy the **full** error list, how to jump to the offending line, error-to-cause table, and an explicit warning to **download rather than copy-paste** source files.
- SETUP_GUIDE 2.7: step-by-step single-file install.
**RESOLVED 2026-11-01 via v0.4.3** — see C-003 below.

### [2026-11-01] [COMPILE] C-003 — Root cause: `iSpread()` unavailable on the user's MetaEditor build
**Component:** `SovereignPA.mq5` OnInit, spread-regime diagnostics
**Symptom:** `wrong parameters count  SovereignPA_single.mq5  1598  17`
**Resolution method:** In the generated single file, line 1598 column 17 maps exactly to the first character of the `iSpread` identifier:
```
1234567890123456789012
   g_h_spread = iSpread(_Symbol,PERIOD_M1);
```
**Root cause:** `iSpread()` is not resolvable as a 2-argument call on this MetaEditor build. Note that `iATR(_Symbol,g_profile.tf_confirm,14)` at line 1590 — the immediately preceding indicator call of identical shape — compiled without error. That isolates the fault to `iSpread` rather than to the `i*` call convention, `_Symbol`, or `PERIOD_M1`.
**Key diagnostic insight:** the build produced **exactly one** error. MetaEditor reports all errors it finds, so a single error also proves that everything else in the file is valid — including `iTime`, the timeseries copies, all `Object*` calls, `ObjectsDeleteAll(0,prefix)`, and every format string. This retroactively validates the earlier automated specifier audit.
**Fix:** removed `iSpread()` entirely. Replaced with a self-calibrating sampler: one spread reading per M1 bar into a rolling 1440-sample buffer, median computed on demand. `ArrayRemove()` likewise replaced with a manual shift. The regime line now reads `CALIBRATING (n/30)` until it has enough data rather than computing a ratio from a single observation.
**Why removal rather than an alternative indicator call:** the feature was diagnostics-only. Any workaround (iCustom wrapper, a different indicator) would reintroduce the same class of build-portability dependency for zero trading value. Removing it makes the EA depend only on `iATR` and `iTime`, both now proven present on the target build.
**Lesson recorded:** I assumed a documented standard-library function was universally available. Function availability is a property of the *build*, not of the language. Every built-in is now treated as unproven until the user's compiler accepts it — which is why the removal also eliminated `ArrayRemove`, an unrelated function that had not yet been tested.
**Status:** FIXED — awaiting recompile confirmation

### [2026-11-02] [POST-MORTEM] C-004
Component: `tests/spa_structure_ref.py` → `find_pivots_zigzag()`
Symptom: First run of the new detector on a known 10-bar series returned 9 pivots where the k=2 fractal returned 2 — the exact opposite of its purpose. It also emitted a pivot at index 0 with no preceding opposite extreme, and returned identical output at `mult=1.0` and `mult=3.0`, which looked like the threshold was being ignored.
Root cause: **Not a code defect.** The test series `H=[10,12,11,14,13,15,12,13,11,16] L=[8,9,8,11,10,12,9,10,8,13]` alternates direction on almost every bar with a 3-point bar range — a 2-bar sawtooth. On a sawtooth every leg exceeds `1.0 × ATR`, so every leg legitimately qualifies as a swing, and the output correctly alternated H/L the whole way down. The "identical at 1.0 and 3.0" observation was an artefact of the same range: with a 3-point bar range the threshold was cleared either way.
**The real defect was the default, not the algorithm: `mult = 1.0` is too permissive.** Confirmed on real data (see below): at 1.5×ATR the detector produces *more* pivots than the fractal on EUR/USD M5, because ATR shrinks in quiet conditions and the wiggles then dominate it.
Fix / Action: default raised to 2.5×ATR, then to **4.0×ATR** once a wider real-data grid showed 2.5× was still no better than the fractal on M5 (4.5 bars/swing vs 4.1). Test suite rebuilt around properties a detector must satisfy rather than around one hand-picked series: (a) only genuine turning points survive, (b) a lower multiplier follows more noise, (c) output strictly alternates, (d) pivots are monotonic in time, (e) non-repainting when the series is extended, (f) zero ATR yields nothing.
Verification: 45/45 green. Measured on real EUR/USD, GBP/JPY and XAU/USD M5 and M15 bars — 3.0× is the first multiplier decisively better than the fractal, and 4.0× was adopted as the default (`changelog.md` [0.5.0] has the full grid).
Status: FIXED
Lesson: **a detector that "returns too many pivots" on synthetic data may be behaving correctly on data that really does turn every two bars.** Build the test around invariants (alternation, monotonicity, no repaint, monotone response to the threshold) and use real bars to choose the default.

### [2026-11-02] [VISUAL DEFECT] V-001
Component: `DrawSwings()` in `SovereignPA.mq5`
Symptom: On the user's M5 screenshots, silver + blue + gold arrows appeared stacked on the same bar with no offset, and the colour coding was never explained anywhere on the chart.
Root cause: every timeframe drew its arrow at the pivot price with the same anchor, so co-located swings from three timeframes overprinted exactly. Colour existed only in code.
Fix / Action: per-slot vertical displacement (`SlotOffsetATR`: BIAS 2×gap, CONFIRM 1×gap, EXEC 0, gap = `InpArrowSpreadATR` × exec ATR) plus two legend rows on the panel.
Verification: awaiting the user's next chart screenshot.
Status: OPEN (pending visual confirmation)

### [2026-11-02] [VISUAL DEFECT] V-002
Component: `DrawPanel()` in `SovereignPA.mq5`
Symptom: Three stray "Label" strings appeared down the left edge of the panel, and panel row 0 printed on top of the heartbeat Comment line.
Root cause: (1) **An `OBJ_LABEL` with `OBJPROP_TEXT` set to an empty string is rendered by MT5 with its default caption, `Label`.** Three spacer rows were `""`. (2) The `Comment()` heartbeat and the panel were both anchored around y≈22, so they occupied the same baseline.
Fix / Action: spacer rows set to a single space; panel origin moved to `InpPanelY + SPA_PANEL_COMMENT_PAD (22)`.
Verification: awaiting the user's next screenshot.
Status: OPEN (pending visual confirmation)
Lesson: in MT5, an empty label is not an invisible label — it is a label reading "Label". Never assign `""` to `OBJPROP_TEXT`.

### [2026-11-02] [VISUAL DEFECT] V-003
Component: `DrawAllSwings()` in `SovereignPA.mq5`
Symptom: On W1/D1/H1 charts the swing arrows formed an unreadable pile next to the current price.
Root cause: structure timeframes are fixed by the profile (H4/M15/M5) but were drawn on whatever chart the EA was attached to. Twelve M5 swings span only a few hours, so on a Weekly chart they compress into one candle. The detector was behaving correctly; the rendering was not.
Fix / Action: `ShouldDrawTF()` draws a timeframe only when `PeriodSeconds(st_tf) >= PeriodSeconds(chart)`. When nothing qualifies, the panel reports `ARROWS HIDDEN - this PERIOD_W1 chart is coarser than every structure TF` and names the three TFs to open.
Verification: awaiting the user's next screenshot.
Status: OPEN (pending visual confirmation)
Rule adopted: **never draw structure from a timeframe finer than the chart.** It is not a scale problem, it is a units problem — one M5 swing is invisible inside a Weekly candle.

### [2026-11-02] [COMPILE] C-005 — 58 errors, six lines, one wrong #include
Component: `SovereignPA.mq5` include block / `tools/build_single_file.py`
Symptom: `58 errors, 6 warnings`. Messages: "declaration without type" and "comma expected" on lines 742/765/862/959/1023, "redefinition of parameter 'CSpaStructure'", "undeclared identifier 'st'" throughout, and the fingerprint `int CSpaZones::Find(int)` at the call site.
Root cause: `#include "Include/SPA_Zones.mqh"` placed before `#include "Include/SPA_Structure.mqh"`. MQL5 includes are textual. `CSpaZones` takes `CSpaStructure&` parameters that did not exist yet, so the compiler discarded each parameter list and reported the function as taking `int`. The 58 messages are one cascade.
Fix / Action: reordered includes (Config -> Symbol -> Structure -> Zones) and documented in-file that this is a dependency order. Added `check_dependency_order()` to the build script: it fails the build (exit 2) if any class/struct is referenced before its declaration, and names both line numbers.
Verification: guard tested by deliberately restoring the broken order (build refuses, correctly naming `CSpaStructure` at 746 and `SpaPivot` at 783), then restoring the fix. 71/71 tests green, 0 format mismatches, 2421-line single file.
Status: FIXED (pending the user's next compile)
Lesson: **when many unrelated functions report "declaration without type", the fault is a type that does not exist yet — check include order before reading a single one of the messages.** The signature as the compiler *renders* it (`Find(int)`) is the reliable clue: it shows the parameter list was thrown away. Also worth remembering from C-003: one line can produce dozens of errors, so the error count says nothing about the number of defects.

### [2026-11-02] [VISUAL DEFECT] V-004 — the chart went blank
Component: `DrawZones()` in `SovereignPA.mq5`
Symptom: `found=2  fresh=0` and no zone drawn at all.
Root cause: `if(!z.fresh) continue;` — the **display filter was the same as the trade filter**. The EA correctly found the two newest zones and correctly judged neither tradeable, then drew nothing, leaving no evidence that it had found anything. Worse, a zone becomes "not fresh" at its first touch, which is exactly the entry moment, so zones vanished at the point of interest.
Fix / Action: draw every zone; encode state visually (solid+filled = ARMED, dashed+unfilled = already tapped) and in the label text. Translate reason codes into plain English on the panel.
Verification: awaiting the user's next screenshot.
Status: OPEN (pending visual confirmation)
Lesson: **a chart that shows nothing is indistinguishable from a chart that is broken.** When a decision goes against a trade, show the thing that was rejected and why. Filtering for display using the trading rule is how a system becomes silent and looks dead.

### [2026-11-02] [SPEC] S-001 — D-06 was specified and never implemented
Component: `SPA_Zones.mqh` / `spa_signal_ref.py` imbalance detection
Symptom: zones appeared on price action with no visible gap. User: "I also do not see an imbalance after that candle… the market here is all efficient."
Root cause: `has_imbalance()` implemented only the *shape* of an FVG (`low[k] > high[k-2]`) and none of the three conditions that make it an imbalance: (1) no **size** threshold, although SPEC-001 D-06 specifies 0.5 x ATR14; (2) no **placement** rule, so a gap anywhere in a 20-bar window qualified; (3) no **fill** check, so a gap price had already traded back through still counted.
Fix / Action: `FindImbalance()` enforces size, placement (within 3 bars of the order block) and unfilled status. The gap is now drawn on the chart with its measured size in ATR.
Verification: 76/76 tests; 3 new tests cover size/placement/fill independently; measured across 6 pair-timeframe combinations at four thresholds (see changelog [0.6.4]).
Status: FIXED (threshold default awaiting the user's decision)
Lesson: **a test that asserts a gap exists is not a test that the gap is real.** The unit tests passed for months because they only ever asked "is there a gap", never "how big, where, and is it still open". When a spec paragraph contains numbers, those numbers belong in the test, not just in the doc.

### [2026-11-02] [DESIGN] S-002 — validity tested against today instead of at birth
Component: `CSpaZones::Find` / `find_imbalance()`
Symptom: after adding rejection counters, 44 of 102 candidates were discarded as "gap filled"; zones were vanishing as soon as they were retested, so no tapped zone could ever appear in history.
Root cause: the "gap must be unfilled" rule was evaluated over the **whole series** rather than up to the break. For a demand zone the gap sits directly above the box, so price returning to retest the zone is precisely what closes the gap — meaning "valid zone" and "untapped zone" had been collapsed into the same test. Validity and freshness are different questions.
Fix / Action: `find_imbalance(..., fill_to=b)` judges validity at birth; `gap_filled_since()` supplies a separate `gap_filled` flag for display. Zones now persist as history with an explicit TAPPED/USED state.
Verification: EUR/USD M15 zones 2 -> 25 (of 81 candidates); 77/77 tests; parity harness extended with `fill_to`.
Status: FIXED
Lesson: **"is it still valid" and "has it been used" are two questions with two answers.** Conflating them silently deletes the record you need in order to audit the engine. Whenever a filter causes objects to disappear, ask *disappear for whom* - the trader or the reviewer.

### [2026-11-02] [BUILD] B-002 — a text replace that matched nothing reported success
Component: build/handover process, `experts/SovereignPA/SovereignPA.mq5`
Symptom: user's compiler: 10 x "undeclared identifier" for `InpZoneAudit`, `InpAuditMax`, `InpAuditRejected`.
Root cause: the inputs were inserted by `str.replace()` anchored on `InpDrawZonesMax    = 4;`. The file had `InpDrawZonesMax      = 4;`. No match, no change, no error. The declarations were absent; the references were present.
Fix / Action: declarations added; `tools/check_identifiers.py` added and wired into `tools/verify.py`, which is now the single gate before handover.
Verification: the new check reproduces the compiler's exact errors at the exact lines (2108 / 2173 / 2291) on a copy of the broken file, and passes on the fixed one.
Status: FIXED
Lesson: **a patch script that cannot report "anchor not found" is indistinguishable from a patch script that worked.** Two standing rules follow: (1) every automated edit must assert its anchor exists before replacing, (2) every check must be proven against the real failure it is meant to catch, not merely observed to pass. Brace counts, format strings and unit tests all passed on a file that could not compile.

### [2026-11-02] [BUILD] B-003 — private method + invented field name
Component: `SPA_Zones.mqh`, `SovereignPA.mq5::DrawZones`
Symptom: 3 x "cannot access private member function 'CSpaZones::FindImpulse'", 1 x "undeclared identifier 'leg_end'".
Root cause: (1) FindImpulse was inserted directly before the class's `public:` label, landing it in the private section; (2) DrawZones referenced `z.leg_end`, a field that was never added to `SpaZone` - the leg end is stored in `break_idx`.
Fix / Action: explicit `public:` before FindImpulse; `z.leg_end` -> `z.break_idx`. `check_identifiers.py` extended to validate `variable.field` against parsed struct bodies.
Verification: the extended check reports the exact fault on a re-broken copy and passes on the fixed build; 80/80 tests.
Status: FIXED
Lesson: **the two failures were of different kinds and only one is checkable.** A field typo is a symbol question and can be gated; an access modifier is a question about where a method sits in a class, which my checks cannot see. Say so plainly rather than implying the gates cover everything - the compiler remains the last gate and it is fine for that to be true.
