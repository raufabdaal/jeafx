Okay, hello, and welcome to

understanding price. This is a 3-4 hour

master course on technical analysis. And

if you watched any of my videos before,

you know that we're going to go deep.

So, we're going to break down why

markets move and spend some good time on

helping you to understand what it is

that actually drives price. We'll go

through Japanese candles, market

structure, supply and demand, market

efficiency, liquidity, momentum, and

top-down analysis. So, all of the

different concepts that I used to trade

for myself, we're going to break them

down in incredible depth and show you as

we go the process being layered onto

different trade ideas. By the end of

this class, you will be able to look at

a chart and immediately know what it's

telling you. Often times, without even

having to draw any analysis onto the

chart you're looking at. So, we're not

going to waste any time. We're going to

jump straight in and start by breaking

down what it is that truly makes the

market move. Let's go. So, we're going

to spend the first part of this course

going through what it is that actually

makes the market move. Because one of

the biggest problems that traders face

is that they view charts as charts. And

I know that sounds really weird, but let

me explain. When you open up your chart

to trade the asset that you want to

trade, you simply look at this, all of

the different candles, the movements

they've made, as kind of a static

pattern. And what you're looking to do

inside of this is use your concepts,

whether it's support and resistance,

supply and demand, trend lines,

liquidity, market structure, whatever

concepts you trade with. You're trying

to use those concepts to basically draw

out patterns and then execute upon them

without any deeper context as to why

you're actually doing that. So, a trend

line trader, for example, may say,

"Okay, we had one tap, two taps, and

then the market broke out, so we should

buy." Right? That could be something

that would happen. You're just using

static patterns. A support and

resistance trader may say, "Okay, this

is a resistance, so we will sell." And

then when it breaks out, they may say,

"Okay, it's broken, so we will buy the

retest." It's okay, but you're not

making any sense of what's actually

happening. You're literally just saying,

"This line broke, so therefore buy."

Right? Doesn't really dig deep into

what's actually happening under this

surface layer. Supply and demand trader

may see, "Okay, the market structure has

broken lower, and this supply zone has

been retested, so therefore I will

sell." Now, that again, it's fine, but

it avoids the context. You're missing

out. Why would we sell? What actually is

happening here to tell us that selling

is the likely move. The point I'm making

here is concepts are good. Concepts are

important and valuable, and we will be

going through a fair few of them inside

of this course, but without the context

beneath the concepts, you are going to

struggle to trade successfully. For a

few reasons, number one, you might take

trades where trades shouldn't be taken,

but number two, you may also hesitate

out of trades. So, let's say you were

the supply and demand seller. You saw

this supply zone. You saw the market

structure had broken lower, and you saw

that there was like an imbalance or

inefficiency into this. So, you thought,

"Okay, when the market gets here, I will

sell." Right? Completely fine,

completely valid, but without the

context, without understanding the story

that's happening underneath the candles,

you can run into two problems.

Number one, let's say you've recently

taken a loss. So, now you're feeling

kind of hesitant about taking a trade

because you're scared that it might lose

because you're scared that it might lose again.

You could find yourself a reason to not

get into this trade, and then you'll

feel good while it's pushing into

drawdown, but as soon as it runs all the

way to targets, you'll feel like an

idiot for not just trusting your gut and

taking the trade.

Now, potentially even worse than that is

you may get into the trade. It may run a

little bit, but then when it starts to

reverse against you, you get out because

you think, "Well, surely this trade now

is going to turn into a loss." Then a

few hours later, when it's at the

target, again you're feeling stupid

because you missed out on the whole

because you missed out on the whole move.

So, by not understanding the context and

the story, it's easy to hesitate or to

avoid trades or to make early exits

against rational kind of thinking

because you don't know why the market

should support your idea.

Now, what we want to do is we want to

read deeper than the surface layer,

deeper than the patterns themselves, and

start to read the story that the market

is telling us. So, every single candle

that you see on a chart, on any chart,

is basically a representation of human

behavior. Every time we see a gray

candle in this instance, or maybe red on

yours, that is going to be a bearish

candle. That is basically the market

saying, "In this given price range,

selling was stronger than buying because

we saw the market close lower.

Therefore, we know more sellers were

trying to get a deal done than buyers

were willing to at this given price,

right?" So, we learn things from every

individual candle.

And when we zoom that out, we can learn

things from every phase of candles as

well. For example, this movement down

here is very strong and very fast. It

just continually weakened without much

pulling back. So, we can see that

sellers were pretty strong there. Now,

if we look at this phase where the

market crawled very slightly up again,

what is this telling us in comparison to

the previous move? Well, this is a lot

slower. We haven't achieved anywhere

near as much ground to the upside, and

it's taken a much longer time to pull

back up. So, we can see again that

buyers in this phase are just not very

strong. So, when we see the market break

down, this is no surprise. And what this

actually tells us again is considerably

stronger selling than the buying we saw.

We made again a larger movement down

than the entire movement up we got in a

much smaller period of time. So, this

confirms selling control.

When we see the buying taking place

again, it's slow, and it's a bit choppy.

In comparison to the selling move we

had, we can still see buyers are not so

strong here.

So, this basically validates as a

seller-controlled market. We're seeing a

lot of pressure from the sellers and

little resistance from the buyers.

Before a lot of pressure from the

sellers and little resistance from the

buyers. Then, of course, what do we

expect that to lead into? Well, of

course, you can see a lot of pressure

from the sellers once again. So, when

you start to read that story, that kind

of extra layer that's hidden in plain

sight beneath the charts that you look

at, that is when trading really makes

sense because the context that you get

from doing that helps you to understand

what trades are good and what trades are

bad. Let's dig deeper into exactly why

this happens now. And by the end of this

section, you'll be able to understand

the story and your perception around

what markets actually are showing you

will be changed for the better forever.

So, let's go. At the core then, the

market is just a battle between buying

and selling.

When price is going up, that means

buyers are in control. And when price is

going down, that means sellers are in

control. Now, this does not mean, and

this is an important distinction to

make, that there is more buying than

selling or more selling than buying

taking place at one given level because,

simply, that is impossible. You cannot

buy more than someone is willing to sell

to you. And you cannot sell more than

someone is willing to buy from you.

Every transaction needs two

participants. We have to have a buyer.

We have to have a seller. So, it's not

that there's more buying or selling

taking place. It's that there's more

willingness to buy or sell at specific

price levels. So, to explain this, we're

going to dumb it right down to a pizza

shop. Imagine you've got the only pizza

shop in your town. Now, because you're

the only place that anyone can get

pizza, you will likely have a very big

queue of willing buyers coming to buy

pizza from your shop. Because all of

these people want pizza and you're the

only provider of the pizza, meaning

there aren't many willing sellers, it's

just you, and there are many willing

buyers because they all want pizza, you

could realistically charge higher prices

for the pizza and people would still pay

it. You could sell at $10. There's

probably willing buyers at $20 and $30

and some people would even buy the

pizzas even if they were $50 each. That

is what's happening when the market is

increasing in price. There are more

people who are willing to buy than there

are assets available at a given price

level or people willing to sell at that

price. The sellers can demand higher

prices and willing buyers will take up

the offer. But, what if now multiple

other pizza shops opened up in your

town? Well, now we have more willing

sellers, right? And let's presume that

the pizzas are of the exact same

quality. So, the only differentiator now

is price.

Well, because there are a bunch more

places selling pizza, your pizza at $50

is not going to cut it anymore because

the person next door might sell pizza

for $40. And then the person next door

to them might offer the same pizzas for

to them might offer the same pizzas for $30.

Now, the willing buyers exist at $30. No

one wants to pay $50 for the same pizza

they can get somewhere else. So, it

becomes a bit of a race to the bottom.

And the only way for you to compete

again or to sell your pizzas is to lower

the price to meet the willingness of

buyers. That's what's happening when we

see the market decline. Buyers are no

longer willing to pay premium prices, so

sellers keep dropping the price until

there are enough willing buyers to take

up their offers. It's essentially a bit

of a race to the bottom where now if you

want to offload your assets, you got to

be cheaper than the next guy. Now, if

the price increases, all that is telling

us is that traders are no longer willing

to transact that low, which generally

means there are more willing buyers

happy to pay higher prices than there

are willing sellers happy to sell for a

cheaper price. That is how the market

moves. It's transactions taking place

between buyers and sellers. And it's the

willingness to buy or sell at specific

price levels that determines whether the

market will go up or down. Markets are

driven by supply and demand, okay?

Supply is the available quantity of an

asset, and demand is simply how much

people want the asset or not. Now, we

could go deep into the semantics of the

formulas, charts, and explanations of

supply and demand in an economic sense,

but we don't need to do that in trading.

We can keep it very simple. What you

need to understand is that prices will

decrease when supply is high and demand

is low. So, when you have a lot of an

asset and people don't really want it

that much, they're not excited about it,

then you have to meet people at a lower

price. Think mass-produced cars like a

Suzuki. We don't really have Suzuki

super fans who are dreaming of one day

owning these, and there are lots of them

available. So, therefore, the prices for

one of these are pretty low. Now, on the

other side of that, prices will increase

when supply is low and demand is high.

So, when you have a scarce resource that

a lot of people want, you can charge

pretty much any price you want for it,

and people will still buy it. Think

about Ferraris that routinely sell for

700,000, 500,000, even sometimes $1

million plus, and people are still

buying them out fully, right? There's

high demand, low supply. Therefore,

prices can be set very high, and they

will still sell. Now, in financial

markets, demand for something doesn't

come from a desire for status in the way

that buying a Ferrari or luxury watches

or designer clothes does, right? In

financial markets, the demand comes from

various different, more boring factors.

So, this is a silver chart from around

2021 all the way through to 2026. Now,

that gray arrow signifies around the $14

price where I was telling my friends and

my private students that I was going to

be buying silver heavily. The reason I

had that idea back then is because we

were seeing the deficits in silver grow.

So, basically, more people every year

are using silver to produce things, to

put to the market, like, you know,

actual products, uh tech, things like

that. With that extra silver being used

up, it created deficits, which meant,

essentially, there isn't enough silver

were produced to go around for everyone

that wants it. So, therefore, silver

prices went ballistic over the following

years. Now, another thing that goes

alongside this, of course, is investor

demand. So, as well as people buying

silver to use it in tech, in products,

whatever it is, there's also investor

demand. That we had very tricky economic

times pretty much from 2020 onwards up

until today. And when we have that, we

see people in the market trying to buy

things that are generally going to

perform better during tricky economic

times. And one of those is precious

metals. So, we saw a lot of money

flowing into silver from investors. And

we also saw the supply problem that

could be was created driving silver

prices higher. So, the demand comes from

those two factors and drove the market

up hundreds of percentage points to

today around $70 at the time of

recording this. And at the peak, a few

months before this, actually trading

over $100. So, that is where the demand

comes from in financial markets. Now,

there is one important caveat to explain

and break down when we're talking about

supply and demand. And that is the

Ferrari, for example, is actually rare,

okay? They only make around 14,000 cars

per year. The demand exceeds the amount

of Ferraris that exist on the planet or

will probably ever exist. And silver,

too, to a degree, because although there

is a lot of silver available on the

world, we actually are already seeing

deficits where so much of it is being

used up every year in many different

industries that we are going to need to

mine and process more of it to keep up

with that demand.

But, many of the markets that we trade,

like currencies, indices, stocks, a lot

of cryptocurrencies, not so much

Bitcoin, and commodities, well, these

things are enormous and often

expandable. So, currencies, for example,

you're never going to buy every dollar

on Earth, right? The total supply is

enormous, and they also print more

dollars every year. So, it's expandable.

So, the real total supply of US dollars

is really never even considered by the

traders who are buying and selling

dollars. The same goes for a lot of

indices, a lot of different stocks, many

of the cryptocurrencies that have, you

know, billion or 100 billion plus

know, billion or 100 billion plus supply,

and a lot of commodities too, like oil.

Millions of barrels of oil are being

produced every week. So, these things

are enormous and expandable.

Which essentially means the total supply

of the assets that we generally trade

is not really a concern to us as traders

or any of the traders because there are

just so many of these assets available.

So, if total supply isn't a concern,

what is? Well, the real answer to supply

and demand in our sense is available

supply at a given price level. So,

imagine you are trading gold, for

example. There are 220,700

tons of gold or thereabouts on Earth.

That is a hell of a lot of gold

considering it's $4,500 an ounce right

now. So, no one is thinking about all

220,000 tons of gold while they're

trading. They're thinking about how much

gold are traders willing to sell or buy

at this price today. Because that number

is very different from the total supply,

right? A lot of it's being used up, a

lot of it is being held in vaults by

government. So, how much gold is being

traded willingly at today's price? That

is the supply that we want to look at.

Which means of those 220,000 tons,

there's only going to be a fraction

available at $4,000, for example, for

the next couple of days. That's the

supply that we're interested in. And

this is the same for all of those

different assets that we just discussed.

It's today's price and today's

availability. That is where we are

considering the actual supply. Now, a

simple way to explain this is housing,

right? There are millions of houses in

any given country, but only a few are

for sale in your town at one time,

right? Which means the price of that

market is set by the demand for the few

available houses. And the rest of the

houses, they're just not really a

concern when setting the immediate

market price because they're not on the

market, they're not available, they're

not for sale, right? So, housing markets

don't move because houses disappear cuz

rarely that happens, but very, very

rarely at that. They move because buyers

and sellers change the price that

they're willing to trade at, right?

Today's price and tomorrow's price may

be different. Today's supply and

tomorrow's supply available may be

different. And that is the way that we

need to view supply and demand when

we're trading in the markets. So, now

I'm hoping you understand how we want to

view the markets, right? It's just one

big auction. When we see prices

declining, these are phases where supply

has exceeded demand and the sellers have

to drop the price of the asset to meet

willing buyers. Now, when they meet the

willingness of buyers, we will see the

market drive to the upside where sellers

now want to charge higher prices and

buyers will only buy for as long as they

are willing to do so. In markets that

are moving down, it's just a clear case

of essentially seller control where the

sellers are setting the price of the

market because the buyers are not

willing to buy at those prices. And when

markets are increasing, this is when

demand is very high and supply at an

available given price is now

constrained. So, when we're trading

here, we are seeing basically buyers

want to be in this market, but the

sellers, they don't want to sell at that

price. So, the sellers can demand more

for the asset and more and more and more

and prices will increase as long as

there are willing buyers ready to take

up the offers of the sellers at these

higher prices. Eventually, that will

fade and that is where the market runs

in these cycles. It's one big auction

driven by supply and demand, buyer and

seller willingness.

All right. So, now that we have that all

important introduction out the way and

you can see how the market can be read

as a story and how there is a lot

happening underneath the candles that

you see, it's time to start getting into

the actual technical concepts. So, the

things we will use to find trades.

Now, I'm going to be showing you the

concepts I used to catch trades like

this, which is the latest trade that I

took as of the time of recording this

took as of the time of recording this video.

Now, this is a trade that uses what I

call logic-based concepts, and that's

what we're going to be going through.

Now, realistically, when it comes to

your technical trading, there is no

right or wrong because the majority of

the money is made or lost in the other

elements like how you manage risk and

how you weigh the probabilities.

But, I would argue that some concepts

are just objectively better than others.

Now, of course, this might be personal

opinion, and you might disagree,

but I think that concepts that make

sense of the market are always going to

be better than static pattern concepts.

When I say static pattern concepts, I'm

talking about things like support and

resistance, right? We have a support

flow here, it breaks through, acts as

resistance. That would be one place that

you would look to trade. And I'm also

talking about trendlines, right? Where

we connect the highs of a

downward-moving trend, and then we use

that to determine our trades. Now, there

is two ways to trade off of these

support and resistance and trendlines

patterns, right? Trendlines, generally,

you're looking to sell the retest, and

support and resistance, you're looking

to sell the resistance. So, now that

we're under a trendline and we're under

a support resistance level, this area

here becomes an incredibly attractive

place to sell from when you're trading

these static pattern concepts. But, the

problem is, right? If we take a look at

what actually happened, the market drove

higher. That would have stopped out

anyone selling. And then, this is a

trendline break and also a resistance

break. So, a new buy would come in here,

but as you can see, this just ran lower

again, leading in another loss. Now, at

this point, when the market's trading

under this level, traders would then

presume, because we're back under the

level, we should look to sell the

retest. And again, another resistance

has come in here. So, again, this

becomes a very attractive place to sell

from, but what happens? Well, you can

guess, the market just drives higher

once again, right? So, this actually

would result in a bunch of losses, and

the biggest problem with this is not the

fact that you're going to lose a few

trades here and there, but it's the fact

that you don't actually understand what

the market is doing because your

analysis is determined by lines you've

drawn on a chart that actually aren't

grounded in any real logic, right? When

we draw a support or resistance level

on, we have literally just drawn a line

that the market's reacted to a few

times. The market doesn't know that this

level is there, and we also don't know

why the market's reacting there. So,

therefore, we don't really have any

context as to what to do if the level

doesn't work. The same goes with trend

lines. Again, these are just lines

you've drawn on a chart, and the market

doesn't even know they're there. You've

just drawn it on, and you're now

reacting to a random line for whatever

reason it may be. Most people don't even

know other than that they were told to

do it in a YouTube video.

So, because we don't have any context as

to what's actually happening underneath

the candles with this style of trading,

it's going to make it very difficult for

us to actually succeed because as soon

as something goes wrong, we can't just

zoom out and realign with the big

picture narrative. We just have to guess

or move with what we think is best next,

and that can result in you getting

whipsawed out of those trades over and

over again in the pattern that I've just

showed you. Truth stands for more

complex approaches to trading like

Wyckoff. At the end of the day, this is

still a static pattern, and when you're

trying to trade these schematics in real

time, you end up thinking things have

happened before they have or joining the

market too late and end up missing the

schematic. These are easy to see in

hindsight, but difficult to trade in

real time because you're relying all of

your trading on a static pattern and not

actually reading into the story behind

the market to determine your ideas. The

same with Elliott wave theory because

the market's not always going to run in

these perfect patterns that Elliott wave

suggests. If you're trying to trade

these more complex strategies, these can

be just as bad as the support and the

resistance and the trend lines and those

basic static patterns as well. Just

because these ones are more complex

doesn't mean they give you any further

context on the market and doesn't mean

they're going to be any easier for you

to trade. And even if you are trading

with the so-called smart money concepts

like structure, liquidity, supply and

demand and imbalances, not fully

understanding how to do it correctly and

not fully understanding the reasoning

why these things are happening is

basically the leading cause of

hesitation end up missing really good

trades or closing them early when they

start to turn around on you instead of

holding them all the way through to

their targets. So, it's very important

that you trade with good concepts, but

it's also very important that you have a

full understanding of the concepts

behind the concepts you're trading so

that you can trade them without

hesitation, fear and doubt. The first

thing that we're going to break down is

Japanese candlesticks. And now, I know

you might already be familiar with

candlesticks, but sit with me through

this because I'm going to be breaking

down how we read individual candles and

how different formed candles can give us

different levels of information. Now, of

course, the candlesticks that we're

talking about are simply the things that

make up the charts that you trade. So,

we have bullish candlesticks. These are

where the open is lower than the close.

So, at the start of, let's say, 1 hour

cuz we're on the hourly time frame

currently, the market opens at this

price. Within that hour, the market

travels all the way up and it closes the

hour at this price. That creates a

bullish candle because throughout that

hour, price moved upwards. It moved in a

bullish direction. Bearish candles are

where the open is higher than the close.

So, at the start of the hour, we opened

at this price and throughout the hour,

we moved down and we closed down here.

Therefore, making it a bearish candle

because throughout that given time

frame, the price moved down. Okay? So,

those are the two types of candlesticks

that we get. Now, these candles are made

up of two parts and this is where things

start to get interesting and very

valuable. They're made up of wicks, the

small sticks that we see coming out of

the tops of the square or rectangle part

of the body, and then we have the

bodies. This is the thing that makes up

the majority of the candle, the actual

colored bit. Could be green and red for

you, or different colors if you've

changed that for yourself and customized

them in the way that I have. So, the

body tells us confirmed price action

within a specified time range. If we are

looking at an hourly time frame,

the market opens here at the start of

the hour and closes here at the end of

the hour.

If we're looking at a 15-minute time

frame, that simply means the same. At

the start of the most previous 15

minutes, the market opened at this price

and throughout the 15 minutes, it went

up and it closed there. So, it shows

that the price moved upward within

whatever time frame it is you're looking

at, regardless of whether it's the

hourly, the weekly, or the 1-minute, or

anything else in between those. So, that

is the body, confirmed price action.

Now, the wicks show rejected price

action. All this means is, throughout

that, let's say, hour, the market did

actually get up to this level. However,

before the hour closed, the market drove

price back down to this level. When we

see wicks on the lower boundary of a

bullish candle, that means within the

hour after opening at this price, we did

actually attempt to go lower, but the

market participants drove price back up

all the way from that level and threw up

to here before the market closed for

that hour, okay? Now, a bearish candle

is exactly the same, of course, only

this time it means we tried to go up,

then we went all the way down, and then

we ended up closing there, right? So,

the wicks are just showing you price

action that was attempted or temporarily

reached, but that didn't actually close

at during that specified period of time,

whatever time frame it is you're trading

on. So, that is the basics of

candlesticks, but now we're going to dig

into what these candlesticks actually

show in different forms, okay? So, we'll

remove this one for now to keep it

remove this one for now to keep it simple

and we'll focus in on the bullish

candlestick for now. Now, when we're

looking at a bullish candlestick, we

want to read the market in two different

ways. We want to read it through the

bodies, okay? And we want to read it

through the wicks. And through both of

these, we are looking for the size and

the speed because these two things,

these two elements here, are going to

give us the insight into how strong or

weak the market is. So, if we're looking

at a bullish candle like the one we've

got drawn on the chart here, this

obviously has quite a large candle body,

right? The body is significantly larger

than the wicks and it shows a clear run

from this level up to this level here.

So, this shows that throughout this

specified period of time, let's call it

1 hour, the market was very bullish. The

wicks on this one are equal both sides,

which basically means there isn't clear

rejection happening from one party or

the other. It's basically the natural

flow of the market because we attempted

to go lower, pulled back up, we

attempted to go higher, pulled back

down. We don't have any significance

really being shown to us from the wicks.

So, this would be a pretty strong

bullish candle. Now, the reason that's

important is because when we understand

how strong the market is in one

individual candle, we can then determine

where it's more likely to go in the

following candles, right? So, if we see

a candle that is this bullish and this

strong, it's about medium-high strength,

right? It's not a massively impulsive

candle, but it's certainly not weak. We

would therefore most generally presume

that the more likely following movements

are going to be continuations higher

rather than a break back down through

the low of the candle and beyond.

So, we gain from that that this is

reasonably strong, okay?

Now, if we were to have, for example, a

candle like this with absolutely no wick

on the upside. This is pretty much the

strongest candle that we can get.

The reason for that is, if we open here

and we close here, it means we closed at

the highest possible point the price

reached within that specified time

period. We didn't have any pullbacks

whatsoever and there isn't any visible

whatsoever and there isn't any visible wicks.

Now, these are the candles that really

show very clear buyer control. You're

not going to see these as frequently as

candles with, let's say, even a small

wick at the top. But when you do see

them, these are the ones that are most

likely to just impulse straight away

into the following candles. So, in

certain settings, and we will get to

this later, candles like this can

actually be really good to execute

trades from, entering there with your

stop beneath the candle. Now, obviously,

this is all relative to how large the

candle is and where it is in the market,

but this is going to be covered closer

to the end of the course.

For now, all you need to understand is

if a candle has no upper wick and it's a

bullish candle, it's basically showing

incredible strength throughout this time

period, okay?

Now, if we have

a small candle body like this with a

large wick, this completely changes

large wick, this completely changes things.

First thing we want to look at is the

candle body itself. We can see within

this time period, we opened here and we

closed here. So, we didn't make much

movement in terms of actual price

direction. That, if we isolate it to the

body, basically shows that there's not a

lot of size behind that movement. So,

this would be a pretty low strength

candle. It's still bullish to a degree,

but it really didn't get too far.

Now, when we bring the wick into the

equation, that's when things get the

most interesting and this is where we

can draw the most value.

This wick, we have a small wick on the

downside. We say small, but it's still

larger than the actual candle body,

which shows we did attempt to get lower

before going higher.

And we have a massive upper wick, right?

Now, this can tell us pretty much one

thing quite clearly. And of course,

context matters and we'll get into

deeper context throughout the course,

but from one individual candle, if we

break down what this is showing, it's an

open here. It's attempt to go lower.

It's pull back up all the way to this

level. And then when we get here, it's

push all the way back down to this

level. So, this with a large wick above

can often times be seen as a reversal

can often times be seen as a reversal candle.

Because if we think about what's

happening behind the candle, it's

basically a way to represent essentially

a bit of consolidation that's taken

place, right? So, we start here.

We get all the way up to here. We go all

the way down there at some point and

then we close there. So, the price

action we're actually seeing, if we were

to break this down to a line chart,

would basically be open,

trade a bit lower,

go all the way up like this,

and then come all the way down like

this, right? That is the price action

that we see behind this candlestick if

you were to translate the candle into a

line chart.

Now, what does this say? Well, this says

we're actually looking pretty weak or

we're at a point where we're starting to

reverse, right? Because obviously having

seen this very impulsive top, we've then

reversed pretty much all of the gains

within that specified period of time.

Which shows us, if we go back to that

battle between buyers and sellers, that

buying was strong from this point, okay?

And strong down here as well because we

didn't fail to actually uh build

momentum, right? We of course did indeed

build momentum. But when we got here,

sellers and selling in the market was

incredibly strong.

Strong enough to actually reverse the

majority of the movement that we'd made

inside of this specified period of time.

So, this shows us a point where selling

pressure has stepped into the market in

full force up at this high and created a

massive downward push, which has brought

us back to a very mediocre and not all

too impressive close where we didn't

make much price movement that was

actually confirmed within that given

time frame. So, when we see huge wicks

like this, these are ample sign of

potential reversal because it basically

shows us that buyers took the market

higher and then sellers stepped in and

said, "No, we're not going any further

with this. It's coming back down." Now,

this can take place for a number of

reasons. Maybe people taking profit on

buys on shorter term trades. Maybe

people just seeing the market has

reached a premium price level, right?

And again, this is where the big picture

context matters. But, regardless of what

it was, we absolutely saw a lot of

selling pressure coming in, which means

this can be seen as a likely, not 100%

it's dependent on context, a likely

reversal candle. Okay?

So, that is where the wicks become kind

of detached from the candle body in

terms of the value they provide. Now, if

we were to see a candlestick which had a

small candle body and small wicks like

this side to side, this changes the

equation entirely. Again, let's draw

this out like a line chart. We open

there, we tried to go there, we tried to

go there, and we closed there.

So, we start,

we go higher, we come back down, we go a

bit lower,

and then we come up, and we close here.

That's the line chart behind this

candle. Now, of course, it could also be

this way,

but regardless, the outcome is the same,

right? We went up, we came down, we came

up, and we closed near the open. Or, we

went down, we went up, we came down, and

we closed near the open, right? They're

both showing very, very similar things.

And what this shows, regardless of which

way it went first of all, is indecision.

It's a market that isn't being

controlled right now by buyers or by

controlled right now by buyers or by sellers.

Because if we saw buyers in control, we

would have seen more upside pressure, or

at least potentially larger downside

wicks where we've actually seen buyers

coming in and driving the market higher.

If sellers were in control, we would

have seen, again, a bearish candle

potentially where we close lower. Or we

would have seen at least a larger upside

wick such as in the case we just broke

wick such as in the case we just broke down.

But we didn't see either of those

things. We see equal weighted

wicks up and down and a small candle

body, which basically shows a period of

indecision. Buyers couldn't control,

sellers couldn't control, and we ended

up closing around where we opened. So,

this is what we call an indecision

candle. Now, unlike the other two

candles that we've looked at so far,

which either show pretty clear impulsive

control or a reversal in the market

where it's potentially shifting control,

this candle kind of just tells us that

the market's at a point of moving

nowhere, right? So, if we see this

candle, we can't really derive from it

an opportunity to immediately trade. But

what we can do is we can see what

happens next. Cuz let's say we have an

impulsive upward candle like this, well

now we can say, "Okay, after the

now we can say, "Okay, after the consolidation,

buyers have taken control." And so,

[snorts] pulling back to here can be a

good point to buy from, which is where

we would look for continuations higher.

But if we were to see instead that this

market went and closed lower, that can

tell us that sellers are in control. And

again, what that shows us is a

consolidation that ended with sellers

taking control of the market. From

there, we would generally look for pulls

back to then trade out of on the

downside because after the indecision,

basically the next movement is where we

confirm who is actually in control.

It's like if we were to get to the top

of the move

and then stall out, that's what's

happening with this candle, right? And

the market's now deciding who is going

to take control of this market. If it's

sellers and it goes lower,

then we look to sell cuz the indecision

is over. If it's buyers and it goes

above, then we look to buy because the

indecision is over. That's what these

candles show, right? Now, you can get

many different forms of these candles,

but they all are following a formats. A

candle like this shows the same thing.

Even a candle like with a a wick up or

down like this, if the candle body is

really, really small and the wicks are

generally or relatively equal,

it's basically going to be a phase of

indecision, okay? So, those are the

different types of candles we can get

realistically. We can get large candle

bodies with little to no wicks. They

show clear buyer control and if it's

bearish, of course, clear seller

bearish, of course, clear seller control.

The smaller the wick is on that one in

the direction of the market, then the

more bullish that's generally going to

be. So, if we were to have a candle like

this, yep, that's pretty bullish, but of

course, this is more bullish because

there's no resistance from sellers at

all. We're basically seeing a phase

where buyers fully control the market

and sellers didn't even push back one

time, right? Which shows clear, clear

buying intent.

Then we have candles with large wicks.

We could do this one, for example, this

time, where we have a very large wick on

the downside and a very small wick on

the upside. Now, we opened here, we

tried to go higher, we failed, we went

all the way down here, and then we drove

all the way back up and closed around

the open. This shows an area where

buyers have stepped in in massive force

in these lows, driving the market

significantly higher. So, again, this is

a reversal-style candle, where we're

seeing sellers losing control to buyers

and buyers closing the market back

around where it opened. This can be

first sign of potential reversal and can

provide opportunity to buy from if the

market then returns upwards, okay?

So, those are the three different types

of candles, strong impulsive candles,

reversal candles, and indecision

reversal candles, and indecision candles.

Now, they will come in many different

shapes and sizes, but what I'm trying to

do here is explain what's happening

behind those candles to you, so you can

make more sense of what it is you're

actually looking at. If we take this

over to a chart,

let's have a look at what we've actually

got going on here.

So, through this phase of price action,

we can see we have lots of these bullish

candles with little to no wicks at the

top, right? Now, we do have a wick at

the top of this one showing potential

reversal, but then what do we get? We

get that kind of indecision. Now, this

obviously shows some pushback from the

downside, but the tiny candle body tells

us that no one is fully in control yet.

It's first sign of reversal. The next

candle that's incredibly impulsive after

that kind of leads the way into the

continuation of the upside, all right?

So, when we see a phase like this where

we have lots of bullish candles where

there are little to no wicks at the top,

and we're seeing the size of these

candles progressively get larger, this

is of course a very impulsive bullish

bit of price action.

Now, you can actually see

in regards to the indecision around the

tops and the bottoms of almost every

move that we get in the market, like

here, we have indecision candles. So, we

have clear buyer control, and what we're

seeing here is basically buying is very,

very willing at these levels.

Buyers are willing to take up the offers

of the sellers at higher prices, and

then we get to this point, and this is

kind of a point where buyers step back

and say, "Hmm, I am not sure whether we

want to be buying at this price."

Then after the price falls a little bit

where sellers are basically saying,

"Okay, we'll lower the price if you

buy." We then reach a fair value point

again where buyers are happy to start

taking up the offers, right? So, that's

actually what's happening behind the

candles you see, but each one of those

candles tells a story. Now, here's a

good explanation as to the indecision

candles I showed you, too. We don't know

100% when we get here whether the

market's going to go up or down, but if

we see the market break back over above

the indecision phase, that basically

tells us that buyers are once again in

tells us that buyers are once again in control.

So, that is the way that we view

candles, and that is the way that you

can start to read the market by reading

the candles and the story behind them.

It's far from the last you're going to

see discussed about candles in this

class, but we are going to return to

talk about candlesticks later on when

we'll discuss momentum, because that's

when they become more relevant to

everything else that we need to discuss.

But for now, we're going to move on to

market structure. So, this is what I

call the central concept of the market.

If you don't get your market structure

right, you are going to find it very

difficult to get anything else right,

okay? So, let's start breaking this

okay? So, let's start breaking this down.

Now, market structure suggests, and it's

just an objective fact, that the market

runs in realistically three different

runs in realistically three different phases.

We have uptrends, where the market is

moving to the upside.

We have downtrends, where the market is

moving to the downside. And we have

consolidation, where the market is

moving sideways, and neither creating

clear upside or downside movement. In an

uptrend, we determine the direction

by the highs and the lows that are

by the highs and the lows that are created.

And in a downtrend, too, right? So, what

I'm drawing on here are levels that show

the highs that have been created in the

the highs that have been created in the market,

and the breaks that are happening

through those highs that were printed in

the market.

These levels are what we call breaks of

structure. So, you'll see these marked

as BOS on my charts, okay? A break of

structure is simply a point where

structure has broken through a previous

high or a previous low. So, we would

have a break of structure here, where

the market has broken through this

previous low.

And [snorts] what a break of structure

shows is a continuation of a trending

direction or a reversal in a trending

direction, okay?

So, let's focus on just the upward trend

for now.

Inside of this trend, we have higher

highs. So, each high that we see is

higher than the previous that was

printed, okay?

So, here we have our first high, then we

have a higher high, because this high

was higher than this high.

And then we have another higher high

in around this level here, when the

market kind of reached its peak.

So, during an uptrend, we will see the

market printing higher highs.

Now, we will also see the market

printing higher lows.

So, after each of these highs has been

printed, we have a pullback movement.

This pull down is basically where we

start to see the buyers become a little

bit exhausted and the sellers take a

little bit of control.

Then, we print a higher low.

The higher low is just a low that is

higher than the previous one, right?

It's pretty self-explanatory.

Now, providing the market stays in a

flow of higher highs and higher lows,

that will continue an uptrend. That's

basically what determines that the

market is indeed trending up. And while

we're in an uptrend, we should only be

looking to do one thing. And that is

going to be buy.

We don't want to sell the market if it

is printing higher highs and higher lows

consistently. We only want to buy in

this market because we can see that the

market is clearly driving up.

Now, during a consolidation, we'll

actually see the market create higher

highs and lower lows. So, we'll actually

see a bit of a mess going on where we

don't have this clean upward trending

price structure. We actually have a push

up, then a pull down, then a push up,

then a pull lower, then a push higher,

and a pull lower, and so on. It will

basically be impossible to make sense of

which way this market is going whilst

the consolidation is happening because

it's not going up and it's not going

down. It's just whipsawing and trading

down. It's just whipsawing and trading sideways.

Now, sometimes consolidation ranges are

going to be very clear and obvious. They

will just be very confined like this,

for example.

And other times, they will be a little

bit trickier. They will have expansion

where, like this example, we make lower

lows and we also make higher highs and

everything's just a bit of a mess.

But, the point through consolidations is

we just do not trade them. And if we are

going to trade them, we do it by trading

the range. So, looking from sells from

there to here and buys from there back

to there. But, this stuff we will get

into when we talk about a concept called

liquidity. Okay?

The general rule surrounding

consolidations, if you want to trade

safe and effectively,

is simply just not to trade because

through an uptrend while we have clear

directional bias, in a consolidation we

don't have that. So, it's better to just

not trade in these ranges and wait for a

clear trend to be taking place. Okay?

Then, [snorts] the third type of trend.

That is the downtrend.

A downtrend is determined in the same

way that an uptrend is, except this time

we're looking for lower lows. So, that's

what that stands for.

And we're looking for lower highs.

So, we're looking for a point in the

market where every high that is being

printed and every low that is being

printed is lower than the previous.

Okay? So, our breaks of structure this

time are actually on the downside. The

breaks of structure come when we see a

low breaking to a new low or a lower

low, right? And providing the market

continues to break down in this fashion

with new lows being created and new

lower highs being created, that is a

market that is in a downtrend. Now, I'm

pretty sure you already know where this

is going. During a downtrend, we should

only look to do one thing and that is

going to be to sell.

So, in an uptrend where the market is

printing very obvious bullish price

structure, where we are seeing higher

highs and higher lows created, we buy.

Through a downtrend where lower lows and

lower highs are being created, we sell.

And through a consolidation where it's

not clear in which direction the

market's going, we do nothing. Okay?

Those are the three general phases of

market structure and these are pretty

much the only things you need to deeply

understand to make sure you're always

moving in line with the market. Trending

moves are made up of two different

moves are made up of two different parts.

We have impulse movements and we have

correction movements.

Now, an impulse movement is the pro

trend move, the overall direction,

right? So, in an uptrend, the impulse

moves are the moves that have created

new highs. In a downtrend, if we were

just to flip this real quick, the

impulses are the movements that have

created new lows, okay?

Now, the corrective movements then are

the pullback moves or areas where the

market has short-term shifted down

against the overall trending direction.

Because trends are never linear. We

never see price action like this without

ever pulling back. What we see is a

series of ups and downs inside of a

trend that creates the overall flow,

right? This is what prints the higher

lows and it's what prints the higher

highs as well.

So, in a movement like this, the

impulsive moves are the ones that create

new highs and the corrective moves are

just the pullback moves where basically

we see some shorter-term buyer

exhaustion and some short-term seller

control coming in.

Now, corrective moves happen because

buyers are taking profits and also

because short sellers think that the

market's reached a premium price that

they think the market will sell off

from, right? Now, inside of a strong

trend, the corrective moves never really

get too far. They are always going to

result in an impulsive move back in the

overall direction.

Now, to explain how to differentiate

between impulses and corrections, it all

comes down to the break of structure,

the higher lows, and the higher highs,

the higher lows, and the higher highs, right?

So, if we focus in for now just on this

first bit of the trend,

we create a higher high and then we pull

back down and we create a higher low.

Now, to create a higher low, we simply

have to stay higher than we were at the

previous low, right? So, if our first

low is here, uh higher low is here,

this higher low is higher than the

previous one,

which means the movement here, the down

move, has not broken through any

structural points, right? All we've done

is we've created structure move number

one, small pullback, we never got under

that low, and then when we break through

into the new high when the break of

structure comes in, that's what

validates this as the higher low

and validates this move as the

corrective move, okay? So, to show you

that here, when we create a low without

getting lower than the previous, and

then we break through structure here,

creating a new higher high, this break

validates the higher low.

And therefore, with a validated higher

low, showing us that this movement

neither got under new structure or got

over any new structure, uh the

corrective move, that's what validates

this as a correction.

So, an impulse move is always the move

that breaks the structure. An impulse

move is breaking through a previous high

or low into a new high or low.

A corrective move is staying within the

confines of the previous leg of

structure. Now, a leg of structure is

defined from the low to the high, like

defined from the low to the high, like so.

So, this becomes a leg of structure,

So, this becomes a leg of structure, okay?

If the market fails to get above or

below that level on a corrective move,

well, it's going to be below in this

well, it's going to be below in this case,

like this,

okay? If we did that,

then this movement would become an

impulse because we would have broken

structure, we would have created a BOS

at this point. But because we didn't do

that and we stayed within the confines

of the previous leg of structure,

then this move down simply becomes a

correction. And then when the next move

takes off, we see the break of structure

coming in there, that validates this

move as an impulse again.

Then from there, if we had a pullback

movement, providing it stays within the

confines of that current leg of

structure, which is that low to that

structure, which is that low to that high,

then this would just be a corrective

move, and the impulse would come when

structure breaks again. Okay?

So, our goal, when we are trading in an

uptrend, is going to be to look for our

buying opportunities on the corrective

moves. We want to be buying here,

somewhere, right? Ideally, as close to

the low as possible.

The reason we want to buy on the

corrective movements is because we get

the best risk reward. Now, that

basically means we get to risk our set

amount and maximize the profit potential

we get because the market has more room

to move.

So, if we were looking to buy

right now, we think this market's going

to continue, we wouldn't buy there

because in order to have a safe stop

loss, we may have to put our stop loss

down here cuz the market realistically

can pull back anywhere inside of this

range before going higher.

So, if we were to buy at the top and we

were to put our stop into the low, we

would have to see pretty significant

price movements just to make a 1x of our

money. So, if we risked $100, it'd have

to get very far just to make $100 more,

and we have quite a lot of drawdown,

basically dead space where the only

thing we can do inside of this is lose

money, right?

Now, opposing that, of course, if

instead we are able to buy on a

correction, so say the market pulls back

down here. If we're able to buy here

and we have our stop loss there, well,

now our entry is much lower, which means

the same amount of risk opens the doors

to a three, a four, or a five x on the

way up because simply just returning to

the previous high would actually give us

2.5 times our money, basically. If we

risk $100 over this price move, then the

run from there up to there is going to

be around $250 of profit. So, it's a lot

more valuable for us to buy on the

pullbacks. Now, exactly how to do that

will become very clear as we go through

the different concepts inside of this

course, but that's what you need to know

for now.

Corrective moves are always going to

happen. They don't tell us anything new

particularly about the trend because if

they don't break through previous lows,

then they're not going to change the

overall direction of the market, but

they are really good for us to buy from.

And in a selling case, they're really

good for us to sell from because we

either get a premium price to sell

or we get a discount price to buy before

the next impulsive move. We've discussed

impulses and corrections, and we've

discussed the direction of trends being

determined by highs and lows. So, if we

were looking at this market, what would

we see? Well, we have a high back here,

we see? Well, we have a high back here, okay?

Then we have a low

just here.

And we have a lower high

just here,

which is validated by the fact that the

market then broke down at this point

to create a break of structure

and therefore

a lower low.

So, if we mark out this trend so far,

first off, our impulses and corrections,

we have an impulse, okay?

Then we have a correction. Why is this a

correction? Because it didn't break

through the previous high. Therefore, it

is confined within the previous leg of

price action, okay? Which is this run

from that low to that high.

We pull back on the corrective move, and

then we have another impulse. Why is

this an impulse? This is an impulse

because it did break through a low.

So, the impulsive movement has broken

through the previous leg of price

action, creating a new leg of price

action, and that new leg is an impulse,

all right?

So, what would we expect to happen from

here generally based on everything that

we've discussed so far?

Well, the general approach would now be

to look for a corrective move. So, we

would be looking for something like

would be looking for something like this.

And then from there, we would look for a

new impulse where we would see the low

break again and a continuation of the

downside price action, right? So, we are

looking to see the market get somewhere

into this range

and then sell back down to create a new

and then sell back down to create a new low.

So, before we continue, let's just mark

this. We have our high.

We have our low. So, we'll just keep

these simple for now. Then we have a

lower high and we have a lower low.

And that is the current trend. So, we

have confirmed that we are in a

have confirmed that we are in a downtrend.

All right. So, from here, we see the

market trades back up. Okay, this is

what we see as a corrective move.

Remember, providing we stay beneath this

high, we are in a corrective move only.

Then our corrective move completes,

which is that movement from

the low towards here.

We only know where this high ends once

we have validated with the new impulse,

right? So, when we get to this level and

we form a new lower low, that validates

the lower high. So, we see this lower

low, we validate the lower high, and we

low, we validate the lower high, and we know

that this is now our corrective move,

the pullback up,

and this is our new impulsive move,

okay? So, we have

impulse, correction, impulse,

correction, impulse. And we have our

high, our low, lower high, lower low,

lower high, lower low. So, this market

is continuing this downtrend nicely. All

is continuing this downtrend nicely. All right.

So, you're seeing those concepts come

together now.

Now, in pushing through this low, we

have created again another break of

structure. So, we would mark that BOS.

And now we have our new leg of price

action, which is going to be this high

to this low. So, we can now mark this

range and we again are looking for a

break beneath and we're looking for the

market to stay beneath this high in

order to continue the downtrend, right?

So, our new leg of price action is now

So, our new leg of price action is now here.

If we were to

pull back inside of this range without

getting above this high, and then we

were to close that, this would again be

a correction impulse and that would form

a new lower high there.

And if the market was to get over this

high, then that would actually an

impulse in the opposite direction

because at that point we would create a

break of structure here, which would

then mean we would expect correction and

impulse higher.

That's a reversal and we're going to

talk about that in just a minute.

So, at this point we kind of have

continued down. I would just not

classify this as a full corrective

movement. Therefore, our lower low would

still be continuing to be formed

essentially at this point in time,

right? Again, at this point we haven't

had a strong corrective move. So, I

would just consider this

the full swing move, right? To see a

correction, we want to see an obvious

pullback move. If we take a look at what

we have here, this [snorts] is all one

leg of price action. This is the

corrective move. It's very clear and

obvious. This is one leg of price

action. This is the corrective move.

This is one leg of price action. This is

the corrective move. We want to see a

notable pull away to actually validate a

new lower high.

We really want it to have that, you

know, that standard zigzag pattern,

right? This is how we know that we're

looking at true corrective moves.

So, we're seeing the market pull back up

and if we let it run forward a bit more,

we [snorts] see that it has failed to

close over the high here. So, again

creates a new lower high and then it has

closed successfully beneath the low. So,

now we've validated a new lower low. We

mark the break of structure. We mark the

lower low. Obviously, this one can still

continue to form if it wants to, but for

now we know that this structure is

validated and we have a new lower high.

So, providing the market stays under

this high, we remain bearish, right? And

from there, we would expect a pullback

and then continuation in the form of a

correction and an impulse and a lower

correction and an impulse and a lower high

and a lower low, right? That is trends

in a nutshell. That's the basics of

everything I've showed you so far in the

context of a down trend. Now, an uptrend

is simply the opposite, but the same

exact concepts just flipped the other

way. Looking at higher highs and higher

lows instead. Okay, so a market is not

going to trend up or down forever. There

are going to be cycles in the market. We

have some uptrends, we have some

downtrends, we have more uptrends, we

have consolidations, we have more

downtrends, right? The market's moving

cycles through different phases. So, we

need to understand when to let go of a

bias and when the market is telling us

that it's changing direction. To do

this, it's very simple.

In an uptrend where we have a higher

highs and impulsive moves and we have a

higher lows created by corrective moves,

the reason we know they're a corrective

moves is because the market didn't trade

through the low, right? So, we know this

is a corrective move and a higher low

because the market didn't get through

this level.

As long as it stays within the leg of

price action, so within the impulsive

leg, anywhere inside of here, it's fine

to continue trading this bullish because

we know that is still a corrective move

in an uptrend. The impulses are still

driving to the upside. We're still

forming higher highs and higher lows.

So, to validate a reversal or to

identify a point where the market is

changing direction, we just keep an eye

on the lows for an uptrend, right? If

we've got this higher low, anything that

happens above this level is simply a

corrective move, of which we would

expect an impulse to follow from that.

However, if we are to see the market go

through this low,

then this changes the picture. Because

what this does is it shows us the market

is no longer structurally moving in

higher highs and higher lows. And what

we've actually printed instead is a

break of structure to a lower low.

So, by breaking down like this through

the higher low, we create a lower low,

which then sets in motion the beginning

of a downtrend.

Because when we talked about downtrends

and in that example we just showed, what

do we expect to see? Well, after we

create a lower low, we expect a

corrective move to print a lower high.

And after that lower high is printed, we

expect an impulsive move to break the

structure again and print a new lower

low, okay? So, that is what a reversal

looks like in the market. It happens

when an impulsive move is followed

immediately by another impulsive move,

but in the opposing direction.

Basically, instead of a correction where

we stay above the previous low, we

managed to close beneath. That then

becomes its own impulsive move lower,

and from there we can expect a

corrective move higher and another

impulsive move lower.

Now, this happens the opposite way, too,

right? We have in a downtrend, if the

market impulses through a lower high and

creates a higher high, that is the first

sign that this market is turning around.

Because, of course, in an uptrend, we

expect, if we do manage to get through

into a higher high, we expect a

correction, a higher low, and an impulse

into a new higher high, okay?

So, that is how all of this works. Now,

reversals are actually quite simple to

understand, as you can see. We're

basically looking for the point where

the trend gives way, and we end up

seeing an impulse lower. As soon as this

previous low goes, it basically tells us

that the market is reversing, and we can

that the market is reversing, and we can start

getting rid of buy ideas and start

looking for sell ideas instead, okay?

That is how we spot reversals. All

right, so let's see what that looks like

on a real chart then. We have here

EUR/USD, a downtrending market, okay? We

are forming lower lows and lower highs

are forming lower lows and lower highs consistently.

We're seeing those break of structures

come through. And if we're to mark on

the structural levels, you can see I'm

putting on the breaks of structure, the

impulsive downward moves, right? So, we

have impulse, we have impulse, we have

have impulse, we have impulse, we have impulse.

These are the movements to the downside,

and then the corrective movements are

like these movements that we're seeing

throughout this trend,

which would leave our most recent higher

high, or lower high should we say, at

this level, okay? So, this is the point

of which if we see the market stay

underneath that, we would be looking to

sell corrections. But, if the market was

able to get up over this level, we would

then presume to see it, as this would be

an impulse, a correction into another

impulse, and then a continuation of an

upside trend, right? So, all it takes to

shift the trend, and this is nice and

simple, is for the candles to go and

close above the previous high, okay? So,

you can see that trending markets are

pretty simple. While it's moving down,

we sell with it. And if it shifts, we

just immediately look buy side, all

right? So, let's see how this market

progressed. We see the market drove up.

Could potentially still be a corrective

move here, but then when we break above

at that point, that creates the impulse,

which now shifts this market from a

downward trend

into an upward trend, right? This break

then sets in motion, we'd be looking for

corrections and continuations. Now that

we've shifted to the upside with this

break of structure, okay? So, I still

just call them breaks of structure, cuz

that's what they are, nice and simple. I

would then

be looking for correction. Now, this

could be the correction, We'll see

whether it closes and then we'll be

looking for impulses further from there,

looking for impulses further from there, okay?

So, running this market forward,

we see we get another large impulse,

pullback, correction, and another large

impulse there as well. So, yeah, we're

seeing here this trend basically in

action, right? You see the downward

trend, lower lows, lower highs, and

breaks of structure to the downside.

Then you see the break up creating an

impulse, and then we have correction,

impulse, correction, impulse, and so on.

That is what a reversal looks like in

the markets now.

This is an incredibly aggressive

impulse. They're not all going to be

like this, okay? We're not always going

to see this level of momentum behind the

reversal moves.

But, long story short, you know what

you're looking for. It's going to be to

see a bullish trend shifting to bearish.

We take a look at the low, and if that

low breaks, that creates an impulse,

then we look for correction and sell. On

a buy side idea, it's just the opposite,

okay? We mark out the structural high,

okay? We mark out the structural high,

and then if the market gets back over

that level, that creates an impulse, and

then we look for a correction down and

an impulse higher, right? That is

reversals. Okay, so those are the basics

of market structure. You've seen the

uptrends, downtrends, consolidations,

reversals, impulses, and corrections.

Now, we're going to go one step deeper

to look at internal versus external

structure, okay?

Now, we have

inside of every trend, smaller trends

taking place if we are to drop down time

taking place if we are to drop down time frames.

So, let's say this black line that we

can see, the standard impulse correction

flow, is the 4-hour time frame.

Now, inside of this 4-hour uptrend that

is quite clearly showing impulses and

is quite clearly showing impulses and corrections,

we have smaller

downward trends and upward trends taking

place on, say, the 30-minute time frame,

right? So, because time frames are

fractal and they're going to show their

own trends, their own patterns,

regardless of what time frame you look

at, we're always in a state where there

are trends inside of trends. Now, these

can be traded uh using topics that we

call substructure versus swing

structure, which we'll get into soon.

But for now, I want to talk through the

basics of this and also help you to

avoid some mistakes that I see people

making all the time.

Right. So, if we have trends inside of

trends, okay, the 30-minute and the

4-hour. One of the most common mistakes

people make when it comes to structure

is they will see a level like this, for

example, break. One of the internal lows

example, break. One of the internal lows breaking.

And they will presume that because we've

broken down into a lower low at this

point, we should sell with the

anticipation of a full-blown market

anticipation of a full-blown market reversal.

Now, the reason that this is a mistake

is because although yes, this 30-minute

trend has shifted bearish, when we take

a look

at the 4-hour time frame, we see the low

to the high, okay? So, those two levels

from here through to here,

these are still intact, okay? This break

hasn't changed anything about the larger

4-hour trend. In fact, all it does is

kick off a potential correction before

we continue trading upwards again.

So, while you can trade these breaks,

the internal structure breaks, you have

to understand that this is a smaller

trend inside of the larger trend. And

the larger trend is generally going to

take precedence over, you know, which

one's more accurate. So, if we are to

trade internal structural movements like

this one, we should only be looking to

trade down somewhere within the 4-hour

swing leg. We shouldn't be looking to

take this market further than that leg.

So, we should not look for that.

The reason for that is, of course, that

the 4-hour trend is still indeed intact.

We have impulse, and so far, all we're

doing is creating a correction.

The only reason we would look to sell

through this low is if we first of all

traded through this low. Now, this would

confirm a bearish trend and then we

could look to pull back and sell. But

because the market has maintained above

this low up until this point, then we

shouldn't be looking for a significant

downward moves.

Now, the same goes when the market

starts to shift back up. We can actually

use this as a good point of information

to start looking for our potential buys,

right? Because we have the impulse, we

have a correction, and when the market

on the 30-minute or the lower time

frame, whatever it may be, starts to

shift bullish again out of a corrective

move without taking out the low of the

4-hour structure, then that creates the

confirmation we'd want to see that says,

"Okay, the 30-minute now moving bullish

is aligning with what we see on the

4-hour, which is bullish." So, now we

have agreement across time frames and we

do this by using kind of these smaller

trends inside of the bigger trends. And

when the smaller trend agrees with the

bigger trend again, that is basically

the best probability point we can get to

start buying or selling into a market

depending on which way it's going,

right? So, the key points to think about

here are every trend is going to have

smaller trends within it. The 4-hour

will have 30-minute trends in it. The

30-minute will have 5-minute trends in

it. The 5-minute may have 1-minute

trends in it. You're always going to see

this flow where there are smaller trends

inside of the larger trends. And the

important thing to remember is that the

bigger trend that you found your ideas

on, let's say you're analyzing here on

the 4-hour, this trend of impulse,

correction, impulse is always going to

take precedence over the smaller trends.

The smaller trends can be traded in

their own fashion and again we'll get

into just how we do that, but you should

never look to take the smaller trend

movements past the lows of the larger

trend, right? So, if you're selling here

on the 30, you have to understand the

market is likely to react from somewhere

inside of the 4-hour leg and continue

trading up. Rather than what you're

probably hoping for, which is for it to

break down into a full-on bearish

break down into a full-on bearish movement.

So, before we come back to talk about

swing and substructure, we're going to

show an idea of this on a chart and I'm

going to present to you a couple of the

extra mistakes that people make when it

comes to trading internal over external

structure. So, here we have a downward

moving market on GBPAUD. And

realistically, marking the structure up

in the swing structure pattern or the

external structure pattern, if we view

this as the simple waves that we have,

we have one large bearish impulse. Then

we have a bullish correction, which

fails to break through any previous

highs, therefore continuing the bearish

impulses down and confirming this to be

a downtrend, all right?

So, if we have a downtrend in action and

we understand that the structural high

of the previous leg of movement sits

around this level here,

then we want to make sure that we are

not looking to take the market past this

not looking to take the market past this high.

If it happens, yes, that confirms

reversal and allows us to trade higher.

But until that happens, we should be

looking to sell, okay? And we understand

the market can run anywhere inside of

this leg of price action before

reversing. It could come up to here.

It could go all the way up. As long as

it stays underneath this high, the

market remains bearish because the price

structure is telling us that the sellers

are still in control.

So, inside of this bigger picture trend

that we've just drawn out, you can see

that there are smaller movements

happening, which basically create their

own trends within. This is that kind of

let's say 15-minute inside of 30-minute

or hourly trend that we see, right? We

have all of these little price movements

creating its own trend. But when we

really just factor everything as simple

waves, we've got one run lower, one

corrective move, and one run lower

corrective move, and one run lower again.

Now, that's something you do have to

work on understanding is viewing

structure as waves. When I say that,

you're really just looking for

the direction down, the pullbacks, and

the direction down. You're not digging

into every tiny little movement that's

taking place. You're trying to

understand the general bigger picture

understand the general bigger picture flow.

So, if we were to look at this as a line

So, if we were to look at this as a line chart,

we have quite simply a big impulse. We

bottom out there, we pull back, we top

out there, and we impulse down, right?

So, average these out into waves, that's

how you read the bigger picture

how you read the bigger picture structure.

Now, again here on the line chart, you

can see there are indeed loads of

smaller these internal structure moves

taking place within the bigger picture

trend that we've got, right? So, that's

the internal structure.

the internal structure. Now,

obviously at this point we know

that the market should remain bearish

providing it stays underneath this high.

So, the one mistake I want you to make

sure you do not make is when you see a

internal structure break taking place,

you treat that as reason to trade all

the way through the swing structure or

the external structure.

So, for example, a lot of traders, they

will see this high break, and yes, this

is bullish to some degree because we

broken through a previous high.

But this is bullish in the case of this

internal trend, the smaller trend, okay?

It's not bullish in the case of the

bigger trend because we know it's still

capped up here.

So, if we break through this high, the

mistake that you need not to make is to

expect this to then continue all the way

through to over this high.

Because at this point in time, there's

nothing telling us that that is going to

nothing telling us that that is going to happen.

What we have is a short-term break to

the upside, right, taking place at this

level. But all that means is we are

likely to see some upside before

reversing from inside of the previous

leg of structure. So this, the break

here, kind of all just confirms a

corrective move is beginning. And

eventually that is likely to turn back

into a bearish impulse, okay?

So we can of course trade this because

if we did get a break, we would

understand that we are bullish to

somewhere else in this move.

That means we could actually start to

target, for example, internal points of

liquidity. Now this is a concept we're

going to get to very soon and we'll

start to put trades together then. But

for now, basically, if we do break

above, all it means is we have some

targets to points basically inside of

the bigger range, okay? So we're never

looking for massive trades, but we could

potentially see something like this, of

which we could then look to sell from

which we could then look to sell from again.

Basically, the core thing is to

understand to draw your structure as

waves, averaging everything out into

these simple visible moves. The line

chart can help you to do that if you

find it difficult to begin with. And

then if we do see internal structural

shifts like this one that we've just

mapped out, yes, it can provide

opportunity, but we must always give

core focus and give precedence to the

4-hour or the hourly or the larger trend

that we've actually set the trade up on,

okay? Because these structure moves that

we get are going to take precedence over

these small ones. And providing the

market stays bearish on the high time

frame, we shouldn't be looking for a

small lower time frame bullish shift to

change the whole market direction for

change the whole market direction for us.

So if I show you how this market then

plays out,

we'll get rid of the lines for now.

Remember, we're expecting the market to

stay capped into this high.

And as you can see there, we have this

internal break. Does this open the doors

to trading all the way through the high?

No. It just created a push up over the

internal high. Then we pushed over

another internal structural point here,

and then we've actually started trading

back down. And as you can see when we

got to that point there, we ended up

creating another leg of price action

structure. So, we have our low here.

Break of structure takes place there,

which essentially then creates the

impulse, correction,

impulse, correction,

impulse. Okay? That is the trend that

we've got.

So, even though these smaller highs

broke, these smaller internal structure

broke, these smaller internal structure points,

it didn't open the doors at all to any

trading through the bigger trend. The

external structure, or swing structure

as you'll hear me refer it to it as

stayed intact and kept the market

stayed intact and kept the market bearish.

Now, back to that point we said where

you can potentially reconfirm the

direction of the trend with lower time

frame breaks, we have of course impulse

correction impulse correction, and then

we started to break internal lows here.

This break down here

puts us back through the internal

structure in line with the external

structure direction. Now, I know there's

a lot of words here, but it's very very

simple, okay?

High to low, external structure. We

think the market's bearish.

Low to high, corrective move. This is a

short-term pullback that hasn't yet

confirmed anything in terms of larger

upside, and generally is going to be

where we want to sell the market from.

We then break down, pushing through

internal structure lows, okay? So, this

is smaller trend lows, but that pushes

us back into the direction of the bigger

picture downtrend that we're in.

So, when we see this break, this is

ample ground to basically start selling

pullbacks because we know the big

picture, the

1-hour trend, and the smaller picture,

this more refined 1-hour trend that

generally is going to be more of a 30-

or 15-minute trend, they're now both in

agreement on the sell side. So, looking

to sell pullbacks down towards the low

and beyond becomes is move there to

make, Okay? So, that's the difference

between internal and external structure

on a real chart, and that is how we look

to use them. We want to make sure we're

always giving precedence to the big

always giving precedence to the big trend.

If the little trend starts to shift

against us, that does not mean we're

going to go through the big trend highs.

And if the little trend then re-agrees

with us, that basically confirms the

corrective move is most likely complete.

It gives us opportunity to sell because

we understand that the low time frame

and the high time frame, the big trend

and the small trend are now in

agreement. All right. So, extending that

topic a little bit further, we're going

to talk about swing versus

sub-structure, which I don't want to get

confusing, but is basically the same as

internal and external, right? Um the

reason we call it swing and

sub-structure is just it's a little bit

more simple to say.

And these two types of structure are,

first of all, the main overall trending

structure, right? The

direction, the external that we just

direction, the external that we just discussed.

And the sub-structure is in reference to

the smaller trends within trends.

However, this time we kind of isolate

those smaller trends to the corrective

those smaller trends to the corrective moves.

So, swing structure, let's say we're

looking at a 4-hour trend, is going to

be a 4-hour downtrend. All right. We can

clearly see impulse, correction,

impulse, correction, impulse. So, the

4-hour swing structure is bearish.

But we said that those internal trends

are going to show shifts at different

points, and we even just saw that on a

live chart.

So, we are going to see the market

creating bullish breaks of structure or

reversals from these smaller, let's say,

30-minute bearish trends into 30-minute

bullish trends.

When we see these breaks up, we have

opportunity, sometimes not always, to

actually take trades that oppose the

overall 4-hour direction. And that's

because, as we've said before, the

market is fractal. Now, fractal simply

means the same patterns and same

formations happen on every time frame,

regardless of whether it's the one

minute, 30 minute, hourly, daily. You're

going to see the same patterns, the same

things happening. That's because buyer

psychology does not change. It just

happens over different periods of time.

A 4-hour trend is quite zoomed out. So,

that's showing you long-term buyer

psychology. The 1-minute trend shows the

same levels of buyer psychology but

happening over a much smaller period of

time such as over the last couple of

time such as over the last couple of hours.

So, because we see

very valid trends taking place inside of

larger trends, we can indeed trade

these. It becomes its own stand-alone

opportunity for us to catch a trade.

If we see the market shifting up on the

30 minute, there's no reason why we

can't take advantage of that trend. The

only thing we have to consider, as we

just discussed, is that we should never

look to take these trends past the swing

structure trends or the external

structure trends, okay?

So, I'm going to show you now an

opportunity where it was possible to buy

from inside of a smaller substructure

move and capitalize upon a

bullish movement inside of a

predominantly bearish trend. These

things do happen quite a lot. That's why

I'm covering them in this video. They

come around frequently enough to

actually create uh a very good basis for

opportunities. Now, this way, if you're

doing high time frame analysis but you

don't always want to hold high time

frame trends, you can still use the

opportunities of these smaller reversals

to capture shorter term trades inside of

big picture trends, right? It's a really

good basis for say day traders or people

who want to trade the smaller time

frames but still want that big picture

context behind their opportunities.

So, let's jump to the charts now and

I'll show you an example of this.

So, from what you've learned so far, you

can probably see this is a bullish

trend, okay? I'm going to draw up the

impulses and corrections for you. We can

see here

the flow of the market up to this point

and then we pull back down and we

impulse to here.

So, this is the swing or external

structure. Okay? We have clear impulse,

clear correction, clear impulse, clear

correction, and so on and so on up to

where we are right now.

Now, at this point, we have indeed

closed over the previous high, which

creates a break of structure. So, this

is a new higher high.

Now, with the formation of this new

higher high, we have validated a higher

low. Okay? That's going to be this point

just here.

So, this is our previous or current,

should we say, leg of price action,

which has taken place. Therefore,

meaning we would expect, given that it's

broken into a new high, for an upside

continuation to occur.

So, our overall idea would be to see

this market pulling back somewhere into

this range without taking out this low

to then move into the next impulse to

the upside. All right? That would be the

plan for this market.

Now, we can, of course, then take

substructure opportunities. So, for a

substructure opportunity, we are

basically looking to catch the

corrective move down. So, we're looking

for an opportunity to trade this move.

Now, because we know the market isn't

going to get all the way through this

low, well, we don't know that, but we

know that if the trade remains valid, so

it would only be safe to trade towards

this level for now,

we would want to find a area, a target

inside of this movement up. Now, for

reasons that will become rather rather

reasons that will become rather rather soon,

this is going to be one of those core

points. Now, this incorporates a few of

the concepts we're going to talk through

in this course, efficiency and supply

and demand. So, for now, don't worry

about the reasons too much, as we're

going to get into those, but that is the

point that we would want to see the

market target.

Now, we have to look at the internal

structure. So, we're looking for the

trend that's taking place inside of this

individual leg of price action.

This is that move. We've averaged the

movements out into those waves. We have

an impulse, a pullback, an impulse, a

pullback, an impulse, a pullback, and

then an impulse into here.

Remember, the mistake that people make

is they see a break of this low, for

example, which yes, it is a valid low,

but it's a valid low of internal

structure, and they think that this

means the market's going to go all the

way down. But, it doesn't mean that

because this

external structure, the swing movements,

they're still intact, right? So, as long

as we stay over the low that we have

marked, just here,

we will remain bullish.

So, for internal structure, we would

realistically expect this low to be the

one we want to focus on. Now, the reason

we don't just sell randomly is because

the market can keep going up. And the

reason we wouldn't sell if we had a tiny

pullback is because once we break down

that internal structure, and we identify

that we have impulse correction, impulse

correction, impulse correction, impulse,

well, if we stay over this impulsive

low, we could realistically pull back

and continue trading higher, creating

more of the internal trend before a

deeper movement comes in the future,

deeper movement comes in the future, right?

So, basically, what we want to see for

substructure trades, for these internal

opportunities, is for the market to

break down through an internal low.

Now, the nearest internal low, and the

one that's currently relevant, is going

to be this low.

So, we would only take a substructure

trade if we saw a break of structure

here because that would put this smaller

internal trend into a reversal, and

therefore, we would expect it to move

bearish, right?

So, what we would do is let the market

run, see what it does, and if it breaks

through this low, now we have grounds

for a trade.

We've actually closed lower, showing

bearish intent or seller control.

And now, if we can, we would want to

find opportunity to sell down into a

point of interest. Now, it is important

that the point of interest isn't already

hit, because if this market was to hit

this level, then selling against this

would be pretty risky, given that we've

hit a pretty cool point that could

continue the market into an upward

trend, right? That is why these are only

tradeable sometimes, and that we can't

get substructure trades every time. For

example, if we look back at the previous

leg up from here to here,

yes, we had a nice impulsive move. And

yes, we had a breakdown at this point

where we started to break into a bearish

trend. But by the time we returned to

anywhere we may look to enter from, the

market had already come through the

entire range and almost met the low.

So, there would be no opportunity for us

to sell here, because the entire range

is essentially already been filled. And

as you can see, of course, the market

didn't reverse after that. It came down,

it came up, and it didn't give a selling

opportunity. It just continued towards a

new high, okay?

So, likewise for the setup we're looking

at, we would want to see the market

basically reversing without filling the

point of interest or the area that we

want to see targeted. But as long as

that doesn't happen, we can use some of

those same concepts. Again, these will

become very clear inside of the course.

For now, I'm just showing you the

concept of this internal trading.

And we could place a trade that looks

something like this, for example.

So, we would be looking to sell from the

top if we got the pullback, and then

take profits once we hit the point of

take profits once we hit the point of interest.

We take profits here instead of all the

way down here, because the way that we

understand structure, the market

shouldn't get this low. It could, but

it's not expected. So, what we're

looking to do with substructure trades

is basically catch a high probability

move and then just get out with our

profits and see what the market does.

Now, if the market was then to break

down significantly, we could lead that

into a bigger picture reversal on a new

into a bigger picture reversal on a new trade.

But for now, it makes sense to just play

safe and take the obvious opportunity,

which would be this trade here.

Now, if we see how this market formed

from there, we returned to the entry

area. Remember at this point, we're

basically catching a reversal trade

because we've seen a break of structure

through this low.

The market came

pretty high into the zone on this

opportunity, but we did break structure

and we did fail to then retake the high.

So, from there, the market created its

run down and hit the point of interest

that we would want to target.

Now, from here, the market could go

lower potentially, but we would

generally expect it to continue into new

highs. And that is why we would take the

safer opportunity and get out a little

bit earlier.

Now, from this example, we can of course

see the market did get lower. It didn't

break through the low, so it did

maintain its bullish structure and we

would expect it to lead into a new

would expect it to lead into a new impulse.

But, this highlights why we want to make

sure we're getting out early, right?

Because the market will give you these

things that will make you feel greedy

where it looks like, "Oh, I could have

made more on this movement down."

But, the market's not always going to

get down this far. Often times, it's

just going to fill a notable point of

interest, of which you will learn how to

identify those, and then it will get its

reversal from there. So, taking these

simple and safe trades with those

smaller internal trends is pretty much

always the right thing to do. Because

when you do that, you get to lock in

small wins and then run into the larger

moves in line with the external or swing

structure. Okay, so those are the core

elements of market structure. And we're

going to recap what we've been through

so far.

First of all, markets move only in three

phases. We have uptrends created by a

continuation of higher highs and higher

lows. Every high is higher than the

previous. Every low is higher than the

previous. And when the market breaks up

through a previous high, that confirms

continuation of an uptrend. A downtrend

is the opposite. Every move we make

creates a lower low and a lower high,

where the lows and highs are lower than

the previous ones formed. And every time

we break through a previous low, we

create an impulse that confirms

continuation of the trend.

When the market is moving sideways and

not showing any clear direction, this is

a consolidation. And the best thing to

do through these phases is simply

nothing, okay? As we get into liquidity

and other concepts, you'll see some ways

to make use of consolidations, but if

you want the most simplistic trading,

the way to trade is buy through

uptrends, sell through downtrends, and

simply stay out during consolidations.

Now, each of the trending moves we see,

whether it's an uptrend or a downtrend,

is going to be made up of impulse moves

and correction moves.

Impulse moves are the movements that

break through previous structural

points. So, when we push through this

higher high to create a new higher high,

this is an impulse move.

Corrective moves don't break through any

Corrective moves don't break through any structure.

Corrective moves never get past the lows

or the highs of the previous leg of

price action.

So, this move remains a correction

providing the market doesn't get under

here and instead leads through to

confirm as a higher low by creating a

new higher high at the end of a new

impulsive move.

Now, this is exactly the same for

downward trends, except everything is

flipped the other way.

When we see the markets reversing, so

when we see a higher low break in an

uptrend, for example, that actually

creates an opposing impulsive move.

And the impulse to the downside that we

see when the structure breaks confirms

the market should now be in a downward

trend. So, from here we are looking for

the formation of a lower high and

expecting a new impulse to a lower low.

So, to see a reversal, all you're

looking for is basically the structural

low in a uptrend or the structural high

in a downtrend to give way where a

corrective move turns into an impulsive

move and then the trend naturally shifts

from there.

Inside of every piece of structure we

see, we are going to have internal and

external structure. We will see the

bigger zoomed out pattern, the waves

that we discussed, say on the 4-hour

time frame, the daily time frame, it can

be any time frame.

And then the internal structure will be

the smaller trends inside of trends that

we see.

Now, this is all completely relative. I

don't want you thinking you can only

find external structure on the 4-hour

time frame because that's not true.

If your external structure is say the

15-minute in this example, then your

internal structure would likely be the

2-minute or the 5-minute trends.

Now, you saw in my example, we don't

always even have to drop the time frame.

We're always going to see these natural

movements that we can refine out to

identify which is the swing structure or

external structure, right? We remember

we uh simplify those moves into waves,

and then all of the smaller moves that

we see within, these then become the

internal structure.

Now, these become useful because we can

trade the trends inside of trends as I

taught you when we talked about the

swing versus substructure. Your swing

structure is your overall higher time

frame direction, whatever time frame

that is relevant to the way that you

trade. And the substructure is the

smaller internal structure moves that we

see on the way into corrective moves.

Now, we trade the swing structure by

selling into the larger trend or buying

into the larger trend depending on which

way the market's going, but we can also

trade the substructure, which relative

to the high time frame is what people

would call a counter trend trade.

However, when we do start to see the

smaller trend shifting, it sets up a

completely valid opportunity for us to

then buy because we are seeing a valid

trend shift on its own.

So, substructure and swing structure are

both very relevant and both can be

traded in their own ways.

Now, you're going to see market

structure come up and all of these

different elements come up as we talk

through other elements and other

concepts inside of this course.

But for now, I'm going to leave you with

this. And before we head on to talk

about the next concept, we're just going

to go through some of the obvious

structure mistakes that people make. So,

if you've been trying to trade structure

and struggling or when you get into

trading structure so that you don't

struggle, we're going to set you up with

some of the mistakes that you can easily

avoid once you understand them. So, with

that said, let's get to it. Okay, the

first thing for us to go through here is

the importance of candle body closures.

So, when we were talking about

candlesticks, we mentioned we have

candle bodies and we have wicks as well.

The candle body shows confirmed price

movements within a given time frame. The

wicks, however, only show rejections.

So, when we are determining whether a

structural level has broken or not, we

have to see candle body closures to

truly confirm the opportunity.

If we take a look at this trend that

we've got moving on up from the low

here, we can see this downward trend has

shifted, right? We started to see the

shifts come in and from there we've

actually shifted over more significant

actually shifted over more significant points.

Now, zooming in then on the bullish

trend we've currently got,

we have a high

and then we closed at this level here,

creating the break of structure.

We then have a new high here and we of

course closed over it with this large

impulsive candle, creating a new break

of structure.

Then we have this high here and the

market has closed through it, creating a

new breaker structure. And then, once we

got to this high, we saw a big sell-off.

Now, our higher low for this upward move

is going to be just here.

So, we would expect, if the market is to

get under this level, that would change

the direction of the trend, right? Now,

obviously, if it stayed above the level,

it should remain bullish, and we

therefore should be looking to buy.

But, one thing people do is they jump

the gun too fast on both of these

things. So, first of all, let's take a

look at this bit of price action.

Here, we created a high. We then had a

corrective move, and the market pushed

up. This wick, however, does not

validate the continuation of the market.

The market could wick over, and then

come lower, and then go higher, and that

would still remain valid, but it would

set the higher low at this point.

So, you never want to trust wicks to

actually confirm your breaker structure

inside the continuation of a trend, cuz

it can actually show rejections.

And what could happen after this is the

market could actually sell off

considerably more.

So, we have to see candle body closures,

just like this candle here, and just

like we've seen on the other candles

here and here, as well. Okay?

Now, the same goes for reversals. We

would really want to see, if we wanted

to in any way validate reversal, if it

was to come through, we would want to

see a candle body closing underneath

this low. So, we do not want to trust a

wick here. It's got to be a body,

because we need to see confirmation of

that move. We don't just want to see a

rejection of that move.

Now, the importance behind that, you're

about to see it now, because we have

this candle, which at one point in time

would have looked like it was closing

beneath here, right? During the 4-hour

window, this at some point would have

been a gray candle or a bearish candle

starting here, and that with a a low

down there. So, if you were to sell into

that too quickly, without allowing the

candlestick to close, you could have

been tricked into thinking that this was

a break. But, as you will see by waiting

for the candle closure, it ended up as a

massive rejection candle.

Now, this is one of those candles that

we discussed, right?

If we dig into what the price action is

actually showing us inside of this

candle as a line chart, for example, we

have an open, the market's moved up a

bit, it's moved down significantly, and

then it's moved back up, and actually

closed a little bit higher than the

open, right? Now, we do have that little

bit of movement as well, but we've

closed higher than the open. So, what

this candle is showing us is an attempt

to go higher from buyers, rejected by

sellers, and then a significant amount

of buying pressure driving the market

back up and closing even higher than the

candle opened.

Now, obviously, in seeing that, you

would understand this is most certainly

a reversal and rejection rejection

candle rejecting any attempt by the

sellers to go lower. We have rejected

that idea, and now the likely outcome,

given the buy-up control that we've

seen, is for the market to trade higher.

So, if you didn't wait for that candle

to close, and you ended up trusting the

wig, or trusting an unclosed candle body

underneath this level, you'd be looking

at this for a selling opportunity. When

really, the closure proves to us that

this is a huge bullish rejection and

reversal candle that is likely to lead

into a simple upward continuation.

Now, if you see what happens next in the

market, that is exactly what went down.

We just had a new impulse up, and we

ended up going and creating a new high.

Now, the interesting thing about this

is, this also doesn't change the

trending structure. We don't have to see

this as a lower low, just because it

closed underneath this level. Well,

because it didn't. It wicked underneath

this level. This is actually what we

call a sweep of liquidity, or a

liquidity sweep, and that is, of course,

a content.

Now, another interesting thing is you

don't have to classify this as a lower

low, because it didn't close beneath the

previous low. It's simply a rejection.

Now, we call these sweeps of liquidity

or liquidity sweeps, and we are going to

be getting into that concept in this

course a little bit later. But, if we

just have a simple wick beneath and a

rejection back into very strong upward

price, we would just keep this as a

simple trend, right? We still have our

low, our low, our low. This one is

slightly lower, but it's a rejection,

not a reversal candle. So, we can just

classify this as our new higher low, uh

and then from there we should be

expecting to see continuations higher.

Now, if the market was to, of course,

come down and close under this low now,

then yes, that would validate sell-side

opportunity, but for now, we should

remain bullish.

So, the first big lesson, the first

thing that I'm trying to get you to

understand is that you should trust

candle body closures only for your

confirmations. You shouldn't be thinking

about candle wicks. Candle wicks will

not confirm reversals, and they will not

confirm continuations because they are

rejective candles. We have to see body

closures to tell us that the market

participants are indeed willing and able

to move in whichever direction the

closure is in.

Okay, the next thing to be aware of is

the correct use of internal structure,

the correct use of internal structure, right?

So, if we have a swing movement, we have

an impulse correction and then an

impulse towards this high. Now, this bit

of the top here, this represents

internal structure.

If we were to have this movement, and

then the internal structure was to break

lower, this could provide us with a

substructure opportunity to sell the

market down somewhere into this range,

remembering that we should stay above

this low, okay? So, this would be valid

for a setup. Now, there is one mistake

that people make very frequently with

this, and something you will probably

make at some point yourself.

And that is that they will see a

movement like this, and they will treat

this in the same way.

Now, what's happened in this case is the

high that we have internally has not

surpassed the previous one. So, we don't

have that reversal pattern where the

market is shifting from bullish impulses

and corrections into a bearish impulse.

In this case, what we're actually

looking at is just a simple corrective

move, right? We don't have the shift

that we want to see. We don't have this

higher high into lower low. That is

essential to confirm a shift in

essential to confirm a shift in direction.

If we think about how that would work

with the current movement, well, uh

impulsive move is just this. We topped

out there, and everything that's

currently happening is simply an

internal correction. Okay, we don't have

any push above and then pull lower. So,

this is kind of actually just

meaningless price action.

Now, what people will do is they will

treat this break as a place to sell from

because they will see this breaking down

here as a valid break of structure. But,

it's not because this in itself is still

not a valid structural move. This all is

just a correction lower. So, selling

from here makes no sense because we are

just inside of a corrective move with no

lower time frame or internal structure

telling us that selling is wise. So, the

most likely outcome from this is going

to be a push back over the high,

therefore stopping you out of a sell

trade that you might be getting into.

So, to look at this on a chart the other

way round here, we have an example. We

have this very bearish impulse. Okay,

that's completely fine. Then, we have

this tricky piece of structure, which a

lot of people will see as grounds to

make a buy, right? Because, I mean, if

you think about it, we created a low, we

created some more lows here. They were a

little bit higher, and then we broke

structure at this point. So, that might

tell us that this is a bullish market,

right? Therefore, you might want to set

up a buy zone, and when the market pulls

back into it, execute the buy.

But, that's not true. That's not

correct. Because the first low that we

created here

was the lowest low that we created. We

did not get that pattern of lower low

into higher high, right? Of everything

I've showed you so far, we have to get

that to confirm reversal because that's

actually the impulse turning into an

impulse in the opposite direction.

In this case, we have impulse, but we

don't have an impulse in the opposite

direction in any way. Not even in the

lower time frame price because this was

the lowest low. So everything inside of

here is just consolidation.

Now this in itself, without any reversal

into it, is a very dangerous place to

sell the market, or in this case buy the

market, sorry, because we don't really

have any reason to make a buy, and the

market can sink [music] at any time.

Now if we were to see instead, let's

say, a pull lower like this, taking out

this low, then we were to see the market

drive higher like this, closing over the

high, then that would validate a

reversal, at least internally, which

would give us grounds to trade a

pullback up towards maybe this point

here, right? This one. For reasons we'll

get into when we talk about supply and

get into when we talk about supply and demand.

So that could create an opportunity.

But as it stands right now, we don't

have any of that. We just have a low

being created, and then what you're

doing is actually just trying to buy in

at a random point, which essentially

looks like trying to buy here or here

when we don't have any confirmation to

do so just yet, right? Now I'm going to

show you what actually happened in this

example that a lot of people would have

bought into.

We just sink down

and confirm a new impulse lower.

Therefore, this substructure provided no

opportunity because it didn't give us

the right confirmation,

and instead we just got impulse

correction impulse, right? So that is

something very important to consider.

It's one of the most common mistakes I

see people making with market structure.

It's not just relevant on these

substructure pullbacks. It can be for

the swing structure as well, but it's

just something that's super easily

just something that's super easily avoided,

but definitely will help you to catch a

lot more winning trades.

So, remember, when you're looking at a

reversal in any context, it has to have

the impulse into impulse fashion, right?

It has to have that. So, what we're

looking at on the chart right now, not

valid because it didn't impulse into

impulse. But, we were to, for example,

get this,

well, this then becomes valid because we

have bullish impulse into bearish

impulse. We have higher high into lower

low, a very clear shift that therefore

creates a very

viable and valid trade.

Same if we're bearish, we have to see

impulse into impulse, lower low into

higher high. That is where we see that

clear reversal.

And if we don't get that, and the market

does this instead, this shows nothing

and is absolutely not valid to trade.

That's market structure, everything we

need to cover up to this point. You're

going to see this woven into the other

concepts we discuss, but for now, we're

going to move on to supply and demand.

So, this, as we said at the start of

this video, is pretty much the core

concept of the market, right? Or in

terms of why markets actually move.

Prices increase when demand is higher

than supply, and we see an increase in

demand creating a willingness to buy at

higher levels. And prices decline when

supply is injected into the market

without demand to meet it. Willingness

to buy is not high enough, and so new

supply, or assets that people are

selling, are listed and offered at lower

prices, which therefore makes the market

decline until we meet willing buyers.

Now, supply and demand, the concept can

actually be used in the chart to

identify areas where we will be finding

buying and selling opportunities.

So, a demand zone is an area of

So, a demand zone is an area of consolidation.

Notice here how the market kind of flats

out before a large impulsive move up.

Remember impulses that we discussed in

market structure.

A supply zone is an area of

consolidation before a large impulse

consolidation before a large impulse down.

Now, each of these things shows us a

very valuable piece of information.

If we think about what's actually

happening behind the charts, right? When

we see an impulse to the upside after a

small consolidation. This consolidation

area that we classify as a demand zone

is an area where significant buying has

taken place. We saw the market coming

down, then it flatted out, and then it

rallied with incredible strength, which

tells us this area right here, this

price range in this point in time is

exactly where significant amounts of

buying and significant amount of demand

entered the market, hence the impulse

that we got.

Now, if we know that this is seen as a

good price to buy from, and we do know

that, right? Because we obviously saw

significant amounts of buying take place

here before,

then we can classify this price range as

pretty much a discount price for the

asset, right? It's seen as a very good

price to pay for the asset, a fair value

for it. So, if we've seen significant

buying take place at this price before,

and now the market's trading higher, we

can pretty much be sure that if the

market is able to get here again, well,

it's going to be seen as an even better

discount now because the market's

trading to a higher value.

Therefore, when we see the market return

into a demand zone after the demand

zone's been created and driven a large

impulse in buying, we will oftentimes

see the market buy once again from that

same level, driving prices even higher.

That's how a demand zone works.

Now, a supply zone, as you can imagine,

is the opposite. This is a price where

we have seen sellers selling in mass,

hence the impulse that we got driving

the market lower.

If we know that sellers have been

selling here in mass, that could be seen

as a premium price level. It's a price

where holders of an asset want to get

out of the market because it's a just a

very good price to do so. It's a high

price, right? And it's also an area

where short sellers are seeing a lot of

profit potential if they were to sell

this market hoping to profit from a

this market hoping to profit from a decline.

So this time, we see this as a premium

price level, right? So this is a premium

because it's a high price that sellers

want to sell at.

And the other one, the demand zone,

that's a discount because it's a low

price that buyers want to buy at.

Now with the supply, of course, as you

can imagine I'm going to draw out, if

the market returns to this level again,

a level that is proven as a good price

for sellers to sell from, we are likely

to see more selling take place when that

level is met, and therefore we are

likely to see the market trade down into

a new impulsive low.

So you might already get a simple idea

as to how we're looking to trade these,

right? When we see a demand zone, we are

going to be looking to buy from that

area with our stop-loss beneath and our

targets up into the highs or beyond.

This is how we find entries. It's

basically the thing that's going to get

us into our trades.

If we see a supply zone, we will be

looking to sell with a stop-loss above

and targets down into the low or

further. This, of course, is going to be

the entry model and the way that we get

in for short trades.

So supply and demand is useful for a few

So supply and demand is useful for a few things.

First, it's of course going to give us

the entry.

Second, it's going to help us to

identify what we call points of

interest. So what I mean by that is if

we are looking to get into a buy trade

we are looking to get into a buy trade here,

it's just an immediate point that we

understand the market's likely to return

to. So rather than buying here, buying

here, buying here, and being too early,

you would just say, "Okay, I see a clear

demand, so this is going to be the point

to buy from." Same with sell-side

setups. If you see a sell here, you

don't have to jump the gun because you

see the clear supply, and then you sell

once the market returns to it.

They can also be used, and we may not

get into this one too much, but we will

go through it, as targets for interim

trades. So, let's say you found one of

those substructure opportunities at the

top here, right?

Well, this is where you could then use

the demand zone as a target. And you

might realize that we actually did this

in one of the previous examples

regarding substructure trades. We used

an area of demand, a consolidation

before a large impulse. And what we did

is we traded down into that demand, and

then exited the trade because we

understood this is historically a good

price to buy from, and so we may see the

market return to the upside and reverse

when we get there. But that means, given

that it's a magnet price area, the

market will be drawn towards, and given

that we are expecting generally to see a

reaction from there, it can be good for

a target as well. So, it's good for

a target as well. So, it's good for entries,

points of interest, and targets. That's

what we're using supply and demand for.

So, what we're going to do is jump over

to the charts, and I will show you how

to draw this in the candles. If we

consider the trend overall, we are

moving down, right? We have these

bearish impulses down. We had a break of

structure coming in under these lows,

which actually was confirmed around this

point with the candle body closure. And

even to back it up even more, we pushed

through the large day's driven wick as

well, right? So, we have two very solid

closures basically confirming that we do

indeed have the impulse correction

impulse format, and we're moving solidly

in a downtrend. Now, why is that

important? Well, that's important

because you always need to be trading

supply and demand in line with the

trend, and I'll talk about particularly

why very soon.

But to plot a supply or demand zone,

what you were looking for is an area of

consolidation where the market flats out

before a movement down. So, we're

looking for this point here, right?

Basically, this broader range.

Now, this only has to be an individual

candle. And I pretty much always will

draw my supply zones and demand zones

off of one individual candle, right?

So, [snorts] what we're going to look

for inside of the movement down here is

basically an area of consolidation where

the market moved sideways.

We already talked candles and you will

see that this candle here, the very

well, the pretty much one that's made up

only of wicks, is an indecision candle,

right? Candle body open and close is

exactly the same price. The market

didn't get anywhere within that given

time, and we have a wick below and a

wick above. So, we can see that the

market was indecisive at this phase. We

had a bearish candle, a bearish candle,

and then an indecision candle, and then

new bearish candles.

So, what that is showing

is basically sellers stepped in

around this point. They drove the market

down a bit, but then there was

indecision where they weren't strong

enough to drive it down immediately the

whole way. After a short while of

indecision, the market then sunk

considerably with a large impulse to the

downside, breaking us through a new

structural low.

So, we know that that candle there is

where the significant sellers stepped in

able to actually drive the market lower.

Therefore, this becomes

a supply zone, which you'll see me mark

as SZ. So, with this being the supply

zone, we would anticipate that if the

market is able to get back to this level

in the future, we are likely to see more

sellers come in because we know this is

a premium price level that sellers would

be happy to execute from.

So, what we would generally then do, now

there's a few ways to go about this, as

you will learn through the course, is

look for a sell from there. So, we

would, for example, place a trade that

looks like this. And when the market

returns to this level, we are then

anticipating a tap into the zone, new

sellers to step into the market, and for

the market to decline.

If we see what actually happened in this

If we see what actually happened in this case,

we did just that, right? We came back

in, we hit this area,

premium price, more sellers entered, and

the market then ran down due to the new

influx of selling that we saw, taking us

through a new low, and creating a new

low inside of the bearish trend. So, you

can capitalize on those movements by

trading out of the supply zone. It's

pretty much the perfect place for us to

target for our entries on these

positions. And now for demand zones, and

these are just the simple opposite.

We're looking for discount price areas

where buyers stepped in in mass. Now, we

can see by looking at this chart, our

consolidation phase basically came in

here, right? We had a drive up, then we

pulled back down a bit, and then we

rallied. So, this is the area that's

going to be treated as our demand zone.

Now, the rule that I use for marking my

supply and demand zones is the last

candle before the impulse. So, as we did

in the previous example, you'll see it

was the last candle before the impulse

down. For this example, I'm going to be

using the last candle before the impulse

using the last candle before the impulse up.

So, the demand zone is going to be drawn

wick to wick, covering the entire

candle, which is the last candle before

the impulse, all right? So, there's the

area of demand.

Now, because we've seen the market

impulse to a new high, that's what

validates this as a demand zone, okay?

We have to see that because that's going

to be basically the trend continuation.

And we have [snorts] this uptrending

fashion of higher highs and higher lows.

Now, we've broke up, we found our

demand, and we're going to look for a

buy from there. So, we would buy with

our stop underneath the zone, and our

target somewhere up into the highs.

Obviously, that comes down to other

concepts, too.

But, this is then going to be treated as

a bit of a magnet price area.

Now, notice here, as I when I was

explaining the diagrams at the start of

this section,

we don't want to just randomly buy into

impulsive moves, okay? This is why

supply and demand is so good because

when we see this demand zone, we

understand, okay, there's a high

probability the market's going to trade

back into here. The simple reason for

that is there's not so much transacting

taking place on the buy side at these

really high levels. People want a

discount price to get into the market,

right? So, we see less transactions

taking place on the buy side, which

naturally allows the market to fall

down. And when we reach an area we know

buyers are uh willing and able to get

into the market at, that's when we see

the reactions.

So, rather than just immediately buying

into the market, you just allow it to

trade down towards the zone, and then

you buy when the market gets there. And

as you can see, after pulling back, we

get the execution,

and then the market runs higher, closing

over the previous highs, and creating a

new bullish impulse that sets in motion

this movement from here up to here. And

from there, you can actually utilize the

next demand, for example, this area

where we would then expect to see the

market return to it,

like so,

and then extend up from there, okay? So,

that's how we plot supply and demand,

and that is how it really works. We're

just looking for areas of consolidation

or slight sideways movement before

bullish or bearish movements up. Then we

mark the last candle before the impulse,

and we use that as our buying or selling

point once the market returns to it.

Now, when you're trading supply and

demand, you must make sure you are

trading it with the trend, okay? We're

going to stick on this example that we

just talked over to explain why that's

so important. Now, realistically, you

are going to see supply and demand

zones, or what look like supply and

demand zones, pretty much everywhere.

You'll see loads of them. For example,

there is one right here that could be

seen as a supply because it's a

consolidation area, a bit of an

indecision candle, before this big push

lower, right? So, you may then see,

well, the market structure pushed under

this wick. Maybe I then sell this supply

cuz that could be a good trade to take

the market lower. But,

think about the context. We are in a

very clear uptrend at this point in

time, and we have this demand zone

sitting right here. So, would we really

want to sell based on what we can see as

a supply zone just because of this small

push lower?

The answer obviously is no because we

would anticipate most likely the next

movement given that we are trading in an

uptrend creating higher highs and higher

lows. We would anticipate what we just

saw, and that's going to be a

continuation higher because market

structure determines which way we should

structure determines which way we should trade.

If the market's clearly telling us it's

going up, then selling from a zone

simply because it looks like a good zone

is not something we should do. You're

going to be fighting the overall

direction, and your probability of

winning with that is going to be pretty

slim. So, if you are seeing supply and

demand zones,

make sure they are creating reasonable

impulses, and make sure they are in line

with whichever direction the market is

going. We only trade demand in uptrends

and not supply,

and we only trade supply in downtrends

and not demand, okay? If you do that,

make sure you're in line with the trend,

you'll be just fine trading this

concept. So, again, just as a quick

reminder, selling from here, now

obviously substructure-wise, okay, fair

enough, but still quite a risky one

there. Uh but, in terms of selling this

hoping for a reversal, it's just not

going to happen cuz the market's telling

us that we should be buying. Many times

as well you'll see that the market will

just blast straight through these zones

without a second thought. So, this one

you could have potentially got lucky on

a short-term trade, but it's not going

to work out long-term if you continue to

do that. And of course, the demand zone

takes precedent over the supply zone

because this is a bullish market. Okay,

so an important thing to understand

around supply and demand is that the

zones that we trade are only good for

one tap. Now, I'll explain what I'm

trying to say and I'll break it down for

you as to why this matters and why it

happens as well.

So, to explain it, we're going to go

through this bit of price action. Now,

we have an impulse correction impulse.

This is a bullish market overall.

Therefore, the demand zone that we've

just marked out being the last candle

before the impulse up should be seen as

a good area for a reaction, right? So,

we'd be expecting if we hit this level,

we can then look to buy because the

market should respect that level,

collect new demand from the discount

price area, and trade towards new highs.

That is the logic behind the move, okay?

So, we could place a trade here if we

wanted to. Let's say we put our entry

there and we look to target the new

high. This would be a wonderful, very

large, brilliant trade.

This would also make complete sense.

We're basically waiting for demand to be

hit and expecting a new influx of buyers

from what is seen by the market as a

discount price level or a fair price to

pay for this asset.

Now, you will see

the market did indeed do that. It hit

the level and it started to see some

upward momentum.

Now, this would be good, right? This is

exactly what we want to see.

However, you will see from there that

the market comes back down and it hits

the level a second time.

Now, your trade at this point would

probably be break even, meaning with

this much movement from here up to here,

you probably would have got your stop

loss and put it to your entry, right? Or

at least I would have in my own trading.

Now, because of this, it means that the

pushback down is not really a big deal.

We'd be out of this trade for no profit,

no loss. And yes, it's annoying that the

market ran for so long and then turned

around on us, but at least we haven't

lost any money. And that's the thing

that matters the most when we're trying

to trade.

Now, this demand zone has been hit a

second time.

This changes the picture considerably

for what we would want to see.

When we had this first tap, we were

interested in seeing the momentum drive

away from there, right?

Why is that? Well, that's because when

we saw this impulse before, the market

told us that this was a price that the

market, the participants, were seeing as

a discount or a fair price to pay for

the asset. Therefore, we assume when the

market hits this level again, we're

going to see a fast influx of buying.

Now, initially we did see that, and

that's really good. But now that we've

come back to hit it for a second time,

things have changed. Because the fact

the market was able to sell off from

that level all the way back into the

demand zone shows us that the buying

that's taking place here obviously isn't

as strong, and the willingness of the

buyers to pay higher prices now is

considerably lower than when we got this

first initial impulse.

We had a very strong impulse with pretty

much no resistance from the sellers. We

would want to see that again to prove to

us that this demand zone is still of

interest to buyers. Because we didn't

see that, and because we were able to

push back into the zone a second time,

we can now confidently say the

willingness of buyers is not as strong

as it previously was. We don't have the

numbers at these levels that we had

coming in at these levels here and

driving the market higher, right? There

is more seller resistance this time.

Now, this actually flips things the

other way. And with this second push

into demand, there's two things you need

to understand. Number one is that you

will not trade a zone that has been hit

twice. And the theory behind that is

simply is if the zone was actually

strong, then we would have seen the

direct impulse from the first tap. Okay?

The fact the market's been able to get

back shows us that the buyers are really

not as willing as they previously were.

And two, you're going to see this as

potentially a selling opportunity.

Now, I know this sounds weird. We're in

an uptrend, and we're seeing a demand

zone being retested. But because it's

been hit again with considerable

downward force, and another interesting

thing here is that the candle actually

got lower than the previous, right? So,

we see the previous, the initial tap,

stop there,

but the second tap has pushed us lower

into the zone.

Now, this leads towards what we call a

supply fail or a zone failure.

What that can basically mean is

as we see this zone gets hit again, it's

essentially getting weaker. Now, you can

think about supply and demand zones as

kind of a brick wall, right? The first

time you throw something at it, it's

probably going to bounce off with good

force. It's not going to do anything to

the wall. You're fine. You should then

be able to trade up from there cuz

you're going to get a good bounce.

But if you keep throwing, let's say, a

steel ball at a brick wall,

yes, the first time it'll bounce off.

The second time it might bounce off as

well, but it's definitely going to

weaken it a bit. The third time and the

fourth time, well, you're probably going

to put a hole in that wall. You might

knock the whole wall down completely.

That's how these supply and demand zones

work cuz [snorts] every drive down that

we get into this zone again now

is telling us that buyers are weaker

than they previously were. And if we

continue to push down into that zone,

like we have again here, we're getting

pretty good insight that this brick wall

is going to fall down. That sellers are

actually currently controlling the

market, hence the continuation of new

lows made inside of the zone. And

therefore, the most obvious outcome for

this trade or for this market currently

is for this zone to fail, and therefore

for the trend to potentially shift. So,

that is why we should only trust a zone

when it's hit the first time.

You can be happy to take a trade here,

and sometimes it will lose, often times

it will win, and the risk reward you get

will be good.

But if you see a zone that's already

been hit and the market's come back to

it again, you absolutely should not take

a trade here, at least not on the buy

side. And if you see a trade where the

market has hit the zone multiple times,

there is nothing here that you would

want to do on the buy side, and your

effort should be focused on basically

preparing yourself for a sell.

Now, generally you're not going to want

to just sell the market simply because

it's in a supply zone for the third

time, but you should understand that

soon it's likely to break, and then your

job would be to catch the movement on.

We don't know that that's going to

happen 100%, but every time a zone is

hit, and especially every time a zone

creates new lows

inside of the zone, right? The price.

That is really looking like a zone

that's going to give way, and you should

treat that more as a failure, or a

failure that's coming soon, as opposed

to an actual opportunity for you to buy

from, okay?

So, it's all about just thinking about

the logic behind the moves. We are at

its core just trying to work out who's

in control between the buyers and the

sellers, and a zone that's hit this many

times, that's showing seller control,

cuz if the buyers were truly in control,

they would have taken it higher

they would have taken it higher immediately.

Now, as you can see in this market, we

did indeed end up coming through the

zone, and then the market traded a

little bit lower. So, once you start to

see a zone that's been hit multiple

times, scrap your buy ideas, and prepare

yourself for what could be a potential

yourself for what could be a potential sell.

Now, I'm going to show you just on the

run out of that as well.

Once we failed this demand, we had this

little supply zone here, this indecision

candle, before the impulsive move down

that ended up breaking through the low.

You can see that the market returned to

that level, and actually sold off from

there. So, this is a case where demand

zone failed, and then a supply zone

actually took control and offered a

trading opportunity to sell from here

down into the new lows, right? But

notice we only look at that after the

zone has completely failed, cuz when we

see this closure beneath, that tells us,

"Okay, this demand is completely off the

cards, and we should be looking to

cards, and we should be looking to sell."

So, that's supply and demand fails. It

works the same both ways around, but the

core lesson to take from it, even if

you're not going to go as advanced to,

you know, trade from the supply and

demand fails just yet, you should

definitely consider the fact that if a

zone has been hit once, it's okay. But,

if it's been hit twice, three times,

four times, or anything more than once,

it's a zone that you should not trade

because every time it's hit, it's like

throwing a steel ball at a brick wall,

and eventually that wall is going to

break down.

All right. So, leading on from that

previous point where we talked about

zones that are hit multiple times are

weaker than those that have been hit

once, or essentially zones that have

been hit multiple times are invalid.

The one final point we need to talk

about before I show some examples of

supply and demand trades is

supply and demand trades is inefficiency.

So, when you're looking for a trade,

your supply or demand zone needs to have

what we call inefficiency or an

imbalance into it for it to be valid.

Now, market efficiency, inefficiencies,

and imbalances is the topic of the next

concept that we're going to go through.

So, you'll see full depth on this in a

moment, but unfortunately, I do have to

bring it in kind of prematurely because

you need to understand it for the case

of supply and demand.

So, an imbalance or an inefficiency in

the market is an open price range

generally created by a candle that

hasn't been filled yet.

So, in the case of this blue candle that

we have going up, this is an inefficient

or imbalanced candle, okay?

What that simply means is we have a

demand zone, which is going to be the

last candle before the impulse up here,

and the price range between this candle,

the demand zone, and where price

currently is has not been filled. It

hasn't been retested, meaning we have

not seen price come back through this

not seen price come back through this range.

Now, because price hasn't come through

the range yet, it's what we call an

imbalance. It's an imbalanced price

range or an inefficient price range.

This simply means that basically, we

haven't had a fill of the orders yet,

and we haven't seen the market return to

a discount price level.

Because of this,

it's a fresh zone. So, therefore, we can

trust this zone for buys

because it has the inefficiency into it.

And we know once the market is able to

fill that range, we should get a new

influx of buyers that haven't had the

chance at this price level yet since

that initial rally.

Now, let's take a look at the zone

before this one.

So, we have this candle here, the last

candle before the impulse. Now, for

candles like this, as a little side

lesson, where we have the candle

and then we have a wick that extends

beneath that candle. I just like to use

the candle to mark out the supply demand

zone. And then I extend the box down to

cover the low of the wick as well,

right? So, that's how I would draw that

right? So, that's how I would draw that demand.

All right. Now, if we take a look at

this demand zone, is it valid? No, not

anymore because it's not inefficient.

There's no imbalance, right?

There was imbalance here through to

here, but that imbalance was filled when

the market retested the zone. So, this

is no longer a fresh zone. Buyers

already had the chance to make

executions at this price level when the

market returned to the level there.

So, this is an efficient zone, okay?

Efficient zone.

With that said, we would not use this

one for buys and we would completely

ignore this zone in the future. In fact,

if the market gets into that based on

the previous lesson about supply and

demand fails, we would actually expect

that that could lead through to a

breakdown in price because we would be

seeing then the market return to a level

which is no longer going to be strong.

So, we need to see inefficiency or

imbalance in order to validate the

zones. We saw it there initially with

this imbalance, so buying this retest

would be completely fine. But now, that

inefficiency, that imbalance no longer

exists. It's been filled.

So, we move our attention to the next

inefficient zone, which is going to be

this one here, this gray candle, the

last candle before the impulse. Is this

a fresh zone? Yes, because the imbalance

still exists. So, we would be very happy

to trade from here once the market

returns to it, okay? Now, if we see what

the market did, it pulled down, it

retested the zone, and then it traded

retested the zone, and then it traded higher.

So, from this point, what if the market

returned to this zone again? Would we be

happy to trade from it? Well, no,

because if we take a look at where the

imbalance was, from there upwards to

where price was when we found the trade,

the whole range here has been completely

filled. So, this is no longer an area of

interest for us to buy from, and we

should instead shift our attention to

supply and demand zones higher in the

range inside of the new leg of price

action, like this point, for example.

So, just remember that when you're

trading, a zone can only be hit one

time, and it's only useful for the

one-time use, because anything past that

is going to be dangerous to trade from.

And a zone has to have imbalance to

validate it at all in the first place.

If there's no imbalance, like the range

has already been filled,

then you simply do not use the demand

zones attached to those impulsive

movements, because they're not fresh,

and they most likely will not work, and

they'll result in the market breaking

down if the market does get back into

those levels. Okay, so to recap

everything we've covered so far on

supply and demand, demand zones are

areas in the market where we have seen

large influxes of buying take place.

Therefore, once the market returns to

these levels, we are looking for

continuations higher. Supply zones are

the opposite. They're areas we've seen

significant amounts of selling taking

place, so therefore they act as premium

price levels, and once the market

returns to them, we expect to see a

decline. We use these for entries, and

we use them to determine good points to

actually run the market into before we

start taking trades.

To identify and plot supply and demand

zones, we use the last candle before an

impulsive move away.

So, we just set it to one candle, and

it's generally going to be an indecision

candle before the larger candles that

kick off a move. So, in a supply zone

case, that's going to be like this in a

case, that's going to be like this in a downtrend.

And we are going to look to target the

downside from there.

And in an uptrend case, we are looking

for the last candle before an impulse

higher, and we will use that for buying

opportunity once the market meets it

once again.

Now, it's important that you only trade

supply and demand zones in line with the

trend because you'll get a lot of false

turns, which kind of look like they

should react, but they're against the

trend. And these things aren't going to

work too much because, after all, market

structure does determine the direction

of the market, and we want to be moving

with that. So, in an uptrend, only trade

demand zones, and in a downtrend, only

look to trade supply zones.

Now, a supply zone or a demand zone is

only good on its first tap, and every

time it's hit after the first tap, it

gets weaker. Remember, I said it's like

throwing a steel ball at a brick wall.

It'll bounce a couple of times, but

eventually, you're going to go through,

and that's what happens to these zones,

too. You really only want to be catching

the trade off of the first retest, and

then you're looking for that momentum to

continue into more significant upside.

If that doesn't happen, and the market

comes back again for a second, a third,

or any amount of taps after that,

this zone is getting weaker, and will

likely, generally, move you into a

selling opportunity instead.

And final note of what we've been

through so far is the importance of

imbalance or inefficiency.

The market has to have an imbalanced

range, meaning an open price range, like

a large candle that hasn't been filled

yet, in order to be valid. So, we

wouldn't be trading zones like this one

for a second time because it's already

been hit, but we would be looking to

trade zones like this once the market

comes in to fill that range. After one

tap, it is not going to be good because

there would be no inefficiency and no

imbalance to work with. Taking what

we've discussed so far about market

structure, candlesticks, and supply and

demand, let's take a look at a first

brief idea of a trade, okay?

So, this market is of course creating

impulses to the upside. We have a break

of structure here, that's impulse number

one. Then we have a break of structure

here, that's going to be the secondary

here, that's going to be the secondary impulse,

and this is the one that's just taken

place, okay? So, we have a higher high,

higher low, and now we're pushing into a

higher high once again.

So, with that said, we know we have

bullish structure, okay? Now, if we lean

over to the candlesticks, of course we

can use these to determine uh strength

of the market by the speed and size of

of the market by the speed and size of candles.

Well, we can see this downward move or

this consolidative move was pretty flat.

We didn't have any significantly large

We didn't have any significantly large candles.

We had some reasonable candles to be

honest, but they would matched with

bearish candles, bullish candles,

bearish candles all the same.

So, this range was flat. This is

So, this range was flat. This is consolidation.

In this, we also saw rejections to the

downside, which indicates to us that we

may be seeing buying pressure stepping

in at this level.

When we see the market take off like

this with incredibly strong bullish

candles, remember little to no wicks at

the top and very large candle bodies,

this indicates to us that buyers are now

in control clearly.

So, market structure paired with the

candles we've discussed so far shows us

that buying is definitely favorable in

this market.

Now, on to supply and demand. We're

going to use the last candle before the

impulse, which is going to be this

candle here, to mark out an area of

demand. We know this is a discount price

level that traders would like to buy

from again most likely if we are able to

reach that value once again. So, we may

see buyers refrain from buying in mass

at these levels in the hopes of seeing a

return to this level.

And when this price is met again, we can

assume that the market will take off

from there because we will see, you

know, a new influx of buyers who weren't

able to get in here previously, who now

want to see this as a fair value to get

into this market.

So, we have structure, supply and

demand, and the candlesticks that we've

read so far lining up to give us a

trading opportunity. The final thing to

mention is of course the imbalance and

inefficiency from the demand zone and

into where price is now. This entire

price range has not yet been filled. We

would need to see the market coming back

through this to validate a fill and

create efficiency in the market. So, we

would then look to buy at this level.

We could put a stop under the zone and

our target into new highs. Obviously,

targets-wise, we'll talk about how to

determine these soon, but for now, we'll

use this random target. And then

allowing the market to do its thing, you

see that we do indeed get a run up. So,

that was quite a lucky run there because

we saw a dramatic turnaround in the

market, but luck didn't come into the

fact that we were able to find a good

setup. Obviously, targets, when we go

through those, will help you to make

sure you're getting out of trades before

there are significant reversals, but as

you can see, that's pretty much what we

wanted to see there. We had a push into

the zone. We had a run away from the

zone. We saw a continuation in the

upward trend, and we saw a continuation

in the strong bullish momentum as well.

So, that is it, everything so far. Now,

let's move on to the next concept,

market efficiency.

So, you just kind of learn the basics of

it when we talked through supply and

demand because I showed you imbalances

and how zones have to be in balance, but

efficiency goes slightly deeper than

that and it has more uses than just

supply and demand zone validation.

So, the theory behind efficiency is that

markets or market participants

like to buy from discount and premium

price areas, right? We know that. You

don't want to get something for really

expensive if you're going to be buying

and you don't want to sell it for really

cheap if you're going to be selling.

So, after we see, for example, an

impulse to the upside, we know we're

likely to draw back through that range

that is created with the previous

that is created with the previous impulse.

That happens as buyers are basically

seeking a better price before they get

into the market.

Likewise, sell side, if we were to flip

this upside down, sellers don't want to

sell at the lowest price. They want to

wait for a premium price to either exit

for a profit or to short sell the market

to profit from a larger decline.

So, we know that market participants

want the best possible price for their

want the best possible price for their orders.

Now, that simply means that throughout

these ranges, throughout the impulse

ranges that we have here, we don't have

the largest number of transacting taking

place, right? The majority of the buying

and selling is going to be happening at

core points such as demand zones that

are created when the market returns to

them, okay? We know this because, of

course, as we've just said, they want

discount prices and it's pretty much

printed on the charts for us. If there

were significant buying selling

transacting taking place inside of a

range, then the range would continue

higher, but generally, we are going to

get that efficiency and that fill back

through the range.

So, there are two types of ranges then

or two types of price action. There's

efficient price action and then there is

inefficient price action.

Now, inefficiencies, we discussed. We

have imbalances, right? An imbalance and

an inefficiency are just two names for

the same thing, an open price range.

So, if we were to look at this for

what it is as a range. We have the

efficient price range. This is a price

range where every time we create a

demand zone and the market comes and

retests that zone, okay? Therefore,

leaving no imbalances open and therefore

deeming it efficient.

And then we have the inefficient price

And then we have the inefficient price range,

which is where we have a large drive

which is where we have a large drive higher

and an imbalance is left open where the

market hasn't come back to fill the

imbalance or inefficiency.

So, efficient price ranges are very

useful to be able to read because even

when we're not trading directly from

them, we can use these in a different

way that we're going to get into very

way that we're going to get into very soon.

And inefficiencies are of course

essential to know because first off,

they're going to help us to validate our

buying and selling zones,

but second of all, they're going to act

as kind of a magnet for price.

Now, if we was to see the market trading

up here where we are right now, we

generally wouldn't be looking to buy at

this level, right? Now, we have a large

imbalance below or inefficiency, and we

know the market likes to fill these. So,

what might make sense for us as buyers

is to wait for the market to get all the

way back through that inefficiency to

take the buy. The inefficiency or

imbalance then essentially act as a

magnet for price and kind of a thing

that foreshadows or forecasts where the

market's going to go.

So, when we can read these imbalances or

inefficiencies and we can work out where

in the market they are, then it's easy

for us to wait on the best trades and

it's also good for us sometimes to say,

take a trade down to this level

because we understand it's going to act

as somewhat of a magnet for price, okay?

So, imbalances are important because the

market will frequently fill them, so

it's good to know where they are so we

can determine where trades could be

through that range or out of the range

once it's been filled. And efficient

ranges are good to know for a different

ranges are good to know for a different reason.

So, I will go through that one shortly,

but first let's jump over to the chart

and I'm going to show you an example of

an inefficient range and an efficient

range. Okay, so first let's break down

an inefficiency or an inefficient range.

We have here a large impulse to the

downside, which comes from this area of

supply. Now the area of supply is going

to be marked as the last indecision

candle before the downward move. And the

inefficiency will essentially be marked

from the low of that candle, the wick of

the candle, through to where price

currently is, which is going to be

around here.

Now we know then there is going to be

inefficiency in this area because we

have an open space of candles that

hasn't been filled. And we know there's

another bit of inefficiency basically

from this area through to where we are

now, but this is just one individual

now, but this is just one individual candle.

Now with this inefficiency open, we

would be interested in seeing the market

return to that point before we look for

a selling opportunity. So this would

provide the prime setup.

Now the reason for that, when we break

down the theory behind this, is of

course that this was seen as a premium

price level for sellers to sell from,

right? This entire range,

sellers were happy to sell here because

they were getting a good price to do so.

If we think about where we are right

now, this relative to the premium price

up there is actually a discount price.

And sellers don't want to sell for a

discount. Some will of course, and that

is of course why the market's moving

is of course why the market's moving lower.

But the majority would prefer take

shorts or sell their positions at

premium levels.

So what we see is simply the sellers

getting exhausted. We see less selling

taking place, and therefore buying can

take a little bit of control for the

short term until we trade back into a

premium price level.

When we hit that premium level, we then

see the market trading lower. So letting

that run forward a bit, you'll see that

after hitting the supply zone, the

premium price area, the market traded

premium price area, the market traded lower.

Now, the inefficiency was crucial in

helping us to actually identify where

that sell would come in from.

Because as soon as we see this

inefficient range, we understand there

is a high, not guaranteed, but a high

probability that we will trade through

this range.

So, we can view this as kind of a magnet

for the price to be drawn through.

Now, this provides us with potentially

two opportunities.

First is if the market shows us signs of

reversal down here, we can look at

actually some substructure type trades,

understanding there's a high probability

the market's going to fill this

imbalance to trade back towards the

premium level. Now, in this specific

instance, there really wasn't much

chance for us to do that because market

structure didn't shift until we ran all

the way through to the target. All we

had was wicks to confirm.

So, this case didn't really provide us

with that, but it's definitely something

to look for because a lot of the

inefficiencies you see will provide you

with these substructure opportunities.

The second opportunity, of course, is

the pro-trend opportunity to simply sell

this market down in line with the

premium price now being retested.

Now, the reason that these

inefficiencies happen is simply because

we know where the core points for

sellers and buyers are going to be.

They're going to be in premiums for

sellers and in discounts for buyers. So,

essentially what happens is we see that

race to the bottom of sellers dropping

their prices to meet buyer willingness.

And we simply get to a point where there

aren't any willing sellers anymore.

People are not willing to sell at this

low of a price.

And so, with less selling taking place,

any buying that does take place drives

the price up. And we see those sellers

then demanding higher prices until

eventually we meet a point where sellers

enter in such force that the the just

sinks down again, right? So, it's simply

a case of the willing sellers leaving

the market and the willing sellers

basically asking for higher prices. And

then eventually, when we're in the

premium, the willing sellers step in

massively and say, "Okay, a lot of us

are willing to sell here." And we start

to see this big decline in price, right?

So, that is why the inefficiencies

actually work. And inefficiencies, if we

break it down, are good for a few

things. Number one, they're good as a

magnet price range to trade through

with substructure

setups. Okay? So, the kind of

countertrend setups.

Number two, they are seen again as a

magnet, but this time for larger trades

protrend. So, when those inefficiencies

are filled, we can look to sell. Now,

the reason we use inefficiencies for

this specifically is because if you have

a bearish bias on this market, but the

price is trading, say, here,

instead of selling into the market here

and getting wiped out or having to have

a massive stop loss, therefore getting

pretty much worthless risk reward, you

can actually wait for the inefficiency

to be filled because you know with a

probability, uh a high probability,

that's what's going to happen. Now,

sometimes it won't, right? If we take a

look just previous to this, there was an

[snorts] opportunity where we had

inefficiency and it wasn't filled. So,

sometimes if you are waiting for the

trades up here, you're not going to get

them, but welcome to trading. It's a

probabilities game, right? We're not

banking on this to 100% give us perfect

setups every time. We're using this to

build the foundation behind potential

ideas. And that is what is so good about

imbalances in that right. Because if we

wait for inefficiencies to be filled,

well, the trades we take, let's say we

take a trade from up here, they're going

to be much better

than the trades that we would execute at

random levels. This is a trade

absolutely not worth taking, but

suddenly, by simply waiting for the

imbalance to be filled, well, the risk

reward grows so much that we can make so

much more than our risk actually would

take away from us if the trade loses,

that suddenly we have a viable trade

from the same bias, right?

Now, another thing that they can be used

for actually are targets on your

pro-trend trades.

So, basically, let's say we have this

setup that we're looking at right now,

okay? This we have our inefficiency

and we're looking to sell

from the inefficient supply zone.

So, up here like this, right?

We can, of course, just target the low.

But, it's a pro-trend move. So, because

we are trading bearish, there could be

more room for us to move and maybe we

would miss out on that if we just took

profits at the low there.

So, what we can do with inefficiencies

is we can look to the left and we can

see how price reacted in the past

because we will find often times that

there are larger inefficiencies like

this that can provide us with very clear

targets for the trades.

So, obviously, ignore the structure on

this one for now. I'm just highlighting

the opportunity, but if we were to trade

higher and then trade lower, and let's

say this is the price action we're

looking at just here, right? If we look

to the left on a daily time frame or a

weekly time frame, we may find that

there is a significant imbalance 100 or

so pips lower than this low.

So, rather than having to take a trade

from here

and target this low,

well, now an inefficiency may have

opened the opportunity for us to trade a

significantly larger target. So, instead

of trading this, we can trade this

because the old inefficiency that is

still open has a high likelihood of

being filled over time. Now that the

trend is moving back in that direction,

it becomes prime time to basically get

in and run the trade through for an

extension towards a larger imbalance.

So, those are the core things that

imbalances are good for. First, they

just help you to identify magnet price

areas that the market is likely to trade

through. Then, areas that you would

ideally want to sell or buy from to get

the best possible trades. And then you

can even use them as targets on

extensions to make sure you're getting

the most out of the trades that you

the most out of the trades that you take.

Inefficiencies are super simple, easy to

understand. You'll see them everywhere

in the markets and they all provide

really good opportunities for you for

actually setting the basis of your

trades. All right, and now for efficient

ranges. Now, this is the one that I find

really interesting and you probably will

as well.

The theory behind it is cool and most

people just don't know about this

people just don't know about this whatsoever.

So, an efficient range is an area where

there are no imbalances left inside of a

piece of price action, right? If we take

a look at the run down from this high,

we have multiple supply zones, but all

of them

but one

are efficient.

So, we do have some slight inefficiency

into this area of supply, right? If we

pull this down the indecision candle,

there is a tiny bit of inefficiency at

this level. And by the way, it doesn't

matter how big inefficiency is or isn't,

it's all just as relevant as one

it's all just as relevant as one another.

So, we'll mark this as our only piece of

inefficiency. But then above that, every

zone that we've created has been

retested by price. So, we have a zone

there which was retested. We have a zone

there which was retested. We have a zone here.

This blue candle which was retested by

the push back up of this candle.

We have one here, this blue candle

again, which was retested there.

We have one here which was retested by

the wicks. You get the point, right?

Every bit of this range has been

retested and is now efficient. So, we

have this blue candle. We obviously we

extend to the high as explained

extend to the high as explained previously.

And yeah, you can just see every bit

that we've seen in the market here.

Every supply zone, every bit of

imbalance that's been created has been

imbalance that's been created has been refilled.

So, with that said, this range then it

becomes efficient.

Basically, what it means is every time

we've created an area of premium price

as indicated by an impulsive candle to

the downside, the market has returned

and retested that level. So, we've seen

that flow of selling control and then

sellers step out until a premium price

is met and re-enter the market. So,

every time we've stepped down here,

we've basically filled what is seen by

the market participants as a premium

price level. Now, as the market shifts

lower and lower we are going to see less

willing sellers simply because there's

been so much selling taking place at

every one of these what's seen as good

every one of these what's seen as good levels.

Now, because there are no untested good

levels left, the willingness to sell

inside of this range if the market

returns to it is going to be pretty low.

So, if we mark our efficient range from

the high down to around here,

then we have our small inefficient range

with the inefficiency or imbalance just

with the inefficiency or imbalance just there.

We basically have two ways to approach

this now. Or, one way to approach but

with a contingency plan backed up.

Now, with no significant areas for

sellers to get into the market left

inside of this entire range, the highest

probability thing for this range is if

the market breaks into it, it will

likely be traded all the way through and

the market will go for the next

inefficiency which could be above the

efficient range.

The reason for this is, of course, we

just don't have any points of resistance

left. There aren't going to be many

willing sellers strong enough to hold

down buying and push the price lower.

We're going to see buyers step in

considerably more now that we're at a

discount price and we're going to see a

lot less sellers willing or able to take

on this market given the amount of

selling we've recently seen through the

efficient range.

So, how we approach a market like this

is first of all, well, the market is

bearish and there is still inefficiency

to the downside. So, we would look for

this initially, right? And we could do

that through sell limits or we could do

it through confirmation entries. Now, if

you were to confirm it, we'll talk about

confirmations a little bit later, but we

have kind of discussed this concept.

A reversal in the market on a lower

timeframe is pretty much what we want to

see, right? If we were to see that

inside of the range, that would be

pretty sure fire to actually get us into

a position.

Now, if instead of this,

if we were to just sell limit, then we

would sell there with a stop above and

our targets into the lows.

Regardless of which one of these goes

down, a loss on this position would

result in a pretty immediate opportunity

in the opposite direction.

So, allowing the market to play forward,

you will see that the market did not

hold inside of this supply zone. In

fact, it broke higher into the efficient

range. So, a sell limit from this level

would have resulted in a loss. And the

reason I'm showing you this, of course,

is because this is incredibly normal.

You need to understand that losses are

not your enemy. Losses will happen, but

a good way to set losses up with this

inefficiency and efficiency kind of

format is that the majority of the

losses you do take should result in

immediate new opportunities.

This would have lost for a sell limit.

It wouldn't have lost on a confirmation

because you wouldn't have entered at

that point.

But after losing or invalidating the

trade, regardless of that outcome,

we now see the market's driven into the

efficient range. We know there is pretty

much no point of resistance waiting

inside of this efficient range. And so,

with buyers now taking control of the

market, it's likely buyers will hold

control of the market until we reach a

significant level like the high of the

range where there could be, for example,

liquidity, a concept we'll go deep into

soon, or inefficiency.

Basically, as soon as the efficient

range is traded into, it becomes a clear

point for us to trade all the way

through, right? And so, what we could do

at this point is we could treat this the

same way we would as a clean market

structure reversal. Supply has failed,

the market's in an efficient range,

there is no point of resistance to cap

buyers. So now we can look for demand

with inefficiency into it that way.

Well, if we take a look from the low

upwards, we have a first zone here. This

has been retested with this pullback on

that candle down. We have a second zone

around here. Again, this one has been

retested by this pullback and tapping

that. And we have a third zone here.

This one at this point in time is

completely inefficient. We still have

the imbalance, which is going to be this

price range, okay? From that up to that.

We still have an imbalance that is now

likely to be filled to provide

a new opportunity.

So what we could do is we could go ahead

and place a trade here.

The stop loss under the low

and targets into the high. Because we

know, now that we're in the range, we're

likely to go all the way through it.

There's just not enough resistance from

sellers. No significant points of

interest that sellers could cap the

price. So the most likely outcome, now

that we see this reversal beginning, is

a full run through the range.

Now, we could put our stop loss for a

trade like this right under the zone.

Because with this being efficient, we

understand that the market gets into an

efficient range, it's likely to go all

the way through.

So if we were to get here, we would

expect a continuation through to here.

So there just is no point having a

really big stop loss and slimming down

the profits you can make on the trade.

We want to get out as soon as we know

we're wrong. In the ways that as I said

with a sell limit on this side of the

market, you would have wanted to get out

right above the zone. Cuz we understand

if the market does get above the zone,

this is unlikely to reverse. So there's

no point having a stop here or here cuz

we know it's likely to get through the

range if that happens.

So this could have been a loss, okay?

Let's call that a loss. But you would

have been getting out immediately when

the market failed the final

the market failed the final inefficiency.

And now we would place a trade this way.

Because we've seen the the break into

the range. We would have our stop loss

tight because again, it's efficient

beneath. And now we are basically seeing

if the market is going to give us the

pullback we want to fill the efficient

range and then run higher.

And again, a reminder here on why

inefficiencies are so good for setting

trades. Cuz if you had a bias to take

this market higher, you wouldn't want to

be buying in here.

There's yes, still some significant room

to move, but now we know there's this

magnet imbalance below. There is a very

high probability that the market will

get into that range. So for you to

execute a trade here, you would either

one, have to have an incredibly unsafe

stop loss around this level that is very

likely to be hit. Or number two, you

would have to set [snorts] up a trade

that looks something like this, which

from a risk reward perspective is just

absolutely horrible. You're risking $100

to make $137 here. It's just really not

a good trade to be taking. Especially

when you understand the probability of

the imbalance being filled is high. And

by waiting for that, you can turn this

$100 of risk into $684 of profit, right?

So that is a good trade setup regarding

efficiency. Now let's see what the

market did.

It comes close and then it comes into

the zone and then eventually it takes

off and it runs through the target.

So this trade, completely fine. We would

say honestly, the execution could have

been a lot nicer in terms of how the

market reacted, but we don't get to

decide that. We tap in here, we hold the

trade, and we close it for a win because

up until this point, up here, nothing

invalidated the opportunity we had,

right? We didn't see the market break

into an efficient range. We Yes, we saw

it weaken a little bit, but it's still

the whole time respected the actual

efficiency that we've got. And we didn't

see any significant closures lower into

the zone, just simply a wick rejecting

even though it wasn't the cleanest move.

So that is how inefficiency and

efficiency can be used to formulate

trades. Inefficiencies, super simple,

that's where most trades are going to

come from. But efficient ranges are

useful, too, because we understand when

the market breaks into them, there's no

point of resistance in there to cap

price. Now, the same goes for a

sell-side opportunity. If we have a

bullish trend that is completely

efficient, and the market breaks into

that range, there are very high odds

that we, once filling the inefficiency,

are going to trade all the way down

through the previous range created. To

recap market efficiency, now this one's

quite simple, there isn't as much to

talk about, but we have two price areas.

We have efficient price areas, and we

have inefficient price areas.

Efficient price areas are points in the

market that have created a demand or

supply zone and an impulse, but that

entire impulse has been filled back in

by price, and the demand or supply zone

has been retested. These areas leave

open no imbalances and no open space for

the market, therefore they are

efficient. This happens because market

participants who are, in this case,

buying don't want to buy at premiums, so

they wait for the market to return to

discounts. With less people buying up

here, we see a larger influx of seller

control because the willingness from

buyers is much lower. That drives the

market lower until we reach what is seen

as a discount price level, and then the

market impulses again.

Now, the inefficient price ranges, these

are simply the same kind of thing, but

just not yet filled.

So, if we create a demand zone, and we

have an impulsive move to the upside,

and this market has not yet seen a

return through the range into the

demand, this is what we see as an

inefficient price range. The

inefficiency is marked from the demand

zone to where price currently is, and

this is what we call an imbalance.

Inefficiency, imbalance, same thing,

different words. What we're looking for

when we see imbalances is for the market

to return through this range towards a

prime buying point, which would be a a

price level. And of course, the same is

true if we flip this upside down for a

bearish market with price returning to a

premium in that case.

Now, we [snorts] can use inefficiencies

in a few different ways. First, we use

them to trade through the range if the

market allows us an opportunity to do

so. Second, we use them to avoid

prematurely entering trades and we wait

for the high probability magnet price

area before we enter for the best

possible rewards of the trades we take.

And of course, we can use the older

balances. So, let's say we have an

imbalance over here

creating a supply zone higher up. We can

use these points as well. So, the

imbalance here

to determine a stronger target for our

trade so that we can extend targets

further than just the current high that

we have. So, inefficient ranges are

super simple. We identify them and we

use them as targets for shorter-term

trades and then executions for big

picture trades when we have them.

And efficient ranges are where things

get really interesting. These are areas

where supply zones have all been hit

throughout the entire range leaving an

area of no price resistance. When the

market trades through any final

inefficiencies like this one here and

into the efficient range, we can

confidently shift the bias because we

understand with no points of resistance

inside of the range left, the market is

likely to trade all the way through. So,

we can shift our focus to identifying

inefficient demand zones following the

impulse into the range and then we can

buy from there and target the high. So,

let's break down a trade using all of

the concepts we've discussed so far.

So, that's going to be market structure

first of all. That's the first thing we

want to look at to determine which way

the market's actually going. We can see

an impulse, a correction, an impulse, a

correction, and an impulse to the low.

So, we have a lower low just here

uh formed at this level. This is the

lowest low. But then, we have an impulse

which pushes us past the lower high of

one of the corrections.

So, here's our current relevant

structure. We've got lower high.

We've got lower low. And now, with this

impulse to the upside, we have a higher

impulse to the upside, we have a higher high.

Now, what do we expect when we see the

market impulsing in the opposite

direction? Well, we expect to see a

market reversal because that's the first

sign that buyers are taking control,

right? So, we're looking at this right

now. And when we see that, what do we

expect? We expect to see a pullback

expect? We expect to see a pullback down,

formation of a higher low, and then the

new formation of a higher high. And that

is exactly the position that we're in.

So, we're at a reversal point for this

trade. It's not a continuation trade

where we join in the trend. It's a

reversal looking to catch the start of a

new trending opportunity.

So, now we need to work out where are we

going to enter the trade? Well, we don't

have the benefit of having very clear

open demand zones in this range here.

On the 30-minute time frame, we're on

the hourly right now, there is actually

inefficiencies there. But what we're

going to do is we're going to stick to

this time frame to show you how you

could find the opportunity regardless,

could find the opportunity regardless, okay?

So, with this higher high, if we take a

look inside of basically the structure

downwards from there, we have our own

kind of trend inside of the trend, okay?

We've broken down into a low here. We

then had a corrective move which topped

out here. And then we broke down again

into a new low here.

So, if we were, for example, able to see

the market getting over this high, what

would that do? Well, that would set us

up with the same pattern on the low time

frame that we've seen on the high time

frame. Essentially, internally in this

smaller version of the trend, we would

be seeing that same exact shift to an

impulse to the upside. And when the low

time frame or the substructure setup

agrees with the high time frame, that's

about as good as we're going to get in

terms of confirming good opportunities.

So, what we would want to see is simply

the market breaking over this level.

Now, if you see, that's exactly what the

market went and did. It closed with

candles over this high, confirming to us

that this lower time frame trend is

indeed agreeing with the higher time

frame trend. So now, what do we look

for? Well, we want to find out the

perfect place to buy.

To do that, we want to identify why

inefficiencies into remaining demand

zones. And between these two lines you

can see here, we have a clear

inefficiency or imbalance. So, we'll

mark that with this little highlighter.

That's going to be just there.

That's going to be just there. [clears throat]

With that now in mind, we can mark out

the demand zone beneath it because we

know it's an inefficient zone.

And that is going to create a buying

zone that sits just there.

So, we have the trend showing us a shift

from lower lows and lower highs into a

higher high. We have the substructure

trend showing us the exact same thing.

And now we've identified an inefficient

demand zone to buy from.

So, our trade is basically complete in

terms of the entry, the idea, the setup.

We can place a buy limit here.

We can put a stop under the low. There's

no reason to put the stop too far down

because we know if the market fails this

zone, we'll be trading into efficiency

and there would be little reason for us

to reverse from that.

And then, we can work out where the

target's going to go.

So, the obvious simple target is just

trading into a higher high like this,

okay? So, if the market comes down, we'd

then be expecting a reaction from demand

after filling the imbalance and a run

higher towards this because of course,

with us now starting a new trend, we're

expecting the next movements to be a

trade into higher highs.

So, targeting each of these highs is a

super simple way to capture good entries

and good targets for your trades.

But, we can actually go one step further

than that by inviting the concept of

inefficiencies into the trades as we've

just explained.

What we can do is we can look to the

left and we can determine where there

might be larger imbalances that the

market could potentially trade towards.

Now, we can see before this large

impulsive move down, we have this kind

of area just here.

This is an inefficient area of supply.

Which means rather than running the

trade here at around 4.32 risk to

reward, this is really good by the way.

It means for every $100 you risk on the

trade, you're going to make $432 back.

We can actually extend it further and

turn it into a 6.51 risk to reward

trade, meaning you're going to make $651

for every $100 you risk. Providing this

trade works out as you want it to.

Now, the higher we can get our risk

reward like this, the better because it

allows us to take more losing trades

which are inevitable and will happen a

reasonable portion of the time.

If you lose, let's say 50% of your

trades, but you can capture a risk

reward like this, well, three losses at

$100 is going to lose you $300 and one

win at $651

will put you at a net total of $351,

which is a very nice place to be

considering you're only winning one out

of four trades there.

of four trades there. So,

anyways, we've set that target up. We

have a 6.51 potential and from

everything we've discussed so far, this

trade is basically complete. We have the

trend, we have the substructure trend,

we found our clear buying zone and we've

used inefficiency to set up a good

used inefficiency to set up a good target.

So, let's see how the market goes from

So, let's see how the market goes from here.

You see [snorts] it pulls down, trades

into the zone and then it runs up from

there towards the imbalance supply zone.

Which sets us up with a 6.51% potential

trade and locks in this win for us.

So, that is a trade breaking down

everything we've covered so far. This

time including efficiency. Now, we're

moving over to one of the most

interesting things in all of this video

and also one of the most important

concepts to understand in all of trading

and that is liquidity. Now, the reason

it's so important to understand

liquidity is that if you don't see where

liquidity is sitting in the market, you

are going to be at at mercy of it, and

you will end up being the liquidity for

the traders who understand it.

So, to explain what liquidity is,

liquidity is simply refers to money,

right? Or orders.

It's areas in the market where there is

a significant number of orders situated.

Now, as we've already been through the

battle between buying and selling, you

understand by this point that it is

orders, it's liquidity, it's transacting

that actually creates the fuel for the

market, for the movements that we see up

and down.

Now, when it comes to the case of say a

supply zone,

basically the reason markets move from

supply zones, right? Is because there is

a significant number of orders situated

in and around that area. We know, being

a premium price level,

that there are going to be

a huge quantity of people looking to

sell if the market returns there. So,

that's why we see returns through ranges

because these areas don't have so much

liquidity. We don't have anyone super

excited to buy or to sell inside of a

range. We know buyers want discount

prices, sellers want premium prices. So,

within here, there is less liquidity

than there's going to be say under the

low, or say inside of the supply zone,

right? So, given that the most

transacting takes place inside of those

larger areas, they become points where

there is a lot of fuel for movements.

Now, the liquidity we're going to

discuss forms in a different way. It

forms around highs and lows, and it's

basically the same thing in terms of a

significant number of orders, but it's

set up in a different way.

A supply or a demand zone is a pretty

obvious area of discount or premium

price where we know there's going to be

lots of buying and selling.

But the liquidity we're going to discuss

around highs and lows, this is a little

bit trickier. But when you see it, it

starts to make a lot of sense.

So, let's say we have a movement down in

the market. We pull back making a

corrective move, then we have a drive

lower. This being a break of structure,

therefore driving us into what we would

see as a bearish market.

Now, we could even have a supply zone

around this point. And we may be

interested in selling from this point,

interested in selling from this point, right?

The problem with this is, in this

specific example,

if we take a look at where the highs

formed, we have one,

formed, we have one, two,

equal highs.

Meaning these highs have formed at

exactly the same level.

Now, a problem arises here. And that is

going to be the mass market education of

supply or no of support and resistance

supply or no of support and resistance trading

suggests to people that they should sell

resistance levels with stop losses above

the high,

or they should buy support levels with

stop losses beneath the low, okay?

Now, because of this, and trust me, a

lot of people, many, many people trade

in this way, even if you are in the

price action kind of bubble,

a lot of people trade this way. Uh and

even not down to just the equal highs,

but down to the fact there is a high

here, we know there's going to be a

significant number of stop losses above

this level.

There's also going to be a significant

number of buy stop trades.

So, to explain what they are, a buy stop

is basically a trade order you set to

automatically buy when the market hits a

certain level.

So, if you are a breakout trader, for

example, and you are expecting to see

the market break out here and then

retest and continue,

it's likely you would put a buy stop at

this point. So, we know there's going to

be a lot of buy stop orders there, okay?

So, we have buy stops.

Now, stop losses, if we think about what

they truly are, which a lot of people

don't stop to think about,

a stop loss is basically just an order

to either buy or sell your contracts

back to the market at a different price

to what you paid, right? It's not this

magical order that's perfectly designed

to save you from losses. It is literally

just a buy or sell order in the market.

Now, if we think about a selling

example, and this is the more complex

example of the two. If you've sold

inside of this range, anywhere really,

your stop loss

is going to be a buy order.

So, when you short sell a market to

profit from a decline, you are

essentially selling contracts you don't

own with an obligation to buy them back

own with an obligation to buy them back later.

If you sold the contracts and then the

market declines, you can buy them back

for cheaper than you paid, and that

difference is your profit. So, let's say

you sold something in advance for $50

here, I'm not even going to try and draw

that, and then you bought it back for

$40 here. Well, depending on how many

you sold, that $10 price decline, you

get to buy back $10 cheaper than you

sold. So, you actually profit $10 per

share, for example. Your stop loss order

then is literally just an order to say,

"If the price gets here, buy those

contracts back." And at that point,

you'll be buying them back for more than

you sold them for, so you would make a

loss. But what that does is stop you

from getting into a big loss that you

cannot avoid, right? But at its core,

that means that buy stop orders are buy

that means that buy stop orders are buy trades,

and stop loss orders are also, in this

case for a selling example, buy trades,

case for a selling example, buy trades, right?

So, with lots of stop losses and buy

stop orders sitting in this area, we

basically have a whole bunch of buying

orders sitting here waiting to be

orders sitting here waiting to be activated.

activated. Now,

in that right then, we understand as

traders that if there is lots of buying

momentum hitting the market, that should

drive the price higher, right? Because

that shows clear buying control.

However, something interesting can

happen here.

Because these areas are

basically predictable, right? You can

see them yourself, and so can

significant players in the market. What

actually happens instead is many times

we will see absorption of the buy

we will see absorption of the buy orders.

And to explain how that works, imagine

you've got 100,000 units that are all

going to be sold at the exact same

level, right? So, we know in here

there's 100,000 units of said thing to

be sold at one price.

Now, imagine you want to sell into the

market, okay? And you have tens or

hundreds of millions of dollars that you

want to get into this market. Now, the

problem with this is your massive amount

of selling orders, let's say you wanted

to sell 100,000 units into the market,

that will create price movements before

the order is filled because of the

amount of selling liquidity or selling

pressure that you're pushing into the

market. So, you sell a bit here,

and that's going to drive the price to

where the next willing buyers are. And

then you'd sell a bit here, and it will

drive the price lower until it meets new

willing buyers.

Essentially, there aren't enough buyers

at the exact price level that you would

ideally want to sell at if you wanted to

get into the market right now. So, it's

tricky for you to execute your full

position without getting a terrible

average entry because every time you

sell some of your units, the price has

to be dropped to meet the next willing

buyers, right? So, you end up trying to

get in there, for example, and by the

time your trade is all in, your average

entry might be somewhere like this,

significantly lower than where you

wanted to execute.

So, how do you combat that if you're a

trading firm or a hedge fund or someone

who wants to execute with massive sums

of money?

Well, what you can do instead is you can

just not sell yet, and you can wait for

the market to naturally glide up here as

the selling pressure declines because

everyone who's selling has already sold,

and there are less willing sellers at

lower price levels.

Now, when the buying pressure takes

control of the market, it will drive

through towards that point of liquidity

above, say, some equal highs or above a

significant range high.

When the buying pressure takes the

market into here, you will see, of

course, these buyers slowing down. There

will be less willing buyers taking place

in the market because we're no longer at

a discount price level.

So, when we hit this point and this

100,000 units worth of liquidity in the

form of buy stops and stop losses on

sell trades is triggered,

well, now there are 100,000 units that

you can take up the other side of.

And that's what the absorption is. So,

what you do here,

if you're the big player who wants to

buy, or in this case sell 100,000 units,

is you wait for 100,000 units worth of

buyers who are automatically being

forced out of their trades or into

trades through buy stops and stop

losses, and you sell the 100,000 units

into them, right? So, what you actually

do is you get your massive position and

they get out of their losing positions.

And that massive influx of selling

pressure that kicks in at one price

level can then drive the market

significantly lower. And what it

actually does is absorbs all of the

buying pressure and flips the market the

other way.

Now, this is why when you've been

trading, if you don't understand this

concept already, you would have seen

phases in the market where you've set up

what seems to be a beautiful trade, your

stop loss is above the high, let's say,

like this,

and then what happens is, rather than

the trade working in your favor, it

spikes directly over into your stop loss

and then goes towards the targets that

you had set.

That is liquidity in action. Your stop

loss has become a part of the liquidity

for the larger player to get into the

market. So, they've absorbed the stop

loss and the orders that you've

triggered into the market through your

stop loss, and they flipped the market

stop loss, and they flipped the market lower.

Likewise, if you were a breakout trader

and you've seen a breakout happen

thinking you were about to get a great

entry for a buy, and then the market's

completely melted on you, again, you

have been the liquidity for those larger

participants who have absorbed the

buying you've done and shifted the

market lower.

And the same exact thing happens on the

buy side, right? If we have stop losses

down here in significant numbers, and we

have sell stops down here, then we have

a whole bunch of selling liquidity at

this point. If the buyer wants to get

in, they can let the market gradually

decline through towards this point, and

when all of that selling liquidity is

opened at the exact same level, they can

absorb that with their huge buys, which

then rallies the market impulsively in

the opposite direction. As of course,

that's a massive willingness to buy

entering the market, a massive wave of

demand, and the sellers aren't really

there to push back on it given that the

selling, of course, has all just been

selling, of course, has all just been absorbed.

So, that is how liquidity works at its

core. All right, so let's talk about

where you find liquidity and how to

identify it in the markets. Now, the

easiest version is equal high and equal

low liquidity. We've pretty much just

been through this one. It's going to be

points where highs and lows have

created, well, equal levels, right? Just

like what you would consider a support

or resistance. Now, when support and

resistance traders are looking to trade

it like this,

we're actually looking for a little push

above. This can provide the opportunity

for us because this actually creates the

point where the liquidity has been

point where the liquidity has been taken.

Now, in order to trade this, we just do

it in a very simple way. We look for,

once these levels have been taken out,

that standard pattern that we want to

see when it comes to the structural

shift, right? So, we would kind of use

substructure to identify this kind of

pattern taking place around this high.

If we see that, we get the idea that

this market is likely to trade lower,

usually providing with an entry

somewhere around here, here, somewhere

like that, to then run the market down

in the overall given direction.

So, when it comes to equal high and

equal low liquidity and pretty much all

forms of liquidity,

we're almost never going to be buy

limiting into trades.

We can't really just place an order

above the high because one, we would

have to guess where the stop loss would

go. We don't know how big the

liquidation's going to be. It could be a

pretty big spike up before the reversal.

Could be a small one. So, that's almost

impossible to work out. And as well,

obviously, sometimes the market may not

want to absorb the orders. There may not

be participants the other side ready to

take on the amount of selling liquidity

that's open or the buying liquidity

that's opening up on the other side of

the market. So, in those cases the

market can rally. That's absolutely

something that can and will happen quite

something that can and will happen quite frequently.

So, we don't want to sell limit in. We

want to see the market confirming a

shift. And that is when the

opportunities become available from

these points.

So, to show you this just the other way

around real quick, this is what the

equal low liquidity would look like. A

point in the market with two or more

lows at the exact same level. These we

expect to see swept, but again, we're

going to want to see confirmation before

we start executing any trades back in

this direction because if the absorption

doesn't take place, then we could easily

adjust trade lower. Another very common

place that we can see liquidity form is

around trend lines.

So, a trend line is, of course, a line

on the chart that you connect multiple

highs together. If it's descending, that

gives traders the idea that the market

is in a downtrend. And if it is

ascending, that gives traders the idea

that the market is in an uptrend.

The theory behind trading trend lines,

of course, is to buy if the market

retests the level. So, you'll be looking

to buy there.

And to sell if the market breaks through

the level. So, if we were to, for

example, get to here, traders would then

start to look selling the trend line

because it's broken. And to trend line

traders, that tells them that the trend

has shifted.

However, this is a very very good point

for these liquidations and absorptions

to take place, and I'll show you why.

Now, with what we've learned around

market structure so far, we could ignore

the trendline for a moment and realize

that this market is a bearish market,

okay? That's fine. That's in line with

what the trendline says. So, at this

point in time the trendline isn't

looking too bad. It's still telling us

the market is in a downward trend.

However, the problem with trendlines is

it doesn't account for the real price

structure. So, if we were, for example,

to get a break above the trendline like

to get a break above the trendline like this,

this tells trendline traders that the

market is now bullish. But, if we had

look at the real price structure of what

the candlesticks are doing, it's not

bullish at all because our lower high is

at this level here.

So, for the market to actually change

direction, it would have to get above

this level. That would actually tell us

that the market has impulse the other

way, and that could provide us with an

opportunity to buy.

But, because it hasn't done that yet

when we're trading at this point, this

is just a clearly bearish market to

anyone who trades with market structure

consideration instead of trendlines. And

the next obvious thing to do with this

movement when we get rid of the

trendline would be to sell this bearish

market, right?

So, this creates the perfect trap for

traders who trade trendlines.

We know, considering we have obviously

the two ways to trade of sell the

retest, these traders are going to have

stop losses in and around this region.

And when we have the buy the breakout,

those traders are going to have buy

stops in this region. And then other

ones who don't execute immediately will

be buying the retest, so there will be

even more buy liquidity upon a retest of

the level. So, there is buy liquidity

buy liquidity buy liquidity here, okay?

Now, as well as this,

these buyers, all of these buyers

really, are going to have stop losses

back beneath the level, right? So, we

have sell liquidity here, and we have

buy liquidity, buy liquidity, buy

buy liquidity, buy liquidity, buy liquidity.

Alongside this, of course, we have the

obvious price structure, which is

obvious price structure, which is bearish.

So, we know significant players are

going to be moving with the price

structure, therefore selling the market,

and their core focus will be on getting

as much selling done as possible. And

then we know the smaller players,

the people who are going to be doing

this kind of stuff,

don't have the power they need behind

the selling. The sellers are not going

to be interested in absorbing the sell

liquidity on the buy side,

but they will be interested in absorbing

the buy liquidity above the zone, right?

So, they are looking to take on as many

sell orders as possible,

and they're not going to be interested

in taking the other side of the sell

orders, because their intention is to

move with the price structure, okay?

move with the price structure, okay? So,

breaking that down to where the

tradeable opportunities live when it

comes to trend line liquidity, well, a

lot of retail traders, and obviously

some commercial banks and whatnot, will

be looking for the breakout and trade

above. So, they'll be looking for this.

But the majority of traders are going to

be looking for, or significant traders

are going to be looking for

continuations of bearish price

structure. So, they will be waiting for

the price to get into this region,

and then taking a sell.

Now, we naturally would be doing this

anyway, because when we strip back, of

course, the trend line, we are going to

be looking for supply zones to sell from

inside of downtrends.

So, we would be looking for this trade

So, we would be looking for this trade regardless.

But that addition of the liquidity that

we've just gone through is a really good

weighing factor that helps us to get

these trades right, or at least helps us

to determine where these trades are

going to come from.

If we see this trend line, and we know

there's a giant pool of liquidity

sitting in here,

we can have pretty good confidence that

this is a prime reversal point for the

market, right? If that pairs with an

imbalance supply zone, well, certainly a

really, really high probability trade

comes in here.

Selling against the trend line.

Everyone who's trading the trend line is

going to get wiped out, but we are going

to get a really good trade here. We're

selling supply.

We're piggybacking on that liquidity,

and we're trying to capture an entry

into the absorption from the big players

who want to take the market lower in

line with the existing price structure.

So, trend lines are a really good point

of liquidity that a lot of people don't

know about, and when you start to see

it, you will realize how good it

actually can be, okay?

Now, another interesting thing about

trend liquidity

is that they become good magnets to

trade towards, as well.

So, let's say we get a bit of price

action like this, where the substructure

shifts to the upside.

We can see,

uh let's of course call this a sweep,

too. We can see the market has room to

move to the upside, trading towards some

of these previous areas of supply.

So, what we could actually do

is execute here off of the confirmation

we have to trade towards this level, and

then into wherever the supply zones are

going to be for a good trade to be

executed. So, not only can you trade out

of the liquidity, but you can use that

liquidity, the trend line, and the zones

above the trend line as a magnet for

price. And if you get a good

substructure trade, there's nothing

stopping you from taking that position

up prior to, of course, looking for the

execution in the bigger picture

execution in the bigger picture direction.

So, that is how trend liquidity works,

and those are the different ways that

you can trade it.

Okay, and the other type of liquidity

that we're going to discuss, and this is

somewhat the most complex or the hardest

to kind of learn, but um it's not too

difficult once you understand it, right?

You'll get into it over time. So, this

is internal range liquidity.

Now, this is a really interesting piece

of liquidity because it can provide us

opportunities to enter trades from areas

that aren't supply and demand zones. Now

I'll show you some examples as well.

But let's break down exactly how it

works first of all.

So inside of our structural moves,

right? We understand we have

swing structure, which is going to be

this overall averaged into waves, upward

trending market. And then we have the

substructure, also known as internal

structure. These are the smaller trends

inside of trends that we see, right? So

the smaller up moves, the smaller lows

that we create inside of the larger

that we create inside of the larger trend.

Now these

are trends of their own inside of

impulsive moves, okay? But the trends of

their own, the little lows that we get,

create the internal structure.

Now once the market sweeps liquidity

under some of these internal lows. So

once the market comes under that level,

that means

we can oftentimes or sometimes, should I

say, see reactions that lead into new

impulses, despite the fact that, say,

the demand zone has not been hit.

Now this is kind of what you will see

when you're looking for a trade and it

doesn't fill into your entry point and

instead reverses and runs in the overall

market direction without you because it

didn't come into the zone that you

wanted to buy from.

So what actually happens here a lot of

the time

is the market takes out what we call an

internal low and the liquidity

underneath the internal low.

And it's pretty much the same exact

format as what we've discussed so far,

where under some of these lows will be

significant amounts of fuel for the

upward move.

So here, for example, what we see is

basically underneath each of these lows,

there's going to be a certain level of

buying or selling orders. Now on the buy

side, of course, we are likely to have

sell orders under these lows, stop

losses and sell stops to trigger

automatic sells if the market breaks

below them.

If one of these lows holds enough

liquidity and enough fuel for the move

and sits at a point that is seen enough

by the market as a discount price level,

then it can create a reaction that sends

the market into a new impulse in

continuation of the uptrend without

fully returning to an area of demand.

So, that is what internal range

liquidity is.

You'll sometimes see this when you are

trying to find bullish opportunities and

the market doesn't fill your zones

because the market is instead reacting

to the liquidity that sits underneath

internal structure lows.

Now, it's exactly the same for sell-side

opportunities, just flipped upside down.

There will be enough liquidity above

some of the internal structure highs

that the market can find the fuel for

the next movement from there, react and

move lower without filling a supply or

demand zone.

Now, these areas can be really good to

find opportunities and it is oftentimes

worth when you're setting up a trade

understanding points where the range

liquidity could potentially reverse the

market so that if it starts to happen

here and your overall trade idea was

expected to take place higher up, you

can at least capitalize on a reversal if

one does take place. Okay, so here we

have a bullish market. The market is

continuing to make upward moves and we

can see that we have inside of this

upward moving structure some equal lows.

So, would we want to buy from this range

in the market? For example, would we

want to buy this demand zone?

Well, the answer is no, even if this one

broke out above the previous high, which

it hasn't yet done. And the reason for

that is because the equal lows will

create enough liquidity that the market

will likely be drawn towards this level.

Okay? So, because of these equal lows, 1

2 3 that we have here, we understand

that this is going to create liquidity,

which acts as a magnet for price. So,

buying above that point is basically

irresponsible because there's a high

likelihood the market will be drawn

through to sweep that liquidity before

absorption into a larger move up. So,

even though everything else about this

may look okay, especially if we broke

out above, it's not somewhere we'd want

to buy because

it's going to be a magnet below. It's

going to draw price lower and then the

buys are likely to take place from

buys are likely to take place from there.

So, if we see how the market went from

this point, we swept underneath this

level and then from there we actually

managed to trade higher.

It happened after the liquidity was

already swept, meaning the best

opportunities for a trade like this

would come in around these points for

continuations, so pullbacks towards

these points for example, or the

pullback here. Or in this specific case,

but not all cases, we actually see the

market return to a demand zone, so just

market return to a demand zone, so just here.

This would have been a very good point

to execute a trade and you'd have been

able to help identify that and not get

caught up in this mess by realizing the

liquidity that was situated here and

understanding that's likely to be hit.

Therefore, it makes more sense to wait

for that to happen before you get into

trade instead of getting into trades

higher up.

So, that is an example of equal low

liquidity. Now, of course, the same

exact thing works in the opposite

direction for equal high liquidity. If

the market's trading down and we see a

collection of equal highs, we simply do

not execute a trade until that has been

swept out and we can work out whether

there's any meaningful supply or demand

areas to trade off of and if not, we can

just join continuations once the market

is moving in the direction after the

sweep, okay? So, that is how equal high

and equal low liquidity works and a

simple rule

that you can live by when you're trading

this kind of liquidity

and when you're trading in your general

and when you're trading in your general day-to-day

is never buy above equal lows and never

sell below equal highs. If you do that,

you will win a lot more trades. You will

avoid a lot of the losses because you'll

stop buying and selling at points that

the market is likely to be drawn through

your stop.

All right. Now, let's talk about a

descending trend line and the liquidity

around this. So, this is a real example

of what we just went through on the

diagrams. We have one tap, two taps. And

for trend line traders, this is what

they want to see. Then, they are going

to look for a sell from here if the

market bounces from that level or if we

see a break above, they will be looking

for a buy assuming this to be a shift in

the trend.

Now, obviously, with the market

structure understanding you've now got,

you can see how this could be

interpreted completely incorrectly

because the real market structure, the

real price that we see, has a break of

structure here

creating a lower low at this point. And

then a break of structure here creating

another lower low at the current point

that we're in. We also have lower highs.

So, it's quite obvious to us what the

trending structure is. You get a

complete perspective shift when you just

take the trend line off. For us, this is

a clearly bearish market and we would be

looking to sell anywhere underneath this

high because that would maintain the

bearish trend that we have, okay?

But for a trend line trader, they don't

see it the same way. They see the trend

line as the actual trend. Realistically,

it's not.

So, we know there's going to be

liquidity up here

in the form of stop losses for sellers,

okay? So, we're going to have a lot of

buy orders waiting there

in the form of stops for sellers. We

know there's going to be a lot of buy

stops for breakout traders. We know

there will be manual buy executions

taken here as well with stop losses

underneath this level. More selling

pressure waiting there.

So, this is what they expect to see, the

trend line traders, and therefore, the

liquidity sits around that point or this

is what they expect to see. Regardless,

that liquidity is building up.

Now, what we will oftentimes see then on

these trend line markets is the market

trades above.

We get stopped out. Okay, the sellers

get stopped out selling the trend line.

Buyers step in. So, there's lots of buys

taking place at this point. More selling

liquidity sitting at this point. More

sell orders ready to fuel a further move

down. And then, we see a continuation to

the downside instead. So, basically,

regardless of whether you traded it for

the retest or the breakout, you got

smoked because your trade opposed the

overall market structure direction.

Now, this is where we can get

opportunities because if we were if we

just jump this back for a moment, if we

were to see, for example, this supply

zone here

in line with an overall bearish trend,

right? And we weren't considering this

trend line. We would say this is a

clearly bearish market, and we have a

clear point of imbalance supply to sell

from. So, a good point for us to take a

trade would be here with a stop into the

efficiency cuz we know if the market

gets there, it will likely go higher.

And a trade like this would be just

perfect, right? Because we have the

overall trend direction in our favor. We

have a clean entry zone. And then, when

we bring the liquidity in, we realize,

okay, this favors our setup even more.

Because in order for this trade to be

triggered, we will need to liquidate the

trend line. Basically, move above it and

hit that point where all the stop losses

are going to be, fueling the move even

further by providing a lot of buyers to

be absorbed by significant sellers. So,

this helps to weigh in pretty much what

we already have as a nice strong valid

setup and stops us from selling from,

let's say, any of these supply zones,

which in themselves wouldn't really be a

great idea due to the inefficiency we

have, but definitely wouldn't be a good

idea if we were to be doing this knowing

that the trend liquidity is sitting

that the trend liquidity is sitting there.

Okay? So, this is then where our setup

would come from.

And as you can see, it plays out pretty

good moving to the downside. So, that's

an example of trend liquidity in action.

And as we're saying on all of them, it's

exactly the same the other way. If we

have an ascending trend line which

creates liquidity, we have a demand

zone, we have bullish price structure,

breaking that trend line doesn't tell us

anything about the actual trend itself.

It just tells us a little bit about how

some participants are viewing the

market. And that is going to create

liquidity for us that we can then buy or

sell into to continue taking the market

in the overall structural direction.

Right, now let's talk about internal

range liquidity.

So here we have an impulsive upward

move, right? We have a clear upward

trend. To mark the structure points, we

obviously want to be clear with this

from the get-go because we need to work

out what's internal and what's

significant structure. They're going to

be our impulses, okay? So we have

impulse number one is the run up to

here, then correction number one,

impulse number two, correction number

two, impulse number three, correction

number three, impulse number four. This

is an interesting one, right? Because

some people would mark this incorrectly

by presuming that this is a higher low,

higher high, higher low. But take a

look, we didn't close over the high. So

this is actually just one impulse,

right? After this correction, the whole

movement here is one impulse. Now this

one does have larger internal structure

than some of the other ones, but um it

is, yeah, just one impulse, okay?

Then we have so far corrective move.

Right. So what we can do at this point

is we can mark the lows of each move. We

have a higher low.

We have a higher low again.

And then we have a higher low just here.

Now inside of

the ranges that we've created, the

impulses, we are going to have a series

of smaller lows as well.

So we have one around this point.

That's going to be an internal low.

We also have one there, too, okay?

On this movement up, we have

one there.

And we also have one around here. So

these are the small consolidative phases

on the internal structure.

This move, well, we have one super clear

one and that's pretty much it because

all of this is efficient. Then we have

this here.

Besides that, we've pretty much got all

of the structural lows locked in, okay?

Now the internal structure lows,

obviously, is where the internal

liquidity is going to react and where

it's going to come from. So, what I'm

going to do is I'm going to get rid of

everything that isn't the internal

liquidity for now so that we can see

where those internal areas are, okay?

So, for this movement up, oh and this

one, too, by the way, we have an

internal load there.

Now this is a piece of price action

that reacted significantly well to

internal structure and less so well to

supply and demand, which is why it's

important to understand this one cuz

this is where a lot of those trades will

actually come from. You can take trades

from internal liquidity sweeps in the

same way you can with supply and demand,

just with the additional layer of making

sure you use confirmation for every

sure you use confirmation for every setup.

So, if we look at move number one, this

reaction here, the impulse that we got,

this did not come from a supply or

demand zone. It came after we swept an

internal low. We then had a sharp

reaction to the upside creating a new

drive higher.

This second move as well, this one

actually did react from a demand zone,

which is nice, but it also came after we

swept this internal low, right? This one

didn't react, didn't give us too much in

the ways of information, but the

internal low being swept at the the

bottom there

in line with the uh supply and demand on

this one, kind of then catalisted the

next move up.

This one, there isn't a clear demand

zone, but there was a reaction after we

swept the internal low, right? So, you

can see continually that sweeping

internal lows can lead us into new

impulsive moves to the upside.

Right now, this larger impulse, okay?

This is where I actually took a trade.

So, the one I'm about to show you is a

trade that I took um and this is going

to, of course, be from the internal low.

Now this impulse up then, the

significant internal low we have is this

point here.

Some people would make the mistake of

presuming if the market broke under this

low, that this then changes the

direction bearish, but it doesn't

because of course as we've already

determined the high and the low of this

impulse are there. So we would need to

see, to validate any kind of shift, a

break under this level. So if we get

into this area here, as long as we stay

above that bottom line, we remain

bullish and on track to create impulsive

movements to the upside. Therefore, this

internal low sweep given is no clear

demand for us to buy from, could be a

very good point to look for an

opportunity to buy, okay? So let's strip

that back again.

And then see how the market reacted

around that low. You will see

the market came underneath the

structural low with a wick, right? So

what does that show? That shows

rejections, that's even better than

seeing a candle body close there. Though

if the candle does close below, as long

as it's wiped back out with some bullish

candles, that's okay as well. But a

wick, even better, showing significant

buyer willingness as soon as we get

under that level.

Then, taking a look at the substructure

cuz now I'm going to show you how to

truly set the trade up. We have this

basically low, lower high, lower low. So

this would be the structural point that

would reconfirm the lower time frame in

agreement with the higher time frame,

agreement with the higher time frame, okay?

We would want to see this to close over

here to shift this back into a bullish

trend and therefore give us opportunity

to buy pullbacks, okay? So that is how

we trade internal liquidity. Now if we

let the market run forward, you will see

we rallied up. After rallying up, so

this one, two, three, four candles or

realistically just this first candle

confirmed it, we opened doors to a

demand zone, which was just here.

This demand zone is where I bought from

and becomes the very obvious point to

buy because it is the demand zone that

created the impulse that pushed the

market higher.

Targets-wise for this trade, well, you

could target the high. I actually went

and targeted higher up, but my stop loss

was more conservative because of lower

time frame zones here as well. So, my

trade ended up being around 3.5%

uh targets-wise, we won't go into it too

much in this one because we're focused

in on the specific concept. But, let's

just call it at the next high. Nice

simple target, right? You can see how

this trade has been set up from start to

finish without a demand zone. Now,

obviously, demand zones, supply zones

are the best places to sell from

generally, but we won't always get them.

And internal liquidity is how we capture

the trades that don't give us clean

zones, right? Um much in the way that

equal highs and equal lows don't have to

be swept [snorts] and then reverse into

a supply or demand zone, they can just

literally sweep the level and then find

reversals. This is very much in the same

way, but this time it's generally the

alternative. If there is no supply or

demand zone, we can look towards

internal lows to find reactions much as

the market created at this level, at

this level. Well, this one did have a

bit of demand. And obviously, at the one

that we're currently coming into as

well, okay?

So, that is how you would set that trade

up. Simple. Sweep of internal low, shift

back in line with the overall bullish

trend, buy from the open imbalance

demand zone after agreement [snorts] on

the low time frames. You execute, the

market runs, you close your trade, and

you take the profit, okay? That is how

to trade internal liquidity. Now,

[snorts] this one is arguably the most

important factor of liquidity to

understand, but also somewhat the

trickiest, but I think this example has

showed you that it actually can be quite

simple. You just mark out the internal

lows, see how they react when swept, and

if you get something like this where the

market confirms after sweeping your

significant low of internal liquidity,

that's going to be solid basis for a

trade from here up to wherever your

target is. Okay, so to recap what we've

discussed on liquidity so far, there are

many different types, but all of the

different forms of liquidity refer to

the same thing and that is money,

orders, or transactions.

We know the market is driven by money,

by orders, by transacting with one

another and we know it depends on who is

in control between the buyers and the

sellers as to which direction the market

will go.

Now, liquidity forms around significant

highs or lows and basically on a

buy-side example like this, we're going

to have a lot of sell orders underneath

the low. Why? Because there's stop

losses on buy trades, which is basically

a contract to sell the contracts for a

loss and we also have sell stop orders

for people expecting to sell directly

into this market if this level breaks to

take the market lower.

Now, if a buyer with massive influence

and capital wants to get some to the

market, they can wait for this to be

naturally swept due to a lack of buyer

willingness at higher levels and then

they can absorb all of the selling

orders at the same time and get a really

good execution on a strong position with

enough capital behind it to generally

move the market. The same goes on the

buy-side example or sell-side example

should we say where there is a lot of

buy liquidity waiting to be absorbed. In

certain cases like this,

all of those buy orders will be absorbed

by a strong selling and then the market

will move down. And that is why when

we're looking at any form of liquidity,

we see these kind of stop hunt looking

things where it hunts your stop loss and

then gets a short reversal from there.

But it isn't personal, it's just a

natural flow of the market.

So, the different types of liquidity you

need to be aware of are equal high and

equal low liquidity where we have

well, equal highs or equal lows and you

should never be selling beneath equal

highs, you should never be buying above

equal lows. You should be waiting for

these levels to be swept because with

significant probability, they will be.

When that takes place, you can then

assess for your standard entry model,

which is going to be that shift in

structure, and you can join the trend

higher. Same with a sell-side idea, but

you want to see this one shifting lower

after sweeping above the high. Then you

can confidently join using that

structural agreement and get your trade

on to trade the market lower. Trend

liquidity is one of the other common

types. This is where we see trend lines

where the majority of traders will be

trading these in a very linear and

similar way, looking to buy the retest

or sell the breakout. But we, as

structural traders, can see the actual

real market structure is pointing to the

upside. So all of the liquidity that

collects under here in the form of stop

losses for buyers on a trend line, and

also sell stop orders and manual sell

executions if the market is to break

through this level, creates a pool of

liquidity that can act as a brilliant

catalyst for trades. If we can line up a

trend line trade with a nice point of

imbalance demand or supply, which

happens quite frequently, then this

becomes a very strong point to make a

buy from due to the fact number one, we

have the structural agreement. Number

two, we have the supply or demand

agreement. And number three, that pool

of liquidity will add to the likelihood

that the market gets that, and also that

the market runs from there with

the market runs from there with strength.

And the third type of liquidity,

arguably the most important to get your

head around, is of course the internal

range liquidity. This is great as an

alternative way to capture trades when

we cannot find clear supply or demand

zones to buy from, or when the market

simply isn't reaching those zones.

Inside of the larger swing structure, we

want to identify the substructure trends

want to identify the substructure trends within.

So the smaller lows, the smaller highs

taking place, that aren't significant in

the grand scheme of the big picture

trend, but are significant in the fact

that they create these own independent

that they create these own independent lows.

When these lows are swept, we can see

from some of them sometimes enough fuel

to actually create the upward move into

a new high, into a new impulse. And we

can actually see, much like the example

we recently looked at on Euro USD,

continually sweeping and impulsing into

new highs. Sometimes these moves will

align with supply and demand, sometimes

they will ignore range liquidity and

move towards supply and demand, but

other times we will get clean reactions

without meeting a supply or at all. So

these can be really good points to run

your standard confirming pattern trades

where you want to see the low time frame

beginning to agree with the high time

frame again after one of these sweeps

has taken place, and this can be a

really great way to capture yourself a

trade and run into the next impulse in

price action. The next concept to talk

about is momentum.

So remember earlier on we talked about

candlesticks and how we could determine

the strength of individual candlesticks

through the size and the speed of the

candles, right? So we talked about how

large candlesticks like bodies like this

with smaller wicks generally indicate

control from the buyers or the sellers,

whereas smaller candle bodies like this

with larger wicks either side generally

indicate indecision. These various

different things that we discussed,

different things that we discussed, well,

they're not only relevant over

individual candles. See, momentum, the

size and the speed of movement, can be

tracked over larger areas, so larger

phases of price action.

So as an example, let's imagine we have

a market that looks like this, where we

have these strong and fast upward moves.

They move up pretty quickly, and we have

a few phases of that where everything is

looking pretty high momentum.

Well, this can tell us, of course, that

buyers are pretty strong inside of this

market. However, if we were to have a

large impulse like that, so

a very quick impulse up, and then we

were to have a very quick impulse down,

well this wouldn't be so useful to

determine who's in control because

obviously the move has been taken back

out by sellers. I mean, we can get in

some information from this, but it's not

going to help us in the terms of a

continuation trade.

Now, if however, we were to see

following these strong impulsive

movements, some slower, choppier

downward price action pullbacks like so,

well this, with the slow speed and the

smaller size of these pullback moves,

would actually help to indicate that

buyers are maintaining control of the

market, right? Because we have strong

impulsive movements up, and then we have

weaker, choppier, and more sideways

movements down.

Now, even if the corrective movements

pull back pretty much the full distance

of the impulsive movements, which would

of the impulsive movements, which would show

uh size-wise that we're actually pulling

back significantly,

we can determine based on the speed of

that move whether there is any element

of control coming in from the sellers

of control coming in from the sellers there.

Because obviously, if we've covered,

let's say, the impulsive ground in 1/3

of the time it takes to pull back

through that range again on the

through that range again on the downside,

that's a pretty good indication that

we're likely looking at a rather bullish

market here. Sellers are unable to get

the market down anywhere near the pace

that buyers were able to take price up.

Now, another thing is how the range is

Now, another thing is how the range is formed.

If we have, obviously, these impulsive

moves, you can see we have large move,

small pullback, large move, small

pullback, large move. What is this

telling us? Well, this tells us that

buyers are pretty uninterrupted. We're

having some small little areas where the

buyers are stopped in their tracks, but

for the most part, this is an

uninterrupted phase of buying. The

pullbacks we see are tiny, and they are

essentially a last-ditch effort from

sellers to push the market back down,

but they're completely overwhelmed by

the amount of buying pressure.

Now, when we see more so like the

pullback moves here, where we have a

large chop where we move down and then

we retrace the majority of the move. We

move down again and we retrace the

majority of the move. Every time we do

this, we're showing that the sellers are

Yes, they're stronger at the moment, but

they're almost equaled in strength by

the buyers because the buyers are

retracing almost the majority of every

single movement down that we get inside

of this corrective phase.

So, when we see price action like this,

we can gather it's sideways, it's

choppy, which essentially means buyers

are stepping in at every single low.

It's slower, which means the sellers

aren't as strong as the buyers were

during their impulsive phase.

Uh and yeah, it's taking longer and it's

just not as strong, right? And generally

as well, in these cases, we've only

pulled back 50% of the bullish move in

let's say nearly twice the time. Same

again with this one, three times the

time and we've come back down around

2/3. So, it's taking a lot longer to

cover less ground than the impulsive

cover less ground than the impulsive move.

Now, how does this help us? Well, it

helps us because we can of course trade

in what we can deem as the controlling

in what we can deem as the controlling direction.

If we understand that buyers are most

likely in control during this phase,

that gives us confidence and clarity and

conviction behind taking buys with this

overall trend.

If instead we were to see, for example,

a very large impulsive movement up,

but then we were to see, a very large

impulsive movement down, something like

impulsive movement down, something like this,

well, this would give us a little bit

less confidence around executing upon

the buy side because we can see, yes,

although the market may be creating new

highs at this point in time, let's say

it's breaking structure upwards, it's

actually reversing the bullish pressure

at the same pace that it was building

it, which tells us realistically,

this might not be the best point to buy

from cuz this could be a point where

sellers are actually taking control over

the market.

So, momentum can be really useful for

basically building conviction and real

clarity behind the ideas. And it's

simply a fact of reading into who is

currently in control. Is it buying or is

it selling that is running this market

right now? Look at that on a chart now.

So, see this bearish impulse, the

initial move. It took from this candle

down to this candle, five total candles

to make this entire bearish impulse.

Now, when we started this corrective

move, it took around eight candles

just to run back up the length of one

individual bearish candle.

Now, in these eight candles, we came

back probably around 30% of the move. We

didn't even come back halfway. So, we

have significantly more speed and

strength in the bearish candles than we

do in this pullback.

As soon as we finish that small upward

push, there is a bearish candle the size

of five of the bullish candles, right?

So, you're seeing even while the

market's appreciating, the sellers are

still pushing back with significant

still pushing back with significant force.

Now, the first notable bullish candle we

get is this one here. But as soon as

this prints, it's followed by a bearish

push which drives us down into even a

new low. So, we're seeing that the

buying attempts completely subdued there

by the selling attempts.

Then we have some buying attempts again.

Notice the wicks either side, lots of

indecision in this buying move. We gap

down, we rally up a little bit. This is

a a reasonable sign of momentum, but

even take a look, right? We have what,

five candles back to back uh bullish

candles there?

They only cover the ground of around one

of the bearish candles. So, we're seeing

basically that the buyers here

are really weak in comparison to the

sellers here. And the sellers here

are just about equal in strength to the

buyers in this phase. So, even during a

corrective phase, we're seeing pretty

good seller intent. After this

corrective phase, which took, I mean, as

a guess, what, about 10 times longer

than the initial bearish impulse, which

was larger as a range. We see again

another significant bearish impulse,

which once again happens incredibly

which once again happens incredibly quickly.

Like that.

So, we have

a bearish impulse that's very strong and

fast. We have a corrective move, a

bullish phase, which is incredibly slow

and very weak, and still even trading

lower despite the bullish attempt. And

then we have another bearish impulse,

which is incredibly strong and fast.

Now, that is pretty much exactly what we

would expect after seeing the weakness

of the buyers and the strength of the

of the buyers and the strength of the sellers.

What we would look for from here for

continuation to build conviction behind

the move would be the same thing. If we

are able to get slower, choppier

consolidation, then that would forecast

to us that the likely outcome is going

to be a pretty dramatic downward move.

So, let's see how this market plays.

Now, immediately you can see

the attempt from the buyers here is a

lot weaker once again. We have a phase

where the market has indeed gone up a

bit from there to there, but it's taken

what, about three times the length of

the entire bearish impulse while

retracing only around 50% of the move.

So, it's taking way longer and it's

covering way less ground. And as soon as

this is over, we get another bearish

impulse. This one isn't as strong, this

bearish drive that we get, but it does

still show considerable strength over

the buying attempt.

Then we have another buying attempt, and

it's really again not too strong. It

takes quite a long while for this to

make any ground, right? So, we're seeing

basically weakness on the buy side,

strength on the selling side.

The first sign of bullish momentum that

we get, really that has any anything

worth noting, is around here. We have

this nice bullish push up. But what

happens as soon as that rally occurs? We

get a sell-off at about the same pace.

In fact, even more pace. This bearish

candle is even larger than the bullish

ones that have driven the price up.

So, this is pretty much exactly what we

want to see to maintain seller control

and hold conviction behind the idea of

selling in this market, right? Here's

two incredibly strong bearish moves and

then we have this big phase of slow and

choppy kind of sideways buying attempts

before again, we run into a strong

bearish impulse. So, to tally up each of

the phases,

we'll simplify it down.

We've got the selling move, correction,

selling move, correction and then

another selling move just here.

And if you take a look at the size of

these and the ground they've covered,

you'll realize how easy it is to read

this momentum to determine who could be

in control in these phases of the

market. The idea behind this and the

value of reading momentum isn't so much

to find individual trades on their own,

but to back up ideas that we have. So,

we have here a phase in the market where

we're shifting from bullish into

bearish. We have this bearish impulse

and that is driving us down lower.

Now, if we factor the strength of this

move, obviously, this leads us to

believe that sellers are likely in

control, right? But if we were to have a

buying candle that was in equal size

pushing back up to around here, that

would write off the idea of selling

because the buying candle would show

that it's managed to wipe out basically

all attempts from sellers and put the

market back into a buying phase.

Basically, it would reverse this entire

Basically, it would reverse this entire candle.

Now, if instead we were to get a slower

choppy pullback up, well, that would be

really good because that would tell us

that this selling control is not being

matched by the buyers. We are still

seeing sellers maintain control even

through the bearish phase.

So, taking a look at what we've got

going on here, you can obviously see,

although [snorts] we covered a pretty

good amount of ground through this

bullish phase, we had all of this time

to reach a high, right? Versus the time

it took to actually get down there

was about three candles, about four

candles. So, it took a significant

amount more time for the market to trade

up. And when we look at the choppiness,

okay, we have yes, we start off with

decent buyer strength, but even then we

have some wicks and some indecision. And

then we step into this sideways phase

where the market wasn't able to get

anywhere for quite some time. Now

obviously that does indicate that

sellers weren't strong enough to drive

the market down immediately, but it also

indicates that buyers really don't have

that much force here cuz even in the

middle of the range where we wouldn't

expect selling intent to be as strong as

the highs, the market still unable to

push higher. Takes quite a while for it

to break out. And as soon as it does,

that actually ends up being the highest

closure we get before the market starts

selling off again.

So being able to determine the momentum

based on the speed and the size of these

movements and how choppy or direct they

are is really really valuable for

helping us to determine which way the

market is likely to go. In this case,

with very strong and direct selling

pressure and weaker, choppier, more

indirect buying pressure, it leads us to

believe we would have good conviction

and good pressure behind a selling move.

One of the most valuable things about

momentum is the ability to use it to

avoid taking bad trades, right? So let's

say we have this market where we've had

this large impulse down, breaks of

structure, we are obviously leaning to

the downside. We have a supply zone

sitting here and it has imbalance.

Everything about this looks like it

could be a good short trade. There's

efficiency above which means that would

realistically be the last point of

resistance for a selling move. Now from

this, we could anticipate a movement

like this. We trade into there and then

we trade lower.

If we see what the market did next

though, we'll see that we had this

massive bullish impulse. Now this can

tell us, even just off of this first

tell us, even just off of this first candle,

we should not take this trade. So what

we could actually do after seeing that

massive bullish candle is if we had,

let's say, a sell limit placed,

we could take that sell limit order off

and not get into this trade.

Now obviously it might seem a bit rash

to avoid taking a trade off of one large

candle, but when you think about what

the candle is actually telling you,

that's where you can get the insight to

decide whether or not this should be a

good opportunity, right? Because

realistically, when we're taking trades,

we are trying to just move with whoever

is in control.

When we see this downward move, and we

see the market continuing down, we see

pretty clearly, okay, at this point in

time, sellers are in control. So, the

setup makes sense.

But, think about what this candle did,

right? Within one bullish candle, we

wiped out, I don't even want to count,

but probably 40 previous candles that,

you know, a significant amount of time

took to actually get to this point. So,

from this level all the way through to

here that's how long it took us to get

down there. And then the reversal took

this long, maybe 1/10 of the entire

move, and it closed higher than the

entire previous range.

So, not only did it move faster and more

significantly than the downward

movements did, but it also closed us

over the highs of this entire range

even over the wick here as well.

That tells us that this buying move has

basically engulfed anything that we've

seen beneath this level. And given that

this is where the market structure

broke, the market's basically telling us

we've completely reversed this entire

break to the downside. Therefore, if

we've seen buying pressure come in with

that much force, it would make sense to

just not take the sell trade, because at

this point you're seeing clear buying

control in the market. And really, what

we're seeing is basically a huge

reversal. So, do we want to sell here,

even if the other concepts look okay?

Well, realistically, no, cuz this looks

mostly like it's going to be a breakout

into new highs, okay?

So, if we see how this played out,

you're going to see that it did indeed

break out to new highs, and it was quite

obvious that that was coming given the

amount of momentum that came behind this

upward move. So, that's just something

to think about, you know, and it really

will save you from a lot of losing

trades. I suggest this to the people I

work with and we usually improve their

win rates pretty significantly simply by

teaching people to avoid taking trades

against significant momentum. Momentum

is something that people really don't

give enough attention to, but when the

whole game is just trying to be on the

right side of the market, there's no

better way to see which side of the

market you're on than the direct and

immediate candles that are forming.

Incredibly bullish candles coming out of

a bearish range tells [snorts] us this

could be the point where the market has

shifted direction. If instead we were to

see a slower and more gradual climb up

to this zone, I absolutely would be

happy to risk the money there because

we're seeing strong seller control,

weaker buyer control. So we would

anticipate strong seller control again.

But when it's, of course, as you can

see, it's strong seller control and then

very strong buyer control, well, no.

This is more reversal than continuation

and it's not something I'm going to want

to take a sell from because for the most

part, it's more likely to lead into

continued buying.

So another thing you can use momentum

for is validating structural shifts. If

we take a look at this piece of price

action. Now, it is a bit messy because

we had a market gap, but the structure

all the same is a low, lower high, lower

low, and then a higher high. So here, we

have a breakout. Now in many instances

this would of course set us up with

potential to buy from this point because

we're seeing that structural shift. An

impulse to the upside can tell us that

we could have a buy opportunity on our

we could have a buy opportunity on our hands.

However, if we take a look at the actual

structure, the bearish momentum down to

here was incredibly strong, right? We

did have some rejections from buyers,

but then we had another reasonably

strong push down.

This candle again exceptionally bearish.

After a small bullish candle, we have

another rather bearish candle. And

although we have actually shifted to the

upside, if we take a look at what it

actually took the market to get up here,

we saw a long phase of buying and the

buying was very indecisive. Every time

we push up, we pull back down. We push

up, we pull back down. We push up, we

pull back down. You can see that this

impulse is what we would just

essentially refer to as not very strong,

right? Even the drive down from here

to there only took this amount of time.

And now to reverse that movement, it

took us this amount of time, right? So,

about 15 times longer just to get back

to that point. So, that can indicate to

us that selling is still stronger than

buying, despite the fact that we've

actually broken above structure. Now,

again, we did have this reasonably

bullish candle. This could give you a

good insight, but as soon as that

bullish candle got over the structure,

we had indecision candle, indecision

candle. Then we had an attempt to go

higher, and then this bearish roll back

over. So, the actual price action after

the breakout is incredibly weak at this

point in time. So, what you could look

at this as is basically a liquidation or

a reversal potential sweep before a

reversal down, rather than a strong

actual breakout that we'd want to buy

into, right? Now, obviously, that could

then tell you don't buy this market

because we obviously see sellers are a

lot stronger than buyers at this point

in time. And if you just simply skipped

this trade, you would have of course

saved yourself some money when the

market went and took out the low.

So, it's good for validating your buys

and your sells as well based on the

structural reversals. As an example, if

we have the bearish impulses down,

but then our shift back to the upside is

slow and choppy like so, and doesn't

manage to gain much ground after

breaking through the high, this is

almost certainly going to be a trade

that you don't want to take on the buy

side because what this usually leads

into is sweep reversal, like the

liquidity that we discussed earlier, as

opposed to what you're hoping for in a

lot of cases, which is a continuation

up. If that continuation was likely, the

buyers would have been a lot stronger

than they were. If this reversal was

worth considering, the buyers would have

been able to take the market higher in a

faster time with more clear buying

intent. Look at momentum real quick.

Now, if there's one thing that people

miss out of their trading too

frequently, it is certainly momentum. I

see not many people talk about this and

it really is very valuable in helping

you to build clarity, conviction, and

make sure you're on the right side of

the market. So, the general idea is the

stronger, the faster, and the larger the

impulses we get, the more clear buying

intent or selling intent that we see. In

this case, it's seller intent. When we

have this large drive down with little

to no pullbacks on the way through and

any attempt by buyers to take the market

back up is quickly wiped out by selling,

this shows us clear selling intent. We

can see this is quite a fast, large, and

impulsive move. So, this gives us the

idea that this is likely a seller

controlled market. Now, the thing that

really becomes valuable is then

monitoring how the market pulls back.

Because, for example, if we were to see

equally strong impulse back to the

upside, well, this could actually be

seen somewhat as a phase of indecision

despite the fact we've had large up and

down moves cuz the market at this point

in time is failing to show clear control

by buyers and sellers. It's

clear seller control, but then clear

buyer control taking that back up and

putting us in a phase where we have to

try and guess which way the market's

likely to go.

What we prefer to see for validating

setups is, of course, slower, choppier,

and less direct price action.

If the selling move is strong and

impulsive and then the buying move is

choppy like this, it has a lot of

pullbacks. So, every time the buyers

take the market up, sellers bring it all

the almost all the way back down. When

we see this, this is really good for

validating continuation of seller

control because if the buyers had any

grip over this market, they'd be able to

just run the market up equal to how the

sellers brought it down, right? So, we'd

see a much stronger impulse. Now,

another thing is the time it takes. This

was rather fast. This has taken almost

twice the amount of time, and we've only

covered around 50% of the distance of

the downward move. So, it shows

basically through this phase marked in a

red box, sellers are still showing some

level of control over the buyers who are

attempting to drive the market higher.

What do we expect to see from that?

Well, from there, with strong seller

control on the impulse down, weak buyer

control on the corrective move back up,

we would expect to see another strong

impulse to the downside.

So, here's what that looks like on a

real chart. We have a large impulsive

bearish move.

Then, we have a corrective move like so,

which you can see is very choppy. The

corrective move takes many times longer

than the impulsive move did to only

cover around 60% of the ground. So,

we're not moving as far or as fast, and

we are seeing that resistance from the

sellers with these drives down every

time the market comes to a new high. The

candle bodies are smaller, there's more

wicks, more indecision, and obviously

that is then followed by another bearish

impulse. Now, for a potential area for a

trade, we could look at this supply

zone. And what do we see on the run into

this? Well, we have a large bearish

impulse showing clear seller control,

and then the pullback up is full of

wicks and indecision, and it takes quite

some time to get back up there. So, that

again is really good basis for what we

want to see to validate our setups and

give us conviction to be able to hold

the setups through to that completion.

Obviously, after this, what we would

expect to see is a strong bearish

impulse like what we saw there.

Now, another use case for momentum is of

course avoiding bad trades. So, if you

found a setup that looks real good, but

then the market rallies with significant

strength against your trade, wiping out

loads of the previous price action,

that can tell you, "Okay, maybe this

trade isn't so great after all, because

we've obviously seen, despite everything

else, significant amount of buying step

in at that level, and I don't want to

sell against significant buying

strength." So, we kind of want to see

that sell, chop back, sell. We don't

want to see sell, consolidate, buy. That

is not going to be such a good market to

sell into cuz at that point buyers may

just hold control of the market for

just hold control of the market for longer.

And the other final thing, of course, is

validating your breaks of structure by

determining how strong the buyers really

are or the sellers, depending which way

you trade it. So, if we see a valid

standard confirmation, but then the

market grinds really slowly up towards

the break of structure and then finds

indecision after taking the structural

high, this can actually be leaning more

towards a sweep and reversal to the

downside than an actual continuation up.

So, these kind of trades, where we have

very slow grinding price action to the

point of the structural break, are often

times or pretty much always best left

alone. You want to see a clear impulse

to the upside which shows clear buying

control taking place here. As we've seen

in many the examples we've shown before,

you don't want to see the market

grinding up and having to really fight

to get to that structural break. When we

see this, we already know buyers are

weak and buyers at a more premium price,

well, they're much less likely to take

the bait there, either. So, that's the

thing we can expect the most. So, that's

momentum, incredibly useful. It's not a

standalone concept you'll trade on its

own, but it's something you weave into

all of the trades you take to determine

whether the candles are telling you

anything about the buying and selling

control inside of the larger narratives

that you create. Believe it or not,

that's actually pretty much all of the

concepts that I use in my trading. Now,

we do need to go a little bit deeper to

talk about fractals, top-down analysis,

and actually formulating this into

trades on the right time frames. But, to

quickly recap the process, we are

looking for structure, first and

foremost. We want to make sure we know

which way the market's going. And to

work that out, we use the direction of

the highs and the lows, the real price

structure. We don't use trend lines, we

don't use any indicators. We look at

where the lows and the highs have formed

and determine whether the market is in

an uptrend or a downtrend.

When we're clear with the direction of a

market, we will, as a standard trade,

look for imbalances to work out where

potential entry points could be. Those

entry points for the most part are going

to be supply and demand zones, sometimes

internal range liquidity or different

points of liquidity, but in this

example, there isn't any visible, so we

work with the simple area of supply.

Then we want to determine the momentum

on the run back into the zone. If we

have smaller, slower, less strong

momentum to the upside, that's a good

point for us. That's going to tell us

that sellers are still in control of

this market, and that will provide us

with what we want to see. The only

caveat to this, of course, is if we were

to see an incredibly strong drive up,

then this would be a trade we would not

take. Instead, providing we have good

momentum back into our zone,

everything is good, and we can look to

take that trade.

Now, we don't generally usually want to

just sell straight into the market. It's

better to see a confirmation. This is

where we use that substructure trend,

the internal structure, to determine a

agreement again with the time frame that

we're trading. So, this, let's say it's

the 4-hour time frame.

If we take a look at the zoomed-in area

here, we can see generally like a 1-hour

uptrend taking place inside of a 4-hour

downtrend. If that 1-hour shifts into

agreement with the 4-hour, and now the

1-hour's bearish as well, that is what

we want to see. Then we can set our

trade up. Generally, it's going to be

execute, stop over the high, target to

the low or beyond, and that is pretty

much the full process. So, that's what

your standard trades will look like with

the concepts that I've taught you. Now,

of course, there will be liquidity

trades, there will be the substructure

trades, where sometimes you'll have an

opportunity to buy from down here and

run through this range,

but the average standard trade in the

format that we're looking for overall is

generally what you can see on the chart

right here. Okay, so now we've been

through the concepts, let's start

talking about the actual application,

starting with one of the biggest

questions I get asked on pretty much

every video, what time frame do I use to

do this? Well, good news for you, the

market is what we call fractal, which

means the same patterns form on pretty

much all time frames. Take a look at

this trade. We have bullish impulsive

structure. Okay, so we have a breaker

structure to the upside, higher high,

the market's come down through some

liquidity, through an imbalance, into a

demand zone, and then traded higher.

That's a pretty clean and obvious setup.

This was done on the 1-minute time

This was done on the 1-minute time frame.

But, we also see the same exact thing,

bullish impulses, higher high, market

comes through liquidity, trades into

demand zone through imbalance, then goes

higher. This is the daily time frame.

So, the same pretty much the same exact

setup forming here on the minute and the

daily, and it also happens on every time

frame in between those. So, the simple

answer is, when it comes to the concepts

you want to trade, whether you want a

day trade or swing trade, you can

basically use whatever time frames you

want to use.

But, you should make sure there is

structure behind it, and that brings us

on to the next topic to discuss, which

is top-down analysis.

So, top-down analysis is the idea of

using multiple different time frames to

formulate your trade ideas.

For example, on the daily time frame, we

could see that we have an upward

trending market. We also have a large

demand zone. So, we could get the

general idea that we probably want to

buy a pullback in this market, right?

That would give us the broad foundation

for a trade idea. However, we probably

don't want to do that on the daily time

frame, because it would take weeks for

the trade to play out. So, you could

then zoom in and see the substructure,

some of these smaller refined areas on

the 4-hour in the same piece of trending

structure, and refine that demand zone

down. So, find a 4-hour zone inside of a

daily zone, which allows you to make the

zone smaller and work out the more

precise point to get into a trade. Now,

this, of course, would then allow you to

get a much better execution. Your stop

loss wouldn't have to be huge, and you

could run this with considerably more

profit potential.

As well as this, we could also maybe

scale down to the hourly to find a

refined area for a substructure trade,

okay? Against the overall trend to trade

through the imbalances and into the high

probability zone that we've prepped. So,

by doing top-down analysis rather than

relying on just one random time frame,

we build a picture that agrees across

the daily, the 4-hour, the 1-hour, and

everything below that as far as you want

to go.

That way you're in full agreement across

time frames, you got full clarity as to

what's actually going on in the market,

and your trades will be able to be taken

with much more confidence and

conviction. And you'll also find those

smaller trades inside of trades like

this one that we've got marked here.

Now, a good thing about this is, and

you've probably faced this in your own

trading, when you've been trying to

trade, you might find something that

looks like a good setup. So, for

example, looking at this market, we can

see an efficient and very bullish

market. So, you may want to buy into

this market, right? Let's say on the

hourly time frame or the 30-minute. But

if you zoom out to the 4-hour or daily,

you may realize that that exact piece of

price action you're looking at is

sitting right inside of a massive supply

zone after a break of structure to the

downside. Well, now suddenly your buy

idea that looked good on the lower time

frame looks like an absolutely terrible

idea that is likely to go wrong on the

higher time frame. When you do the

top-down analysis process from the top

to the bottom, you understand what every

time frame is doing, you understand

where in the market you're sitting on

each of those different time frames, and

it's easy to avoid taking these trades

that logically in hindsight were never

going to work. But when you zoomed in

and over-refined and you're not in

consideration of the big picture

context, they're easy to take, they're

easy to lose consistently. Okay, so to

teach you top-down analysis, we're going

to run it back to the EUR/USD trade we

shared not too long ago, but instead of

just looking at the hourly timeframe,

we're going to do it from the weekly

we're going to do it from the weekly down.

Now, I suggest you begin all of your

top-down analysis on the one-week

timeframe for a simple reason. It's

going to give you the most zoomed out

and clear look as to what the market is

doing overall, right? If we take a look

at this on the weekly,

we kind of see not too much in the way

of clear direction, cuz this is quite

consolidative. But, we have first ideas

that the market closed through this low.

That's maybe the start of a bearish

impulse, right? The start of a bearish

trend. So, we have impulse there pushing

through this low.

Then, we have a second break of

structure, again pushing through the

next low.

So, from what we can take from the

weekly, and we really don't need to pull

too much in the way of trade

opportunities here. We just want to get

a broad idea for what's going on. We

could say, "Okay, impulse, correction,

impulse. This is probably a market that

we want to sell at some point in this

current trend."

So, if we go to the daily timeframe now,

this is where I suggest you go second.

And what we're doing here is running off

the same idea, but refining it down a

little bit. We can see on this level,

the impulse correction impulse is pretty

clear. I'll map that on real quick, just

so it's in our minds.

And if we take a look at where the

market landed, so looking to the left

over here,

this is an efficient range, okay? So,

there is efficiency here. Therefore,

meaning the market doesn't really have

too much ground to fully reverse from,

further backing the idea of potentially

selling this market, okay? So, we're

building a good picture now. We probably

want to be selling overall when it comes

to the high timeframes.

So, with that, we can jump down to the

4-hour timeframe and see what's going on

4-hour timeframe and see what's going on there.

This is where we can really start to

build a little bit more information as

to what's happening.

So, one thing I would notice on the

4-hour perspective here is, of course,

with the idea to sell, where could that

selling take place from?

Now, looking in the previous leg of

impulsive price action, which is going

to be this high to this low, we want to

determine where the best possible place

to sell could be.

Obviously, first off, we have a supply

zone. So, your attention would be drawn

towards that. That's completely fine. We

can mark this area out and consider that

for a possible reversal.

And now, we want to factor liquidity.

This is what's going to help you to not

get caught up in traps, okay?

So, the first thing I can note when it

comes to liquidity is we've got a pretty

obvious descending trend line, which

runs through from here down to where

price currently sits. So, [snorts] this

could create some potential trend line

liquidity in and around this range. So

far, that's okay. Maybe that could still

back the short trade that we're looking

at, right? Because there's liquidity

being swept as we speak.

The other thing I can see, however, is

some equal high liquidity here. So, we

have two equal highs in the market. We

know this is going to act as liquidity

and potentially draw price towards it.

So, if we have equal highs, what did we

rule when we were talking through

liquidity? We said we shouldn't sell

beneath equal highs, okay? Not like

beneath equal highs, okay? Not like this.

So, with this now acting as a potential

magnet for price, we could say with more

certainty that this supply zone might

not be the best because we still have

some liquidity just above that that we

can go and trade into. Now, if these

equal highs were miles away, we could

potentially brush that away, but this is

right above the point of which we are

looking to sell in a supply zone. So,

with that said, these are going to hold

some reasonable weight because they're

close to where price currently is and

they're going to act as a magnet for

price, okay? That's why it's important

to spot liquidity. So, the trend

liquidity, maybe that's okay, maybe it

wants to be purged a bit further. The

equal high liquidity, that's not going

to be okay to sell under. So, I

personally would pretty much write off

the idea of looking to sell from here.

Now, we've got a more zoomed in view of

this leg of price, which gives us zoomed

in perspective of the internal range

highs and lows, okay? We have a high,

we have a low, we have an internal high

there, pull back down, internal high

there, pull back down, internal high

there, pull back down, internal high there.

So, with the internal high liquidity and

the equal high liquidity sitting

together, we could basically say the

market is quite likely to come towards

this range between this high,

where we expect it to surpass this high

and go through the equal highs really.

So, we'd ideally look at, say, the next

internal high, because internal highs

are a good point for the market to

collect fuel from, as we showed

previously, as well.

So, although we're in a bearish market,

okay, we've pretty much been able to

write off the supply given the liquidity

that sits above it. And if we're

expecting the market to get to here, we

would generally want to see it take an

internal high for fuel for the movement

down. So, this would be that point,

right? So, the 4-hour that we're on now

is really where we're formulating the

idea, validating and invalidating

certain areas to set up good trades.

So, with this said then, I'm going to be

quite interested in seeing the market

come up towards here, and then I will

look to see if there is an opportunity

to sell. But of course, this is pretty

high time frame stuff. So, with us

expecting the market to be magnetized up

there, is there a possibility for an

opportunity for us to buy the market

from where it is into these higher price

from where it is into these higher price levels?

Well, the simple thing we could do is

simply target the equal highs, cuz

that's a very high probability point to

be hit.

So, we'll take this supply zone off for

So, we'll take this supply zone off for now.

We'll take off the trend liquidity for

now as well to keep it simple.

And now we have an idea that we could

maybe, whilst this market is still

bullish on the lower time frames, trade

through towards that point of equal

through towards that point of equal highs.

So, now let's zoom in on the hourly and

work out what we're working with here.

So, the equal high target is going to be

this level. Let's just strip everything

back to that. That's going to be the

target we want to go for.

What is the current trend telling us?

Well, we had this bearish phase of lower

lows and lower highs.

Then we broke over into a higher high.

Then we have higher low, higher high,

higher low, higher high, higher low,

higher high. Okay? That's the structure

we're currently working with.

Now, within this structure, we can

actually see that the market has reacted

quite significantly through each of

these phases to internal liquidity. So,

we have internal liquidity there.

We have internal liquidity around this

point being swept as well.

We have internal liquidity around this

point, the sweep leading to a reversal.

And now we have a trickier impulse

because the impulse was slow until this

because the impulse was slow until this phase.

So, with this being a break of

So, with this being a break of structure,

that then sets us up with uh

the structural break we want to see, and

now our only job is really finding the

point to buy from.

Well, we would generally then want to

look under the internal liquidity low.

So, that's going to be the internal low.

And then from there, if we were to trade

down gently, we would look for our

confirmation, and we would buy from

there. Okay? Obviously, on this one, we

can actually extend the target up

towards this point, too.

And you already know how this one goes.

Let's run it forward.

The market came down brilliantly.

Remember also consider your momentum

when you're in trades. And now, by the

way, the hourly is where we find the

smaller opportunities and refine

potential trades inside of trades,

right? We are looking for a big short

once the market gets higher.

And then, because we expect the market

to get higher, we have the possibility

to look for a smaller buy. Still a

pretty reasonable buy from where we are,

pretty reasonable buy from where we are, though.

So, we sweep the liquidity, we break up,

we retest demand, and then we get an

execution from the area of demand

to take the market higher. From this

region, with stops under the low to keep

it nice and safe, and you could target

all the way into that. So, that's going

to give you around a 6.6%

potential trade, and that is simply by

following that top-down flow, where

we're finding trades inside of trades,

and making sense of the overall market

to then give us, you know, the big

picture opportunity, and then smaller

picture opportunities within that price

action as well.

So, when I was trading this myself, as

said, I ended up getting out of the

trade around this point. Um I had a

smaller area that I was looking at.

Realistically, I could have held it up,

and probably should have, but we're not

all perfect all the time.

So, there we go. That is basically where

we're at in the market right now.

If we skip this forward, you can see

what's progressed from that point, and

take a look at this, this reversal that

we've seen come from a sweep of the

equal highs, and also from a sweep of

the internal high. So, I am interested

in shorts from around this point, and

see where the market can get to, because

that fits in with the big picture that

we built, right? The sweep of internal

liquidity, which can potentially turn

into a larger term reversal to bring the

euro lower. Now, that's not 100%

confirmed just yet due to structure, but

everything is kind of in place to

potentially set up another good trade.

So, that's how top-down analysis works.

You basically build a story around what

the market's doing using the weekly into

the daily into the 4-hour into the

1-hour for your refinement and

execution. And look, if you want to do

this as a very, very low time frame

trader on the 15-minute, 5-minute, you

absolutely can. I suggest just doing

that weekly around once a week, analyze

that weekly daily, and then day-to-day,

you can follow this exact flow inside of

the big picture on, say, the hourly down

to the 30-minute, down to the 15-minute

with 5 minute for executions and

refinements if you want to do that.

Because the markets are fractal, it

really is down to you what you want to

do. Higher time frames, easier to trade,

more consistent, less chaos, but if you

are interested in the low time frames,

nothing stopping you doing that as well,

okay? So, we got weekly into daily, into

4-hour, into 1-hour, and then if you

want to go lower and find those trades

inside of trades and day trade to your

heart's content, no one's stopping you

from doing that.

So, that's the theory of top-down

analysis and a practical application of

how it actually goes down.

And that is everything. That's pretty

much everything you're going to need to

know to go forward and do successful

technical analysis and make a lot more

sense of the market and I'm sure you can

see that now. So, what is the next step?

What should you do? Well, you should go

and practice these concepts through some

back tests first of all. So, go and mark

up past price data, run some back tested

simulated trading. Don't trade this live

because at this point, having only just

watched the video, you're not ready to

trade them with real money this soon.

And if you try these concepts with real

money at risk, you're going to mess

things up. So, you should practice on a

demo and in back tests first of all.

Now, if you want to master this trading

style with my help alongside many others

inside of a community where we're all

trading in the same way and learn the

full step-by-step process I use to

capture trades, you can join the ETM.

That's my program. The first link is in

the description will take you there, but

that is a paid program. Now, if you want

to learn more without paying, if you

want some more freebies, uh you can

learn more about the statistical side of

trading, obviously the next natural

layer, inside of a 40-ish minute video

that I've got also linked in the

description, and that one's going to be

the second link. So, whichever one you

want to do, check them out, and if you

don't want to do either of those, just

at least practice on demo and back test

before you start doing this live. Hope

you've enjoyed this course. Thank you

for watching, and I'll see you in

another video soon.





-----------------------------------------------------------------




In this video, we are going to break

down this trade that I took recently on

down this trade that I took recently on GBPUSD.

Here is that trade sent out before it

was taken. And here is that trade after

the fact to show you that I did actually

take it. Now, this is what the market

looks like now. Although we rallied

significantly since filling the target,

we actually came into the exact point

that I said would be a good place to

close the trade. As you can see, if I

just zoom this out a little bit. Now,

this is what I would classify as a day

trade. It's not something I intended to

hold for a long time, and it was pretty

much just me taking advantage of a very

obvious opportunity that I saw in the

market when I came to the charts, well,

yesterday at the time of recording this.

So, in this video, I'm going to break

this trade down start to finish, show

you how the idea was formed, how the

target was chosen, and pretty much give

you my thought processes behind the

whole operation of this trade.

Now generally my analysis is going to

begin on the higher time frames. I begin

on the weekly, go to the daily and down.

That is to build narratives, the big

picture ideas. Now for GBPUSD, it's been

a little bit difficult to do so given

that pretty much since the start of

2025, we've been in a sideways

consolidation. So narratives wise, what

we're actually doing is we're pretty

much zooming in on nearterm price. We're

looking at what's going on over the past

couple of weeks and then running off of

that. Now, we did get a bit of insight

because over the past couple of weeks

here, we'd seen the market breaking down

through this low and trading towards the

next low, this low here. Right? That's

pretty much all the information we can

gather from this. A lot of the

information that led me to focusing on a

short bias for GBPUSD was actually

correlation. So, this is the first thing

I want to cover as a little lesson for

you. If we take a look at the US dollar

index, this is the DXY. That's what the

chart's called. This shows the relative

strength of the US dollar versus pretty

much all the other currencies uh in the

list. Now, this one obviously has been

rather bullish. From this point, we

broke into a higher high, printed a

higher low, a higher high, and then we

came down and created another higher

low. We then started rallying once

again. Now, the reason for the latest

rally is the US Federal Reserve have

raised interest rates. What that does is

it means US dollar interest rates are

going to be higher. It means holding US

dollars is more viable, valuable because

you are going to make money or make more

money for holding your US dollars. And

being the safe haven or world reserve

currency, it's very good place to park

your money. So if you got a bunch of

money, you want to put it somewhere safe

and get a yield for it. Higher interest

rates on the US dollar is very

attractive for people to then buy US

dollars. So that's why we saw such sharp

reversals in the downside price action

of the dollar index. people were buying

US dollars because the yield is higher

and it's expected to go higher or stay

higher for longer which is a bullish

sign for the dollar index or for the US

dollar as a whole. So because I was

expecting the US dollar to be bullish

I've been looking short side on eurousd

and GBPUSD which are pretty much the

only two things that I consistently

trade. I don't trade everything else too

frequently but I always do stick by

these ones. Now, I haven't seen the

movements that I wanted to see on

EuroUSD yet to actually capture a trade,

but I did see something interesting on

this one and also on the dollar index

too. So, when we saw the market coming

down, we'll jump back to this point.

When we saw the market coming down

towards this low, we printed what we

call equal low liquidity. Basically, two

equal points in the market that

generally will then act as a magnet for

price because we know there's going to

be stop losses and sell stop orders

situated around that level. So, I was

expecting to not see this go higher, but

actually to see this come lower and

sweep out this low before a buying

opportunity would come in mind. And that

kind of looks like it might be happening

now that the market got a bit deeper

than I expected it to. Now, because I

expected euro to come down

significantly, it prompted me to take a

look at the dollar index. And we saw on

the dollar index, while we did have a

break, it's not the strongest break in

the world. Now, you'll see that just

here where we immediately reverse and

start trading bullish with pretty

significant wicks and a very large

indecision candle as soon as the break

takes place. Now, when the market got up

here and it drove through the only

supply zone that could keep it down, I

had a pretty good inclination that the

market was likely to take out the high.

So, these things are all correlated,

right? If the US dollar is going to go

up and take out the high, that tells us

that Euro USD being versus the US dollar

is likely to go down and take out the

low because it's the euro strength

against the US dollar strength. And if

the US dollar is getting strong enough

to take highs, then the euro is likely

going to get weak enough to take lows,

right? Relative to the US dollar at

least. Now GBPUSD was in an interesting

position then because while this was

kind of following suit and does

correlate in the same way as Euro USD I

mean if we look at the recent movement

down that we've seen on GU and we

compare that to the move down we've seen

on EU you'll see these two pairs move

very much the same right now the only

difference was obviously on EuroUSD the

low has now been taken on the dollar

index the high has almost been taken and

on GBPUSD The low is still open in the

same way as the dollar index it is.

Although the dollar index is quite

obviously leaning to the upside likely

to take out the high now because we have

this kind of what could we call it

disparity where Euro USD has actually

already taken the low but GBPUSD hasn't

done that yet. We get the idea that okay

the low is probably rather likely to go.

So now we just have to see if that makes

any sense when we put it to the test.

Now, obviously, we could say the markets

created a confirmation, right? So,

shouldn't we be looking to buy and that

would be viable? We could keep that in

mind and it's definitely something I did

keep in mind while I was setting the

trade up. We can mark that high on. We

can see we got the breaker structure.

That's all good. And then we can drop

down to a slightly lower time frame and

see what the market is up to here. Now I

saw one thing on this chart which I

found very interesting and it was when

the market had gone a little bit further

than this. So let's move it to where it

was when we set this trade up. The

market was trading here before this

drive higher. So with this bearish

candle that we see just here and let's

zoom in a bit. This bearish candle

pushes us past what would be the only

meaningful demand zone left. Now, a

demand zone, if you don't know, is an

area of consolidation before an

impulsive move that indicates buying or

selling strength. A demand zone is going

to be for buying strength. We see the

market flat out here. An impulsive move

begins driving us to a new high that

creates demand. Now, if we were to then

see the market create reactions in here,

break structure on the lower time

frames, such as break through some

internal structure like this. So, let me

plot it for you. If we were to see this

then sure we could look to potentially

buy this market if it pulled back right

we could look for a pullback and then we

could buy the market because it would

have respected the demand zone and

helped us to follow a continuation to

the upside right however we didn't see

that okay I mean all of that to say that

that didn't happen what actually

happened instead was we ended up closing

beneath the low so this bearish candle

here closed underneath the demand zone

that actually creates something we call

a demand fail or a zone failure. And all

that is basically showing is buyers who

were incredibly strong here previously

are no longer incredibly strong here in

the current because if they were, it

would have actually not been able to

close lower than the demand. Generally,

when we're looking at demand, we're

looking for quick reactions. The theory

behind it is it's a discount price level

that buyers are happy to enter the

market at seen as a fair value for the

asset. So if it's retested again, we

should see fair value once taken up

again and see the market drive higher.

We don't get that if the market closes

under the zone. So it's classified as a

demand zone failure and basically

invalidates that zone entirely. Now then

we move into the second concept that I

use quite a lot in my trades, especially

in these smaller trades where we're just

running through existing ranges. In this

one, we have what we call an efficient

range below. So if we go to the 30

minute, efficient ranges and inefficient

ranges are two different things and I'll

explain them real briefly now. So an

efficient range is a range where every

time we create a demand zone, the market

pushes away but then it pulls back and

retests the demand zone, right? So like

this, this becomes an efficient range.

Every zone created is then retested. So

there's no imbalance or you might know

it as fair value gaps. That kind of open

space we get such as uh these candles

here before the market came back and

filled it in. There's none of that left

in an efficient range. Now in an

inefficient range basically, let's just

use this last move like this. We have a

demand zone here. The market's pushed

up, created an imbalance, fair value

gap, inefficiency, whatever you want to

call it, and it hasn't pulled back yet

through that. So this is an inefficient

range. Now there's a difference between

these two things that is very useful and

not many people talk about or I don't

think know when the market pushes into

an efficient range meaning there's no

imbalance left below it's very unlikely

that it will actually reverse inside of

that range back into the overall

direction. So, what I mean by that is if

we have an efficient bullish range like

what we've got going on here and the

market comes down to here for example

and trades back into some of the old

demand zones, it's very unlikely that

the market will then be able to find the

fuel to create this movement up and go

higher. And the reason for that is

there's no significant points of

interest in here. There's no areas of

significant liquidity anymore. there's

no areas of, you know, significant um

buying orders in the form of demand

zones or any key points of interest that

would actually prop the market up and

give it the fuel to create another large

bullish movement. So, when we see a

market trade into an efficient range

with no imbalances left, this is a

pretty good sign that the next likely

following move is going to be a pullback

and a continuation lower. Okay, so let's

draw that back to where we are on this

chart. We have a failed demand zone and

then we have an efficient range here. We

take a look here. Every single time we

created a little demand, it was retested

by the wicks pulling back in. So we have

wicks, wicks, wicks, wicks retesting all

of those open zones. Another thing is as

well drawing back to liquidity, we have

some equal low liquidity down at these

lows. So just there we have the one,

two, three. Now these are what we call

relative equal lows but they are still

basically giving us the same bit of

information that um the market has going

well it's going to have a collection of

liquidity and orders beneath this level

and therefore it will act as a magnet

for price. Okay so if we have a lot of

orders markets react to orders we know

the market's likely to be drawn down

towards that point and therefore

anything above that isn't likely to

create a reaction. A simple rule that I

have in my trading is to never buy above

equal lows, never sell below equal

highs. And that works very, very nicely

for avoiding these bad situations.

All right, so that's kind of the target,

the premise, the basis of the trade. How

do we actually get in though? And why

are we targeting this low? Well, I think

I explained that pretty simply. This is,

of course, the current low of the range.

And this range low is the same

correlating low that's been taken out on

Euro USD and on the opposite well yeah

at this point in time has just been

taken out on the US dollar index right

and that was when the trade set up. So

what I wanted to do from this point

onwards was find a point to actually

execute a trade. I'm pretty confident on

the bias. I'll run it back to where I

actually found this setup. It was here.

Pretty confident on the bias now. We've

weakened into this zone. We're

definitely rolling over. This is more of

a bearish than bullish impulse. We've

failed that zone. We've pushed into an

efficient range. We have equal lows. We

have the range low and we have the

correlation of those higher time frames

suggesting to us that we are likely to

move lower. Now, another thing as well

is on the 15minut time frame, we

actually do have a supply zone. The

opposite of a demand zone. It's for

sellers, an area that sellers stepped

into the market and forced previously

and therefore we're likely to see it

again. And as you can see, we attempted

to get there and failed. got there with

a tiny wick, got there with another

wick, had no closures in or anywhere,

you know, significant in the zone, and

then we just immediately started rolling

over. So, this shows us again sellers

have entered in force. Here we have

buyers attempting to take the market

higher, sellers stepping in with force,

buyers trying once again to actually

regain the market there and failing. So,

now we have seller control and a failure

from buyers, right? We are going to be

moving down. Okay, so how do we actually

sell into something like this? Of

course, that is the big question. It's

all good knowing how to read the market,

but where exactly do you e execute? Now,

for that, it's actually quite simple. I

look at two things realistically to get

into pretty much every trade I take.

First is supply and demand zones. I love

supply and demand. I've been trading

with it ever since I started trading,

which has got to be what, like 10 years

ago now. And it's pretty much the thing

I'm going to be trading with forever

because it makes the most sense to me

and it's just so easy to set up your

trades. So, with supply and demand,

we're looking to find little

consolidation areas before impulsive

moves. Now, an obvious one is this one

here. And an important note about supply

and demand is it has to have imbalance

into it, right? So, this candle, the

impulse down, is of course imbalanced.

It's inefficient. So, that creates a

supply zone that we can focus on. Now,

I'm going to change the color of it so

we know it's a bit more substantial. If

we look inside of the current move, so

after this pullback, we don't have any

supply zones. They're all retested at

this point. Every time a wick taps back

into the zone, it invalidates it. So

this is an efficient range once again.

So we have efficiency

to this high and then we have imbalance

and a supply zone with inefficiency

above. Okay. So that becomes a very

prime point for us to sell. Now, there

was also this area above this one kind

of back towards the highs uh that I made

a note of just here. So, I mentioned in

there uh if we do get there, it's

possible and we can look for it, but I

doubt it's going to get that far given

the bearish momentum that we see. The

reason for that is simply this zone is

not as significant as this one here.

Okay, this one, if we look at the

impulse that came from it, it didn't get

through any previous lows, not even

wicks. However, this zone has managed to

push through previous lows in this

trend, push through that previous low

and even now push through this low and

create a demand failure. So, this zone

is a lot more significant than the zone

up here. And of course, with the bearish

momentum that we have, is it likely we

get all the way back up there? Probably

not, especially not when we're reaching

for a pretty insignificant zone. So, it

was a pretty obvious choice for me that

we're going to look at this supply zone.

Now you also heard me mention internal

liquidity. So inside of a movement we

are going to have basically I break it

into a swing move and then sub moves or

internal moves. So the swing move for

example would be in a trend like this we

have an impulse correction impulse. But

inside of each of these impulses and

corrections we're basically going to

have smaller trends inside of trends

with their own impulses and corrections

taking place. Right? So inside of the

one larger movement which we would draw

in this case from this high to this low.

So this would be our larger impulse

move. Inside of this movement you can

see we actually have trends inside of

trends. We have our own small

corrections and things taking place

within that. Right? And each of these

little corrective moves that we get

creates an internal high right some more

significant than others. So, this is an

internal high that creates liquidity

because we know any selling that's

taking place beneath that likely going

to be stop losses, buy stop orders,

whatever it may be. That's the wrong

tool. Um, above this high. So, that

creates again an area that the market

can potentially fuel the next movement

down. Now, if we think about what is

actually driving buying and selling

moves, up and down moves, it's the

transacting that's happening between

participants, right? If we have an area

with a bunch of orders here, okay, we

can see the market return there and then

take the other side of those orders and

run the market lower. Inside of this

range, we're going to have less

significant quantities of orders uh or

random distribution of orders with more

buying versus selling than we would have

at one set level where many people are

looking for the same opportunity, right?

Because um while we're low in the range,

we don't really have sellers selling at

uh discount prices. they want to sell at

premiums and we don't really have

buyers. Uh well, yeah, because we're in

a bearish market, bearish controlled

market, right? So, what we are generally

understanding from that is that traders

want a good price. If it's sellers, they

want a premium. They want to sell as

high as possible. Obviously, if you're

holding and selling, you're profiting

when you exit. So, you want the best

price possible. And if you are uh

getting into the market, you again want

a premium price because you're going to

be able to get the maximum profit when

the market runs lower. Makes more sense

to sell here than it does to sell here

because if the market gets to the same

point, well, you've endured less draw

down on this entry and you have made

significantly more profits in terms of

the riskreward and also uh the gain well

the distance before your target is met.

Okay, so those things considered then

anyway, we'll get back on track.

Hopefully that was a nice little lesson

as well. I'd pretty much locked in the

entry and I think you can see why. Clear

supply zone, clear internal liquidity,

and everywhere above is just kind of a

bit mid. There isn't really a

significant zone that we'd want to sell

from up there. So, how do I execute this

trade then? Well, it's actually very

simple. I place a sell limit order. I

place it there. I put the stop loss

there. I'll explain that in a minute.

Again, another interesting thing. and I

put the target at the low and it was

around 6R.

So there it was. Okay, so that was the

trade start to finish. Okay, pretty much

enter on the zone regardless of what it

does and then we run it to the target

and we get out or it runs to the stop

and we get out for a loss. Now, why

would I take this trade with a sell

limit and why would I not wait for

confirmation inside of there? Well,

there's a couple of reasons for this.

The first is the market's pretty much

already confirmed its bias to me by

creating this large bearish impulse,

failing the demand zone. And of course,

the correlations leading us to believe

the market's likely to draw towards the

low and the macroeconomics of the dollar

just being stronger than the pound at

the moment. All of those things tell me

that the market's likely to get down

there. So, I have conviction and I'm

happy to just place a sell limit. And

the other reason is uh we may not get a

confirmation in this case because of the

bearish momentum. For a day trade like

this on the lower time frames, I know

you may classify 15 as a higher time

frame, but it's really quite a low time

frame. For a day trade like this, we do

get fast momentum. We don't always get

pullbacks. We do get those sharper

movements than if we were trading some

of the higher time frame stuff like

hourlys and 4 hours. So, we may not get

the confirmation we want to see without

the market just running straight to the

target. Okay. Now, the final reason is

simply because with the conviction I've

built in this trade, as you can see,

I've got a lot of reasons to be taking

it. I don't care if it loses. Okay. The

loss is controlled. I'm very happy to be

holding the risk on this position. If it

does lose, it will lead us into new

potential opportunities. Obviously,

we'll confirm those ones because the

conviction will be a little bit waned.

not in terms of mentally, but obviously

things will have changed at that point.

Uh, and we may want to then reassess

before we get back in. But a controlled

loss that leads to a new potential

opportunity is nothing to be scared of

and will be the result of around half

the trades you take in your entire

trading career probably anyway if you're

trading for any decent riskreward. And

then the last point is look at the

riskreward, right? It's 6R. I can risk

$1 on this and make $6 in return.

Amplify that as many times as you want.

You're making six times the amount you

risk if it wins. Do I care if a trade

like that loses? As long as it's a good

one, no. Because if that happens five

out of six times, I'm still profitable.

And when you build convicting trades

like this with a lot of reasons, a lot

of analysis, it's not about finding

reasons, but reading the story behind

the market. When you have the amount of

conviction that I have behind the trades

I take, you don't have to worry uh, you

know, about losing so many trades

because you're not going to lose loads

of them. And when you do lose, they're

outweighed by the riskreward you're

gaining on winners anyway. All right.

Now 6R I will say is a very big trade.

Um I don't always get trades that big. I

generally go for around 3R but I mean

this one was kind of free money in that

sense that it was just allowing me to go

for this much with a quite tight stop

loss. And now let me break down why the

stop loss exactly is there cuz we've

done pretty much everything else. So

we'll start on the 15. First of all, you

saw that when I executed, I was setting

up off the 15-minute candle, right? It's

that indecision candle just there before

the impulsive move down. Now, I

initially thought, could we get away

with putting the stop here? I thought

that would be a bit crazy, though, cuz

it would only be four pips. Um, and I'm

quite boring nowadays. I don't really do

this kind of thing anymore, but I could

have done it. Okay, so what we wanted to

do then was check, is this viable or

not? because I will take a very small

stop-loss position if it becomes the

logical point to put the stop. What I

did was I went two steps down from the

15-minut time frame to the 5-minut time

frame. And in doing so, I saw this. All

right. Now, this isn't going to change

where I execute from because if you over

refine your trade entries, you will miss

lots of them. Like let's say the market

came up to here and then reversed and I

was trying to get this perfect entry.

Well, now I'm going to miss out on like

6R, 7R, 8R simply because I wanted to,

you know, go one pip higher with my

entry. So, I wasn't too interested in

moving the execution for that. But what

I did was actually put the stop loss

over this zone and then over the wick as

well just to account for any potential

taps into this zone that we do get. Now,

I could have put the stop over here,

sure, but I just thought, what's

actually the point in doing that, you

know, like uh this high just here, if

the market's going to get up to over

this high,

then it's going to get up over the other

one. Let's be real, because it's

efficient and there's no reason for the

market to pass the level that I'm

currently holding. and then reverse. So,

I thought, well, we might as well go a

little bit tighter. Raw spread accounts

anyway, you don't have to worry about

spread so much, especially on these

majors. If you're on a prop firm

account, your spread gets bigger, then

sure, put it over the highs. But for the

account I'm at, I thought this is the

viable point. This is the last point I'd

expect the trade to be valid, but this

high just accounts for any spreads, any

tiny possibility of a wick coming really

high up into the point before reversing

down. Okay, so that is why the stop loss

is where it is. Again, you could put it

there. uh I wouldn't put it there

because it's not safe when we refine

down to the five minute but I thought

around in that area was a pretty good

point to be putting it. Now you will see

actually on the return back into the

execution. So let's see how the trade

ran out now. It did hit that 5m minute

zone. So there's probably someone on

Instagram flexing their 17 trade now and

that is really cool for them. But um I

didn't do that one. I just went for this

standard and slightly more boring

approach, but probably more consistent

as well. And that was to just execute

off of the simple 15 and run it down

into the low. And that's that. That's

pretty much the whole trade start to

finish. Done. Okay. Now, I'm not sure

what other lessons I can pull out of

this, but we can recap the ones real

quick. The first is correlations.

Something that not enough people use. If

you track the dollar index, you can gain

a lot of information from this as to

what you're going to do with your other

trades. If I'd seen basically this

weakening, then I probably wouldn't have

been looking to uh initially sell the

pound against the dollar in the first

place. But because we saw that strength

building towards this high because we

saw Euro USD, the most closely

correlated pair with GBPUSD taking out

those lows, that gave us the first idea

that okay, yeah, we're probably going to

be seeing moves down coming in soon on

GBPUSD. The next thing is

macroeconomics. And I don't go super

crazy with macros, but if you understand

what the Fed is doing with interest

rates, so literally just track Fed

interest rate decisions month by month,

you're going to get a good idea as to

what the US dollar is going to do. When

rates are higher, they're being held

higher. They're not being cut. That is

generally more bullish for the US

dollar. When rates being cut, when rates

lower, that is generally more bearish

for the US dollar. So obviously with the

new Fed chairman and the hikes that we

saw coming in, I was pretty confident

that the dollar was going to be building

strength. Therefore factoring, you know,

additional conviction behind the buyers

to sell the pound versus the dollar.

Uh what other lessons do we have in

here? I mean the efficient ranges. Okay,

we came into an efficient range and we

took it all the way out. As you can see,

uh that theory has now come true. And

then internal highs, supply, demand, all

that stuff that we taught. But the big

core lessons I think we just recaped.

So, I hope this video was useful. Uh,

there's no editing and it's just like

kind of off the hip. So, hopefully uh

it's not too rambly or whatever. I'm

sure you've learned a thing or two. I

won't go on. Thank you for watching. If

you're interested in being in that

group, uh it's totally up to you, but

there is a link in the description for

that and there'll be a link to some free

class as well. So, thanks for watching

and I'll see you in the next video.



-----------------------------------------------------------------

I have helped hundreds, if not

thousands, by this point of traders to

get funded, reach payouts, and some even

go full-time. So, at this point in my

trading and of course teaching journey,

it's pretty clear that I know why people

lose, and I know what it is that makes

them win. So, today we are going to look

at five reasons why you're losing at

trading and how you can turn your

results around fast. These are things

that you cannot ignore. If you want to

win, you have to fix these very soon.

One good trading system can override

every bad trading decision that you have

ever made. So, over these few classes,

that is what we're going to be building

out for you, so you can go forward and

win. But, we need to start by

eliminating the leaks in your system

that are costing you everything. So,

we're going to jump straight into reason

number one, and that is over-learning.

So, in trading, you can actually learn

too much. And sometimes the more you

learn, the worse you get. It's very

likely by this point that you've learned

too much information from too many

different people. What this does is

create conflict in your mind. When you

look at the charts, you don't know

whether you should follow a strategy you

learned from this person or a strategy

you learned from this person. Or even

worse, you try and mix them together,

but because they trade in different

ways, it simply doesn't work. So, when

you look at a chart, if you have

information about supply and demand in

your mind, you might look at the markets

like this. But, if you have trend lines

in your mind, you might be thinking,

"Well, should I take this trade

instead?" If you have support and

resistance as something you've tried

before, you may see the support floor as

an opportunity to buy. But then, if you

understand liquidity, you might think,

"Well, no, that's likely to be taken

out." If you've learned about fair value

gaps or ICT trading, you might think if

the market returns to this zone, I will

buy. But, if you trade imbalances in the

way that I trade them, you would be

looking for it to be filled instead. See

what I mean? The confusion that occurs

when you have all of these different

systems and way of viewing the market in

your mind actually becomes more

difficult to find trades because you

have learned too much. There are so many

different ways to see the market, and

realistically, none of them are

inherently wrong. I have no doubts that

people win with basic support and

resistance. I can't do that, and I

prefer to trade with logic-based

concepts, supply and demand, and things

like that. But, none of them are

inherently wrong because what we're

doing is balancing probabilities. The

problem becomes when you try and mix

these things together because these

systems work in isolation. If you have a

trend line strategy that has a 50% win

rate, that's completely fine. If you

have a supply and demand strategy that

has a 50% win rate, that is also

completely fine, and both of these

things are likely profitable on their

own. But, when you mix them together,

you break the edge. Let's say you look

at the market from a supply and demand

perspective. If you take this trade,

it's either going to win or it's going

to lose. But, if you continue to do this

long-term, you're going to get positive

returns because of your risk to reward.

If you trade a trend line strategy, when

you take a trade, it's either going to

win or it's going to lose. But, again,

profit is made through probability,

okay? Profits come from the long-term

edge that a system has. So, let's say

you take 50 wins and 50 losses at a 1:2

risk to reward ratio, meaning you're

risking $100 to make $200. meaning

you're risking $1,000 to make $2,000.

Well, then, you're going to lose $50,000

on the losses and win $100,000 on the

wins, which creates a $50,000 net

return. But, when you mix these

conflicting systems together, the edge

dissolves because every trade you take

is different to the last. So, what

actually happens when you overlearn is

you learn so much that you become worse

than when you knew almost nothing at

all. Your knowledge increases, and as

that goes up, your ability decreases

because you've just learned too much,

and nothing makes sense anymore. So,

what you need to do to fix number one,

and don't worry, we're going to get into

how we can truly fix all of these things

towards the end, is stop learning new

things and just turn what you currently

know into a system with an edge. Or, do

one final hard reset and focus on

turning that into your system and

eliminate all of the other chaos that

you've been focusing on for so long. So,

that is reason number one. Reason number

two is being outcome-focused. This one

is super common and also super be

So, it is likely at this point in your

trading journey that you're too

concerned about making money now, and

you're not thinking about the long-term

profitability or the long-term outcomes

of your trading. Most traders, when they

come to the markets, are focused on

making some money today, which means if

you come into the markets, you take a

trade, and you win $100, you feel very

good about yourself because you've

walked away with a profit, you feel like

a successful trader. Now, all you have

to do is come back and do that again

tomorrow and the day after, right? That

is the thought process that people have.

But, the problem is this leaves you

trading in a way that isn't really best

set up for long-term success. So, take a

look at this example. You could be up

after 70 trades where you're just

forcing trades each day, and you are

just looking to make money in the short

term. And this feels, in the moment,

very successful. It feels profitable

because you're making money. However, if

you're trading in a way that is too

short-term focused, and your only

interest is making money right now,

you're probably not trading a very good

rules-based system. You are actually

just taking whatever opportunity you

think will pay you today. You can make

bad decisions. And if we zoom this out,

and we extend this further, you'll see

that this actually can go pretty

terribly wrong. Because what you're

doing is not trading a long-term edge,

you're trading short-term returns.

You're just looking for any way to grab

$100 from the market today. Do that long

enough, and yeah, you might be

profitable for a bit, but everything

will come tumbling down, and you'll lose

your funded accounts, your personal

accounts, and everything you put into

the markets. So, your attention should

not be on making money right now, it

should be on following a plus EV system.

So, EV is expected value, okay? Or

expectancy. A positive expectancy, plus

EV, is basically something that, if you

do it enough times, will produce a

winning outcome. Negative expectancy is,

if you do this enough times, it will

produce a losing outcome, okay? So, we

always want to be trading plus EV. And

if you are doing this trade forcing, you

are generally trading minus EV, or

negative expectancy. So, there's

something in trading that we need to

talk about as well, which kind of leads

you to believe that you're winning when

you're not actually. And that is

variance. See, you can do the right

thing for quite a while and you can

still lose money doing so. If you take

perfect trades, you follow your system,

that does not mean that every trade you

take is going to win. Doesn't mean that

you're going to have a winning week or a

winning month because the markets decide

our results. But you can also do the

wrong thing for a while and still win. I

mean, you can trade a very bad system,

no strategy at all, and just guess your

way into trades or gamble your way to a

profit today and it will win some days

and it will win some weeks and you might

even win for a couple of months, but

it's not a winning system long-term. So,

if we take a look at this negative EV

trading, so trading with an inverse edge

or no edge at all, you see that for a

while a lot of these traders are

actually in profit, but eventually

everything leads to the downside because

the edge just isn't there to

mathematically make money long-term.

This red line trader, for example, was

up towards the beginning. They got up

even more, actually up to 20% returns,

which looks very good, but in the end

they still come down below the starting

balance of the account because they're

trading with no edge and all of the

profits come down to luck. So, if we

look at plus EV trading with just a

small edge, you can see again on the

variance perspective, some of these

traders do go into drawdown. One of them

goes as low as 20%, but if we look at

the end of this test, all of them end

above the start balance because their

long-term strategy, the way they're

approaching the markets, is positive

expectancy, plus EV. So, it forces the

markets to pay them over the long term.

Now, if you have a solid strong edge,

this becomes a lot stronger, you have

less drawdowns and you have more returns

and a more clean run towards where you

want to be. Even when we incorporate the

variance factor, which essentially says

even if you do everything right, your

results may be better or worse than

someone else and there's not really much

you can do about that. We don't get to

decide our results, but we do get to

decide the inputs that create the

positive trends that we build, okay?

Now, this means to stop being outcome

focused and instead start focusing on

following plus EV systems. Sometimes you

have to take uncomfortable trades. You

have to hold trades past the point of

comfort. So, when you get into a trade

and it's running nicely and you're

scared and you want to get out, you have

to hold them to your targets because

this is what creates positive

expectancy. You have to let some wins

turn to dust if they haven't ran far

enough to warrant closing and they turn

around on you, then that is just the

nature of the game. Today's trade losing

or today's trade turning back into a

break even is not going to affect your

long-term performance, but closing every

trade early and cutting down the returns

that you can make absolutely will. So,

if you follow a plus EV system and you

put yourself through these difficulties

of making sure you're holding your

trades, letting some trades turn around

if that's what the market wants to do,

all of this, this difficulty, these hard

decisions will combine to create

long-term plus EV or positive

expectancy, which is how we make money,

okay? You're going to have some

stressful downswings, but you'll also

have some relaxing upswings. You're

going to have some hard trades, but

you'll also have some easy trades. And

it's all of this combined, following

that rigid approach and making those

hard decisions when they come up, that

actually makes you a profitable trader.

When you try to win today every day, you

can run good for a bit, but everything

will fall apart, okay? So, what you need

to do to eliminate your outcome focus is

focus on doing the right thing. Make

those hard decisions when they're there.

Don't rush to make money today every day

because this usually or pretty much

always ends in ruin in the end. So,

reason number three, emotional

shortcuts. This is an interesting one,

okay? Now, emotions are dangerous on

individual trades as we know, but

they're way worse across your broader

trading journey. And I know a lot of you

watching this are guilty of what I'm

about to explain. So, on an individual

trade, emotions can cause damage because

if you enter a trade and then you panic

exit too early because the market's

moving in your favor and you're scared

that it's going to turn around, you can

miss out on massive amounts of profits

and this is really where your edge is,

in everything above the point where you

early closed your trade out of fear.

Another way that emotions can affect

trades is of course hesitation. You see

a setup that's working, completely valid

to the way that you trade, but you're

kind of scared to take it because you

think it might lose. Maybe you're on a

losing streak, or maybe you just don't

have trust in the setup even though it

looks fine. Now, because you missed that

trade and you hesitated away from the

entry, you miss out on the whole move

and that whole move could be where your

edge lives. If you take a bunch of

losing trades, this could have been the

win that pushes you back into the green.

And if you miss it, well, now you're

just going to go deeper into the hole,

okay? And the most damaging way that

emotions can affect individual trades is

of course fear when it comes to stop

losses or should we call it hope? You

buy into a market, it starts moving

against you, but you have such

conviction the market's going to go up

and you don't want to accept the loss

that you take your stop loss off

thinking, "I'll just let it turn around.

It's definitely going to go up." Then it

doesn't, keeps going down, and your

entire account is destroyed before you

know it. So, these are the ways that

individual trades can be ruined by

emotion and that of course can spiral

into big problems. But, I would say when

it comes to emotions, emotional

shortcuts are the most dangerous and

damaging thing. So, the biggest danger

of emotions is when you shortcut

important steps in your journey in a

desperate pursuit of reaching your goals

as fast as possible. Such as, if you are

an unprofitable trader and you were

already buying funding challenges. I

know so many traders do this nowadays

because they have this thought that if I

just get funded, I'll be able to easily

make a few thousand dollars. But, if you

can't trade, no, you'll just lose it

all. Same with flipping accounts. You've

watched some YouTube videos of people

telling you when they they didn't really

that they flipped $100 into millions and

now you're trying to do that as well.

But, you're not profitable and all

you're doing is gambling every day and

hiding it under the mask of this

interesting trading journey. When

realistically you're just a gambling

addict. See, when your aspirations are

so high that you shortcut important

steps of the journey and you try and

force those goals out and your skill

sets are just not there to match the

aspirations and ambitions you've got,

then you lead into this spiral where you

just lose money for a very long time.

But the most damaging part of this is

not the money you lose, it's the time

that you lose as well. If you are

focused all in on a funding challenge

over and over again until you pass it

for 6 months or a year, instead of

learning how to trade, well, that is

valuable time that you're not going to

get back, okay? So, this is what the

real trading journey of a winner

generally looks like. You're going to

start out flat. You're probably going to

go negative for some time because

trading takes a while to get your head

around. But eventually, when you've

worked things out, you will move into

profits, into returns, and trading will

start to work for you. And trading is

usually exponential. So, when you get to

a point where you have your strategy

dialed in, that is when things really

start to, you know, fly upwards. But

most people don't want to wait through

this downward curve. They don't want to

give it the time. They don't like the

idea that they might not be successful

for another one, two, or three years.

And because of that, they want this to

happen. They want to try and force a

massive, you know, exponential run from

day one, which is why people go and flip

accounts. It's why people go and buy

funding challenges without being

profitable. They're just trying to force

success as fast as possible so they

don't have to wait through this. But

here's what actually happens. You

usually kick to the upside with, you

know, ambition and excitement thinking

you're going to nail this, and then very

quickly, things move against you, and

you just continue to move down. And as

we can see across this timeline, as long

as alongside losing money, you're

actually also losing valuable time,

which means by the time a sensible

trader is successful and exponentially

getting returns from the markets, you're

down here, massively below where you

started in terms of money, ability, and

confidence in yourself. So, you can burn

through your life savings doing this

very quickly, unfortunately. But that is

not even the worst part. The worst part

is that you waste the months or years,

you build a hatred or a disdain for

trading, and you ingrain the worst

habits possible that are then hard to

break free from. It's harder to win

after you've done this. It takes longer

to get out of these holes and it's more

mentally draining because trading has

beat you down so bad that you're no

longer really enjoying the time you're

spending trying to learn it. So, you can

escape this, but you need to do it now.

You need to stop chasing achievements

above your skill level, master the

foundations, and you will naturally

climb towards your goals, okay? We'll

talk more about how we can do this

later, but this is definitely something

you need to stop doing right now and

start focusing on a steadier journey.

So, reason number four is the desire to

be right. Loads of traders chase

perfection too much. They overestimate

the importance and the viability of

being right all the time, okay? So,

you're trying to get 100% marks in your

trading. Most traders will view a good

trade as a win. If a trade won, if it

made you money, that means it was good.

And a loss is by default just a bad

trade, okay? So, if you lost money

today, that means your trading was bad

and you suck as a trader. This is the

way people view things. So, if I made

money, I had a successful session. If I

lost money, I had an unsuccessful

session. It sounds logical, makes sense

on the surface, but it is absolutely the

furthest thing from the truth that you

can physically imagine. We're going to

liken this to a game of poker for a

moment because I like poker and it's a

good analogy, okay?

So, we'll break down why good trades are

not always winners and why bad trades

are not always losses, okay? So, in a

game of poker, 7-2, 7-deuce is known as

basically the worst hand that you can

get. And pocket 10, so two 10s would be

a good hand. Now, in general, the person

with the pocket 10, if these two people

went all in against each other, so they

both put all their chips in the middle,

the person with the pocket 10s has

around an eight out of 10 chance of

winning all the money. Whereas, the

person with 7-2 has only around a two in

10 chance of winning all the money. So,

going all in with 7-2 versus 10-10 is a

very bad idea. But, sometimes the board

will run out in a way that actually

makes that person win, right? So, those

two out of 10 times, the person with 7-2

will beat the good hand. That does not

make it a good play. You will lose

everything 80 out of 100 times by

playing this terrible hand in this

terrible way. So, even though it won

today, it does not make it a good hand.

This is the same in trading, right? A

bad hand that works this time is still a

bad hand. It doesn't matter if it made

you money. It's just like a bad trade.

If it works today, it's still a bad

trade because if you do it enough times,

you will lose everything that you've

got. Now, on the flip side of that, if

we look at people saying losses are bad,

the person here with 10 10, your

opponent, they made the right decision.

They got it in good and they should

realistically win and eight out of 10

times they will. But, they still lost.

Does that mean they should never do this

again? No, because 80 out of 100 times

this will work. So, even though it lost

today, it's still a good play. And we

can liken that to trading again. If you

took a trade that was systematically

proven through your testing to work and

it made you lose money today, that does

not mean it's a bad trade. So, losses

are not always bad and wins are not

always good. You can get in, you can get

the money in with the worst trade ever

and you can win. And that does not mean

that it's a good trade and it does not

mean it's something you should do again.

You can get all the money in with the

best trade ever and it can still lose.

But, that doesn't mean you should never

do that again. It means you should

continue to do that because over time

that is the profitable play, okay? So,

the desire to be right is kind of

ego-fueled and it drives people to think

that making money is good, losing money

is bad, but without really thinking

about what is causing the win or the

loss. What you need to do is stop

judging the quality of a trade off of

the dollar outcome today. Good trades

can lose and bad trades can win. You

need to stop worrying about being right

and feeding your ego and trying to win

70 or 80% of the trades you take and

focus on that expectancy, that plus EV

trading that we discussed earlier,

instead. Now, an extra point is you are

going to lose 40 to 50% of all of the

trades you take even if you're a really

good trader. That is just the fact of

the market. So, getting angry about

losses makes absolutely no sense at all.

Here's a quote from Peter Lynch which,

if you watch my videos for some time,

you've probably seen me repeat many

times over. And that is, in this game,

if you're good, you'll be right six

times out of 10, but you're never going

to be right nine times out of 10. Now,

this guy made ungodly sums of money in

the markets, and even he said this after

decades of trading and being one of the

most successful trader investors of all

time. If you have an anger at losses

over this, you're going to break your

discipline and dig yourselves into holes

when even the best traders in the world

know you're only going to be right

around half the time. So, if you are

trying to force yourself to win every

time, you're going against what some of

the most successful traders ever said,

okay? And here's another one from

Richard Dennis. You can be wrong more

than half the time and still make a

fortune. That means you can win four out

of 10 trades and still make a lot of

money. And of course, we do this by

risking $1 to make $2 or more on the

winning trades. And we're going to talk

more about this later on, as well, okay?

So, understand that being right does not

equate to making money. You can be right

or you can be rich. Trading is a numbers

game of balancing profit and loss

through probabilities, and you need to

focus on extracting a lot of money from

the wins you take, and not on how

frequently you win. You don't need to

worry about losses. You don't need to

try and force every trade to be a

winner. You don't need to be angry at

losing trades and happy at winning

trades. You just need to make sure you

are making the right decisions, and then

extracting as much money from the

markets as possible when trades go your

way. So, now, reason number five. And

this one, arguably the most important,

but everything else kind of comes into

this. And that is the lack of a good

system. Now, there's a few elements to

this that we need to discuss. First of

all is, you probably don't have a

profitable systematized way to trade,

which immediately means you're going to

lose. Or, this is the kicker, you do

have one, but it doesn't work for you.

So, let's start here with the broader

breakdown of systems, okay? To make

money in trading, you need to

consistently make positive EV actions,

right? You basically just need a way to

repeat the right decisions over and over

again enough times that it turns into

money. So, what most people do is they

collect a bunch of random concepts, that

over learning we discussed, they apply

them randomly into the markets and if

these three confluences stack up will

take trade and then they hope that

something works and most of the time it

doesn't. That is what stagnates you,

gets you moving sideways, you might have

some good weeks, some bad weeks, but you

never really make any meaningful

progress in your trading. See, if we

want to consistently apply positive EV

actions to break out of this and start

moving to the upside, we have to have a

process that can be repeated over and

over again, so that it prints that

positive expectancy over time. Now, the

best way we can do this is to build a

rules-based system. So, this is what my

general trading looks like and what it

is that I teach people to trade like so

that they can win as well. You analyze

the market, you see if your setup is

present, if it isn't, you don't take a

trade, if it is, you check if your entry

criteria is met, if it isn't, you don't

take a trade, but if it is, you check

additional consideration like economic

data or anything that may influence the

trade. And if all of that works out as

well, then you take an A+ trade. If it

doesn't and none of the conditions

align, then you simply do not take a

position. So, what we do here is we turn

trading from guesswork into a repeatable

system that we can just come to the

markets every day and apply and it will

print a good trade for us. It removes

guesswork, levels out the ups and downs,

ensures long-term reward and it actually

makes trading easy or as close to easy

as we can get because when we have that

system, our day just becomes rinse and

repeat. So, you need a system to win,

right? But some of you will be like,

well, I have a system, I learned a

system, I bought a course, I watched a

YouTube video, but here is the problem.

Not every system, even if it's

profitable, is actually going to work

for you and a lot of people don't think

about this point. But a good system,

realistically, in theory, should work

for anyone, but in reality, it doesn't

always work like that. There are a few

variables that can ruin things for you.

So, if you think about how systems are

built, right? A system generally works

for the person who designed it best. So,

if you've learned a rigid 9:00 a.m.

trading strategy, just do this at 9:00

a.m. This is built around someone else's

preferred trading style, someone else's

preferred trading hours, someone else's

preferred time frames, and someone

else's preferred assets. So, when you

run into one of those just do this at

9:00 a.m. systems, there's a few

problems. What if you're in a different

time zone? What if at that time of day

you're taking the kids to school, or

you're at work, or you simply just don't

want to trade at this time of day? Well,

if this is the case, schedule, your

lifestyle, and your trading preferences

don't align with theirs, you can't

reliably follow a system that doesn't

work for you, in your lifestyle

commitments, and trading hours. But,

there's an even bigger problem with

these kind of cookie-cutter just do this

systems. And that is the why behind the

actions that you're meant to take. And I

think this one will hit home for a lot

of people. So, when we see one of these

systems that tells us to just follow

this pattern at this time of day, the

question comes into our mind, but why

though? Why are we actually doing that?

If you don't fully understand why you're

taking trades with 100% conviction

behind the moves, you will hesitate, you

will miss trades, you will exit trades

early, and you will destroy the edge

that the system has, because you're too

worried or anxious or stressed to

actually take and hold the trades

long-term. Which makes complete sense,

because if you don't know why you're

taking the trades, well then how are you

going to confidently put your money on

the line for it? Well, the way that we

can fix this, which needs to be done, is

to develop a system that works for you.

So, we need to think deeper than just

the statistics of the system, and make

sure we're considering something that's

going to fit your lifestyle, the way you

want to trade, the time of day you're

available, whatever time zone you're in,

and all of these different factors that

kind of personalize trading, and make it

your system. Now, the thing that I'm

going to show you, we're going to go

very deep into this, is dynamic

narrative trading, which is basically

just a fancy name that I've given to the

style of trading that I've found to be

the best for myself and all of the

people that I've taught to trade, okay?

So, this is a way of repeating positive

EV actions that can be adapted to pretty

much any approach and any person. Now,

what if instead of deriving the plus EV

actions that we have to continually

repeat from random patterns or

formations that you learned on YouTube

where you're boxed into strict rules and

you don't really know why you're taking

the trades, we instead derive the plus

EV actions from a deep understanding of

the story that the market is telling

you? What if you learn to see the battle

between buyers and sellers and use that

information to make high conviction

informed decisions as to when to buy and

sell? That way you could eliminate

indicators, chaos, and arbitrary methods

and instead focus on clean charts

because when you look at a clean chart,

you know exactly what the market is

telling you. You know who's in control

and you can use that information to take

good trades. See, when I look at a

market, I don't see patterns and I don't

see signals. I see what is actually

going on behind the scenes. So, in a

market that looks like this, I will see

strong buying pressure moving the market

to the upside. And these tiny sideways

pullbacks that we get indicate that the

selling pressure here is incredibly

weak. What does this tell me? It tells

me there is more buying than selling at

willing levels taking place in this

market, which means price is increase

because people are willing to pay more

than they are willing to sell for. When

I look at a market like this, I take a

look at the lows breaking, the highs

holding, the size, direction, and speed

of the movements taking place and I can

determine who is in control of this

market and exactly what is happening

behind the candles. This gives me

maximum conviction to take trades in the

correct direction. And then I turn this

system into an if this, then that rules

base. And this is where we actually take

the deep understanding of the market and

turn it into a systematized approach.

So, as a broad example, if we take a

look at this chart, we can see the

market is shifting lower, sellers are

dominating this market. We definitely

want to look to sell this from the bias

that we collect by reading the market

story. Now, what we do to systematize

the market story is we set up scenarios.

We say if the market fails to close over

the highs and then it reverses through

the lows, then we will sell this

reversal towards our low target. But, if

the market breaks over the high, then it

will buy into supply. That will be where

we will look for opportunity. And then

if it reverses from the supply, then we

will sell it to the original target. So,

what I've done here is create scenarios

around whichever direction the market

goes, living inside of the bigger bias

that I've created. And then we just say

if the market doesn't do either of these

things, then we simply won't take a

trade. Now, this style of trading is

trade. Now, this style of trading is 110%

conviction trading because you have read

what the story of the market is. You

know who's in control, whether it's

buyers or sellers, and you know which

way the market should be heading based

on real logic instead of just patterns

and indicators and guesswork. Now, this

style of trading as well is not

something that you can just do on one

chart. You can take this exact same way

of thinking and you can apply it to any

market, any time frame, and any style of

trading without breaking the systematic

nature of it. Because you're not

memorizing patterns anymore, you're

actually reading the story that price is

telling. You're reading into the battle

between buying and selling, and that's

applicable in every market on every time

frame. Once you understand that story,

it doesn't matter whether you're on the

1-minute or the daily, whether you're

trading forex, indices, futures, stocks,

or anything else, the process remains

completely the same. Because at that

point you're not reacting to price

anymore, you're understanding price. You

know why a move is happening, you know

what would validate it, what would

invalidate it, and then you can execute

out of that. So, instead of guessing or

hoping or having those anxious hesitant

trades, you're making clear informed

decisions as to where the market's

likely to go and then setting up

predefined scenarios to execute in that

direction. Now, this system that I've

just explained to you exists. You go

through a deep reading of the market

story and you systematize it into a

repeatable flow. It's workable across

any time frames. You can swing trade or

day trade with it. You can trade any

asset you want, and it's all bundled

into a simple week-by-week process. Now,

it sounds pretty insane that this is

possible, but it is. And it's a system

that has helped people that I've taught

to reach payouts like those, okay? Now,

if we consider everything else we've

discussed today, the overlearning, the

outcome focus, the emotional shortcuts,

and the desire to be right, along with

the lack of a good system, all of these

things that have been keeping you stuck

can be fixed with one good system that

eliminates all of these problems and

systematizes your workflow into

something that works for you personally.

That style of trading should be dynamic

narrative trading. Now, this sounds like

some fancy buzzwords, but I'm going to

break down what this is today. Starting

with dynamic, this basically means it

can be applied to any asset, any time

frame, any time of day, and any trading

style without actually breaking the

systematic nature of this system.

Narrative means we are deriving our

opportunities from the story the market

is telling us instead of following

arbitrary patterns, indicators, and

cookie-cutter strategies. When we finish

this class, you will have a systematized

process that you can easily apply every

week that gives you maximum conviction

behind the trades that you take, and

that can be adapted to day trading,

swing trading, any session, any asset,

however you personally want to trade,

because that is an important element of

sticking with a system long term. We're

going to start with exactly how I found

this out and how I worked this out, and

it was actually through a book called

the Market Wizards.

This is basically interviews with some

of the greatest traders investors in

history. I've been losing a lot of money

in the markets, and I found this book,

and I hoped it would give me a strategy

or something I could do where I could

copy what they're doing and actually

then start making money. Well, I didn't

really get that, but what I did get was

something very simple and very

effective, and it actually changed the

way that I saw the markets entirely.

See, all of these different traders that

were interviewed that had made

significant sums of money, some of them

billions of dollars, were trading

different assets, different markets,

different time frames, and different

levels of capital, and they were

operating with different personalities

and preferences. But, they all had the

same foundation in place, and that was

all of them operated a repeatable

rules-based system. And you need one of

these. So, if we think about how money

is made in trading, it is simply made by

repeating plus EV, positive expected

actions, right? Which basically means if

you have a system with a 1:2 risk-reward

ratio or more, meaning you're risking $1

to make $2 on winning trades, you win

around 50% of the time. So, you're

essentially flipping a coin and winning

more on the winners. This is your edge,

right? When you have this edge, you

apply it over and over and over again.

So, you find out what it is that will

allow you to take these trades with

these outcomes, and then you just do

that, and you do nothing else. So, over

time, that will lead you into the

positive, and you can't choose your

exact performance results, but if you

follow the plus EV action system, you

will turn out with returns in the end,

okay? Now, if you don't have an edge,

everything is left up to luck. And you

can win for some period of time through

pure luck, but you're basically gambling

your entire future on this, and it's not

going to work for long. Eventually,

things will fall apart if you don't have

an edge in these markets. So, if you

want to achieve the plus EV, the

positive outcome, you need a way to

consistently repeat those plus EV

actions that make the winning trends

happen. And that is why we systematize

so that we can do the same thing over

and over again that we know long-term

will give us a positive result. So, to

do this, we are going to build out a

rules-based system. We want everything

to be systematized into a

start-to-finish flow. We analyze the

market, we see if a setup is present, if

it isn't, we don't trade, and if it is,

we check the next thing. That is entry

criteria. If that's not met, we don't

trade, but if it is, we check additional

considerations, anything else that may

influence the trade. If that's not met,

we don't trade, but if it is, then we

take a position. This automatically

filters all of our trades so that we

only take the best of the best. This

means we have the highest win rates, the

highest possibility of actually getting

to a successful trade outcome and the

highest rewards on the trades that we do

take. It will shift your trading into a

simple daily process which has no room

for guesswork and results in calm,

confident trading that actually gives

you results. Okay?

So, let's dive into narrative trading

first of all. So, I said with narrative

trading, we are actually deriving our

opportunities by reading the story the

market tells us. This is way better

than, for example, arbitrary systems

like support and resistance where the

idea is you should buy a support floor

once the market has traded over it. Now,

this can make you some money, but the

big problem with this is that you don't

really know why this is happening. Why

exactly should this invisible line that

you've drawn on the chart actually give

you a winning trade? What does it even

mean that this is taking place?

Likewise, with the cookie-cutter

systems, the systems that tell you just

do this at 9:00 a.m. Why though? What is

it exactly that's telling us that this

is going to lead into a winning trade?

Now, when we don't have confidence

behind the system we trade because it

doesn't really make sense to us or we

don't really understand the mechanics of

why the market is doing this, we can't

really trade this with confidence,

meaning we'll be stressed, anxious, and

hesitant in every trade you take. And

when you feel that way, you skip trades,

you close trades early, and you make bad

decisions which overall destroy your

edge. See, a standard trading system

when performed well should realistically

look something like this, right? We

don't have a linear drive up in trading.

We're going to have losing trades, we're

going to have winning trades. And your

performance may look like this. You take

a few losing trades, then you take a

nice big win, take a couple more losing

trades, and you take a nice big win.

When you understand your system, this is

easy to do. But when you don't fully

trust or understand the reason why

you're taking the trades, what you can

often do instead is take a few losses

and then hesitate because you're on a

losing streak and you don't trust the

system, you see a setup but you think

this one's just going to lose, so I'm

not going to take it. So, you miss the

win and then you take more losses. You

hesitate out the next win and you take

more losses and before you know it,

everything you've worked for up to this

point is completely gone. You failed

your funding challenge, you've lost all

of your account, nothing is working out,

and you're just digging yourself into a

hole because you're just too worried to

take the trades that can actually make

the system perform well long term. So,

what we need to do is break you out of

your beginner mentality of trading a

basic checklist strategy that you don't

really understand, following it blindly,

and then stressing every time you're in

a trade, and move you into a pro trader

mentality where you can read markets

deeper and clearer than you've ever seen

them before, and then confidently

systematize that into a process that

allows you to execute calm, consistent,

winning trades, okay? The narrative part

of this system is all about reading the

market story. So, that when a trade goes

against us, instead of thinking, "What

do I do now?" we are left understanding

exactly what the market has just told us

to do. And now we think, "Okay, yes,

that trade lost, but this has opened a

new opportunity because I fully

understand what the market is telling me

from the ups and the downs, the wins and

the losses that it's actually creating

for me." So, what you need to do first

of all to trade calm, confident, and

successful long term is build that level

of market understanding. So, let's start

with a question. When you open a chart,

what is it that you're actually looking

at? Now, a lot of people will say

they're looking at price, candles,

levels, and patterns, and sure these

things are present on the charts, but

they're not really what the market is

all about. See, when I look at a market,

I am always weighing the seller and

buyer control. So, markets go up and

down because of willing buyers and

willing sellers. If a market is moving

down, this means there are more people

here trying to sell this market than

there are people willing to buy. So, the

sellers have to drop the price to entice

the buyers to actually take up the other

side of that position, right? It's like

a big auction. Then, if we start to see

the sellers weaken, and we see the

buying coming back in, this simply means

that buyers have found interest in this

market, and they are buying. And those

sellers can now say, "I'll sell you the

asset, but I'm selling it you for a

higher price. This is what drives the

market to the upside. Now, when we see

things like this, where the market

breaks out of a high, but then it

reverses immediately with pretty strong

selling pressure, this is actually an

absorption point where the buying has

been totally taken over by the selling.

So, when the market reaches this high

level, buyers are exiting en masse, and

sellers are entering en masse, right?

These could be short sellers who were

looking to profit from a downward move.

And then, when this leads into a

seller-dominated market, I can see all

of this happening before it takes place.

And now, I can even use this as more

information to take continued trades.

Because what I'm doing is I'm reading

that battle between buying and selling.

I know who is in control of the market,

and I know where the core points are

that the market is likely to reverse or

continue with strength, okay? So, all

you are looking at when you see a

downward-moving market is that there is

a volume of selling larger than the

volume of buying. And now, let me

explain this just real quick, because

this confuses people. Obviously, to take

a trade, there has to be a buyer and a

seller on either side of the position.

You can't buy if there's no one to sell

to you. So, it's not that the volume of

buyers is larger than the volume of

sellers in a market that's moving up.

What it is is a volume of buyers willing

to pay higher prices, okay? So, if a

seller in this seller-dominated market

wants to sell their asset, but the

buyers are not willing to pay this

higher price, then there are less

willing buyers than there are willing

sellers. The sellers therefore have to

drop the price to actually match a price

that buyers will be happy to pay, okay?

That is how it works. So, it's about a

volume of willing sellers in this market

is larger than a volume of willing

buyers at these specific prices. And as

prices do decline, then we will have

more willing buyers stepping in, and

that is why after large downward moves,

we see these larger reversals, because

people say, "Okay, this price is pretty

good now. I think I will buy." And then,

sellers stop wanting to sell, or there's

less sellers left to sell. So, they will

start saying, "I'll sell it you, but I'm

selling it you for a higher price,

right?" That is the kind of auction

theory that the market runs off. That is

what you need to understand to really

read these markets deep. So, when it

comes to narrative, a narrative is a

structured reading of what the chart is

telling you, who is currently in

control, what would confirm that, and

what would change that. When you trade

in a narrative-based way, you actually

create an opportunity, and then multiple

other opportunities can stem off of that

opportunity. So, rather than marrying

one bias and saying, "This is my trade,

and this will work." You basically build

a picture as to what the market looks

like it can potentially do. You work out

who's in control, which way the market's

going, and where those points of

interest are, and then you stem multiple

opportunities out of one narrative,

which is what makes it so powerful. So,

really quick now, let's jump to the

chart, and I'll show you kind of how we

read the story between buying and

selling in a market. Okay, so how this

narrative trading works then is what

we're doing when we're looking at charts

is we're trying to determine overall

who's in control of the market, and

where is that story likely to lead us.

So, if we look at this USD/JPY weekly

chart, we can determine just by looking

at this weekly that the most recent move

we've had is an aggressive impulse to

the upside from this low.

We then had a stalled out so far

pullback, but no break of any meaningful

lows here. And now we're driving back up

with strong momentum again.

So, if we consider basically the battle

between buying and selling, we can see

that every time we've reached this

level, we've seen aggressive attacks

from buyers.

Now, this second one wasn't as strong as

the initial one. However, this third

drive we've had is actually pushing us

through these highs towards basically

the open area, which would target this

next high.

So, if we think about what that is

actually telling us, and what this is

behind the scenes of just patterns in

the market, we basically see buying has

been incredibly strong on the US dollar

versus the Japanese yen, okay? For

whatever reason, there are macro reasons

for this, but we're going to keep it

technical focused here. And every time

we've attempted to come lower again,

even after this aggressive sell-off,

we've continually pushed back up. Now,

what this is is basically buying is

willingly taking place at higher prices

consistently throughout this upward

move. Then, for whatever reason, we had

this dramatic selling move. However, the

failure to get back under this low, and

considering this is an uptrend overall,

right? The failure to get back through

the low here shows that buying is still

stronger than selling in this market.

Because if selling was indeed strong

enough, we would have seen the market

push through the lows that have

previously been set as a floor by the

buyers, right? We would have seen less

people willing to buy at these prices,

selling continue, all of these buyers

that bought previously selling in, short

sellers selling in. And basically, we

would have seen that close lower and

then likely lead into further downward

prices. However, what we've actually

seen is every time we've reached this

level, this has been a kind of floor

that buyers have set in place. And this

price range around 140 is essentially a

price point that buyers are very happy

to snap up massive amounts of these

contracts at. So, every time we reach

140, we see a massive new influx of

buying and buyers willing to buy at

higher prices back in towards the highs

of the range, right? So, from a

buying-selling perspective, we are

basically told by the presence of this

low that we've just mapped in around

140, that buying is very happy to take

place above the 140 level. And buyers

and general market participants

basically see 140 as a viable floor for

this market that really the market

shouldn't trade beneath. So, that's step

one. Now, the next thing is, of course,

momentum. We can see these upward

movements are very strong. Now, this

initial selling movement is very weak,

but that is supported by what we just

explained as that psychological 140

floor, price floor that people don't

want to see the market go through there

cuz every time we get there, we snap up

buys. Now, this impulse to the upside is

very strong. How do we know that? Well,

the size of the candles and the speed

that we completed this movement in,

okay? When we had the pull back, if we

take a look at the candles on the

downside, these are smaller bearish

candles than the ones that drove us up.

We also see from the wicks that we're

continually attempting to go back higher

throughout the downward move. And here,

where we have this kind of chop, this is

basically buyers pushing back. So, we

still see, even in the downward move

that we have willing buyers coming in.

Now, when we reach the low, what does

this tell us? Well, the fact that we

closed higher here than we did

previously shows that there is more

buying pressure, buying intent coming in

at this point than there was here and

that there was here. And this wick tells

us that this is again that solid floor.

Every time we get lower, the market is

driven higher by significant buying. If

we then lead into the buying move, sure

it started out weak. However, we pretty

rapidly progressed in this move. And

this quick movement and basically the

failure to get any lower from the

sellers indicates to us that buying is

alive and well in this market and that

is what's leading us into where we are

is what's leading us into where we are now.

So, if we take a look at the current

position of price, this is actually

taken out a previous high only with a

wick at the moment. However, just in

taking out this high, so with this price

move here, this indicates that buying

now is stronger than buying was in the

previous attempt to go higher. So, we've

actually driven through a high, which

shows more willingness from buyers to

buy at higher prices than previously.

Then take it to where we are right now,

we had a pullback, which was a pretty

dramatic one. However, even more

interestingly, is over the past 3 weeks

into this analysis, this bearish candle

has been completely taken out with this

slow progressive bullish price action,

which this progressive price action has

no bearish pullbacks in it, right? It's

one clean drive from there to where we

are right now.

Again, with this breaking through the

high, indicating buyers here were

willing to take it higher than

previously, we're getting a sign of

strength again. So, it's all about

reading the story of what the buyers and

sellers are telling us in the print of

the candles, okay? So if I were to look

at this market, I would presume the most

likely outcome will be a continuation on

the buy side towards the high because

we're moving in an already bullish

manner and we [snorts] are showing that

the buyers are continually basically

outpacing the sellers. We have buying

setting a very clean floor, very

aggressive rejections when we get to

that floor again, and then clean buying

taking place right now breaking us

through previous highs showing more

willing buying taking place at higher

levels. So if we take a look at this on

the daily, we can see again very similar

kind of movement, right? We have this

strong upward move. It's a little bit

slow, but this is that weekly movement

that was going on for a very long time.

Then we have a very aggressive sell-off

which generally this will be a bearish

sign and will tell us that sellers are

stepping into this market in massive

force. However, as soon as we had that

selling move, we printed at low around

151. Then the market had a very

aggressive drive back up and when we

attempted to go lower again, we actually

failed. We closed higher. The wick

didn't even push through the low which

indicates that sellers here are not as

strong or willing as sellers were here.

So when we see this aggressive price

action again, which once again drives us

through a high showing more willing

buyers at higher prices this is an

indication that this market is likely to

continue trading bullish. So how do we

turn this into opportunities? Well, if

we think this market's going to keep

going up, we can look at the high near

term and then what we can do is just map

out areas for this market to actually

buy from. Now I would look at these

points initially and we can go down

lower to say the 4-hour time frame to

really refine an idea, okay? So we have

now basically in mind that the market is

indeed bullish and we're being told that

by the market participants themselves by

the way the candles are printed, right?

This was our very low point after a

dramatic sell-off. We managed to pull

back significant way and then which what

would have proved us bearish, which

would have been a closure under this

low, failed. We created a higher low.

Now, in terms of structure, not entirely

valid higher low, but in terms of the

actual market participation, a low

higher than the previous one, indicating

that sellers are weak, buyers are

strong, and then we drive up through the

high, further backing that idea. So, if

we zoom in on the 4-hour perspective,

that's just going to be a simple trend

like this, and what we can look to do is

just join this movement up, right? So,

from a trend perspective here, we would

look at the highs and the lows that have

been printed. We have a high,

and then this high breaks through at

this point to print a new high. Our

pullback on this movement is around this

low, this low. That's going to be our

low. The fact that the low here is

higher than the low here, again, tells

us that buyers are trending to the

upside over sellers, which means more

buying pressure than selling pressure.

And then, in theory, the market

shouldn't, if it does remain strong,

shouldn't go under this level. So, it

should basically remain above this low.

Which, what would that do? That would

validate buying strength because that

would say, "Okay, the buyers clearly

have a basically root of control here,

and if they hold that, buying above this

level makes absolute sense." And if we

get under that level, then that could be

a sign of shift into seller control,

which could mean we trade lower, right?

So, what we're doing is we're not just

looking at patterns, we're reading what

are the market participants telling us

through the candles. Now, a trade that I

took was simply this area of demand

here. We had what I classify as like

equal low liquidity. So, basically what

looks like a support floor in the

market. We know there's going to be lots

of orders under here. Again, this drives

back to that market psychology. So, if

you've been buying at this level or at

this level, and you're a basic retail

trader, you're going to have stop-losses

under the low. Now, because there's lots

of stop-losses under the low, there is a

significant amount of orders here that

the market can take the other side of

essentially. So, if we're able to drive

into that big collection of orders

towards this kind of core point, this

demand zone. We know there's going to be

lots of buy orders waiting here. If we

think about what the stop losses are for

buy trades, they are sell trades, okay?

So, we get lots of sells triggered here,

they can be absorbed into buys, and then

even more buying pressure in the form of

this demand. Basically, these being

prime points for massive buying

absorption to take place. Pair that up

with the fact we've already built our

bias narrative to be bullish, and we can

see this is a very simple trade to be

taken, okay? So, now, if we run that

forward, you can see that is exactly

what happens and how the market plays

out. It came back down, traded into this

zone, and then ended up rallying to the

upside. And again, another trade I took,

and I'll post these up in just a moment,

was actually from this demand. So, you

see the same exact pattern occurred. We

created a demand zone, which had some

slight imbalances into it, one, two, so

equal low liquidity. We came back down,

traded into that area where buyers

typically absorb orders, and then

continued moving, and we did this

because we built that big picture

context, all right? Now, for some

traders, they may see this shift here as

a break of structure and start looking

to sell the market. But if you've got

the big picture context, if you

understand who's in control of this

market, selling there makes no sense,

and you should be following the buy side

ideas that I've just explained to you.

And and that's pretty much how I find

them, right? It's contextual narrative

building around the market. It's reading

into the speed and the size of candles,

but not just in isolation, but in terms

of the larger movements and the

pullbacks we see, the highs lows

holding. All of this gives us

information as to who is in control of

the market. A movement like this, very

strong upside, slow choppy downside,

very strong upside, slow choppy

downside. This tells us weak selling

pressure in these points, and strong

buying pressure in the impulsive moves.

When that is taking place, we know

buying is taking place more willingly in

large volumes than selling is. So,

therefore, we should look to join the

buyers and continue until they lose

control of the market, okay? So, that is

a general overview of how we do this

narrative-based trading and how I read

markets myself. Contextual, it's

top-down, and it's all about reading the

story of the market. And as you can see,

those two trades followed through over

that one week of price action, you get a

couple trades there, which runs you

higher into the targets and further

validates that bull idea. Cool, so

that's it. We're going to draw back to

this in full detail in a moment, but

let's jump back to the slides for a

moment. So, to trade with confidence, we

want to answer four questions from our

analysis. Number one, who is currently

in control of the market? Number two,

what confirms this expectation? Number

three, what would invalidate this idea?

And then number four, where do the

trades come from as a result of all of

this? Now, the problem most traders have

is they skip all three of the first

steps, and they immediately just look

for where are the trades, okay? You jump

to the markets and you're just fishing

for any opportunity you can find without

building bias or context or an

understanding of what it is that the

market is doing right now. So, you need

to build bias before you execute. Now,

if you've ever been on a low time frame

chart, and you probably do this quite

frequently, like the 5-minute, the

15-minute, or really any chart actually

without bigger picture context, you

might be left completely confused. You

look for any opportunity for supply

zones, demand zones, whatever it is you

trade. You buy and sell them all. None

of it works, and you lose loads of money

at the end of the day or week. The

reason for this is that charts at these

time frames, or realistically any chart

without a big picture context behind it,

they lack major context, right? You're

not seeing the big picture, you're not

seeing what's actually going on. You're

seeing short-term speculative moves.

You're trying to trade that, and that is

where you get whipsawed around and

killed back and forth on buy trades and

sell trades. Now, when you bring in a

big picture context and you read the

narrative in the way that we've just

explained there, you know what to

ignore, and you know where the real

selling and buying points will be. So,

you can stop focusing on short-term tiny

movements. So, you can stop focusing on

tiny insignificant moves, and you can

stop focusing on the real buying and

selling points in the market, fully

understanding where those points are.

So, the shift that you need to make, the

shift that I have made and thousands of

my students have made, which actually

got them profitable, is to stop looking

for a trade. What you're doing is you're

looking for the narrative, and then you

wait for the market to say go. The

market will tell you when to take

positions, okay? So, instead of trying

to predict the market and fish for

trades, we just want to map out the

possible outcomes based on the bias and

context we build, and then build

predefined scenarios for how we will

approach each outcome. All right, that

if this, then that format that we

discussed in the last class. So, if I

was to see this market, and we have some

open imbalance and a demand zone below,

but we can see at the moment that

sellers are clearly in control of this

market, I would say if the market

returns, there's only really two things

that can happen. The market can pull

back and then sell down towards that

level, or the market can trade up and

break through that level. Now, it could

also go straight to the target, and that

would just mean there's no trade, but

these are the two predefined scenarios

that would actually give us an

opportunity, right? Then what we would

do is simply say if the market reverses

inside of this range and confirm shorts,

I will then sell down towards the target

I've got. And if that fails, and the

market trades above, then we can look

for reaccumulation and buy through the

larger imbalance to the upside to the

next supply, where maybe the market will

sell from just then. So, we're actually

prepped on both sides of the market, and

what we're doing is executing predefined

scenarios instead of reacting to any

tiny candle that happens in real time.

We're just executing decisions that

we've already made. Now, the powerful

thing about this is when you move over

to the markets and you're staring at a

chart and you're trying to fish your

ideas out, instead of thinking what

should I do right now, what we're doing

instead is thinking what are the only

things that can happen, and what is my

plan for each of those things, okay? It

means you can hit the market both sides,

and you don't have to stress or guess at

trades. You just follow that if this,

then that flow, and if not, if it

doesn't validate, then you don't take

any action. This is how you can catch

the market both ways instead of being

married to a bias through multiple

losses when things don't go your way.

All right, what we're going to do now is

go through a trade that I took in March

on GBP/USD. And what I want you to do is

kind of detach your mentality from the

way that we'd usually view charts, where

you're looking at patterns and trying to

kind of formulate ideas without thinking

about context, and listen to how I

explain the way that I see charts and

what it is that I'm actually looking at,

okay? Cuz this will be a big step in

your understanding of the markets and

therefore your systems and performance.

So, we're going to start on the weekly.

I always start top-down of the with my

personal trading because if I'm on the

weekly time frame, I can get a general

broad idea as to where the market is,

what the directional bias is telling me,

and likely a range that we could trade

within, okay? So, by taking a look at

this weekly time frame, we see this is

obviously quite an impulsive bullish

market up to this point. This tells us

buyers were clearly in control. When we

reached this point here, we started to

see that buyer control soften. We had

sellers coming in, and we've kind of

failed and struggled to get back up

again uh in terms of significant buying.

Now, one of the most significant things

here is, if we take a look at this high,

we had an impulse up to this point, and

then in this week, a significant

reversal from sellers which drove us all

the way back down here. Now, this is a

really strong potential reversal sign

because if we think about what this is

telling us behind the candles, right? We

saw that buyer strength soften at this

level and has basically pushed the

market into this range. But this

rejection shows again very clear control

from sellers coming in. When we kind of

reached that uh we could call it a price

ceiling that has been set by sellers.

So, buyers are just not so happy to

willingly buy massive quantities up

here, and sellers, of course, are very

happy to sell because this is a premium

price. So, if you're selling or

offloading contracts that you bought,

this is the most profitable point to do

that. So, you sell it when it gets back

through the highs. If you're short

selling the market to profit from a

decline, this is obviously a very

profitable point to do that, too,

because we're so high up that now, if

the market does reverse lower, you're

getting a significantly better entry up

here to profit from the decline than you

would be if you sold anywhere in around

these levels. So, this is basically a

core point for sellers to start entering

the market in force, and we see that

because after the big rejection, we see

continued seller domination. So, when

buyers see this rejection, they are now

no longer too happy to start buying in

numbers. Buyers want clean impulsive

moves like these, right? If we see a

rejection like this coming from a high,

this can easily be a point where the

market starts to reverse. So, we saw

buying soften and selling kind of

strengthen up in and around this range.

And then that was somewhat confirmed as

we pushed through the high and then

reversed immediately into a phase of

seller domination. Now, I want to draw

your attention to this low. So, this

point just here. Now, this is not a

massive important structural low, but it

is an internal low within this leg of

price. And if we consider what the break

of this, which has taken place now, is

telling us, it's basically telling us

that buying, okay, here is weaker than

buying was here because buying was

strong enough to drive us to an

impulsive high, and it wasn't strong

enough right now to actually hold the

low that was created by that impulse.

So, by pushing through this low, we're

basically getting further indication

that sellers might be weak, and this

market might be likely to lead lower.

So, if we factor everything that we've

put together so far,

we have softening buyer control coming

in quite a while ago, actually, in June

2025. We've then really ranged and not

managed to push significantly higher for

almost a year. And then when we did

manage to get higher, it was immediately

reversed by sellers with a massive wave

of selling pressure completely

dominating the buying moves, absorbing

the buys, and driving back lower. This

then led into a break of an internal

low, which again just indicates to us

that sellers now are stronger than they

were previously, and buyers now are

weaker than they were previously. So,

we're getting a good idea that sellers

are likely in control of this market.

Now, with that in mind, we can take a

look at the daily and start to assess

exactly what's going on from a daily

perspective, okay? So, what we can see

immediately is that huge bullish impulse

that we had has been taken out, and this

is what that wick was on the weekly

timeframe. We see a big rejection, which

is driving the market back down, and

again pushing us through this low. Now,

an interesting point is that we haven't

closed through the low yet, which could

say that maybe we end up rejecting and

going higher. So, that's definitely

something we can keep in mind. Now, in

order for that case to take place, we

would realistically need to see a high

break, and that for me would be this

high, because this current downtrend

that's taking place on the 4-hour or the

daily, sorry, is being capped by the

high. Now, in markets, when lows break,

that indicates seller control, and when

highs are maintained, that indicates

again another level of seller control,

because buyers are not strong enough to

get through previous highs, right? Means

basically there are more people trying

to sell assets and willing to sell

assets at these prices than there are

people willing to buy at higher prices.

If we saw the high break, that would

tell us that buyers are actually

starting to get interested in buying

this asset, even for higher prices. So,

therefore, we could shift into

possibility of buys. But, as it stands

right now,

the sellers are maintaining the

strength, and the buyers are maintaining

weakness. So, we would say the market

remains bearish, providing it stays

underneath this high. Now, another

important thing to assess is these

wicks, because as we know, wicks do

indicate rejections, which shows there

is at least some buying pressure coming

in from these lows. We have to then ask,

"Where is this coming from?" If we take

a look over to the left, we can see that

there is a demand zone down here. Now,

what is a demand zone? It's basically a

range before an impulsive move, okay? Uh

a buying move for the case of demand.

Supply is the opposite, so it's before

an impulsive downward move. And what

supply and demand shows is, in the case

of a demand zone, an area that buyers

were willing to buy the asset or a price

level that will it uh buyers were

willing to pay for an asset previously.

Therefore, we know this is seen as a

discount price. Buyers then, if this

level is met, will likely want to take

another stab at buying this market,

okay? So, that's what a demand zone is

all about. A supply zone is basically

the opposite. If we look at this zone

here, it's consolidation before a

downward move. Generally, a supply zone

is sellers were happy to sell here

before, happy enough for this to

actually break structure, which tells us

that this is seen as a premium price for

sellers. They like this zone to sell

from because again, you're getting in a

good price if you're selling your

contract and you're getting a good entry

if you're short selling for a profit on

a decline. So, that's a premium price.

So, we can expect that if we get into

that range again, sellers therefore will

be interested in selling down. So, it's

all just about identifying where

previous significant buying and selling

took place from and then using that as

an understanding that this is probably a

point of interest if we get there again,

we're pretty likely to start seeing the

same things happening, okay? If buyers

were happy at that price before, they

probably will be again. If sellers are

happy at this price before, they

probably will be again, right? So,

anyway, how that actually has relevance

here is these wicks, these rejections we

see, yes, it is some buying pressure.

No, it is not enough to start buying

because we would need to see a high

break and then a low maintain to

actually validate buying, right? So,

buying would come in on a pattern like

this. At the moment, it remains bearish

and although the buying pressure is

coming in, it's actually not really

coming in from anywhere significant.

It's coming in from what we call an

imbalance. Now, an imbalance is

basically the gap between a demand zone

and then wherever the next kind of point

was or where price is now. So, this area

that I've just marked here, this open

price range, this is an imbalance. And

the way that I see imbalances is

basically it's an area where no

significant buying or selling is likely

to take place because the premium and

discount price levels are above and

below these imbalance points, right? So,

what I see imbalances as basically a

magnet for price to draw through and

completely fill before retesting a

demand or supply zone and that is where

the real solid trades come in from.

So, what we can expect at this point

basically is for that imbalance to be be

because we know that buyers will come in

in force at some point. Well, if they

do, it's likely going to be from a

discounted price level or a demand zone.

So, we can say this is reasonably likely

providing and considering that we

maintain this downward trend where we

maintain highs and break lows, okay? So,

we have from the weekly the idea of

potential seller domination reversal,

big weekly rejection, big drive lower,

sellers are currently in control of this

market. From the daily, we see a

continuation of that in a tighter format

where we see the lows breaking and highs

maintaining, which again gives us an

idea that sellers are in control of this

market and providing we stay under this

high, we should look to sell. We see the

buying pressure rejections, which is

some cause for concern for the sell

bias, but when we line up where that's

coming from, imbalance, it's really not

a significant point that's likely to

attract too much attention for buyers.

What's more likely is we will at least

get to a discount price level. So, if we

get down into there, then we can worry

about the market potentially reversing,

but until then, we should realistically

remain on the sell side, okay? So, what

we're doing is we're reading that story

endlessly and just working out who is

currently in control of the market.

Okay, so dropping to the 4-hour. 4-hour

and below is generally where I start to

find opportunities and as I've

explained, we can do this on the weekly,

we can do this on the 4-hour, we can do

this on the 5-minute. The narratives,

because they are following the real

story of price, they work everywhere,

okay? It doesn't matter if you're on the

1-minute, it doesn't matter if you're on

the hourly. These setups all work in the

same way because the way we're reading

the market is just reading into them

the market is just reading into them basically

uh the psycho- logy of buyers and

sellers and the patterns, the the phases

they go through, right? So, what I'm

going to do

on the 4-hour, first thing I want to do

is of course, we have a marked in high.

We know the market's not likely to get

past that and if it does, that would

open up one of our if this then that

alternative opportunities. We would say

if the market gets over this high, then

it's probably bullish because we're

seeing a pushback from buyers, so we can

buy, okay? So, that's the if this then

that alternative buy situation. But

unless that happens, our focus is going

to be on selling this market down

towards this area of demand. So that

would be basically the basis for the the

primary trade that I would look for. And

what we have here is a selection of

things. Number one, the supply zone. We

know this was seen as a premium price to

sell this price at before. Therefore,

it's likely to be seen as a premium

price again. Number two, imbalance.

Again, this one has a gap. This gap is

likely to be filled. That will draw us

into the area of supply. And then

basically the supply zone being the

premium could be the point where we

start to see a shift from the sellers

regaining control over this short-term

bullish move and drive us back down

towards the low. So we have here

maintained downward price action, a

premium price zone that's likely to be a

good catalyst for sellers. And then we

have our downward targets basically

pushing us into this low. So

targets-wise, we can look at this low

here. And we can look at the demand zone

beneath as that's going to be kind of

the next magnet point for price. Now we

can also see the market is pushing

through one of these internal range

highs. This is what we classify as

liquidity. So this is kind of a key

point where basically anyone who's sold

from this level below trading with, you

know, standard rules is going to have a

stop loss somewhere in this range or a

lot of those people are. These stop

losses for sell trades are buy trades

because if you think about what it is,

if you are in a short position and you

have a stop loss on, you basically have

sold the contracts and if your stop loss

is hit, you're buying them back for more

than you sold them for, which means you

take a loss, right? So it means there's

loads of buy orders in here. Now buy

orders can actually be really good

catalyst for sell positions at certain

points because if we see an influx of

selling coming in at the point where

there is a massive quantity of buy

orders being hit at the same time, we

can see basically a lot of selling

taking place because someone can take

the other side of all those buy trades.

That's what we call absorption where all

of the buying orders are immediately

absorbed by selling. If we factor how

that is currently lining up, we have

this potential absorption point where

all the liquidity is. We have a premium

price zone where we know sellers want to

sell from and we have seller control

over all with maintained highs and

broken lows. So basically we've got a

very good case for selling, right? Now

we shift that into the if this then that

format and all we're going to do is say

format and all we're going to do is say if

this market trades into supply and then

confirms short like this with a shift in

structure, then I will sell. That is if

this then that scenario number one.

Scenario number two from this point

would simply be if the market gets over

the high here, then that shows a shift

in control. Therefore I will look to

confirm and then buy, okay? So that's

the alternate scenario and every one of

my trades has one of these because as

one trade invalidates, a new opportunity

generally will validate, right? So if

this sell doesn't work and it does drive

higher, then that's going to tell us

that buyers are stronger than we thought

and maybe there's some room for us to

then trade up towards some next points

of supply for example. But as it stands

right now, what we would just want to do

is look for that opportunity that we

just prepped out. So we're looking for

the market to come into this range and

then give us a change in the overall

direction, okay? So we've seen the

market drive up there. Realistically

what we'd want to see now would be the

market coming and closing under this

low, okay? Here we see rejections,

rejections, large bearish movement

coming in. Then we get closures beneath

which tells us that sellers are now once

again taking control over the short

term. So highs, okay? Highs maintaining,

uh well, highs being created, lows

maintaining, that's buyer control and

then a low being created and failing,

that is seller indication or reversal

indication. Now what we would look for

is simply the best point to actually

sell from which again is going to be a

supply zone. Why? Because this is a

premium price zone that has created an

impulsive move before. It's likely then

that if the market gets into there,

we're going to see new sellers see this

as a premium price to sell from. So our

trade becomes this and then all we have

to do is place an order like that, put

our stop over the high, targets down

into the low, and then you've We've a

narrative based trade. And we've built

this out of basically assessing who's in

control of the market at this point,

which way that leads, and then what the

entry criteria would need to be in order

to formulate a trade. So, what we do is

we build the idea, and then we just let

the market come to us with the

opportunity, right? We're not forcing

anything. We're just saying, "This is

the most likely thing to happen next.

Therefore, if this does happen, I will

take this position." And as you can see,

it results in some pretty high accuracy

trades. So, that's basically the full

flow. But that's how this narrative

trading works. Build out a full reading

of the market, the battle between buyers

and sellers, the volume of buying, the

volume of selling, and which direction

points of interest that is likely

leading the market into, and then just

set up your entry criteria. If this

happens, it's telling me that I should

sell. If this happens, it's telling me I

should buy. And then just do nothing

until one of those two things happens,

and then you get A+ positions like this.

So, that is the flow of narrative based

trading in a systematic way. All right,

so now let's bring this all together.

What we're doing is we're taking an

understanding of the market, and we are

shifting that into a system that you can

run every day. The process goes as

follows. First, you want to build out

your narrative. This is the top-down

flow that we've covered, creating clear

answers to who's in control, what

confirms that direction, and what would

change it. This is the foundation to the

opportunities that you were going to

trade. Then we move on to trade

execution. Form trades and execute them

from your narratives by preparing all of

the outcomes in advance, setting up the

bullish and bearish trade criteria, and

then executing from predefined

conditions. Shifting your trading from

what should I do into which outcome is

playing out. Then, of course, we want to

systematize it. So, we follow the same

flow, same concept, same logic every

time. We build the top-down narrative,

develop a clear bias, build out the

alternative scenarios, so if the market

goes against us, we can still find

positions, and then define our execution

criteria in advance so that we can can

trade in that plain simple if this, then

that format. Every trade that you take

in this system is a result of a process

that you've already followed. And the

real magic behind this approach, of

course, is that it is not tied to a

specific market, it's not tied to a

specific time frame, and it's not tied

to any specific schedule. Because your

trades are formed by reading the markets

deeper and clearer than you've ever seen

them before, you can do this on any time

frame. The same behaviors, same

speculation, the same battles, they're

all taking place everywhere. Doesn't

matter if you want to trade EUR/USD,

gold, oil, master, or Bitcoin on the

1-minute, 15-minute, hourly, 4-hour, or

daily, as a scalper, a day trader, a

swing trader, or a position trader, it

really doesn't matter. Because what

we're doing is reading basically the

market psychology, the buying, the

selling, who is in control, what they're

thinking at each different point, and

how that leads into different

opportunities. This is basically

translatable to any asset, any time

frame, because it's the real dynamic or

mechanics of how the market actually

moves, and what it is that drives price

appreciation and depreciation. So, this

means this system is not someone else's

signals, it's not built around someone

else's schedule, and it's not someone

else's way of trading. It is just

reading the real market drivers and then

taking your trades around that on

whatever preferences you want. So, you

can day trade it, you can swing trade

it, you can trade what you want. It's

very, very freeing while remaining

systematized. It allows you to shape

your trading around your life instead of

shaping your life to fit trading, which

realistically, we're all trading for

freedom, right? So, you don't want to

box yourself into a system and a

schedule that you don't like and you

don't want to follow. That's not very

freeing at all. If you're going to do

that, you might as well get a job. Now,

in order to succeed at trading, you

don't need finance degrees, loads of

experience, a special personality, or

tons of starting capital. You just need

a clear process executed in the right

order. And this is what most people

miss. See, the way that most traders

operate is they find a scrap of

information in a YouTube video or a

course, they try to make it work, get

confused and hopeless, lose some money,

give up, and then start the cycle again.

And people stay trapped here for months,

sometimes years, and most of the time

until they just give up on trading one

day, however far in the future that may

be. Now, we need to break you out of

this cycle, so I'm going to give you a

four-stage journey that you can follow,

which is going to take you from wherever

you are right now, whether that's a

break-even trader, a very small winner,

or completely down in the hole, and

bring you out of that towards funding,

payouts, and everything that it is

you're trying to achieve from trading.

So, step number one is to learn to

deeply read price and build narratives

around what the market is telling you.

We want to shift our trading from just

being able to see things on the chart to

actually being able to understand what

it is that the market is telling you.

Because you can read supply and demand

zones, or you can see them on the chart,

without actually knowing whether they're

relevant or important zones to be

trading from. And you can see momentum

for what it is without really

understanding whether these are

impulsive or corrective movements, and

whether they're relevant to trade off at

all. You need to be able to sit down

with a chart that you've never seen

before, work from the weekly down,

reading the battle between buyers and

sellers, and form a structured narrative

from this information. You want to

answer these questions from your

analysis. Who is in control of the

market right now? Is it the buyers or is

it the sellers? What is driving the

move? And where are the points of

interest that you could potentially buy

or sell from to actually formulate your

ideas. If you can build narratives

correctly, and you read the story in the

way that we explained how to in the last

then this will all become very simple,

and reading the markets will be clearer

than it's ever been before for you. Then

we want to be able to synthesize this

information into a story, determining

what the story of the market is right

now, and where that will lead in terms

of biases, directions, and where the

executions will be. Now, this skill of

learning to read markets deeply is more

important than anything else right now.

It's the one thing you need to master

because everything else will fall into

place when you can see the markets

clearer than ever before. Now, this is a

learnable skill, okay? It's not

intuition. Anyone can learn how to do

this, and when you do, you will never

see the markets the same again. Instead

of looking like a chaotic mass that you

endlessly burn money in, markets will

become a coherent story that

consistently print positive outcomes for

you. When you've done that, it's time to

move on to step two, which is where you

want to build this narrative edge into a

rules-based system. So, when you're

confident with your abilities to read

the narratives of the market, you want

to shift that into a process that will

consistently allow you to repeat the

same positive expected value outcomes

that actually give you results. This

means going from the high time frame

through to the medium, and if you want

to, the low time frames for trading

using bias, range, and points of

interest. So, you want to determine what

is that battle telling you? Who's in

control right now? What is the bias of

the market? Then, range is is where is

the market likely to go next, whether it

moves up or down. That's where your next

relevant trades will be, so it's

important to get those in mind. And

then, for points of interest, inside of

that range, where are the buying and

selling opportunities? The points of

liquidity, the supply zones, the demand

zones, the points where you'll actually

get into and out of your trades. We want

to do this in the if-this-then-that flow

that's been explained throughout the

previous two classes, where we build a

situation or a scenario in the market,

and we say, "If this supply holds and we

get bearish confirmation, we will sell.

But, if this supply breaks, then we will

look for a buy through towards the next

area of interest on the upside." When

you build these multiple scenario

outcomes, trading becomes simple because

you're not marrying biases and getting

stressed when trades lose. You have an

endless flow of opportunity. Every loss

or every miss or every invalidation

immediately validates a new opportunity

in the opposing direction. So, when it

comes to systematizing this process, you

want to consider what is the narrative

telling you? Where are the significant

points of interest? What is the specific

trigger that would get you into a trade?

And where would your stop loss, your

target, and where would your stop loss

and your target be, and why? All of this

is specific, unambiguous, and clear, and

most importantly, prepared in advance.

This is how we systematize trading by

prepping everything ahead of time

instead of trying to react in the

moment. Now, if you have a system to

some degree now, and you're just worried

that systems don't work because the one

you're trading with isn't working out

for you, that's generally because it

looks like some rules on the surface,

but it's weak, fragile, and prone to

falling apart, and it's open to

interpretation and interference in the

moment. To fix this, we have to build

that narrative-based way of seeing the

market. Then, it just becomes a process

of is the market telling me to trade? If

it's not, you don't take a trade. If it

is, you execute your positions. It

simplifies trading, removes guesswork,

and separates the calm, consistent

winners from the chaotic, stressed, and

anxious losers, one of which you may be

right now, unfortunately, but you can

break free from that. If you nail this

systematization step, everything will

change for you. And when you have that

narrative down, and when you have it

systematized in a way, and when you've

got your narrative and you've

systematized it correctly, you then want

to move into testing and validating your

system. And if you skip this step, I

promise you will lose forever, so make

sure you do the work. So, at this point,

you'll have built your system, you'll

understand the framework, and you'll

have some solid rules. Now, you need to

ask the question, does it actually work,

and can you do it correctly? That is

what we're trying to do here. So, if we

want to achieve long-term positive

outcomes and move our equity curves to

the upside and build a career from

trading, we need to know that what we're

doing works, otherwise we are kind of

blindly buying and selling and hoping

that this moves to the upside. You can

have a good system, but you might not be

able to profitably apply it because of

mistakes that you're making. That is

what makes testing and validation so

important. So, the first thing that you

should do is get yourself a backtesting

software like FX Replay or Forex Tester

and trade your system, your

narrative-based system, your rules-based

flow in a simulation using past price

data over the long term, and you will

see over that time how the system

performs. And if the system performs

well and has an equity curve like this

or even if it's a little messier, if

it's still moving to the upside over a

sample of a few hundred trades, you know

for sure that this system is going to

pay you. And then when you come to

trading it, you have conviction and

confidence in your system, which makes

trading a lot nicer. And you also

understand that you're not going to be

trading for the next year only to end in

the red because your system doesn't

actually work. Now, in your backtesting

you should be tracking your win-loss

ratios, risk to reward, maximum

drawdowns and largest losing streaks

because these things are important so

that when you encounter them in the

real-world scenarios of your real

trades, you know what to expect. You

know when something is concerned and

when something is just standard variance

of the system. When you've done

backtesting, you should move on to

forward testing. Trade with a small

capital of $1,000 or less, purely

system-focused at this point. We care

about learning, not earning in this

stage. And what we're trying to do here

is basically prove our ability in

real-time markets. Backtesting is fast

and there's no money on the line. When

we're in forward testing, we are

building that ability to actually

execute the same way in real markets in

real time where things move slower with

real money on the line. This will test

your patience, your discipline, and your

emotions as well. But with that

backtesting data behind you, it will be

a lot easier to find profitability here.

This stage proves your ability and build

your conviction so that when you come to

real achievements like funding

challenges and reaching payouts with

those or trading your larger personal

capital, you have way better odds of

actually succeeding with those things,

okay? If you skip this step, it will

result in permanent uncertainty, likely

what you've been living in up to this

point in your trading journey. Where you

think, "Am I on to a winning system or

am I just getting lucky in the short

term?" But if you do this step properly,

you'll go into live trading with solid

proof in your system's performance and

your ability to apply it correctly to

produce positive expectancy over time

and therefore positive results. And when

all of this is done, we can actually

start to get interesting. All of that

can be done in literally a few months if

you actually nail it down and get it

done. And when it's done, you can move

on to step four, scaling to six-figure

capital through prop firms. Now, not

everyone will want to use prop firms.

That's completely okay if you're

capitalized yourself, but they are very,

very useful. I've had many, many

students succeed with them, and I used

them myself when I started trading, too.

So, if you do everything outlined in

this series so far, this is where it all

gets real. You've got your validated

system, your proven positive expectancy,

and you have the conviction to execute

it correctly based on the backtesting

and forward testing you've done up to

this point. Now, one of the biggest

problems that traders face when they get

to this point in the journey is

undercapitalization. See, 80% of traders

trade with less than $25,000. Most are

trading with $1,000 or less, and

realistically, I and if we're being

honest, I know not a lot of people want

to hear this, but you can't win

significantly with these numbers at all.

It's not really going to get you

anywhere. Prop firms change this, and

this is why them. Again, if you're

against them, if you don't like them,

you can do this with personal capital,

but this is how you get that big step up

towards where you want to be. So,

basically, a prop firm, if you don't

know how they work, is a company that

will give you funds to trade with and

then pay you out a percentage of the

profits. All you have to do is take an

evaluation and prove that you can make

money without losing money. It's usually

make 10% without losing 10%, and if you

can do that, they will give you the

account. This is just a look into some

of the students that have gotten

accounts by following the process that

I'm laying out for you today. And these

are some payouts that one of the members

got very recently, and these are some

payouts from one of my students very

recently from just the past few weeks.

That's about six and a half thousand

dollars in just one month of trading.

So, they are So, they do work. They are

valuable, and they can get you paid.

These challenges that a lot of people

jump into and lose over and over again

are actually not hard if you have a real

validated system. So, nailing in that

dynamic narrative-based strategy and

building an approach that works for you,

your personality, and your preferences

is a very big step in the right

direction to passing these prop firm

challenges with ease, and then actually

reaching payouts. And when you do that,

you can actually make money in trading

instead of lighting it all on fire. So,

these are the four steps that you need

to follow in order if you want to become

successful in 2026. And you can do all

of this before the year is up if you

really lock in now. And to show you that

this is actually possible, here are just

a few of the many funding challenges

that people have gotten following the

exact same process that I've laid out

for you. Here are some of the smaller

payouts, but still very respectable nice

payouts, that people have gotten trading

this system as well. Here's some more

payouts, and here is a story from one of

my traders who learned from me, who

learned this approach to trading, went

on to get funded multiple times, make

big payouts, and then made $20,000 in a

month with this approach. This stuff

works. And all of the people you're

seeing here followed this process,

including Lisa, who literally went

full-time with trading. These are not

exceptions. This is what happens when

you stop collecting concept, and you

start executing an actual real system in

the markets, and you follow that

four-step flow that I've laid out for

you, and build your trading out in a way

where everything is consistent,

repeatable, predictable, enjoyable, and

profitable. The system works, the path

is clear, and the only variable as to

whether you're going to win or lose now

is whether you walk that path or not.

Okay, so I hope you enjoyed that class.

Now, there are two things you can do

from here. The first is, this is

probably the option you want to go for,

I send out daily emails. Now, I know

that sounds like a lot of emails, but

these things are super useful, okay?

This is probably where you're going to

learn the most from me without joining

my program itself. There is a link to

this at the top of the description.

You'll get daily emails from myself,

various different things. I'm sure

you'll find them interesting. If not,

you can unsubscribe. And you will also

get my best ever free class. Now, this

goes through how you can break the cycle

of win some, lose more. How to win big

even with a 40 or 50% win rate. How to

look at a clear repeatable strategy.

Pretty much everything that we've gone

through in today's class, but in a bit

more depth as well. So, you'll get that

and the daily emails. That's 100% free.

And if you want to go a step further and

just get into gear learning from me, I

also have a program. Now, this program

is responsible for an ungodly amount of

results at this point to be honest. This

is where I actually work with traders

day-to-day and help them out. So, all of

the information about that is on the

second link in the description, which is

going to show you what this is all

about. There's a lot of information on

this page, but you can read through it

and see if that's for you. Now, one of

those two things is going to help you to

improve in some way or the other. The

only mistake you would make is leaving

without doing either. So, hopefully, I

see you on the daily email list or maybe

I even see you inside of the program.

Whichever one it is, I hope to see you

Whichever one it is, I hope to see you soon.


_________________________________________________________________

What actually makes a 'perfect' entry?
Transcribed by TurboScribe
. Go Unlimited
to remove this message.
Okay, one important question for today's video, what makes a perfect entry? We all need to know
the answer to this. Now, if I were to ask your average trader what makes a perfect entry, we may
get answers like this, high risk reward, sniper execution, massive profits and tiny stop losses.
Because of course, that is what a beautiful trade looks like when we catch them.
But these things are not the things that are going to make your perfect entries. In fact, these are
byproducts of actually having a good entry finding process. So what we're going to talk about is
the root of how to actually get to that point where you get those beautiful entries, what it is that
actually creates that and allows that to happen, okay? Now, the first big thing that you need to
understand when it comes to finding good entries is context.
This is kind of disconnected from the entry itself, but it is the most important element because this
is where all good trades are born. Now, when I'm talking about context, I'm talking about where in
the market your potential trade idea or your execution is actually coming in. So obviously, if
you've watched any of my videos or maybe someone else's videos, because this is a pretty
standard thing in trading, you'll know that many traders, myself included, like this pattern for
entries.
So what we have is a market that is trading up, creating higher highs and higher lows, then it
breaks down to create a lower low and we capture the lower high with our execution, selling from
there and taking the market lower. And the same is true for buy side ideas, but upside down. So
that is what I like as a perfect entry.
However, that pattern in the middle of nowhere is completely useless. You'll see that happen
quite a lot, but if it's not in the right context, it won't work. Instead, it might do this.
It might go up and create the first part of the structure, come down, break through your low. You
then want to sell the market here, but instead of going down, it just keeps on going up. That's
pretty common if you are trading in bad context.
So context and where exactly you are in the market is the first and one of, well, probably the most
important thing when it comes to your entries. Now for this breakdown, we are going to use a
trade that I took a fair bit back now, but I just like this trade and I think it's going to be a good one
to show you the theories on. So we're talking about context, right? We want to understand where
is our trade taking place in the grand scheme of the current market.
We don't want to take those confirmation patterns. We don't want to set good trades up in the
middle of no man's land, I would call it, which is basically if there's no real context or bias behind
the reason to take the trade, then you simply don't take the trade, okay? So to break down the
context, I'm going to go to the daily timeframe. I like to build my context and my narratives for my
ideas on the higher timeframes like the weekly and the daily.
So that's where we're going to begin. So this market, EURUSD, is a market that was initially
trading to the upside, creating new highs on its way up until we hit a peak, which was at this
following point just here. After we peaked at this point, we actually started moving the other way.
The first inclination of that is when we broke through this low, which basically created our first
lower low, which was then followed by a lower high at this point and another lower low when the
market broke into the upside. This low. So from this, I understand, okay, I probably want to be
selling this market overall, okay? Where can we sell from? Well, there are a couple of points.
We can look for internal highs. So we could see this high being taken or maybe even this high
being taken and then sweep and trade lower from there or we have potential supply zones. So
like this area that the market is just about trading into right here, okay? So this is the context.
We have the trending direction and we've worked out some potential points that the market could
trade lower from, right? So that is some context we've got. We think the market's gonna trade into
this zone, then trade lower or trade into and through this zone and then trade lower from there.
Now on the context topic, something I realized when I was trading this market is this market has
not really reacted to supply and demand too well and has instead been reacting to internal
liquidity sweeps.
So we can see in this drive up, we have this internal low here which was swept by price before it
traded higher. Then inside of this upward move, we could see that the market again traded
through an internal low, swept it and then traded higher. In this movement up, the market
returned, swept through an internal low and then traded higher, right? Same thing three times.
And on the way down here, you can guess what we did. We actually had an internal high here.
We swept, oops, we swept through it and then we traded lower.
So I was naturally drawn towards the idea of us potentially hitting the internal highs rather than
reacting from supply, okay? So I was more interested in seeing the market coming up to these
points, for example, like this one and this one than I was in seeing this just sell off from supply.
But of course, that doesn't mean we should write the supply off. This is just part of the context
building process.
Working out based on the market, what are we likely to see happening? Working out based on
what the market's been doing recently, what are we most likely to see? Okay, that is the context
element. And it's the most important part behind your trades because you only want to be taking
your entries inside of good price areas, whether that's a sweep, a supply zone, any point of
interest that is significant inside of your trading. The most important thing is just to remember, we
literally never want to take a trade.
So let's say we have a big uptrending move, then we have this confirmation pattern stepping in
here, but it's kind of in the middle of nowhere. There isn't really a point for us to take the trade.
You never want to take a trade that looks like that.
You always want to make sure that the entries, the executions you're making are coming from
points of interest. And that is the context element. So let's go a little bit lower into the price action
that preceded the trade that I took.
We can see inside of this move, if we are to kind of refine the supply zone, we have a little area
here with imbalance into it, which is likely to be the point that we would then want to sell from if it
is gonna react from an area of supply. So we can see, given the little imbalance there, the context
again tells us, okay, if we're gonna be selling, we probably want to sell from this point earliest,
meaning we can pretty much run the market through all of this upside price action, right? Now,
what might seem a little bit confusing is that the trade that I took and the one I'm showing you
today wasn't even a sell from one of these points. It was actually a buy from around this area
through towards this point.
And this is something that I do. I trade into the big picture trades quite a lot. So I'll set up my
narrative on the higher timeframes.
Then I will use the smaller timeframes to actually work out, is there an opportunity for me to trade
into this point? Because these are the trades that will be done in a day or a week. Whereas the
big ones, they're gonna take a good few weeks to actually run through, right? So again, leading
into the context for the specific trade that I took, the weekly and daily breakdown that we just did
was very important. We have to do that because that is where the big picture narrative and
buyers for trades, ideas comes from.
Then when we scale lower, we already understand what the market is trying to achieve or what
we're hoping to see the market try to achieve. Then we can work within that on a smaller context
to actually find a good execution, right? So right now I've got an idea. I think the market's gonna
go up to this point or maybe even over this point to then provide short opportunity for us to sell
the market lower.
I have context. Now we can build context around the current range. What is the market doing?
Well, from this high or low, sorry, we've actually been moving to the upside.
We were confined inside of a range underneath the previous lower high for quite some time, but
around this point we broke out of it, which basically drives us into an imbalance, which is this
region here, to the upside that we think the market's gonna trade through, okay? So we are
currently, on this four hour timeframe, which is what we're looking at now, we are currently
bullish, okay? We think this market is gonna go up towards those selling points we've discussed.
That's the first level of context. Second, what do we see? Well, we see inside of this bullish
movement, its own little trend.
We have a break there. We have another break there. And now we can basically drive this into
impulses, right? We have an impulse, correction, impulse, correction, impulse, correction.
And now this is an interesting one. This impulse actually takes us all the way to here. Why?
Because this high didn't break.
Well, it's not a high, right? It's an equal high. It's not a new high, which means this isn't its
standalone impulse move. This is an impulse correction impulse.
This is all just one impulse because it's the low to the next high. So that's the trending structure
we've got, right? We've built the context around this now. So what could we look for in terms of an
area to take a trade from? Well, we have, again, two points of context that we can build out here.
Number one, there's an area of demand just around here. This could create a market reaction.
And number two, because this is all just one impulse, this is actually an internal low.
Now, internal lows are basically points in the market inside of an impulsive move up or down that
the market can sweep out to collect fuel for a move. And the reason it collects fuel for movements
at internal lows and highs is simply because there is liquidity here. So if we have people buying
above this low, we know there are going to be lots of stop losses at this point.
There may also be sell stop orders, which is basically if the market gets through that level, traders
want to be automatically sold into the market to profit from a downward move. However, around
internal lows, traders kind of get it wrong, which is why these areas help to fuel upward
movements. See, if we break through this low here, this doesn't actually tell us anything about the
trend.
The trend isn't changing at that point. We would need to break through this low for the trend to
change, given that this is the impulse. So when we have a bunch of stop losses, which are sell
orders, because when you have a stop loss for a buy, it's just an order to tell the market maker to
sell your contracts back for a loss, right? So sell orders there.
And we have sell limits or sell stop orders, the automatic sell triggers. It means we have a whole
bunch of selling orders waiting in a bullish range, right? We're bullish, we're trending up. We're
still trending up even if we take out this low.
So a bunch of selling orders here basically allows larger participants to take the other side of that
trade. If there's loads of selling taking place here, they can do a lot of buying at one point instead
of having to take staggered orders with bad average entries. So that's why internal lows work.
I know that's a bit off topic, but I'm setting you up my entry, right? I'm showing you how I find a
perfect entry. So we build context, we understand the story and we understand the points of
interest that we can take trades from. That is the first and foremost, most important thing you can
do when you are trying to find perfect entries.
Don't think about the risk reward. Don't think about how small or big your stop loss is going to be.
None of that stuff matters.
If you can see what I've done so far, we haven't even looked at that. We don't even know if this
trade is viable just yet because the risk reward could potentially be too small. What we've done is
successfully build out context and an idea that can lead to a good trade.
When it comes to actually getting the risk reward and all of that stuff, as I've said, it's a by
product. Once we've done all of this, we can then see if there is a trade worth taking. It doesn't
take long, it's worth doing.
And what we're doing is setting up a perfect entry. All right, so the first thing is context. We'll write
that down real quick and leave that there.
I've showed you how to do that. It's about bias creation, narrative creation, essentially
understanding what the market is doing right now and what that is likely to lead to for your trade
in the future. Is there an opportunity present? Well, now we've found it.
We're not just firing off confirmation entries in the middle of nowhere. We've built a story around
what is likely to take place. Now with our context, we can move on to the setup, the confirmation.
We have here two points the market could react from. We've got a demand zone. We have an
internal low.
We know we want to buy somewhere basically in and around this area, right? But we don't know
exactly where that's going to react from. So pretty much every trade I take nowadays and for
quite a long time is going to use a confirmation. That confirmation is something we already
discussed.
It's this pattern. This is the buy side version. We're looking for lower lows and lower highs to shift
into a higher high and then we find a point of interest, generally a demand zone in this case, to
buy from when the market pulls back, okay? And we capture a trade from there to the upside, of
course, inside of the context that we've built.
So for this, it's gonna be a trade from there to there. Confirmation then, how do we find it? Well,
generally, we're gonna take a little step down on the timeframes. We're not gonna go too far
because we want to make sure everything stays timeframe relevant.
But from the four hour here, I'm gonna go down to the hourly and see how this trade sets up.
What we're looking for and the reason we're using the confirmation is because we have a
demand and we have an internal low and we don't know where the market's gonna react from.
Now you could put a buy limit there.
You could put a buy limit there. But what happens if the market keeps on going? You've lost two
trades instead of one, right? So we don't really wanna do that. It's better to confirm the setups.
So let's let this market run forward a little bit then. We can see coming into the demand zone
here. Well, the first thing I'd note is it's reacted so far.
It's looking okay, but we haven't got any confirmation to actually execute a trade. So a lot of
people would just buy into the trade here, but I don't think that is going to create a perfect entry.
And the reason I don't think that creates a perfect entry is because you don't know if this is
actually gonna hold or not, right? There's still reason that we could come lower for the internal
low.
So therefore taking a trade like this, yeah, it's an okay entry, but it's not a perfect entry and it's
gonna result in a reasonable amount of losses. What we wanna see is that real confirmation,
which means we have to see that kind of lower low, lower high, lower low, shift into higher high
pattern that really sets up a good trade. At this point, of course, we haven't done that.
Instead, what we've done is we've come down and created a lower low, then we've created a
lower high, and then we've created another lower low, which has taken out the demand zone.
That's why I say straight buy limits onto zones like this is not really gonna set up a perfect entry
because there's every chance it can just lose. When you confirm a trade, sure, it can still lose, but
the possibility of it losing or the probability of it losing is significantly lower simply because you've
actually got agreement from the chart now.
So what we're looking for at this point, as you can imagine, is going to be the market to create a
candle closure above this high. This is where the confirmation comes in. So this is our low.
This is our new low. If we close up here, it shows a short-term trend shift on this structure and
sets us into what we would then expect to be an uptrend. So confirmation is super simple and
you can do it the same way for every trade.
That's standard confirmation pattern I've showed you. If you follow that, you will be fine. It's really
not an awkward thing to have to do.
Now, what do we see? Well, we've got... Let's remove the demand zone because it didn't hold.
We've got the confirmation we wanted to see. We have a sweep of our low just here.
So that's the internal low swept, the context element. And then we have a structural shift to the
upside inside of this smaller trend. That's the confirmation element.
So we could now say a trade would become viable from the demand zone that created the push
up. And this pretty much sets up the entry. Now we can move on to the third element.
So I zoom the screen out. I'll write it again. We have context, which we've done.
We have confirmation, which we've now found. And now the final thing is going to be execution.
So execution is basically all of those elements that people skip to.
When we're talking about tight stop losses, large targets, high risk reward trades, those things are
good, but you shouldn't design your trade for them from the get-go because then you will cut
corners on the actual bias and how viable the trade is in pursuit of just getting the biggest and
largest possible profits that you can get. We want to make sure that what we're doing is we're
setting up a trade correctly. Then we're working out whether the execution can fit into that trade.
So when it comes to the execution, this is things like, where is your entry actually going to be?
Well, we've determined the entry is going to be on that zone. Where is your stop loss going to
be? Well, we could very just safely put it under that low. If it goes under there, we want to be out
of the trade anyway because there wouldn't really be a reason for us to hold it past this low.
And then where would we want our target to be? We would want it to be at that supply zone,
which creates around a 4.5% trade with a super simple setup behind it. So what we've done is
we've reverse engineered the actual market and then we've seen if the trade is going to be viable
on top. Now, in some cases, trades won't be viable.
Let's imagine we could only target this high for whatever reason it would be. Now, this being a
1.97 risk reward, some people that's okay. For me, I don't like to take trades that are kind of
projected target less than 3R because I want to trade, you know, the good opportunities that are
going to be able to return me around three times what I'm risking.
This helps me to stay afloat when you have your losing trades that are inevitably going to come.
So this is completely viable for me, but if the risk reward wasn't big enough, I simply wouldn't take
the trade. Now, this is something of course that a lot of people don't get their head around and
instead they'll start pulling in the stop loss to make it as small as they can to give this trade a
bigger risk reward.
But there's a problem with that. And of course that is that your stop loss can lead into basically
illogical grounds that is very likely to be taken out. If you do that, then you're going to lose a lot of
trades that should have been winners just because you're chasing the best risk reward.
If a trade setup doesn't provide good risk reward and it doesn't provide me a good opportunity to
kind of refine to good risk reward without becoming dangerous, I simply won't take the trade. And
that's what the execution element is all about. Making sure you're executing the good trades and
not executing the bad ones, right? Finding out where is your entry, where is your stop loss, where
is your take profit, and then determining whether that trade is worth taking.
So to break down these three elements super simple that you can use in every trade you take
from this point onwards, we have, first of all, the entry. This is simply going to go on the demand
or supply zone that your confirmation created. That is it.
It's that simple. Your stop loss. This is going to go at the point that the trade becomes invalid.
So if we have our stop loss under this low, that means we're only going to be taken out of the
trade if the market creates a new low. And what happens if the market creates a new low? Well, it
basically proves our confirmation has failed. So we would be more happy to get out of this trade
and just take the smaller loss because we don't see any reason from this point that it should then
reverse to the upside.
We want to make sure our stop loss is always at a point where a trade becomes invalid. You
want the trade to be stopped out only if you're wrong. One of the worst things that can happen to
traders and does happen to traders every day is they get stopped out of trades that aren't wrong.
They'll get stopped out by a wick and then it will run all the way to their target and they haven't
caught any of this movement. So what we want to do is make sure a trade stays in as long as it
stays valid. And as soon as it's invalidated, we are out.
That generally means putting stop losses below lows, above highs in simple, smart locations. You
don't have to overthink it. That is how I set these trades up.
And that is how you can be good with your stop losses when you're setting up perfect trades.
Now for targets, well, the target is always pretty much always going to be predefined before we
get into any form of setup. For us, it was the supply zones that we saw up in this high.
We knew we wanted the market to run into there. So we don't actually have to do much in the
ways of setting up our target past the point of context. The context delivers that for us.
Now everything we're doing is just trading within that. So your stop loss should be at pretty much
the next significant target point based on your higher timeframe bias. Where can the market go?
Where is it likely to reverse? If it is going to reverse, where's the safest place for you to capture
the profits from where you are now and into where the market could potentially go? Don't extend
them too far, but don't cut them too short.
In a trade like this, there's no point in having the target at this high. This range is efficient. At bare
minimum, we will likely get up here providing the trade wins.
But even then, if you want to create perfect entries and perfect trades, we can stretch that further
in this case because this is a very simple and high probability point for the market to trade into.
So you can see then the nice entry. So let's let it run out, which we can see there.
That sniper entry kind of pattern that people like to see, right? The nice entry paired with the high
risk reward, which we are achieving on this trade, 4.8, it's pretty good. These are a by-product of
actually doing the perfect entry process, right? Obviously this sniper entry didn't work too well on
this one, but it's all good. They're a by-product, right? Sniper entries, high risk reward, tight stock
pluses, all of that stuff is a by-product of a good, perfect entry process.
But the actual route of creating those results is going to be through the context, confirmation and
execution. This three-step process will allow you to take significantly better trades more
consistently. And that is pretty much gonna be it.
So if you ask me what makes a perfect entry, it's these three things that can lead to some really
good trades, just like the one you can see here. And that's it for this video. Hopefully that was
useful.
Take these tips away, use them yourself and remember to focus on the route and not the by
product when you're trying to find those really nice trades. Thank you for watching and I'll see you
in the next one.
Transcribed by TurboScribe
. Go Unlimited
to remove this message.


�________________________________________________________________


BoS... Or Liquidity Sweep? - Bootcamp Ep.16
Transcribed by TurboScribe
. Go Unlimited
to remove this message.
Okay hello and welcome back to season two of the Technical Bootcamp. Today in episode four
we are talking about structure shifts versus liquidity sweeps. So sometimes the market will do
what looks like a break of structure but then actually flip and reverse on you leading you to a
losing trade.
Well this is the exact situation we're talking about today and I'm going to show you the difference
between shifts and sweeps, how you can differentiate the two before of course they burn and
how you can actually trade those sweeps or failed shifts successfully. So even when the market
doesn't go the way you want it to it opens new opportunity. So with that said let's get into today's
class.
Generally a market structure shift is determined by a market that is trading in higher highs and
higher lows breaking down into a lower low. This is most of the time going to be indication of a
reversal. When the market makes this new lower low the expectation is that it will return on a
corrective movement to print a lower high and then continue downwards starting the new
downtrend.
So that's why we call it a reversal because this point here indicates the shift from an uptrend into
a downtrend. It's where the market has reversed from higher highs and higher lows into lower
lows and lower highs and this creates a selling scenario. However not every single break that we
see in a market is actually going to indicate a reversal.
So sometimes we will see what on the surface looks like a break of structure but doesn't lead
through to a reversal. In fact what happens in these cases instead is the market finds its footing
again and runs to a new high. Now you've probably been caught on the wrong side of these
movements at least once in your trading journey and maybe it happens quite often.
Well after today's video we're going to be able to significantly cut down how often that happens.
So the focus of today is differentiating these structure shifts from sweeps of liquidity. So the first
example we're going to look at in this video is USDJPY.
As we can see this chart has some bullish structure behind it. So we are trading currently in an
uptrend. We would anticipate providing we stay above this low that the market will remain bullish
and if we break under that low then the market may reverse right because what we would be
seeing from there would be that break into a lower low and then the anticipation would generally
be a pullback to a lower high and then a continuation into a new downtrend.
So we look to buy above this level and sell below this level. That is generally how this is traded.
However this situation is a little bit different.
This is actually one of those situations where we can with context determine whether this is a
viable break or not. So if this structural low was to break it would trade into an imbalanced range
and it would push beneath these relative equal lows the liquidity that we've got over here. It would
drive into an imbalance and it will potentially lead towards a demand zone as well.
So there's a lot of things down here that will be acting as magnets for price. We've got a demand
zone that's untested and imbalanced. We've got liquidity which is obviously going to act as a
magnet for price and then the other contextual thing we can consider here is if we take a look at
the range we're currently in this is what we classify as an efficient range.
There's no clear demand zone in here for price to react from at this point. So even if we do stay
bullish on this market there really just isn't a lot of reason for that to take place from where we are
and it might be that the market needs to collect more orders from a more significant area before
we start to see buying commence. So because we don't have a clear demand, because we have
equal low liquidity, because we have imbalance and because we have a demand zone beneath,
we could say that buying from here is not the best idea.
If we want to buy we would need to see it come down through this liquidity first and then find
reversals from there once liquidity has been taken and new volume can step in or from the
demand once that has been hit and the imbalance is completely filled. Simply because there is no
core reason for us to buy from here. So even though the structure is bullish it may just need a bit
more fuel to move higher.
So we always want to think about essentially that fuel in the market. Now fuel for movements
comes from liquidity, comes from orders, comes from transactions. Let's talk about the liquidity
around these regions for a moment.
With these equal lows that we have over here we know there are going to be a lot of selling
orders beneath that level right. So there's buyers here, there's buyers here, there's buyers
anywhere in this range and if they have a stop loss it's generally at least a significant amount
going to be situated underneath the equal low liquidity. So these stop losses are sell orders.
If you buy your stop loss is an obligation to sell those contracts back at a loss. So there's sell
orders there in that case and then there's also going to be sell stop traders who are looking to
capitalize on if the market pushes under these they will be automatically triggered into a sell to
take the market lower. So these are support and resistance traders.
Now with that motion in mind we know there's going to be a lot of sell orders here okay. If we then
take a look at the current existing movement basically anyone who's bought over this low a
significant portion of them are going to have their stop losses beneath that low. Again creating a
big pool of stop losses and sell stop orders inside there.
So if we were to average that out to the broader range taking a look at this bigger picture this
whole area here is basically just a big collection of sell orders at the same price levels okay. Now
if we think about what happens if those levels are to be hit well that is what creates fuel for the
market. So two things can happen when we hit this liquidity.
One we can see cell pressure injection which could create massive downside so we could see a
huge drive to the downside very quickly. Number two what we could see instead is absorption of
sales into massive buying moves. So if we get significant selling pressure pushed into a market
and it is not absorbed what that does is basically create massive amounts of supply which will
sink a market dramatically.
But if we see those orders being absorbed what that simply means is when we get down to that
point buyers step in and kind of take control of this market because what happens is at these
levels there is so much selling taking place that if you want to add a 10, 50, 100 million dollar
position into this market on the US dollar well now you've got a lot of liquidity at one point a lot of
sellers who are forcing their out of the markets and you can take the other side of their trades
which is where the absorption comes in. You absorb all of the selling orders and from this point of
massive liquidity we then see a market reversal as large institutional participants like commercial
banks step in and basically eat up all the sell orders replacing them with huge buys. So if we
consider that we have a bullish bias in this market we want it to go up we see the uptrend is in
motion but we see that there is no significant buying demand from where price currently is in this
region well then it makes significant sense that when the market trades into an area with lots of
fuel right these sell order liquidity pockets that we could see that fuel provide the opportunity for
significant buys.
So what we may anticipate here instead given the liquidity that we've just discussed and the fact
that we don't have a clear buying zone from where we are yet we are still structurally looking
pretty strong we could look for this trading under this level and then from there taking the market
higher and now this reaction could happen immediately upon touching into the liquidity so we
don't have to fill the imbalance or hit the demand in this case but it could happen from a complete
fill of the imbalance and a retest of the demand. All this would do is basically absorb those selling
orders slower but reach into a discounted price range where we may have additional buyers just
looking to step in here naturally. So it depends on how hard the absorption is on the buy side
when we get down there okay.
So in this case what we would be looking for is a sweep and then a reversal to the upside as
opposed to the standard pattern we expect to see which would be a breakdown and a reversal
into downside price action and the way that we differentiate between that sweep or that reversal
and the way that we can decide that this even if the low is taken should be a buying opportunity is
simply what's going on down here. Now if we were to break through into a large open
overextended bullish movement and it was significantly imbalanced there wasn't any clear
liquidity there and there was a clear demand beneath and the break was very strong then yeah
we could look at the sell side but in this case we've got a very small range right we just literally
have the area from here to here and there is so much intent inside of this area and so much
transaction interest essentially in terms of the amount of selling liquidity there is and of course the
amount of fuel there will be for buying in here and the significance of no clear demand here. Well
this becomes then a significant situation where the most probable outcome is not a reversal to
the downside but a sweep and collection of that fuel to then release more orders into the market
on the buy side.
So we're going to keep that in mind for a moment but what I want you to do for now is just take a
look at this smaller bit of price action. So what we're going to do is just zoom in for now on price
around here. Now as you can see we have something very similar taking place but on a smaller
perspective.
So we account for the fact that this is not a significant demand, there is no clear imbalance, the
market's already pushed under this low so we're trading in an efficient range. Now that
immediately makes this range not great for reversals and something that is more likely to be
taken out on the downside rather than creating a reaction for buyers. Well if we then zoom in on
the price action here we can see that we kind of have our own little trend inside of the trend.
So we have a lower low, a lower high, a lower low and then we've created a range. So you could
say if we isolated this situation given that we have this lower low lower high structure this would
be a valid lower high. If the market was able to break over there that could lead us into buying
opportunity because this would indicate a change in this smaller trend right.
But again when we factor in the larger context we run into the same situation. Now above this
high, because there's no imbalances left inside of the existing range beneath the high we marked,
any selling that has taken place has liquidity above this high. So there are stop losses and there
are buy stop orders.
Think about what a stop loss is for a short seller, it is an obligation to buy back the contract. So
every stop loss here is a buy order and every buy stop is also a buy order. So now we have the
opposite, we got a lot of buy liquidity in here.
Factor in the market context, this is not coming from a meaningful area and we've got all of these
magnet price areas down here that will draw price in. Well then I would see this totally opposite to
what the majority of people see. I would not see a break above this high as a bullish opportunity
for us to buy into.
I would see a break above this high as a lead-in for some fuel to fuel the movement down
towards the magnet price areas below. So this side, what people see as a bullish reversal, I see
as a liquidity sweep to fill the get enough power to make the movement down. And then on the
downside, what a lot of people will see as a bearish reversal, I see as an opportunity for the
market to collect mill fuel this way, trade into a more meaningful buying area and then fuel the
next movement up.
So what we've actually got is what some people will classify as a reversal, which I see as a
sweep. And again, the same thing but on a bigger picture perspective, right? So we're
differentiating here between reversals and sweeps by considering the contextual liquidity and
orders and everything else that's situated around the areas we're in. And the most simplistic way
to get that point across to you is just to keep referring to that point of market fuel.
Every movement, every significant movement needs transactions, it needs volume, it needs fuel.
If we're in an efficient range, there's no core supply zones, there's no clear area, there's no
massive seller or buyer intent from here, then we need to reach into an area where mass
amounts of orders will be triggered at the same point to create liquidity or fuel for the next
movement. And that is all we're looking at here, fuel down here, fuel up there, nothing in the
middle.
So even if we want to buy, we need to wait for the load to be taken to create buying fuel. And
even if we saw a break above here, that wouldn't interest me for buyers because we're looking at
seeing absorption of these buy orders, massive selling down, to get to where the fuel is for a
significant move higher. And we factor that in again by weak buying zone, liquidity, imbalances,
fuel down here, fuel up here, nothing in the middle.
So if we take a look at how this market then went and played out, we got a push over this high,
we reversed, we came back down and then we had a selling opportunity. Now in real time when I
was trading this, and this is a while ago now, about six months or maybe longer by the time I
released the video, the selling movement was a movement like this. So selling from the high to
bring down to the low.
Now we close this at the range liquidity low, which is just there. This is actually where we have
the same kind of thing playing in motion again. So just down here, of course, we know there's
going to be some fuel, some liquidity for the other way.
This is kind of a smaller picture view of what we see on the big picture. So we have buying stop
losses and we have sell stop orders creating sell liquidity in here. However, the sell liquidity that
we have here is only factoring a small range.
It's not factoring the more considerable larger trend. So the liquidity in this region is going to be a
lot smaller than the liquidity on the big picture. This liquidity would not be enough to rocket price
up to new highs, but it could potentially be enough to flip the market in the short term.
So we could even see the market coming to this range liquidity and then maybe going over here
as well. Now you may have seen these ranges before, kind of expansion ranges where we end
up consolidating, but we continually make opposing highs and lows. So we'll make a higher high,
but then a lower low, then a higher high, then a lower low.
That's generally what is happening here. We're expanding in a range, right? Now, if we run this,
you'll see that's actually what we did. We traded under this low, taking out that range liquidity.
Again, what looks like a reversal in the moment, but isn't quite yet because there is still liquidity
above and below. So again, you see, we trade up and then when we take out this high again, we
are sweeping liquidity once again for, I guess, people like me who took this trade but didn't get
out because I got out at the range liquidity low. If I'd have continued down, it's me, this kind of
position, that would have been getting liquidated to create the fuel for the next movement.
And the market ran like this for a bit, okay? So you can't really trust every break here. Now, in this
context, it's easy to determine what's a liquidity sweep versus what's a reversal because we are
expanding, sweeping highs, sweeping lows, trying to collect aloof fuel to actually get down to a
significant point, all right? So it's a bit of a trickier range to trade. You can trade from the range
liquidity at the low to the high and so on.
But realistically, we just want to ignore directional confirmation from this kind of range until we've
made a clear run to where the fuel is, okay? But this just follows the same flow. Here, we went for
fuel and we came back down, we got some more fuel, we went back up, we came for some more
fuel. That's all we're doing, right? We're trying to fuel the movements to a more significant point.
Now, this can happen endlessly realistically until we actually get down under this structural low.
It's when we get under this point that will create the significance and the liquidity for us to actually
get the larger movements, all right? So this is the real core point that we want to see the market
get to, but there's nothing really stopping the market from chopping side to side until that
happens. Now, here's the point where we've taken out the low.
So here's what we could indicate initially as the point that would create a reversal confirmation
and lead us into shorting the market. But because we built that idea around fuel and what we're
looking for the market to do, and because we still maintain that bullish bias of these continual
higher highs and higher lows that we see, this was kind of a sub-opportunity. But the big trading
opportunity, as we prepped back here, was to see this liquidity taken and then a bullish increase
in price.
Because at this point, we would have run into a point, knocked off enough orders essentially,
absorbed the other side of those, and seen a massive rally in the market. Now, this is indicated
even by the wick, right? Take a look at the size of this wick. This is a wick rejection.
This is around 70 pips in a wick, right? That's a lot of pips to be moving like that. Now, a 70 pip
rejection within the span of four hours is significant. And the reason that we saw such a rejection
is because as soon as sellers brought the market down into this point, all of that liquidity was
absorbed.
The other side of the position was taken in force and that drove a 70 pip wick reversal and around
another 50 to 60 pip candle as a bullish closure. Now, if we see what happens from this point
onwards, we actually go and take out the highs entirely, creating a very nice bullish movement for
UJ. And this actually fueled then the next movement up.
So what we did here was use the context, the buying areas, the liquidity and the understanding of
where the fuel in the market is to avoid buying above this low and also to avoid treating this as a
reversal and getting caught trading the other side of the market. We had everything prepped to
understand that sweeping this low would just be tapping into liquidity and allowing fuel for a run
higher. And that is exactly what happened.
Now, another thing I want to cover on this topic is something that's a lot less advanced, but I
haven't actually covered it yet in the bootcamp. I had some presumption of knowledge. If you're
newer to trading and you've used this bootcamp as kind of the entryway to learning, then this
class and this bit of the class is going to help you a lot.
All right. So it is very important, in fact, completely crucial that when we are looking at a candle,
determining a break or for anything really, we have to wait for that candle to close. So each
candlestick is showing price action within a time frame of say, let's say one hour, right? That
means at the start of the hour, the market opened here and at the end of the hour, the market will
close somewhere and print the full candle.
However, until the time scale or the timeframe you're on has actually closed the candle, anything
can happen, right? So you could be looking at this, we've broken above structure and seeing this
as a reversal and you might start looking for opportunity to buy into this. So you might be looking
at prepping your buyers or placing your orders to take the market higher because you've seen the
markets traded above this high. Therefore, this is bullish.
But the thing is, because the candle hasn't yet closed, it could go up more. That would be good
news, but it can also come back down and close beneath the high. And if this happens, then all
we have is a wick.
We just have a rejection, right? Which shows us that this market did not have intent to go higher.
It had intent to trade towards where, as we've just been discussing, the fuel is for another
downward move. And then after we hit that area with enough fuel to bring the market back down,
the next likely thing, as per what we've just been through, is going to be continuation of lower
price.
So you have to wait for candlesticks to close in order to determine whether it's a sweep or a
reversal. Because if we close as a candle body, then you've got good indication that this could be
a bullish opportunity, all other things considered. But if we close as a wick like this, or even
shifting back bearish like this, well then you're in a situation where everything looks completely
different.
And if you're in your earlier days of trading, you probably have been killed by this a few times.
You get into trades up here, you think this is it, you buy in, maybe you buy in here or whatever.
But then by the time the candle closes, it looks like this.
And now you're sitting on a buy from this level and it's not looking good for you, because we're
now trading all the way down here. So waiting for candle bodies to close, just the final and very
simple tip to determine structure breaks versus sweep reversals. Because if we close as a wick,
we're showing rejections, not closures, okay? So closures above or below structural points, that's
good, like this.
Closures with wicks beneath the structural high or above the structural high. Closures beneath
the valid structural point with only wicks above the level, then this is not good, not something we
want to be treating as a reversal. This is a sweep, this is a reversal, okay? So that's pretty much
everything for this class.
Hopefully you found this valuable, as I'm sure you probably have. Head to the link in the
description and watch the trading diagnosis class where I teach you everything that's keeping you
away from the charts, the things you probably haven't considered yet. It's only 15 minutes long,
loads of value in there, so check that one out.
And with that, I will see you in the next episode of the bootcamp.
Transcribed by TurboScribe
. Go Unlimited
to remove this message.

_________________________________________________________________


ULTIMATE Supply and Demand Masterclass (Beginner to Pro)
Transcribed by TurboScribe
. Go Unlimited
to remove this message.
In this masterclass, I'm going to teach you everything that you need to know about one of the
best concepts in trading, supply and demand. We are going to go through all of this and by the
end of the video, you will fully understand the theory of supply and demand and how to apply it to
find great trades. So with that said, let's get into the video.
To briefly explain the theory of supply and demand, this is the thing that drives all markets. So
we're looking at a price scale here and when demand increases, so this will be our demand line,
we see an increase in the price of an asset. So let's peg this to gold for this example.
As demand for gold increases, the price of gold also increases. This happens because the supply
of gold that's available ready to trade in the market declines with the increase in demand. Now,
why does this happen? Why does supply fall as demand rises? Well, it's because, of course, if
there are lots of people trying to buy an asset, i.e. there is lots of demand, then there are going to
be people buying that asset, taking available supply off of the market.
So that means as demand increases, more assets are bought up and the supply will decrease. A
lower supply creates higher scarcity and a higher scarcity demands higher prices because, of
course, if something is rare versus something that's not rare, the price is going to be more
expensive for the rare item. That is simply how it works.
It's a very simple format. If we then saw demand start to slow down, so we saw the market
coming back down in terms of demand, this would mean people are selling their assets. Now, if
they're selling their assets, the supply is going to increase.
And as supply increases, of course, there are more readily available units in the market, which
generally means if there is less scarcity, the price is going to decrease. So as we see an increase
in demand, we see supply lowering because the assets are being bought up. When we see
demand decrease, we see more assets being sold to the market.
Therefore, a lower price comes in due to the fact that there is now more available supply, less
scarcity, and simply the fact that if demand is low, it pretty much means no one wants the asset.
To bring supply and demand into our actual trading and our technical analysis, we do this using
zones. So this here and this here indicate supply and demand zones.
A demand zone is an area in the market before a large upward move. So when we see a
sideways bit of price action, can be an individual candle, show you some examples in a moment,
and then a large push away, this creates a demand zone. When we see the same, that kind of
sideways price action of one candle or maybe more before a large move down, this creates a
supply zone.
Now to talk about the theory as to why this happens, basically the reason that we use this as our
demand zone or our supply zone is because it's showing us where buying and selling pressure
came into the market. Now in order for the market to slow down, kind of recoil and consolidate
before a large push up, that tells us that this region here, where it slowed down, where it went
sideways, is where massive buying orders have been placed. That is why the market drove
higher because demand kicked in here, supply was bought up, the price appreciates because of
that increase in demand and decrease in supply.
In the supply example, here we see the area of consolidation before a large move down as
essentially a point where new supply has entered the market. Demand has declined, more assets
have been sold readily available to trade, therefore with more supply and lower demand, the price
depreciates. Now the way that we actually trade these then is to buy demand zones when the
market returns to them or to sell supply zones when the market returns to them as well.
So in the case of a demand zone, knowing that this area here is an area where significant buying
has taken place, we know that this is what we could call a discount price. Traders before saw this
as a very good price to buy this asset, so they stepped in en masse and we saw that large drive
of momentum. If we then get up to this point and we start to slow down, this is telling us that the
price up here is no longer seen as a discount price to buy and it's no longer seen as a good price
to purchase this asset.
However we know, we have solid confirmation that this area here was indeed seen as a good
place to buy from, a good price level to purchase this asset. So the theory is and the concept is, if
the market is to return to this price range again, we are likely to see a second phase of buying
coming in because this is a discount price region. If it was a good price to buy before and now the
market's appreciated, you can be damn sure it's going to be seen by a lot of people as a good
price to buy again.
The same goes for supply, except this is what we would call a premium price level. So this was a
premium price to sell your assets at, whether you are taking a buy trade and you're closing out for
profit or you're getting into a short sell position where you've sold with the intention of profiting
from a down move. Regardless, it's a premium price to sell from and now the market's lower, so if
you're holding a buy, maybe you don't want to sell it down here, you'd rather sell it up here
because the higher you sell it for, the more profit you're going to get.
And if you want to get into a short position to profit from a down move, well you don't want to do it
down here because if you do it from up here, you're going to get a much better entry, which
means more profits. This entire range you could actually profit from instead of just, you know,
selling all the way down here and hoping the market doesn't return. So therefore, with this
understanding that this is a premium price to sell from, if the market is able to return to this level
again, this is going to be a prime place to place a short order and to profit therefore from the
move down.
So that is how supply and demand zones work. Let's take a look at those on real charts. So here
we have a market that is in a downtrend.
We're going to identify a supply zone and show you what it looks like in the real markets on a real
candlestick chart. So we can see we have this big push to the downside. This candle here is an
area of consolidation.
Now, how do we indicate an area of consolidation or indecision? Generally, when we are plotting
supply and demand, the simple rule is to use an indecision candle and I like to use the last candle
before the impulse. So what this means is, I don't care what color the candle is, but I want to see
the last candle before an impulsive move away. So if we take a look at this one here and we take
a look at this one here, these are indecision candles.
They are indicated as indecision by the fact they have large wicks and very small candle bodies.
Wicks show rejected prices. So what we're seeing here with these wicks is attempts to go higher,
attempts to go lower.
And what we see with a small candle body is pretty much failure to get far in one direction either
way. We didn't get high, we didn't get low in this given period of price action. So this creates an
indecision candle.
Now we are looking for the last indecision candle before an impulsive move. An impulsive move
is a strong bearish or bullish candle or a series of strong bearish and bullish candles. So you can
see the candle I've just marked here, this is a impulsive candle.
It's a large sell candle with no resistance from the buyers. We see as well this one after this
indecision candle is a large selling candle with clear strength from sellers. No resistance from
buyers.
So that is how we're going to be plotting these in real time. We want to see the last indecision
candle before the impulse. Last candle before the impulse is the rule I use.
Now if you've learned supply and demand anywhere else before, you might have the last down
candle before the up move, the last up candle before the down move as a rule. I don't use that, I
use the last candle before the impulse. The reason I do this is because it is this candle here
where the selling pressure has accumulated.
It's not the last up candle where the selling pressure came in, this was a strong bullish candle. It's
here, it's the very last candle before the impulsive move. It's exactly where the momentum has
built up to create a selling move, it's the selling pressure.
So that is the rule, last candle before the impulse is going to be the one that we use for our
supply zones. So now to show you this example we're going to focus in on this one. We're going
to talk a bit more about differentiating zones a bit later but for now we've got our supply zone.
To mark a supply zone we find that last candle before the impulse and we want to mark the high
to the low, that includes the wicks. So our supply zone would be this, okay. We've just gone high
to low of this candle.
What we would then expect is for the market to return to this level and then sell off from there
because we know that that's where the selling pressure has been previously. We know this is a
premium price to sell from so we would expect that to take place once again and this is going to
be a supply zone. So we're going to mark it SZ.
Why is it supply? Because it's in a downtrend, it's a selling move, okay. Demand is obviously
when we pull back to a buying zone, supply is when we pull back to a selling zone. So this is a
supply zone.
So what we could generally expect to see from here then, having plotted that correctly, would be
the market to return to here. We would look to sell there and then we would profit from a new low
being formed as the market falls. So just as a very simple example trade, we would have our
entry there, stop above the zone and our target down at the low.
We're going to get more into all of this stuff soon but first brief example, here it is. So there we go,
we see the market push into the supply zone and what actually happens here when the supply
zone is hit is a new wave of selling pressure comes in because of that discount price level.
Because that premium price has been hit, sellers that sold here before are more than happy to
sell here again and you get this nice positive movement straight down to your target, which is of
course how we make profits from supply and demand.
Now one very important thing about supply and demand is that you use it in line with the overall
trend direction. So we can see this market is falling, it's creating lower lows and lower highs,
meaning every low is lower than the previous one and every high is lower than the previous one
as well. So what this tells us is that the market is in what we call a downtrend, and in a downtrend
we only want to focus on selling supply zones, we do not want to buy demand zones.
If we take a look at this market we have multiple areas we could see potentially as demand zones
but if we were to buy these every time the market came into them, we would be destroyed. All of
these areas would classify as demand zones but if you were buying here on the way down, you're
buying here, you're buying here, you're going to get killed, you're going to lose loads of trades. So
the kind of sneaky thing about supply and demand is that supply and demand zones visibly
appear everywhere but you need to trade them in context.
So in a market that is moving down we only want to sell from supply zones, we do not want to
focus on demand zones. Now I'm going to give you a very quick class on market structure to
explain it, let's go. So through this phase of price action just here we can see the market is
creating higher highs and higher lows.
So a higher high very simply is just a high like this that's been printed in the market that's higher
than the previous one. Higher lows again it's just a low that's higher than the previous one. So as
the market is creating higher highs and higher lows that puts it in an uptrend and that means the
only thing we should focus on doing here is buying demand zones, we should not sell supply
through here.
So this is an uptrend, we want to buy demand and that is how we trade when the market is
forming higher highs and higher lows. At this point we see the market shift and it actually breaks
into what we call a lower low. How do we get this? Well simply this low is lower than the previous
one therefore it's a lower low and through any phase of price action where we can clearly define
the market is creating lower lows as well as lower highs we want to be selling supply.
So if the lows start to form lower than the previous ones and if the highs start to form lower than
the previous ones this puts us into a downtrend and during a downtrend we want to pretty much
ignore demand zones and in here we want to sell supply. Now there will be a card in the top
corner of this video if you really want further depth on market structure, lucky for you I have a full
masterclass on that as well, click in the top right somewhere and that will take you to it. So here
we have a market that is creating lower lows and lower highs therefore what would we want to
do? We would want to sell from supply zones.
Now an extra little lesson woven in here I'm going to use this sideways candle, this pullback
candle, this kind of indecision candle in this downward move as supply. As we can see in this
example there is a little wick here that extends further on the next candle so I would actually use
this candle to mark my range, the blue one, but I will extend the high of the zone to the wick that's
been created by the next following candle. So we use the high there down to the low here that
creates our supply zone.
So the idea is then we are going to sell supply because the market is currently downtrending
creating new lows and new lower highs consistently. So that would be pretty much where we get
into a trade from that point onwards and as we see the market coming down of course we could
then just continue selling supply zone. So we see again indecision candle, the market pulls back
to supply that would be another opportunity to sell.
So that's the general idea as to how we focus on a downtrending phase of price action. Now as
we can see coming in from this point we are starting to push to the upside. Taking a look at the
structure we actually pushed over this high so we have a high, lower low, lower high, lower low,
lower high, lower low, lower high, lower low.
The market's pushed up and now it's created a higher high. So this actually puts us into an
uptrend, meaning what do we want to do in uptrends? We want to buy from demand. So here's
our indecision candle, our sideways candle before the impulse, last candle before the impulse is
what I use for my zones and what we want to do at this point is buy from demand, meaning any
supply zones that form will be ignored.
You can see that demand zones did form in this move up but we ignored them and focused on
selling supply because the market direction was down. Now that we've shifted up we want to
focus on buying demand and we want to ignore supply because the market direction is up and we
are moving with the market direction using supply and demand to make our executions. So in one
moment you will see market returns towards this area of demand and then we get a tap in and a
push away into new highs.
So that is how we use supply and demand in line with the trend with a real example there of a
downtrend, selling supply and an uptrend, buying demand. So in order to validate a supply or
demand zone we need to make sure there is something we call an imbalance. If there is no
imbalance into a zone then it's not a zone that we want to look at.
If we take a look at where I'm drawing these black lines we can see just above this candle here,
this blue candle, is going to be our supply zone. It's the last candle before this impulse to the
downside. Now we can see what we have beneath the low of that candle and then above where
price currently is, there is an imbalance.
An imbalance is an open price range, it's this area here. Basically what it is is an area that hasn't
been filled yet with wicks. If this candle had pushed up and hit that area then this would have
created what we call efficiency and removed any imbalance into that zone.
But because we still have this open price range here that means that there is imbalance into this
supply zone. So this would be a good supply zone to sell from. And we would expect when the
market comes back to it we could happily sell from this point because that would fill the
imbalance and then the market would be likely to move lower.
Now you have to have an imbalance to your supply or demand zone otherwise it's not really valid.
So if we take a look above we've got here this indecision candle. This is the last candle before an
impulse to the downside.
And just to clean it up let's get rid of this. We'll get rid of this. But the problem with this zone is
there is no imbalance into it anymore.
So here we have our supply zone, we have a push away, the market's pulled back, filled
imbalance and pushed down. So initially if you were looking at this supply and you wanted to sell
it here that would have been okay. But now that this has already been filled, now that there is no
imbalance, this would not be a good supply zone to try and sell the market from.
For two reasons. Number one, the market probably isn't going to get there because it's probably
going to react from the area with the imbalance. Number two, if it does get there because the
imbalance has already been filled there's a high likelihood of actually pushing higher which
means it's low probability and probably isn't going to give you a good trade.
So we need to trade from supply or demand zones that still have imbalances. If we look in this leg
of price movement there is no imbalance up here, there's no open price ranges, every wick is
touching previous wicks. So we have this wick pushed up, touch this wick, we pull back down, we
have these wicks being filled by these wicks, but then we have a push down and we have a gap
here where the wick is not meeting the wick.
So that is basically going to create our imbalance making this the high probability point to sell
from. And to show you that in action that's the kind of movement we would expect, a fill of the
imbalance and a push to the downside. And a rule that goes alongside that is of course that a
zone is only really good on its first tap-in.
So here we of course had the first tap-in at this point. So we created supply, pushed down, pulled
back and then sold off. However, if the market was to come back into this supply zone again we
wouldn't want to trust that for a trade because it's already been hit.
And basically what we're looking for is for the supply zone to absorb all of the new sell orders and
drive lower like the one we're currently looking at. We have supply, the market has pulled back,
filled imbalance. As soon as we hit supply we absorb all the selling orders, new sell orders that
come into the market, we go and make a new low.
Which means this supply zone is pretty much redundant now. The actions we would then want to
take would be to start looking at the next imbalanced supply zones, for example maybe like this
one. But if the market was to return to that supply zone again, so if we came up to here, we
definitely wouldn't want to look for another sell.
The more times a supply zone is hit, even if it doesn't break the first time, the more likely it is that
soon it's going to break through and actually go the other way. So let's take a look what happens
next. Not 100% sure on this one but we can definitely take a look at that.
We can see that if the market comes up to this level we don't want to sell there again because
there is a high likelihood, as you can see there, that the market's going to go through it. So
although we had this supply zone prepped up, we had the first trade which would have been a
great trade, but then the second tap, we don't want to sell here. This is not likely to get us into
new lows, as you can see it didn't do that.
Third tap, we don't want to sell there. Fourth tap, we don't want to sell there. And then on the fifth
tap it actually breaks through.
So a supply zone is only really good for its first retest. After that, ignore it. And the same goes for
demand.
If we're in a buying example, of course, we only want to use the first tap of a demand zone. Then
we move on to other zones to validate next trades because the more times that demand zone is
remet, it's essentially showing us that the buying pressure is not strong in here anymore and it's
showing us sellers are really attempting to push this lower and eventually they will likely win. So
crucial tips to remember when trading supply and demand.
Always trade it in line with the trend. Only trade imbalanced zones, so any zones that aren't
imbalanced are not worth trading. And only trade the first tap of a zone.
If a zone has been hit three, four, five times, do not trade it. It will likely break. Okay, now that
we've covered all that, I want to talk about different zones.
So we're going to talk about extreme zones first of all, and then how to approach multiple zones.
So this market is down trending. Okay, we had a break of structure here.
The market has created a new lower low at this price point. Say we want to sell this. How are we
going to select which zone to sell from? First, we can follow the rule of imbalance.
We say we want to see imbalances into a supply zone, otherwise there is no reason to take a
trade from that point. If we take a look anywhere, pretty much from the top of the movement down
to here, we can see there is no remaining imbalanced zones inside of this price move. So every
single one of these zones here has been retested by a wick.
There is no candle where the wicks to wicks are not meeting each other, therefore there is no
imbalance. Okay, now there was some slight imbalance created here, but we see that the market
filled that range and retested just here. So all imbalance before this point is filled.
There is no imbalance ahead of this level. That's going to lead us to look at this area just here,
and in here there are two areas that we could look at as our trade entry to sell. The first is this
one at the top, this indecision candle before this impulsive move down.
This is what we call the extreme zone. Now, an extreme zone is simply the furthest zone from
price in the existing leg of movement. So if there was an imbalanced zone up here, being within
this leg of movement, from the top down to the bottom, the extreme zone would be whichever the
furthest one from where price currently is, is up here.
However, there isn't any imbalanced areas up here. So the furthest zone from price inside of this
existing leg of price action, from this point right now, is going to be this one that we've drawn the
red arrow to, because this is the final imbalance zone. Therefore, basically, if the market gets
past this, we can expect, because there's no real supply anywhere in here, that the market has a
pretty good likelihood of actually just moving into new highs.
So if we're looking for the highest probability place to sell from, we can do that from just here.
Now there is, of course, a level just beneath as well. It's going to be this little bit of indecision
before the continued sell-off.
Now, it's not really the greatest supply zone, and what we still have here is imbalance above,
which is pretty clear, which leads us through to a pretty significant point, being that extreme zone.
So in an example like this, we would definitely want to focus on this zone over this zone.
However, that's not to say that we have to completely write off any possibility of finding a position
from this lower zone.
We could still maybe see the market flip. So what we can do inside of any zones, when we have
a situation where there are multiple zones, is we can use what we call a standard confirmation or
a confirmation entry. That's going to be a pattern like what you see here, which is basically where
we're looking for a lower time frame structural shift, and then if the market goes from creating
higher highs and higher lows inside of this existing trend, for example, where we start here,
create a high, higher low, higher high.
If we trended up like this and then we had a shift in this higher high, higher low structure into a
lower low here, then we would use fractal supply zones to sell again. Then we could use this
area, a supply zone inside of the smaller price section here, to actually get an execution to take
the market down. So if we approach it this way, basically if the market confirms a reversal in here,
we get a trade.
If it doesn't confirm a reversal, so if the market just comes up and goes straight through, then
because we waited on that confirmation, we actually don't take a loss. We just don't take any
trade at all because it hasn't confirmed. So the extreme zone is the highest probability point to
sell from or buy from when it comes to supply and demand.
We would be happy in this instance then to place a sell order in the terms of a sell limit at this
level. If you're going to be placing sell limits and buy limits, the best place to do that is at extreme
zones. And if you're going to be approaching the market with confirmation or you're approaching
a market that has multiple potential zones, then you're going to want to use confirmation on pretty
much all of them except the extreme zone.
Now when we see the market come up into this area, we do however get a confirmation entry.
And I want to walk you through it now so you can see what it looks like in the real markets. So
we're going to remove that for now, the hypothetical sell limit idea, and we'll take a look at this
structure that we have right here.
We've hit the supply zone just there which gives us what we want to see to have confidence and
clarity to start selling. Now the confirmation entry has actually arisen inside of this price action. So
if we mark the low to the high to the low, this is going to be our trending structure right now.
We then have basically smaller trending price action like that. This is the kind of trend that we
have. By marking the highs and lows of this bullish movement, we're then basically looking for
this to shift bearish to provide us confirmation to sell into this market.
Now as we can see then, our swing lows or our higher lows are going to be pretty much at this
point here and then a more significant one will be this one here. Now we can see with this bearish
candle, we've had a closure beneath both of these lows. So what this actually does is allow us to
sell into this because we are seeing with the formation of this lower low that we've just got here,
we are seeing the market shifting to bearish, to a selling setting.
We're seeing it shift to a downtrend which agrees with the high time frame narrative of of course
this bearish trend idea. So what we do here by bringing this in is actually use kind of the big
picture and then a more refined smaller picture to build a scenario in the market where the high
and the low time frames are in complete agreement. When we have that, we can sell with
confidence because now we know the high time frame is telling us the market is bearish.
The low time frame has also now agreed and told us the market is bearish. We actually use
supply and demand here in a fractal nature. So fractal essentially means the same patterns will
form on all different time frames.
They will form in all different scenarios regardless of whether you're looking at the daily, the
weekly, regardless of whether you're looking at the high time frame, zoomed out price action or
the more refined zoomed in price action, it's all going to work the same. So the big picture trend
which is going to be this one that we're looking at, this is bearish and we have our supply zone
which we wanted to sell from. Now the smaller picture trend which is going to be this one here
has also now shifted bearish and what it's done in doing so is provide us with a supply zone to
sell from.
Now the supply zone in question here is the last indecision candle before the impulse away. Very
simple stuff. That means we can therefore place our sell limit on this area, target down into the
low or wherever we want this to go to and for this we don't have to put the stop over this swing
high because we have new confirmations inside of this structure.
So we can actually put our stop loss over this high and that's going to provide a very safe trade
as well but this time we have that kind of double confirmation. We've had that shift standard
confirmation here, we've sold on this retest here and now we'd be looking for the from supply
once and then reacted from the second supply providing two supply reactions and as you can
see that is exactly what happens. So in a general market scenario you want to focus primarily on
the extreme zone which is going to be the last imbalanced candle in this leg of price action.
For this scenario it's this one here. If there are other zones to focus on such as this one here then
the best way to approach these if you want to focus on these zones at all is to go in with standard
confirmation which as you've just seen is actually what we've got going on here. This pattern of
shifting from higher highs and higher lows into a lower low and then pulling back and selling from
supply can be utilized not only from the extreme zones but from these smaller zones within.
If you see this pattern formulating in one of the other zones in a scenario where there are multiple
supply zones to choose from then that can give you the confirmation you want in order to a trade
that is likely to win. But if there is no confirmation such as there wasn't any in this zone then you
simply avoid taking the trade meaning in most cases you're going to avoid taking a loss and then
you can take your trades comfortably from the extreme zone or if you really want to you can use
that confirmation from there anyway and that a lot of the times is going to provide you with a good
entry to get in. But I just want to give you a warning, confirmation entries while they are very very
strong are not going to happen all of the time.
If we take a look back at the price action here, I'll jump it back just to show you. At this point our
extreme zone was this candle here, this indecision candle. We had this big push to the downside,
we have no imbalances above, we have no other zones left open, so our extreme zone is the one
that we are looking at just here.
If you were going to wait for a confirmation from this zone you would then want to see the market
pull in and make a shift in structure like this that would allow you to get into a trade. However as
you will see and as you may have already seen there was no confirmation given. In fact the
confirmation for this trade is actually going to be when the market returns all the way to this
supply.
But this is going to mean you're not able to profit on this entire move down, you're going to have
to wait for the pullback to get it. So essentially that becomes a missed opportunity. So you can
avoid that from happening if you focus on extreme zones as I say sell and buy limits most of the
time are going to be good from these.
It's not always going to work, sometimes the market will flip on you, but the risk reward you can
get from these, if you sold this extreme zone, stop above the zone, target down into wherever you
wanted to go, you've got potential 5%, 6%, 7% trades coming in here, which means even if
there's only one half of the time you're making a significant profit overall due to the fact that every
time you risk $100 you're making $700 in return. So they stack up from a risk reward perspective
but that confirmation entry is a really solid way to number one double confirm the trades if you
really feel like you need it. So you know getting in from around this point after this market
confirmation has occurred and number two you can use this if you're not trading from the extreme
zone and if you're looking at a more refined zone as well.
So that is kind of how you differentiate between multiple zones. The extreme zone is always the
highest probability, the highest reward, the most favorable zone to buy or sell from, but if there
are other areas that you might want to look at just go out.
This file is longer than 30 minutes.
Go Unlimited
at https://turboscribe.ai/
to transcribe files up to 10 hours long.