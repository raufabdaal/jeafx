# Sovereign Price-Action & Algorithmic Trading Engine
## Master Logic Specification & Rule Book (Version 1.0)

---

## Section 1: System Definitions & Numerical Thresholds

All qualitative concepts are converted into objective, measurable formulas for precise programmatic execution:

*   **1.1 ATR (Average True Range):** Calculated on the execution timeframe using a 14-period setting ($\text{ATR}_{14}$).
*   **1.2 Impulsive Candle / Move:**
    *   A candle whose total body range ($\text{Abs}[\text{Close} - \text{Open}]$) is greater than or equal to **$1.8 \times \text{ATR}_{14}$**.
    *   An impulsive leg consists of at least 2 consecutive directional candles expanding in the direction of the trend.
*   **1.3 Indecision Candle (Base):**
    *   A candle where the body accounts for **$\le 35\%$** of the total High-to-Low range.
    *   Upper and lower wicks must each account for at least **$25\%$** of the total range.
*   **1.4 Unfilled Imbalance (Fair Value Gap / FVG):**
    *   **Bullish Imbalance:** Formed across a 3-candle sequence where $\text{Low}_{\text{Candle 3}} - \text{High}_{\text{Candle 1}} \ge 0.5 \times \text{ATR}_{14}$.
    *   **Bearish Imbalance:** Formed across a 3-candle sequence where $\text{Low}_{\text{Candle 1}} - \text{High}_{\text{Candle 3}} \ge 0.5 \times \text{ATR}_{14}$.
    *   **Fill Condition:** If intervening price wicks penetrate or overlap this gap, the imbalance is marked as *Filled/Invalid*.
*   **1.5 Market Structure Shift (MSS) vs. Liquidity Sweep:**
    *   **MSS (Confirmed Break):** A candle-body **Close** beyond the previous structural Swing High or Swing Low.
    *   **Liquidity Sweep (Rejection):** A candle **Wick** that pierces beyond a Swing High/Low or Equal Highs/Lows but **Closes back inside** the original range.

---

## Section 2: Timeframe Hierarchy & Execution Workflow

The algorithm operates on a strict top-down structure:

```
┌─────────────────────────────────────────────────────────────────┐
│  1. HIGHER TIMEFRAME (4-Hour / 1-Hour)                         │
│     • Identifies Directional Bias (Uptrend vs. Downtrend)       │
│     • Maps Major Supply / Demand Zones & Unfilled Imbalances    │
└────────────────────────────────┬────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│  2. INTERMEDIATE TIMEFRAME (15-Minute)                          │
│     • Monitors price approach to HTF Points of Interest (POIs)  │
│     • Confirms Liquidity Sweeps of internal/session extremes    │
└────────────────────────────────┬────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│  3. EXECUTION TIMEFRAME (5-Minute / 1-Minute)                   │
│     • Triggers on LTF Market Structure Shift (MSS Close)        │
│     • Enters on 50% retrace of newly formed LTF Order Block     │
└─────────────────────────────────────────────────────────────────┘
```

*   **2.1 Higher-Timeframe (HTF) Trend Rules:**
    *   **Uptrend:** Sequence of higher highs ($\text{HH}$) and higher lows ($\text{HL}$). The bot **ONLY** looks for Demand buys.
    *   **Downtrend:** Sequence of lower lows ($\text{LL}$) and lower highs ($\text{LH}$). The bot **ONLY** looks for Supply sells.
    *   **Consolidation Filter:** If price action remains within a historical range without forming a new $\text{HH}$ or $\text{LL}$ for 20+ candles, trading is suspended until a confirmed MSS occurs.

---

## Section 3: Zone Construction & Selection Engine

*   **3.1 Supply & Demand Zone Marking:**
    *   **Demand Zone:** The last **Indecision Candle** (or consolidation base) immediately preceding an **Impulsive Bullish Move** ($1.8 \times \text{ATR}_{14}$).
    *   **Supply Zone:** The last **Indecision Candle** (or consolidation base) immediately preceding an **Impulsive Bearish Move** ($1.8 \times \text{ATR}_{14}$).
    *   **Boundaries:** The zone boundaries cover the extreme High to extreme Low (including all wicks) of the base candle(s).
*   **3.2 Zone Freshness & Retest Filter:**
    *   A zone is classified as **Fresh (Valid)** if price has touched it **0 times** since its creation.
    *   **Tap/Retest Rule:** The moment a price wick touches or enters the boundary of a zone, its status changes to **Used/Invalid**. The bot will **never** re-enter on a second or third tap of the same zone.
*   **3.3 Extreme Zone Priority Algorithm:**
    *   If multiple valid zones exist within a single swing leg, the algorithm ranks them by proximity to the swing extreme.
    *   The bot selects the **Extreme Zone** (the furthest valid zone from the current market price that still possesses an **Unfilled Imbalance**).

---

## Section 4: Exact Entry, Confirmation, & Trade Execution Rules

The algorithm uses a strict "If-Then-Else" confirmation sequence before placing an order:

```
IF (Time is within London/NY Session Window)
  AND (Current Broker Spread <= 1.5 Pips)
  AND (Price reaches a Fresh HTF Supply/Demand Zone)
THEN:
  1. Wait for LTF Market Structure Shift (MSS Close on 5M/1M).
  2. Mark the new LTF Order Block created by the MSS impulse.
  3. Place a Limit Order at the 50% Equilibrium level of the LTF OB.
```

*   **4.1 Session Time Window Filter:**
    *   **London Session Window:** 07:00 GMT – 10:30 GMT
    *   **New York Session Window:** 12:30 GMT – 16:00 GMT
    *   *Rule:* No new entries are placed outside these windows. Existing open trades are held or managed normally.
*   **4.2 Spread & Slippage Protection:**
    *   `IF Current_Spread > 1.5 Pips THEN NO_TRADE`. (Prevents trade entries during news releases or Asian session closes).
*   **4.3 Confirmation Entry Algorithm (Long Example):**
    1. HTF trend is Bullish. Price pulls back into a fresh 1H Demand Zone containing an unfilled FVG.
    2. Step down to 5M timeframe: Wait for price to sweep an internal low and execute a candle-body **Close above** the last 5M swing high (MSS).
    3. Identify the 5M Indecision Candle that caused the shift.
    4. Place a **Buy Limit Order** at the top or 50% midpoint of that 5M zone.
*   **4.4 Direct Limit Exception (Extreme Zones):**
    *   If price arrives at an **Extreme HTF Zone** during peak session hours with high momentum, a direct Limit Order may be set without LTF confirmation, provided the Stop Loss covers the extreme HTF wick.

---

## Section 5: Systematic Risk Management & Capital Rules

*   **5.1 Account Risk Per Trade:**
    *   Strictly **0.5% to 1.0%** of total account balance per trade.
*   **5.2 Dynamic Lot Size Formula:**
    $$\text{Lot Size} = \frac{\text{Account Balance} \times \text{Risk \%}}{(\text{Entry Price} - \text{Stop Loss Price in Pips}) \times \text{Pip Value}}$$
*   **5.3 Stop Loss (SL) Placement & Invalidation:**
    *   **Long Trades:** Set SL **$2.0 \times \text{Spread}$ + 2.0 Pips** below the absolute low of the entry zone/structural pivot.
    *   **Short Trades:** Set SL **$2.0 \times \text{Spread}$ + 2.0 Pips** above the absolute high of the entry zone/structural pivot.
    *   *Rule:* Never move a Stop Loss wider once a trade is active.
*   **5.4 Take Profit (TP) & Risk-to-Reward (R:R) Rules:**
    *   **Minimum Target:** **1:3 Risk-to-Reward (3R)**. If the logical market target (e.g., opposing major liquidity pool or HTF zone) offers less than 3R, **the trade is automatically rejected**.
    *   **Partial Take Profit:** Take 50% volume off at 2R; move Stop Loss to Breakeven ($\text{Entry Price}$).
    *   **Final Target:** Remaining 50% position runs to the opposite HTF Supply/Demand zone or equal highs/lows.
*   **5.5 Hard Daily Loss Circuit Breaker:**
    *   `IF Daily_Realized_Loss >= 3.0% THEN SUSPEND_TRADING_FOR_24_HOURS`. (Protects against prop firm daily drawdown limits).
```
eof

I have generated the markdown file containing your complete **Sovereign Price-Action & Algorithmic Specification Rule Book**. 

You can copy this document directly or hand it off to an MQL5 developer or code generation agent to begin building the initial Expert Advisor script. Would you like to write the first MQL5 code module (e.g., the ATR & Imbalance Indicator logic) next?