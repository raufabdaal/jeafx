//+------------------------------------------------------------------+
//|                                                   SPA_Config.mqh |
//|      Sovereign Price-Action EA — symbol profiles & configuration  |
//|      SPEC-001 v0.2.0  §7.3                                        |
//|                                                                   |
//|  Loads data/symbol_profiles.csv and resolves the most specific    |
//|  profile for the chart symbol (exact > prefix wildcard > "*").    |
//+------------------------------------------------------------------+
#ifndef __SPA_CONFIG_MQH__
#define __SPA_CONFIG_MQH__

//--- entry arithmetic mode (Decision Q4) -----------------------------
enum ENUM_SPA_ENTRY_MODE
  {
   SPA_ENTRY_BOUNDARY = 0,   // JeaFX-faithful: proximal zone edge
   SPA_ENTRY_MIDPOINT = 1    // 50% refinement (Rule Book 4.3)
  };

//--- liquidity window mode (Decision Q3) -----------------------------
enum ENUM_SPA_WINDOW_MODE
  {
   SPA_WINDOW_DYNAMIC = 0,   // empirical hour-of-day volume percentile (default)
   SPA_WINDOW_FIXED   = 1,   // Rule Book 4.1 GMT windows — A/B testing only
   SPA_WINDOW_OFF     = 2    // no window filter — diagnostic only, never live
  };

//+------------------------------------------------------------------+
//| One row of the profile table.                                     |
//| Every field is overrideable from the EA Inputs tab at run time.    |
//+------------------------------------------------------------------+
struct SpaProfile
  {
   string               pattern;
   string               asset_class;
   double               pip_size;            // 0 = auto-derive
   ENUM_TIMEFRAMES      tf_bias;
   ENUM_TIMEFRAMES      tf_confirm;
   ENUM_TIMEFRAMES      tf_exec;
   double               risk_pct;            // R-01
   double               spread_pips_ceiling; // R-10a (coarse, pip-denominated)
   double               max_spread_of_risk;  // R-10b (spread as fraction of SL distance)
   double               min_atr_floor_atr;   // dead-market guard
   double               liquidity_pct_min;   // §7.2 window strength
   int                  swing_k;             // D-08
   double               sl_spread_mult;      // R-04
   double               sl_buffer_atr;       // R-04 floor
   double               min_rr;              // R-06
   double               max_zone_width_atr;  // §4.2
   ENUM_SPA_ENTRY_MODE  entry_mode;
   bool                 enabled;
  };

//+------------------------------------------------------------------+
//| Hard-coded safety defaults. Used ONLY if a profile cannot load.   |
//| Deliberately conservative: disabled + minimum risk.               |
//+------------------------------------------------------------------+
void SpaProfileDefaults(SpaProfile &p)
  {
   p.pattern             = "*";
   p.asset_class         = "DEFAULT";
   p.pip_size            = 0.0;
   p.tf_bias             = PERIOD_H4;
   p.tf_confirm          = PERIOD_M15;
   p.tf_exec             = PERIOD_M5;
   p.risk_pct            = 0.25;
   p.spread_pips_ceiling = 3.0;
   p.max_spread_of_risk  = 0.20;
   p.min_atr_floor_atr   = 0.65;
   p.liquidity_pct_min   = 50.0;
   p.swing_k             = 2;
   p.sl_spread_mult      = 2.0;
   p.sl_buffer_atr       = 0.15;
   p.min_rr              = 3.5;
   p.max_zone_width_atr  = 1.5;
   p.entry_mode          = SPA_ENTRY_BOUNDARY;
   p.enabled             = false;   // fail closed
  }

//+------------------------------------------------------------------+
//| Profile table                                                     |
//+------------------------------------------------------------------+
class CSpaProfiles
  {
private:
   SpaProfile        m_rows[];
   int               m_count;
   string            m_last_error;

   //--- timeframe string -> enum (MQL5 has no StringToEnum) --------
   ENUM_TIMEFRAMES   ParseTF(const string s)
     {
      string u = s;
      StringToUpper(u);
      if(u=="PERIOD_M1")  return(PERIOD_M1);
      if(u=="PERIOD_M5")  return(PERIOD_M5);
      if(u=="PERIOD_M15") return(PERIOD_M15);
      if(u=="PERIOD_M30") return(PERIOD_M30);
      if(u=="PERIOD_H1")  return(PERIOD_H1);
      if(u=="PERIOD_H4")  return(PERIOD_H4);
      if(u=="PERIOD_D1")  return(PERIOD_D1);
      if(u=="PERIOD_W1")  return(PERIOD_W1);
      return(PERIOD_CURRENT);
     }

   bool              ParseBool(const string s)
     {
      return(s=="1" || s=="true" || s=="TRUE" || s=="yes");
     }

   double            ParseD(const string s)
     {
      return(StringToDouble(s));
     }

   //--- wildcard match: "EURUSD*" -> prefix ; "*" -> all -----------
   bool              Match(const string pattern,const string symbol)
     {
      string p = pattern;
      string s = symbol;
      StringToUpper(p);
      StringToUpper(s);
      int len = StringLen(p);
      if(len==0)
         return(false);
      if(p=="*")
         return(true);
      if(StringGetCharacter(p,len-1)=='*')
        {
         string head = StringSubstr(p,0,len-1);
         return(StringFind(s,head)==0);
        }
      return(p==s);
     }

   //--- specificity score: exact 3, prefix 2, "*" 1, none 0 --------
   int               Specificity(const string pattern,const string symbol)
     {
      if(!Match(pattern,symbol))
         return(0);
      if(pattern=="*")
         return(1);
      if(StringGetCharacter(pattern,StringLen(pattern)-1)=='*')
         return(2);
      return(3);
     }

public:
                     CSpaProfiles(): m_count(0), m_last_error("") {}
   string            LastError() const { return(m_last_error); }
   int               Count()     const { return(m_count); }

   //--- Load CSV. Tries shared folder first, then terminal folder. --
   bool              Load(const string filename="symbol_profiles.csv")
     {
      m_count = 0;
      ArrayResize(m_rows,0);
      m_last_error = "";

      int h = FileOpen(filename,FILE_READ|FILE_TXT|FILE_ANSI|FILE_COMMON);
      if(h==INVALID_HANDLE)
         h = FileOpen(filename,FILE_READ|FILE_TXT|FILE_ANSI);
      if(h==INVALID_HANDLE)
        {
         int err = GetLastError();
         m_last_error = StringFormat("cannot open '%s' (err %d) - place the file in "
                                     "MQL5/Files (or Common\\Files)",filename,err);
         return(false);
        }

      int    line_no = 0;
      string line    = "";

      while(!FileIsEnding(h))
        {
         line = FileReadString(h);
         line_no++;
         StringTrimLeft(line);
         StringTrimRight(line);

         //--- skip blanks, comments, header -------------------------
         if(StringLen(line)<10)
            continue;
         if(StringGetCharacter(line,0)=='#')
            continue;
         if(StringFind(line,"symbol_pattern")>=0)
            continue;

         string parts[];
         int n = StringSplit(line,',',parts);
         if(n<18)
           {
            m_last_error = StringFormat("line %d: expected 18 columns, got %d",line_no,n);
            continue;
           }
         for(int i=0;i<n;i++)
           {
            StringTrimLeft(parts[i]);
            StringTrimRight(parts[i]);
           }

         SpaProfile p;
         SpaProfileDefaults(p);
         p.pattern             = parts[0];
         p.asset_class         = parts[1];
         p.pip_size            = ParseD(parts[2]);
         p.tf_bias             = ParseTF(parts[3]);
         p.tf_confirm          = ParseTF(parts[4]);
         p.tf_exec             = ParseTF(parts[5]);
         p.risk_pct            = ParseD(parts[6]);
         p.spread_pips_ceiling = ParseD(parts[7]);
         p.max_spread_of_risk  = ParseD(parts[8]);
         p.min_atr_floor_atr   = ParseD(parts[9]);
         p.liquidity_pct_min   = ParseD(parts[10]);
         p.swing_k             = (int)ParseD(parts[11]);
         p.sl_spread_mult      = ParseD(parts[12]);
         p.sl_buffer_atr       = ParseD(parts[13]);
         p.min_rr              = ParseD(parts[14]);
         p.max_zone_width_atr  = ParseD(parts[15]);
         StringToUpper(parts[16]);
         p.entry_mode          = (parts[16]=="MIDPOINT") ? SPA_ENTRY_MIDPOINT : SPA_ENTRY_BOUNDARY;
         p.enabled             = ParseBool(parts[17]);

         ArrayResize(m_rows,m_count+1);
         m_rows[m_count] = p;
         m_count++;
        }
      FileClose(h);

      if(m_count==0)
        {
         m_last_error = "profile file contained no valid rows";
         return(false);
        }
      return(true);
     }

   //--- Resolve most specific profile for a symbol ----------------
   bool              Resolve(const string symbol,SpaProfile &out)
     {
      int best_score = 0;
      int best_idx   = -1;
      for(int i=0;i<m_count;i++)
        {
         int sc = Specificity(m_rows[i].pattern,symbol);
         if(sc>best_score)
           {
            best_score = sc;
            best_idx   = i;
           }
        }
      if(best_idx<0)
         return(false);
      out = m_rows[best_idx];
      return(true);
     }

   //--- diagnostics ------------------------------------------------
   bool              Get(int i,SpaProfile &out)
     {
      if(i<0||i>=m_count)
         return(false);
      out = m_rows[i];
      return(true);
     }
  };

#endif // __SPA_CONFIG_MQH__
//+------------------------------------------------------------------+
