//+------------------------------------------------------------------+
//|                                                SPA_Structure.mqh |
//|   Sovereign Price-Action EA - market structure engine             |
//|   SPEC-001 v0.4.0  (D-08, D-09, D-10, D-14, RB 2.1)               |
//|                                                                   |
//|   WHAT THIS MODULE ANSWERS                                         |
//|     1. Where are the swing highs and lows?                         |
//|     2. Which way is the market actually going? (HH/HL vs LL/LH)    |
//|     3. Has a level been BROKEN (body close) or SWEPT (wick)?       |
//|     4. Is the current break a real shift, or noise inside a        |
//|        corrective leg?                                             |
//|     5. Is the market consolidating (no new extreme for N bars)?    |
//|                                                                   |
//|   VERIFICATION                                                     |
//|   The arithmetic in this file mirrors tests/spa_structure_ref.py   |
//|   one-for-one. 17 unit tests pass against hand-built price series. |
//|   Any divergence between these two files is a release blocker.     |
//|                                                                   |
//|   ARRAY CONVENTION                                                 |
//|   Data is copied CHRONOLOGICALLY: index 0 = oldest closed bar,     |
//|   index m_n-1 = most recent closed bar. This matches the Python    |
//|   reference exactly. The forming bar is excluded at copy time      |
//|   (start_pos = 1), which is what makes the engine non-repainting.  |
//+------------------------------------------------------------------+
#ifndef __SPA_STRUCTURE_MQH__
#define __SPA_STRUCTURE_MQH__

//--- trend classification (RB 2.1)
enum ENUM_SPA_TREND
  {
   SPA_TREND_UP   = 0,   // higher highs AND higher lows
   SPA_TREND_DOWN = 1,   // lower highs AND lower lows
   SPA_TREND_RANGE= 2    // anything else - do not trade
  };

//--- how a level resolved (D-09 vs D-10)
enum ENUM_SPA_RESOLUTION
  {
   SPA_RES_NONE  = 0,    // level still untested
   SPA_RES_BOS   = 1,    // candle BODY closed beyond the level
   SPA_RES_SWEEP = 2     // wick pierced, closed back inside
  };

//+------------------------------------------------------------------+
struct SpaPivot
  {
   int      idx;          // chronological index of the pivot bar
   double   price;
   bool     is_high;
   string   label;        // H / L / HH / HL / LH / LL
   datetime time;
  };

//+------------------------------------------------------------------+
class CSpaStructure
  {
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;
   double            m_min_swing_atr;  // significance threshold (x ATR)
   int               m_atr_period;     // Wilder ATR period
   double            m_atr;            // ATR at the most recent closed bar
   int               m_bars;           // history depth requested
   int               m_consol_bars;    // consolidation threshold

//--- chronological price arrays (index 0 = oldest closed bar) -----
   double            m_h[];
   double            m_l[];
   double            m_o[];
   double            m_c[];
   datetime          m_t[];
   int               m_n;              // number of closed bars actually held

//--- results ------------------------------------------------------
   SpaPivot          m_pivots[];
   int               m_pivot_count;
   ENUM_SPA_TREND    m_trend;
   int               m_bars_since_extreme;
   bool              m_ready;
   datetime          m_last_bar_time;
   string            m_last_error;

   void              AddPivot(const int idx,const double price,const bool is_high)
     {
      ArrayResize(m_pivots,m_pivot_count+1);
      m_pivots[m_pivot_count].idx     = idx;
      m_pivots[m_pivot_count].price   = price;
      m_pivots[m_pivot_count].is_high = is_high;
      m_pivots[m_pivot_count].label   = is_high ? "H" : "L";
      m_pivots[m_pivot_count].time    = (idx>=0 && idx<m_n) ? m_t[idx] : 0;
      m_pivot_count++;
     }

   //----------------------------------------------------------------+
   //| Wilder ATR over the closed-bar series held in this object.    |
   //| Computed by hand rather than via iATR() so the structure      |
   //| engine has no indicator-handle dependency at all.             |
   //----------------------------------------------------------------+
   double            WilderATR()
     {
      if(m_n<m_atr_period+1)
         return(0.0);

      double atr = 0.0;
      for(int i=1;i<=m_atr_period;i++)
        {
         double tr = m_h[i]-m_l[i];
         double a  = MathAbs(m_h[i]-m_c[i-1]);
         double b  = MathAbs(m_l[i]-m_c[i-1]);
         if(a>tr) tr = a;
         if(b>tr) tr = b;
         atr += tr;
        }
      atr /= (double)m_atr_period;

      for(int i=m_atr_period+1;i<m_n;i++)
        {
         double tr = m_h[i]-m_l[i];
         double a  = MathAbs(m_h[i]-m_c[i-1]);
         double b  = MathAbs(m_l[i]-m_c[i-1]);
         if(a>tr) tr = a;
         if(b>tr) tr = b;
         atr = (atr*(double)(m_atr_period-1)+tr)/(double)m_atr_period;
        }
      return(atr);
     }

   //----------------------------------------------------------------+
   //| D-08b : significance-filtered swing detection (ATR-ZigZag).   |
   //|                                                               |
   //| A k=2 fractal fires on ANY local extremum - on M5 that was a  |
   //| pivot every ~4 bars, i.e. every minor wiggle, which is not    |
   //| market structure. This detector demands that price actually   |
   //| GO somewhere before the swing is recorded: a pivot is emitted |
   //| only once price has retraced at least                       |
   //|     m_min_swing_atr x ATR                                     |
   //| from the extreme.                                             |
   //|                                                               |
   //| NON-REPAINTING: the still-running extreme is never emitted;   |
   //| only the retrace that CONFIRMS a swing can create one.        |
   //|                                                               |
   //| Mirrored one-for-one in tests/spa_structure_ref.py            |
   //| (find_pivots_zigzag) and covered by 6 unit tests.             |
   //----------------------------------------------------------------+
   void              BuildPivotsZigZag()
     {
      if(m_n<3 || m_atr<=0.0 || m_min_swing_atr<=0.0)
         return;

      double th = m_min_swing_atr*m_atr;

      int    hi_i = 0,     lo_i = 0;
      double hi_p = m_h[0], lo_p = m_l[0];
      int    dir  = 0;                 // +1 up-leg, -1 down-leg, 0 undecided

      for(int i=1;i<m_n;i++)
        {
         if(dir==0)
           {
            if(m_h[i]>hi_p) { hi_i=i; hi_p=m_h[i]; }
            if(m_l[i]<lo_p) { lo_i=i; lo_p=m_l[i]; }
            if(hi_p-lo_p>=th)
              {
               //--- whichever extreme printed LAST defines the open leg
               if(hi_i>lo_i)
                 {
                  AddPivot(lo_i,lo_p,false);
                  dir=1;  hi_i=i; hi_p=m_h[i];
                 }
               else
                 {
                  AddPivot(hi_i,hi_p,true);
                  dir=-1; lo_i=i; lo_p=m_l[i];
                 }
              }
            continue;
           }

         if(dir==1)
           {
            if(m_h[i]>hi_p) { hi_i=i; hi_p=m_h[i]; }
            if(hi_p-m_l[i]>=th)
              {
               AddPivot(hi_i,hi_p,true);
               dir=-1; lo_i=i; lo_p=m_l[i];
              }
           }
         else
           {
            if(m_l[i]<lo_p) { lo_i=i; lo_p=m_l[i]; }
            if(m_h[i]-lo_p>=th)
              {
               AddPivot(lo_i,lo_p,false);
               dir=1;  hi_i=i; hi_p=m_h[i];
              }
           }
        }
     }

   //----------------------------------------------------------------+
   //| Trend from the last two highs and last two lows (RB 2.1).     |
   //| Deliberately uses RAW pivots - see the warning below.         |
   //----------------------------------------------------------------+
   ENUM_SPA_TREND    ComputeTrend()
     {
      int hi[2], lo[2];
      int hc = 0, lc = 0;

      for(int i=m_pivot_count-1;i>=0 && (hc<2 || lc<2);i--)
        {
         if(m_pivots[i].is_high)
           {
            if(hc<2) { hi[hc]=i; hc++; }
           }
         else
           {
            if(lc<2) { lo[lc]=i; lc++; }
           }
        }
      if(hc<2 || lc<2)
         return(SPA_TREND_RANGE);

      //--- hi[0] = most recent high, hi[1] = the one before it -----
      double h_new = m_pivots[hi[0]].price, h_old = m_pivots[hi[1]].price;
      double l_new = m_pivots[lo[0]].price, l_old = m_pivots[lo[1]].price;

      if(h_new>h_old && l_new>l_old) return(SPA_TREND_UP);
      if(h_new<h_old && l_new<l_old) return(SPA_TREND_DOWN);
      return(SPA_TREND_RANGE);
     }

   //----------------------------------------------------------------+
   //| Bars since the most recent pivot that set a NEW extreme.      |
   //| Input to the RB 2.1 consolidation suspension.                 |
   //----------------------------------------------------------------+
   int               ComputeBarsSinceExtreme()
     {
      int last_extreme = -1;
      double prev_high = 0.0, prev_low = 0.0;
      bool   have_high = false, have_low = false;

      for(int i=0;i<m_pivot_count;i++)
        {
         if(m_pivots[i].is_high)
           {
            if(have_high && m_pivots[i].price>prev_high)
               last_extreme = m_pivots[i].idx;
            prev_high = m_pivots[i].price;
            have_high = true;
           }
         else
           {
            if(have_low && m_pivots[i].price<prev_low)
               last_extreme = m_pivots[i].idx;
            prev_low = m_pivots[i].price;
            have_low = true;
           }
        }
      if(last_extreme<0)
         return(m_n);
      return((m_n-1)-last_extreme);
     }

public:
                     CSpaStructure(): m_symbol(""), m_tf(PERIOD_CURRENT), m_min_swing_atr(4.0),
                                      m_atr_period(14), m_atr(0.0), m_bars(600),
                                      m_consol_bars(20), m_n(0), m_pivot_count(0),
                                      m_trend(SPA_TREND_RANGE), m_bars_since_extreme(0),
                                      m_ready(false), m_last_bar_time(0), m_last_error("") {}

   //----------------------------------------------------------------+
   bool              Init(const string symbol,const ENUM_TIMEFRAMES tf,
                          const double min_swing_atr,const int bars,
                          const int consolidation_bars)
     {
      m_symbol        = symbol;
      m_tf            = tf;
      m_min_swing_atr = (min_swing_atr<0.5) ? 0.5 : min_swing_atr;
      m_bars          = (bars<100) ? 100 : bars;
      m_consol_bars   = consolidation_bars;
      m_ready         = false;
      m_last_bar_time = 0;
      return(true);
     }

   //----------------------------------------------------------------+
   //| Refresh - recompute from closed bars only.                    |
   //| Cached: recomputation happens at most once per new TF bar.    |
   //----------------------------------------------------------------+
   bool              Refresh()
     {
      datetime cur = iTime(m_symbol,m_tf,0);
      if(m_ready && cur==m_last_bar_time)
         return(true);            // nothing new to do

      m_last_error = "";

      //--- copy CHRONOLOGICAL data, starting at bar 1 (skip forming) -
      //--- as_series = false -> index 0 is the OLDEST bar ------------
      ArraySetAsSeries(m_h,false);
      ArraySetAsSeries(m_l,false);
      ArraySetAsSeries(m_o,false);
      ArraySetAsSeries(m_c,false);
      ArraySetAsSeries(m_t,false);

      int got = CopyHigh(m_symbol,m_tf,1,m_bars,m_h);
      if(got<=0)
        {
         m_last_error = StringFormat("CopyHigh failed (%s %s) err=%d",
                                     m_symbol,EnumToString(m_tf),GetLastError());
         m_ready = false;
         return(false);
        }
      m_n = got;

      if(CopyLow(m_symbol,m_tf,1,m_bars,m_l)!=m_n ||
         CopyOpen(m_symbol,m_tf,1,m_bars,m_o)!=m_n ||
         CopyClose(m_symbol,m_tf,1,m_bars,m_c)!=m_n ||
         CopyTime(m_symbol,m_tf,1,m_bars,m_t)!=m_n)
        {
         m_last_error = StringFormat("price series out of sync (%s %s)",
                                     m_symbol,EnumToString(m_tf));
         m_ready = false;
         return(false);
        }

      //--- 1. pivots (D-08b: significance-filtered) ------------------
      m_pivot_count = 0;
      ArrayResize(m_pivots,0);

      m_atr = WilderATR();
      BuildPivotsZigZag();

      //--- 2. HH / HL / LH / LL labels ------------------------------
      double prev_high = 0.0, prev_low = 0.0;
      bool   have_high = false, have_low = false;
      for(int i=0;i<m_pivot_count;i++)
        {
         if(m_pivots[i].is_high)
           {
            if(!have_high)      m_pivots[i].label = "H";
            else                m_pivots[i].label = (m_pivots[i].price>prev_high) ? "HH" : "LH";
            prev_high = m_pivots[i].price;
            have_high = true;
           }
         else
           {
            if(!have_low)       m_pivots[i].label = "L";
            else                m_pivots[i].label = (m_pivots[i].price>prev_low) ? "HL" : "LL";
            prev_low = m_pivots[i].price;
            have_low = true;
           }
        }

      //--- 3. results ------------------------------------------------
      m_trend              = ComputeTrend();
      m_bars_since_extreme = ComputeBarsSinceExtreme();

      m_ready         = true;
      m_last_bar_time = cur;
      return(true);
     }

   //----------------------------------------------------------------+
   //| Resolve a level: what happened to it FIRST? (D-09 / D-10)     |
   //|   body close beyond  -> BOS                                   |
   //|   wick beyond, close back inside -> SWEEP                     |
   //| Returns SPA_RES_NONE if the level is still untouched.         |
   //----------------------------------------------------------------+
   ENUM_SPA_RESOLUTION ResolveLevel(const int level_idx,const double level_price,
                                    const bool high_side,int &event_idx)
     {
      event_idx = -1;
      for(int j=level_idx+1;j<m_n;j++)
        {
         if(high_side)
           {
            if(m_c[j]>level_price)                       { event_idx=j; return(SPA_RES_BOS);   }
            if(m_h[j]>level_price && m_c[j]<level_price) { event_idx=j; return(SPA_RES_SWEEP); }
           }
         else
           {
            if(m_c[j]<level_price)                       { event_idx=j; return(SPA_RES_BOS);   }
            if(m_l[j]<level_price && m_c[j]>level_price) { event_idx=j; return(SPA_RES_SWEEP); }
           }
        }
      return(SPA_RES_NONE);
     }

   //----------------------------------------------------------------+
   //| D-14 : is a break actually tradable, or is it a correction?    |
   //|                                                               |
   //| A bearish shift is valid ONLY if a HIGHER HIGH printed first   |
   //| and then the last structural low broke on a BODY close.        |
   //| If the preceding high was a LOWER high, the down-move is just  |
   //| a corrective leg inside the uptrend:                          |
   //|                                                               |
   //|   "they will treat this break as a place to sell from... But   |
   //|    it's not, because this in itself is still not a valid       |
   //|    structural move."  - JeaFX                                 |
   //+------------------------------------------------------------------+
   bool              IsValidShift(const bool bearish)
     {
      if(!m_ready || m_pivot_count<3)
         return(false);

      if(bearish)
        {
         //--- did the last high exceed the previous high? -----------
         double h_new = 0.0, h_old = 0.0;
         int    n_h   = 0;
         int    low_idx = -1;
         double low_px  = 0.0;

         for(int i=m_pivot_count-1;i>=0;i--)
           {
            if(m_pivots[i].is_high && n_h<2)
              {
               if(n_h==0) h_new = m_pivots[i].price;
               else       h_old = m_pivots[i].price;
               n_h++;
              }
            if(!m_pivots[i].is_high && low_idx<0)
              {
               low_idx = m_pivots[i].idx;
               low_px  = m_pivots[i].price;
              }
            if(n_h>=2 && low_idx>=0)
               break;
           }
         if(n_h<2 || low_idx<0)
            return(false);
         if(!(h_new>h_old))
            return(false);

         int ev_idx = -1;
         return(ResolveLevel(low_idx,low_px,false,ev_idx)==SPA_RES_BOS);
        }

      //--- bullish mirror -------------------------------------------
      double l_new = 0.0, l_old = 0.0;
      int    n_l   = 0;
      int    high_idx = -1;
      double high_px  = 0.0;

      for(int i=m_pivot_count-1;i>=0;i--)
        {
         if(!m_pivots[i].is_high && n_l<2)
           {
            if(n_l==0) l_new = m_pivots[i].price;
            else       l_old = m_pivots[i].price;
            n_l++;
           }
         if(m_pivots[i].is_high && high_idx<0)
           {
            high_idx = m_pivots[i].idx;
            high_px  = m_pivots[i].price;
           }
         if(n_l>=2 && high_idx>=0)
            break;
        }
      if(n_l<2 || high_idx<0)
         return(false);
      if(!(l_new<l_old))
         return(false);

      int evb = -1;
      return(ResolveLevel(high_idx,high_px,true,evb)==SPA_RES_BOS);
     }

   //----------------------------------------------------------------+
   //| Accessors                                                      |
   //----------------------------------------------------------------+
   bool              IsReady()             const { return(m_ready); }
   string            LastError()           const { return(m_last_error); }
   int               Bars()                const { return(m_n); }
   int               PivotCount()          const { return(m_pivot_count); }
   double            ATR()                 const { return(m_atr); }
   double            MinSwingATR()         const { return(m_min_swing_atr); }
   double            SwingThreshold()      const { return(m_min_swing_atr*m_atr); }
   ENUM_SPA_TREND    Trend()               const { return(m_trend); }
   int               BarsSinceExtreme()    const { return(m_bars_since_extreme); }
   bool              IsConsolidating()     const { return(m_bars_since_extreme>=m_consol_bars); }
   ENUM_TIMEFRAMES   Timeframe()           const { return(m_tf); }

   string            TrendText()           const
     {
      if(m_trend==SPA_TREND_UP)   return("UP");
      if(m_trend==SPA_TREND_DOWN) return("DOWN");
      return("RANGE");
     }

   //--- read-only bar access for downstream modules (zones, signal) ----
   double            BarOpen(const int i)  const { if(i<0 || i>=m_n) return(0.0); return(m_o[i]); }
   double            BarHigh(const int i)  const { if(i<0 || i>=m_n) return(0.0); return(m_h[i]); }
   double            BarLow(const int i)   const { if(i<0 || i>=m_n) return(0.0); return(m_l[i]); }
   double            BarClose(const int i) const { if(i<0 || i>=m_n) return(0.0); return(m_c[i]); }
   datetime          BarTime(const int i)  const { if(i<0 || i>=m_n) return(0);   return(m_t[i]); }

   bool              GetPivot(const int i,SpaPivot &out) const
     {
      if(i<0 || i>=m_pivot_count)
         return(false);
      out = m_pivots[i];
      return(true);
     }

   //--- most recent pivot of a given side (searching backwards) ----
   bool              LastPivot(const bool is_high,SpaPivot &out) const
     {
      for(int i=m_pivot_count-1;i>=0;i--)
        {
         if(m_pivots[i].is_high==is_high)
           {
            out = m_pivots[i];
            return(true);
           }
        }
      return(false);
     }

   //----------------------------------------------------------------+
   //| One-line summary for logs and the chart panel                  |
   //----------------------------------------------------------------+
   string            Describe()
     {
      SpaPivot lh, ll;
      string sh = LastPivot(true,lh)  ? StringFormat("lastHigh %.5g (%s) @%s",lh.price,lh.label,TimeToString(lh.time,TIME_DATE|TIME_MINUTES)) : "lastHigh n/a";
      string sl = LastPivot(false,ll) ? StringFormat("lastLow  %.5g (%s) @%s",ll.price,ll.label,TimeToString(ll.time,TIME_DATE|TIME_MINUTES)) : "lastLow  n/a";

      return(StringFormat("%s %-3s | pivots=%d | %s | %s | sinceExtreme=%d | consolidating=%s | shiftBear=%s shiftBull=%s",
                          EnumToString(m_tf),TrendText(),m_pivot_count,sh,sl,
                          m_bars_since_extreme,
                          IsConsolidating() ? "YES" : "no",
                          IsValidShift(true) ? "VALID" : "-",
                          IsValidShift(false)? "VALID" : "-"));
     }
  };

#endif // __SPA_STRUCTURE_MQH__
//+------------------------------------------------------------------+
