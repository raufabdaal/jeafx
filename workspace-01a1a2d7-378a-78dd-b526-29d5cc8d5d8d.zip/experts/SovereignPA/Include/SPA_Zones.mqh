//--- A candidate order block that did NOT become a zone, kept so the audit
//--- view can show what the engine looked at and why it said no.
struct SpaReject
  {
   datetime  t_ob;
   double    top;
   double    bottom;
   bool      demand;
   int       why;      // 1 = no 3-candle gap, 2 = gap too small, 3 = gap closed
  };

#define SPA_MAX_REJECT 300

//+------------------------------------------------------------------+
//|                                                  SPA_Zones.mqh   |
//|   Sovereign Price-Action EA - zone construction & trade planning  |
//|   SPEC-001 v0.6.0  (D-A, D-B, D-D, R-06, R-07)                     |
//|                                                                   |
//|   WHAT THIS MODULE ANSWERS                                        |
//|     1. Where is the ORDER BLOCK that the breaking move came from? |
//|     2. Did that candle leave a CLEAR IMBALANCE behind it?         |
//|     3. Has price already traded back into it (fresh or stale)?    |
//|     4. What is the first structural level still standing ahead?   |
//|     5. Does the resulting reward:risk clear 3.0?                  |
//|                                                                   |
//|   USER DECISION D-A (2026-11-02)                                  |
//|   "we look and see the last candle before the impulse, but this   |
//|    candle has to have a clear imbalance that comes after it"      |
//|   -> the order block is mandatory AND the imbalance is a filter.  |
//|      Neither alone is a zone.                                     |
//|                                                                   |
//|   USER DECISION D-B                                               |
//|   Entry at the FIRST TOUCH (near edge). Stop beyond the far edge  |
//|   plus the rule book's 2 x spread + 2 pips buffer.                |
//|                                                                   |
//|   VERIFICATION                                                    |
//|   Mirrors tests/spa_signal_ref.py one-for-one. 16 unit tests.     |
//|   Any divergence between the two is a release blocker.            |
//+------------------------------------------------------------------+
#ifndef __SPA_ZONES_MQH__
#define __SPA_ZONES_MQH__

//+------------------------------------------------------------------+
struct SpaZone
  {
   bool      demand;        // true = demand (buy), false = supply (sell)
   int       ob_idx;        // order-block bar
   int       break_idx;     // bar that closed through structure
   double    top;
   double    bottom;
   double    entry;         // near edge = first touch
   double    stop_ref;      // far edge = zone invalidation
   bool      fresh;         // price has not returned into it yet
   int       age;            // bars since the break: fresh is not the same as current
   datetime  t_ob;
   int       gap_idx;        // bar of the imbalance that validates this zone
   double    gap_low;
   double    gap_high;
   double    gap_atr;        // gap size in ATR - what the threshold is measured against
   int       pivot_idx;      // the swing the impulse left from
   double    leg_atr;        // how far the impulse travelled, in ATR
   bool      gap_filled;     // the gap has been USED UP, not merely touched
   bool      retested;       // price has been back into the block at any time
   datetime  t_gap;
  };

//+------------------------------------------------------------------+
struct SpaPlan
  {
   bool      valid;
   bool      is_buy;
   double    entry;
   double    sl;
   double    tp;
   double    sl_pips;
   double    tp_pips;
   double    lots;
   double    rr;
   string    reason;
  };

//+------------------------------------------------------------------+
class CSpaZones
  {
private:
   SpaZone           m_z[];
   int               m_n;
   int               m_lookback;
   bool              m_latest_only;   // D-E: only the newest impulse per direction
   double            m_fvg_min_atr;   // D-06: minimum gap size, x ATR
   //--- audit counters: why did candidate order blocks not become zones?
   int               m_cand, m_why_none, m_why_small, m_why_filled, m_ok;
   SpaReject         m_rej[SPA_MAX_REJECT];
   int               m_rejc;
   int               m_fvg_window;    // gap must sit within N bars of the OB
   //--- impulse-first parameters (v0.7.0)
   double            m_min_leg_atr;   // a leg must travel this far to be an impulse
   int               m_ob_scan;       // how far back to look for the opposing candle

   //----------------------------------------------------------------+
   //| D-A + RB D-06: a VALID, UNFILLED, ADEQUATELY-SIZED imbalance  |
   //| created by the displacement that left the order block.        |
   //|                                                               |
   //| Three rules, each one visible on a chart:                     |
   //|   1. SIZE  - at least m_fvg_min_atr x ATR (RB D-06: 0.5).     |
   //|              Without it a 0.1-pip sliver counts as a "gap".   |
   //|   2. PLACE - within m_fvg_window bars of the order block, so  |
   //|              the gap belongs to the impulse, not to some      |
   //|              unrelated bar twenty candles later.              |
   //|   3. FILL  - price must not have traded all the way back      |
   //|              through it. A filled gap is history, not         |
   //|              imbalance.                                       |
   //|                                                               |
   //| Returns the bar of the gap, or -1.                            |
   //----------------------------------------------------------------+
   int               FindImbalance(CSpaStructure &st,const int start,const int end,
                                   const bool bullish,const double min_gap,
                                   const int window,const int n,int &why,
                                   const int fill_to=-1)
     {
      //--- fill_to limits the fill scan. At BIRTH we only ask whether the
      //--- impulse itself closed the gap; whether price closes it later is
      //--- the zone's freshness, not its validity.
      int fill_end = n;
      if(fill_to>=0 && fill_to+1<n)
         fill_end = fill_to+1;
      why = 1;   // 1 = no 3-candle geometry at all in the window
      int last = end;
      if(start+window<last)
         last = start+window;

      int lo = start+1;
      if(lo<2)
         lo = 2;

      for(int k=lo;k<=last;k++)
        {
         double gap_low, gap_high;
         if(bullish)
           {
            gap_low  = st.BarHigh(k-2);
            gap_high = st.BarLow(k);
           }
         else
           {
            gap_low  = st.BarHigh(k);
            gap_high = st.BarLow(k-2);
           }
         if((gap_high-gap_low)<min_gap || gap_high<=gap_low)
           {
            if(why<2)
               why = 2;      // 2 = a gap exists but it is too small
            continue;
           }

         bool filled = false;
         for(int j=k+1;j<fill_end;j++)
           {
            if(bullish && st.BarLow(j)<=gap_low)   { filled=true; break; }
            if(!bullish && st.BarHigh(j)>=gap_high) { filled=true; break; }
           }
         if(!filled)
           {
            why = 0;         // 0 = accepted
            return(k);
           }
         why = 3;             // 3 = a real gap, but price already closed it
        }
      return(-1);
     }

public:
   //----------------------------------------------------------------+
   //| IMPULSE-FIRST ORDER BLOCKS (v0.7.0)                           |
   //|                                                               |
   //| "First of all, we should first nail that thing of identifying  |
   //|  the last candles before the impulses, because those are       |
   //|  where we enter from."                                        |
   //|                                                               |
   //| The impulse is the primary object; the order block is derived  |
   //| from it. The previous engine started from a structural break   |
   //| and searched backwards, so an order block could only exist     |
   //| where a BOS happened - and most impulses never break structure.|
   //|                                                               |
   //| The imbalance is searched across the WHOLE leg, not within a   |
   //| few bars of the block: it forms inside the impulse. Measured   |
   //| on EUR/USD M15 that is 109 of 162 impulses instead of 8.       |
   //----------------------------------------------------------------+
   void              FindFVGZones(CSpaStructure &st)
     {
      m_n    = 0;
      m_rejc = 0;
      m_cand = 0; m_why_none = 0; m_why_small = 0; m_why_filled = 0; m_ok = 0;

      int nb = st.Bars();
      if(nb<5)
         return;
      double atr = st.ATR();
      if(atr<=0.0)
         return;

      double min_gap = m_fvg_min_atr*atr;

      for(int k=2;k<nb;k++)
        {
         bool   bullish  = false;
         bool   found    = false;
         double gap_low  = 0.0;
         double gap_high = 0.0;

         if(st.BarLow(k)>st.BarHigh(k-2))
           {
            gap_low  = st.BarHigh(k-2);
            gap_high = st.BarLow(k);
            bullish  = true;
            found    = true;
           }
         else if(st.BarHigh(k)<st.BarLow(k-2))
           {
            gap_low  = st.BarHigh(k);
            gap_high = st.BarLow(k-2);
            bullish  = false;
            found    = true;
           }
         if(!found)
            continue;

         m_cand++;
         if((gap_high-gap_low)<min_gap)
           {
            m_why_small++;
            if(m_rejc<SPA_MAX_REJECT)
              {
               int obr = k-2;
               m_rej[m_rejc].t_ob   = st.BarTime(obr);
               m_rej[m_rejc].top    = st.BarHigh(obr);
               m_rej[m_rejc].bottom = st.BarLow(obr);
               m_rej[m_rejc].demand = bullish;
               m_rej[m_rejc].why    = 2;
               m_rejc++;
              }
            continue;
           }

         //--- THE ORDER BLOCK IS THE CANDLE BEFORE THE DISPLACEMENT CANDLE.
         //--- In a 3-candle imbalance (k-2, k-1, k) the MIDDLE candle k-1 is
         //--- the one that "has the imbalance" - the displacement. The block
         //--- is the quiet candle in front of it, which is k-2.
         //--- Using k-1 marked the displacement candle itself: measured on
         //--- M15 that is 1.97 x ATR wide instead of 1.19, and 74% of blocks
         //--- came out wider than 1.5 ATR. That was the giant boxes.
         int ob = k-2;

         int sz = ArraySize(m_z);
         if(m_n>=sz)
            ArrayResize(m_z,sz+128);

         SpaZone z;
         z.demand    = bullish;
         z.ob_idx    = ob;
         z.pivot_idx = k;
         z.break_idx = k;
         z.top       = st.BarHigh(ob);
         z.bottom    = st.BarLow(ob);
         z.entry     = bullish ? z.top : z.bottom;
         z.stop_ref  = bullish ? z.bottom : z.top;
         z.t_ob      = st.BarTime(ob);
         z.t_gap     = st.BarTime(k);
         z.gap_idx   = k;
         z.gap_low   = gap_low;
         z.gap_high  = gap_high;
         z.gap_atr   = (gap_high-gap_low)/atr;
         z.leg_atr   = 0.0;
         z.age       = (nb-1)-k;

         //--- HOW FAR HAS PRICE COME BACK? One pass, both bounds.
         //--- The user's correction, 2026-11-02:
         //---   "when an imbalance is there, it's there ... a tiny bit of an
         //---    imbalance that the wick did not retest ... that zone is
         //---    still valid, and then we shift the last candle before the
         //---    impulse to the top candle"
         //--- So an imbalance is USED UP, never merely TOUCHED. Validity
         //--- is used up, never merely touched.
         double lo_since = 1e100;
         double hi_since =-1e100;
         for(int j=k+1;j<nb;j++)
           {
            double lo = st.BarLow(j);
            double hi = st.BarHigh(j);
            if(lo<lo_since) lo_since = lo;
            if(hi>hi_since) hi_since = hi;
           }

         //--- VALIDITY ONLY. The box geometry is NOT touched: the zone is
         //--- always the block candle, wick to wick, exactly as approved in
         //--- v0.12.0. Shrinking the box to a "live" remainder was my
         //--- invention and it moved every zone on the chart. Reverted.
         if(bullish)
            z.gap_filled = (lo_since<=gap_low);   // crossed the whole gap
         else
            z.gap_filled = (hi_since>=gap_high);

         //--- has price been back into the block AT ALL? A block that has
         //--- been retested has served its purpose and comes off the chart.
         if(bullish)
            z.retested = (lo_since<=z.top);
         else
            z.retested = (hi_since>=z.bottom);

         //--- "fresh" now means NOT FULLY CONSUMED, not "never wicked once".
         if(bullish)
            z.fresh = (lo_since>z.bottom);
         else
            z.fresh = (hi_since<z.top);

         m_z[m_n] = z;
         m_n++;
         m_ok++;
        }
     }

public:
                     CSpaZones(): m_n(0), m_lookback(20), m_latest_only(true),
                                  m_fvg_min_atr(0.15), m_fvg_window(3),
                                  m_min_leg_atr(1.5), m_ob_scan(6),
                                  m_cand(0), m_why_none(0), m_why_small(0),
                                  m_why_filled(0), m_ok(0), m_rejc(0) {}

   void              SetLatestOnly(const bool v) { m_latest_only = v; }
   int               RejectCount() const { return(m_rejc); }
   bool              GetReject(const int i,SpaReject &r) const
     {
      if(i<0 || i>=m_rejc)
         return(false);
      r = m_rej[i];
      return(true);
     }

   void              Diag(int &cand,int &none,int &small,int &filled,int &ok) const
     {
      cand=none=small=filled=ok;
      cand   = m_cand;
      none   = m_why_none;
      small  = m_why_small;
      filled = m_why_filled;
      ok     = m_ok;
     }

   void              SetImpulse(const double min_leg_atr,const int ob_scan)
     {
      m_min_leg_atr = (min_leg_atr<0.0) ? 0.0 : min_leg_atr;
      m_ob_scan     = (ob_scan<1) ? 1 : ob_scan;
     }
   void              SetImbalance(const double min_atr,const int window)
     {
      m_fvg_min_atr = (min_atr<0.0) ? 0.0 : min_atr;
      m_fvg_window  = (window<1) ? 1 : window;
     }

   //----------------------------------------------------------------+
   //| Scan the structure for valid zones. Returns the zone count.   |
   //| A zone needs: a BOS, an order block, and an imbalance.         |
   //----------------------------------------------------------------+
   int               Find(CSpaStructure &st)
     {
      m_n = 0;
      m_cand = m_why_none = m_why_small = m_why_filled = m_ok = 0;
      m_rejc = 0;
      ArrayResize(m_z,0);

      int nb = st.Bars();
      if(nb<5 || st.PivotCount()<1)
         return(0);

      int ob_used[];
      ArrayResize(ob_used,0);

      for(int i=0;i<st.PivotCount();i++)
        {
         SpaPivot p;
         if(!st.GetPivot(i,p))
            continue;

         int ev_idx = -1;
         if(st.ResolveLevel(p.idx,p.price,p.is_high,ev_idx)!=SPA_RES_BOS)
            continue;                       // wick-only = sweep, not a break

         int b = ev_idx;
         if(b<2 || b>=nb)
            continue;

         bool bullish = p.is_high;

         //--- last candle that closed AGAINST the breaking move ------
         int ob = -1;
         int floor_i = b-m_lookback;
         if(floor_i<0)
            floor_i = 0;
         for(int j=b;j>=floor_i;j--)
           {
            if(bullish && st.BarClose(j)<st.BarOpen(j)) { ob=j; break; }
            if(!bullish && st.BarClose(j)>st.BarOpen(j)) { ob=j; break; }
           }
         if(ob<0 || ob>=b)
            continue;

         //--- one candle cannot be two zones -------------------------
         bool seen = false;
         for(int q=0;q<ArraySize(ob_used);q++)
            if(ob_used[q]==ob) { seen=true; break; }
         if(seen)
            continue;

         int why  = 0;
         int gapk = FindImbalance(st,ob,b,bullish,m_fvg_min_atr*st.ATR(),
                                  m_fvg_window,nb,why,b);
         m_cand++;
         if(gapk<0)
           {
            if(why==2)      m_why_small++;
            else if(why==3) m_why_filled++;
            else            m_why_none++;
            if(m_rejc<SPA_MAX_REJECT)
              {
               m_rej[m_rejc].t_ob   = st.BarTime(ob);
               m_rej[m_rejc].top    = st.BarHigh(ob);
               m_rej[m_rejc].bottom = st.BarLow(ob);
               m_rej[m_rejc].demand = bullish;
               m_rej[m_rejc].why    = why;
               m_rejc++;
              }
            continue;
           }
         m_ok++;

         ArrayResize(ob_used,ArraySize(ob_used)+1);
         ob_used[ArraySize(ob_used)-1] = ob;

         SpaZone z;
         z.demand    = bullish;
         z.ob_idx    = ob;
         z.break_idx = b;
         z.top       = st.BarHigh(ob);
         z.bottom    = st.BarLow(ob);
         z.entry     = bullish ? z.top    : z.bottom;
         z.stop_ref  = bullish ? z.bottom : z.top;
         z.t_ob      = st.BarTime(ob);
         z.age       = (nb-1)-b;
         z.gap_idx   = gapk;
         z.t_gap     = st.BarTime(gapk);
         if(bullish)
           {
            z.gap_low  = st.BarHigh(gapk-2);
            z.gap_high = st.BarLow(gapk);
           }
         else
           {
            z.gap_low  = st.BarHigh(gapk);
            z.gap_high = st.BarLow(gapk-2);
           }
         z.gap_atr   = (st.ATR()>0.0) ? (z.gap_high-z.gap_low)/st.ATR() : 0.0;
         //--- did price close this gap AFTER the zone was born?
         z.gap_filled = false;
         for(int j=b+1;j<nb;j++)
           {
            if(bullish && st.BarLow(j)<=z.gap_low)      { z.gap_filled=true; break; }
            if(!bullish && st.BarHigh(j)>=z.gap_high)   { z.gap_filled=true; break; }
           }
         z.fresh     = true;

         for(int j=b+1;j<nb;j++)
           {
            if(bullish && st.BarLow(j)<=z.top)       { z.fresh=false; break; }
            if(!bullish && st.BarHigh(j)>=z.bottom)  { z.fresh=false; break; }
           }

         ArrayResize(m_z,m_n+1);
         m_z[m_n] = z;
         m_n++;
        }

      //--- chronological, so "most recent zone" is a simple tail ----
      for(int a=1;a<m_n;a++)
        {
         SpaZone key = m_z[a];
         int b2 = a-1;
         while(b2>=0 && m_z[b2].ob_idx>key.ob_idx)
           {
            m_z[b2+1] = m_z[b2];
            b2--;
           }
         m_z[b2+1] = key;
        }

      //--- D-E: only the most RECENT impulse in each direction is live.
      //--- "Another pullback, it retests the last candle before the impulse,
      //---  then it goes down to our zone." The zone you trade is the one the
      //--- LATEST impulse created - not the last one that happens to be
      //--- untouched. An ancient untouched zone is a level the market has
      //--- already walked past, not an opportunity.
      if(m_latest_only && m_n>1)
        {
         int best_d = -1, best_s = -1;
         for(int i=0;i<m_n;i++)
           {
            if(m_z[i].demand) { if(m_z[i].break_idx>best_d) best_d = m_z[i].break_idx; }
            else              { if(m_z[i].break_idx>best_s) best_s = m_z[i].break_idx; }
           }
         int k = 0;
         for(int i=0;i<m_n;i++)
           {
            int want = m_z[i].demand ? best_d : best_s;
            if(m_z[i].break_idx==want)
              {
               m_z[k] = m_z[i];
               k++;
              }
           }
         m_n = k;
         ArrayResize(m_z,m_n);
        }
      return(m_n);
     }

   //----------------------------------------------------------------+
   //| The first structural level STILL STANDING in front of the     |
   //| trade. A level already closed through is behind us, not a     |
   //| target.                                                       |
   //----------------------------------------------------------------+
   bool              FirstObstacle(CSpaStructure &st,const double entry,
                                   const bool bullish,double &out)
     {
      out = 0.0;
      bool found = false;

      for(int i=0;i<st.PivotCount();i++)
        {
         SpaPivot p;
         if(!st.GetPivot(i,p))
            continue;

         int ev = -1;
         if(st.ResolveLevel(p.idx,p.price,p.is_high,ev)==SPA_RES_BOS)
            continue;                       // already broken

         if(bullish && p.is_high && p.price>entry)
           {
            if(!found || p.price<out) { out=p.price; found=true; }
           }
         else if(!bullish && !p.is_high && p.price<entry)
           {
            if(!found || p.price>out) { out=p.price; found=true; }
           }
        }
      return(found);
     }

   //----------------------------------------------------------------+
   //| Turn a zone into an exact order.                              |
   //|                                                               |
   //| Rejection is explicit and never silent: under min_rr there is |
   //| no trade, full stop. The target is NOT stretched to fit.      |
   //----------------------------------------------------------------+
   //--- output by reference: MQL5 cannot return a struct that holds a
   //--- string by value, and SpaPlan carries a reason code.
   void              BuildPlan(const SpaZone &z,const bool have_tp,const double tp,
                               const double spread_px,const double pip,const double min_rr,
                               const double min_sl_px,SpaPlan &pl)
     {
      pl.valid   = false;
      pl.is_buy  = z.demand;
      pl.entry   = z.entry;
      pl.sl      = 0.0;
      pl.tp      = 0.0;
      pl.sl_pips = 0.0;
      pl.tp_pips = 0.0;
      pl.lots    = 0.0;
      pl.rr      = 0.0;
      pl.reason  = "";

      if(!have_tp)
        {
         pl.reason = "REJ_NO_TARGET";
         return;
        }

      //--- rule book 5.3 buffer: 2 x spread + 2 pips -----------------
      double buffer = 2.0*spread_px + 2.0*pip;
      pl.sl = z.demand ? (z.bottom-buffer) : (z.top+buffer);
      pl.tp = tp;

      pl.sl_pips = MathAbs(pl.entry-pl.sl)/pip;
      pl.tp_pips = MathAbs(pl.tp-pl.entry)/pip;

      if(pl.sl_pips<=0.0)
        {
         pl.reason = "REJ_NO_SL";
         return;
        }

      //--- a stop closer than the market's own noise is not a tight stop,
      //--- it is a guaranteed loss. Reject the zone; NEVER widen the stop.
      if(min_sl_px>0.0 && (pl.sl_pips*pip)<min_sl_px)
        {
         pl.reason = "REJ_SL_TOO_TIGHT";
         return;
        }

      pl.rr = pl.tp_pips/pl.sl_pips;
      if(pl.rr<min_rr)
        {
         pl.reason = "REJ_RR";
         return;
        }

      pl.valid  = true;
      pl.reason = "OK";
     }

   //----------------------------------------------------------------+
   //| Best tradable zone: direction must agree with the bias trend, |
   //| zone must be fresh, and the highest reward:risk wins.         |
   //| This is the user's "we use the zone with that magnet" made    |
   //| mechanical - a zone only wins if there is liquidity worth     |
   //| travelling to behind it.                                      |
   //----------------------------------------------------------------+
   bool              BestPlan(CSpaStructure &bias_st,CSpaStructure &confirm_st,
                              const string trend,const double spread_px,const double pip,
                              const double min_rr,const double min_sl_px,const int max_age,
                              SpaPlan &out,SpaZone &out_zone)
     {
      //--- no bias = no trade. Say so plainly instead of blaming zones.
      if(trend!="UP" && trend!="DOWN")
        {
         out.valid  = false;
         out.reason = "REJ_NO_TREND";
         return(false);
        }

      bool have = false;
      double best_rr = -1.0;
      string last_reason = "REJ_NO_ZONE";
      int    in_dir = 0;

      for(int i=0;i<m_n;i++)
        {
         if(!m_z[i].fresh)
            continue;
         //--- untouched for too long is abandoned, not fresh -------
         if(max_age>0 && m_z[i].age>max_age)
            continue;
         if(trend=="UP"   && !m_z[i].demand) continue;
         if(trend=="DOWN" &&  m_z[i].demand) continue;
         in_dir++;

         double obst = 0.0;
         bool have_obst = NearestObstacle(bias_st,confirm_st,
                                          m_z[i].entry,m_z[i].demand,obst);

         SpaPlan pl;
         BuildPlan(m_z[i],have_obst,obst,spread_px,pip,min_rr,min_sl_px,pl);
         if(!pl.valid)
           {
            last_reason = pl.reason;
            continue;
           }
         if(!have || pl.rr>best_rr)
           {
            best_rr  = pl.rr;
            out      = pl;
            out_zone = m_z[i];
            have     = true;
           }
        }

      if(!have)
        {
         out.valid  = false;
         if(m_n<=0)          out.reason = "REJ_NO_ZONE";
         else if(in_dir<=0)  out.reason = "REJ_NO_FRESH_ZONE";
         else                out.reason = last_reason;
        }
      return(have);
     }

   //----------------------------------------------------------------+
   //| The nearer of the two structures' first obstacles. A target is |
   //| only honest if it is the FIRST thing in the way, whichever      |
   //| timeframe it came from.                                        |
   //----------------------------------------------------------------+
   bool              NearestObstacle(CSpaStructure &a,CSpaStructure &b,
                                     const double entry,const bool bullish,double &out)
     {
      double pa=0.0, pb=0.0;
      bool ha = FirstObstacle(a,entry,bullish,pa);
      bool hb = FirstObstacle(b,entry,bullish,pb);

      if(ha && hb)
        {
         out = (MathAbs(pa-entry)<=MathAbs(pb-entry)) ? pa : pb;
         return(true);
        }
      if(ha) { out=pa; return(true); }
      if(hb) { out=pb; return(true); }
      out = 0.0;
      return(false);
     }

   //--- accessors ---------------------------------------------------
   //----------------------------------------------------------------+
   //| RULE BOOK 3.3 - EXTREME ZONE PRIORITY, word for word:         |
   //|                                                               |
   //|   "If multiple valid zones exist within a single swing leg,   |
   //|    the algorithm ranks them by proximity to the swing extreme.|
   //|    The bot selects the Extreme Zone (the furthest valid zone   |
   //|    from the current market price that still possesses an      |
   //|    Unfilled Imbalance)."                                      |
   //|                                                               |
   //| Three filters, and the winner is the FURTHEST, not the        |
   //| nearest:                                                      |
   //|   valid    - price has not been back into the block  (3.2)    |
   //|   unfilled - a wick has not entered the gap          (3.3)    |
   //|   leg      - the block was born after the swing extreme       |
   //|                                                               |
   //| Returns the index into this set, or -1, and always fills      |
   //| `reason` with a sentence that can be shown to the user.       |
   //----------------------------------------------------------------+
   //----------------------------------------------------------------+
   //| SORTING THE BLOCKS (v0.16.0)                                  |
   //|                                                               |
   //| The user, 2026-11-03:                                         |
   //|   "we cannot get the last candle before the impulse again     |
   //|    immediately after it... we are going to be considering the |
   //|    extreme, the last candle at the top, which brought all of  |
   //|    these inefficient candles... unless there is a break of    |
   //|    structure, maybe a pullback, after that pullback we can    |
   //|    consider that also."                                       |
   //|                                                               |
   //| One move = a run of same-direction blocks with no retest      |
   //| between them. Inside a run only the EXTREME survives: the     |
   //| highest top for supply, the lowest bottom for demand. A       |
   //| retest ends the run and a new one may begin.                  |
   //----------------------------------------------------------------+
   void              CompressRuns(CSpaStructure &st)
     {
      if(m_n<2)
         return;

      int     out  = 0;
      SpaZone run;
      ZeroMemory(run);          // silence "possibly uninitialised"
      bool    have = false;

      for(int i=0;i<m_n;i++)
        {
         SpaZone z = m_z[i];
         if(!have)
           {
            run  = z;
            have = true;
            continue;
           }

         if(z.demand==run.demand)
           {
            //--- a wick poking back into the block does NOT end the move -
            //--- only a candle that CLOSES back inside it does. This is what
            //--- the user marked with an X: the block immediately after the
            //--- first one in a move is not a block of its own.
            bool ret = false;
            for(int b=run.ob_idx+1;b<=z.ob_idx && !ret;b++)
              {
               if(run.demand)
                 {
                  if(st.BarClose(b)<=run.top)     ret = true;
                 }
               else
                 {
                  if(st.BarClose(b)>=run.bottom) ret = true;
                 }
              }
            if(!ret)
              {
               //--- same move: keep the extreme, discard the rest
               if(z.demand)
                 {
                  if(z.bottom<run.bottom) run = z;
                 }
               else
                 {
                  if(z.top>run.top) run = z;
                 }
               continue;
              }
           }

         m_z[out++] = run;
         run = z;
        }
      if(have)
         m_z[out++] = run;

      m_n = out;
     }

   int               SelectExtreme(CSpaStructure &st,const bool demand,
                                   const double price,string &reason)
     {
      reason = "";

      //--- the leg starts at the last swing in the opposite direction:
      //--- for a demand zone that is the last swing LOW, for supply the
      //--- last swing HIGH. Blocks older than that belong to an older leg.
      int leg_start = -1;
      for(int i=st.PivotCount()-1;i>=0;i--)
        {
         SpaPivot p;
         if(!st.GetPivot(i,p))
            continue;
         if(demand ? (!p.is_high) : p.is_high)
           {
            leg_start = p.idx;
            break;
           }
        }

      string want   = demand ? "demand" : "supply";
      int    valid  = 0;
      int    open   = 0;
      int    inleg  = 0;
      int    best   = -1;
      double bestd  = -1.0;

      for(int i=m_n-1;i>=0;i--)
        {
         if(m_z[i].demand!=demand)
            continue;
         if(!m_z[i].fresh)                  // 3.2: already tapped = invalid
            continue;
         valid++;
         if(m_z[i].gap_filled)              // 3.3: the imbalance is used up
            continue;
         open++;
         if(leg_start>=0 && m_z[i].gap_idx<leg_start)
            continue;
         inleg++;
         double d = MathAbs((demand ? m_z[i].top : m_z[i].bottom)-price);
         if(d>bestd)
           {
            bestd = d;
            best  = i;
           }
        }

      if(best<0)
        {
         if(valid==0)
            reason = StringFormat("no fresh %s zone yet",want);
         else if(open==0)
            reason = StringFormat("%d fresh %s zone(s), every imbalance already filled",valid,want);
         else
            reason = StringFormat("%d %s zone(s) with an open imbalance, none in this leg",open,want);
         return(-1);
        }

      reason = StringFormat("%d valid, %d with an open imbalance, %d in this leg - extreme %s chosen",
                            valid,open,inleg,want);
      return(best);
     }

   int               Count()               const { return(m_n); }
   bool              Get(const int i,SpaZone &out) const
     {
      if(i<0 || i>=m_n)
         return(false);
      out = m_z[i];
      return(true);
     }
   int               FreshCount()          const
     {
      int c=0;
      for(int i=0;i<m_n;i++) if(m_z[i].fresh) c++;
      return(c);
     }
  };

#endif // __SPA_ZONES_MQH__
//+------------------------------------------------------------------+
