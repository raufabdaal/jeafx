//+------------------------------------------------------------------+
//|                                                   SPA_Symbol.mqh |
//|   Sovereign Price-Action EA — multi-asset symbol abstraction      |
//|   SPEC-001 v0.2.0  §3.1 (cross-asset normalisation) / §7.3 / R-01..R-04 |
//|                                                                   |
//|   PURPOSE                                                         |
//|   Every downstream module talks to the market through this class  |
//|   ONLY. No other file may touch SymbolInfo*, point, digits, or    |
//|   tick value directly. That single choke-point is what makes one  |
//|   parameter set behave identically on EURUSD, XAUUSD, USDJPY and  |
//|   BTCUSD, and it is where all lot-sizing risk arithmetic lives.   |
//+------------------------------------------------------------------+
#ifndef __SPA_SYMBOL_MQH__
#define __SPA_SYMBOL_MQH__

#include "SPA_Config.mqh"

//+------------------------------------------------------------------+
class CSpaSymbol
  {
private:
   string            m_symbol;
   SpaProfile        m_prof;
   bool              m_ready;

   int               m_digits;
   double            m_point;
   double            m_tick_size;
   double            m_tick_value;
   double            m_contract;
   double            m_vol_min;
   double            m_vol_max;
   double            m_vol_step;
   double            m_stops_pts;      // SYMBOL_TRADE_STOPS_LEVEL, in points
   double            m_freeze_pts;     // SYMBOL_TRADE_FREEZE_LEVEL, in points
   long              m_fill_flags;
   double            m_pip;
   string            m_last_error;

public:
                     CSpaSymbol(): m_symbol(""), m_ready(false), m_digits(0), m_point(0.0),
                                   m_tick_size(0.0), m_tick_value(0.0), m_contract(0.0),
                                   m_vol_min(0.0), m_vol_max(0.0), m_vol_step(0.0),
                                   m_stops_pts(0.0), m_freeze_pts(0.0),
                                   m_fill_flags(0), m_pip(0.0), m_last_error("") {}

   //----------------------------------------------------------------+
   //| Init — reads everything the EA will ever need about the symbol |
   //----------------------------------------------------------------+
   bool              Init(const string symbol,const SpaProfile &prof)
     {
      m_symbol  = symbol;
      m_prof    = prof;
      m_ready   = false;
      m_last_error = "";

      if(!SymbolSelect(symbol,true))
        {
         m_last_error = "SymbolSelect failed (symbol not in Market Watch)";
         return(false);
        }

      m_digits     = (int)SymbolInfoInteger(symbol,SYMBOL_DIGITS);
      m_point      = SymbolInfoDouble(symbol,SYMBOL_POINT);
      m_tick_size  = SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
      m_tick_value = SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE);
      m_contract   = SymbolInfoDouble(symbol,SYMBOL_TRADE_CONTRACT_SIZE);
      m_vol_min    = SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
      m_vol_max    = SymbolInfoDouble(symbol,SYMBOL_VOLUME_MAX);
      m_vol_step   = SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
      m_stops_pts  = (double)SymbolInfoInteger(symbol,SYMBOL_TRADE_STOPS_LEVEL);
      m_freeze_pts = (double)SymbolInfoInteger(symbol,SYMBOL_TRADE_FREEZE_LEVEL);
      m_fill_flags = (long)SymbolInfoInteger(symbol,SYMBOL_FILLING_MODE);

      //--- structural sanity: refuse to trade on a symbol we do not
      //--- fully understand. Silent defaults here cause lot-size bugs
      //--- that only surface as account damage. -------------------
      if(m_point<=0.0)     { m_last_error="SYMBOL_POINT is zero";     return(false); }
      if(m_tick_size<=0.0) { m_last_error="SYMBOL_TRADE_TICK_SIZE<=0"; return(false); }
      if(m_tick_value<=0.0){ m_last_error="SYMBOL_TRADE_TICK_VALUE<=0"; return(false); }
      if(m_vol_step<=0.0)  { m_last_error="SYMBOL_VOLUME_STEP<=0";     return(false); }
      if(m_vol_min<=0.0)   { m_last_error="SYMBOL_VOLUME_MIN<=0";      return(false); }

      //--- pip definition ----------------------------------------
      //--- 0 in the profile = auto.                                    |
      //--- FX fractional-pip brokers (5 or 3 digits): pip = 10 points.  |
      //--- Legacy FX (4 or 2 digits):                 pip = 1 point.    |
      //--- Gold/BTC/indices MUST specify explicitly (see csv) because   |
      //--- a 2-digit XAU feed would otherwise be read as "pip = 0.01".  |
      if(prof.pip_size>0.0)
         m_pip = prof.pip_size;
      else
        {
         if(m_digits==3 || m_digits==5)
            m_pip = 10.0*m_point;
         else
            m_pip = m_point;
        }

      m_ready = true;
      return(true);
     }

   //----------------------------------------------------------------+
   //| Accessors                                                      |
   //----------------------------------------------------------------+
   string            Symbol()      const { return(m_symbol); }
   SpaProfile        Profile()     const { return(m_prof); }
   bool              IsReady()     const { return(m_ready); }
   string            LastError()   const { return(m_last_error); }
   int               Digits()      const { return(m_digits); }
   double            Point()       const { return(m_point); }
   double            Pip()         const { return(m_pip); }
   double            TickSize()    const { return(m_tick_size); }
   double            TickValue()   const { return(m_tick_value); }
   double            VolMin()      const { return(m_vol_min); }
   double            VolMax()      const { return(m_vol_max); }
   double            VolStep()     const { return(m_vol_step); }
   ENUM_TIMEFRAMES   TfBias()      const { return(m_prof.tf_bias); }
   ENUM_TIMEFRAMES   TfConfirm()   const { return(m_prof.tf_confirm); }
   ENUM_TIMEFRAMES   TfExec()      const { return(m_prof.tf_exec); }
   ENUM_SPA_ENTRY_MODE EntryMode() const { return(m_prof.entry_mode); }

   double            NormalizePrice(const double price) const
     {
      return(NormalizeDouble(price,m_digits));
     }

   //--- minimum permitted distance for SL/TP, in price units ------
   double            MinStopDistance() const
     {
      return((m_stops_pts+m_freeze_pts)*m_point);
     }

   //----------------------------------------------------------------+
   //| Bid / Ask / Spread                                             |
   //----------------------------------------------------------------+
   double            Bid() const { return(SymbolInfoDouble(m_symbol,SYMBOL_BID)); }
   double            Ask() const { return(SymbolInfoDouble(m_symbol,SYMBOL_ASK)); }

   double            SpreadPrice() const
     {
      double ask = Ask();
      double bid = Bid();
      double sp  = ask-bid;
      if(sp<=0.0)   // tick not yet updated in tester
         sp = (double)SymbolInfoInteger(m_symbol,SYMBOL_SPREAD)*m_point;
      if(sp<0.0)
         sp = 0.0;
      return(sp);
     }

   double            SpreadPips() const
     {
      return(m_pip>0.0 ? SpreadPrice()/m_pip : 0.0);
     }

   //----------------------------------------------------------------+
   //| R-10a : COARSE spread gate (pre-filter, called every tick)      |
   //| Pure pip ceiling. Cheap, and catches news spikes / Asian close. |
   //| It is deliberately NOT an ATR ratio: spread/ATR differs by 10x  |
   //| between asset classes, so any single ratio rejects whole        |
   //| classes or passes everything. (See debug_log D-002.)            |
   //----------------------------------------------------------------+
   bool              SpreadOKCoarse(string &reason)
     {
      reason = "";
      double sp_price = SpreadPrice();
      double cap      = m_prof.spread_pips_ceiling*m_pip;

      if(cap<=0.0)
         return(true);          // 0 disables the coarse gate

      if(sp_price>cap)
        {
         reason = StringFormat("REJ_SPREAD_PIPS %.2f>%.2f",sp_price/m_pip,m_prof.spread_pips_ceiling);
         return(false);
        }
      return(true);
     }

   //----------------------------------------------------------------+
   //| R-10b : COST-OF-RISK spread gate (final gate, SL already known) |
   //|                                                                 |
   //|   spread_cost <= max_spread_of_risk * SL_distance               |
   //|                                                                 |
   //| This is the economically correct formulation: the spread only   |
   //| matters relative to what is being risked. 1.5 pips of spread    |
   //| against a 20-pip stop is 7.5% of risk (fine); against a 6-pip   |
   //| stop it is 25% (the edge is gone and the 3R target is fiction). |
   //| Symbol-agnostic, because both terms are in price units.         |
   //----------------------------------------------------------------+
   bool              SpreadOKAtRisk(const double sl_distance,string &reason)
     {
      reason = "";
      if(sl_distance<=0.0)
        {
         reason = "REJ_NO_SL";
         return(false);
        }

      double sp  = SpreadPrice();
      double max = m_prof.max_spread_of_risk*sl_distance;

      if(m_prof.max_spread_of_risk<=0.0)
         return(true);

      if(sp>max)
        {
         reason = StringFormat("REJ_SPREAD_OF_RISK %.1f%%>%.1f%% (spread %.5g / SL %.5g)",
                               (sp/sl_distance)*100.0,
                               m_prof.max_spread_of_risk*100.0,sp,sl_distance);
         return(false);
        }
      return(true);
     }

   //----------------------------------------------------------------+
   //| Money maths                                                    |
   //| value of a 1.0-lot position per 1.0 unit of price movement      |
   //----------------------------------------------------------------+
   double            MoneyPerLotPerPrice(const double price_distance) const
     {
      if(m_tick_size<=0.0)
         return(0.0);
      return((price_distance/m_tick_size)*m_tick_value);
     }

   //----------------------------------------------------------------+
   //| R-02 : dynamic lot sizing                                      |
   //|   Lots = risk_money / (SL_distance * money_per_lot_per_price)  |
   //| Rounded DOWN to volume step (never up: rounding up is an       |
   //| unrequested risk increase). Clamped to broker min/max.         |
   //| Returns 0.0 when the trade is not placeable — caller must      |
   //| treat 0.0 as a hard rejection, never as "use the minimum".     |
   //----------------------------------------------------------------+
   double            LotsForRisk(const double risk_money,const double sl_distance)
     {
      if(sl_distance<=0.0 || risk_money<=0.0)
         return(0.0);

      double per_lot = MoneyPerLotPerPrice(sl_distance);
      if(per_lot<=0.0)
         return(0.0);

      double raw = risk_money/per_lot;

      //--- floor to step (with a small epsilon so 0.2999999 -> 0.30) -
      double steps = MathFloor(raw/m_vol_step + 1e-9);
      double vol   = steps*m_vol_step;

      if(vol<m_vol_min)
        {
         //--- the minimum lot would exceed the risk budget: reject.
         //--- We do NOT silently take the minimum lot. That is how a
         //--- 0.5% rule becomes a 4% loss on a small account.
         double min_risk = MoneyPerLotPerPrice(sl_distance)*m_vol_min;
         if(min_risk>risk_money*1.001)
            return(0.0);
         vol = m_vol_min;
        }
      if(vol>m_vol_max)
         vol = m_vol_max;

      vol = NormalizeDouble(vol,8);
      return(vol);
     }

   //----------------------------------------------------------------+
   //| Free-margin guard: shrink volume until it fits with a buffer.  |
   //| Prevents the "no money" OrderSend error on correlated baskets. |
   //----------------------------------------------------------------+
   double            FitToFreeMargin(const ENUM_ORDER_TYPE type,const double price,
                                     const double volume,const double buffer_pct=30.0)
     {
      if(volume<=0.0)
         return(0.0);

      double need  = 0.0;
      if(!OrderCalcMargin(type,m_symbol,volume,price,need))
         return(0.0);

      double free  = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
      double avail = free*(1.0-buffer_pct/100.0);
      if(need<=avail)
         return(volume);

      if(need<=0.0)
         return(0.0);

      double scaled = volume*(avail/need);
      double steps  = MathFloor(scaled/m_vol_step + 1e-9);
      double out    = steps*m_vol_step;
      if(out<m_vol_min)
         return(0.0);
      out = NormalizeDouble(out,8);
      return(out);
     }

   //----------------------------------------------------------------+
   //| Broker capability / permission gates                          |
   //----------------------------------------------------------------+
   bool              TradingPermitted(string &reason)
     {
      reason = "";
      if(!m_ready) { reason="SYMBOL_NOT_READY"; return(false); }

      ENUM_SYMBOL_TRADE_MODE mode =
         (ENUM_SYMBOL_TRADE_MODE)SymbolInfoInteger(m_symbol,SYMBOL_TRADE_MODE);
      if(mode==SYMBOL_TRADE_MODE_DISABLED || mode==SYMBOL_TRADE_MODE_CLOSEONLY)
        { reason="SYMBOL_DISABLED"; return(false); }

      //--- explicit ==0 comparisons: keeps the build free of implicit
      //--- long->bool conversion warnings on stricter compiler builds.
      if(TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)==0) { reason="TERMINAL_NOT_ALLOWED"; return(false); }
      if(MQLInfoInteger(MQL_TRADE_ALLOWED)==0)           { reason="EA_TRADE_NOT_ALLOWED";  return(false); }
      if(AccountInfoInteger(ACCOUNT_TRADE_ALLOWED)==0)   { reason="ACCOUNT_NOT_ALLOWED";   return(false); }
      if(AccountInfoInteger(ACCOUNT_TRADE_EXPERT)==0)    { reason="ACCOUNT_EXPERT_OFF";    return(false); }
      return(true);
     }

   //----------------------------------------------------------------+
   //| Filling mode: the #1 cause of silent OrderSend failures on MT5 |
   //----------------------------------------------------------------+
   ENUM_ORDER_TYPE_FILLING FillingMode()
     {
      //--- prefer IOC, then FOK, then RETURN (market/pending limits) -
      int flags = (int)m_fill_flags;
      if((flags & (int)SYMBOL_FILLING_IOC)!=0)
         return(ORDER_FILLING_IOC);
      if((flags & (int)SYMBOL_FILLING_FOK)!=0)
         return(ORDER_FILLING_FOK);
      return(ORDER_FILLING_RETURN);
     }

   //----------------------------------------------------------------+
   //| Diagnostics — one-line dump used at OnInit and in journals     |
   //----------------------------------------------------------------+
   string            Describe()
     {
      return(StringFormat("%s [%s] digits=%d point=%.8g pip=%.8g tick=%.8g/%.5g vol=%.2f..%.2f step=%.2f stops=%.0fpts fill=%d",
                          m_symbol,m_prof.asset_class,m_digits,m_point,m_pip,
                          m_tick_size,m_tick_value,m_vol_min,m_vol_max,m_vol_step,
                          m_stops_pts,(int)FillingMode()));
     }
  };

#endif // __SPA_SYMBOL_MQH__
//+------------------------------------------------------------------+
