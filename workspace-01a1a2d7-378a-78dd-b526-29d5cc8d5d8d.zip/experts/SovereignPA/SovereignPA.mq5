//+------------------------------------------------------------------+
//|                                                  SovereignPA.mq5 |
//|      Sovereign Price-Action EA - main Expert Advisor              |
//|      SPEC-001 v0.4.0                                              |
//|                                                                   |
//|  v0.5.0 SCOPE - SIGNIFICANT STRUCTURE. Still places NO orders.    |
//|                                                                   |
//|  The EA now reads the market: swing highs/lows, HH/HL vs LL/LH    |
//|  trend, body-close breaks vs wick sweeps, and the D-14 filter     |
//|  that rejects breaks occurring inside a corrective leg.           |
//|                                                                   |
//|  Every swing it detects is DRAWN ON THE CHART. That is the point: |
//|  you must be able to look at the chart and agree with what the    |
//|  EA sees before any of it is allowed to drive an order.          |
//+------------------------------------------------------------------+
#property copyright   "ApexQuant-Engine"
#property description "Sovereign Price-Action EA - v0.4.3 structure engine (no trading)"
//--- NOTE on #property version:
//--- MetaEditor validates it against the MQL5 Market format "xxx.yyy" (three
//--- digits, dot, three digits). Our semantic version "0.4.0" is one digit
//--- before the dot, so it raises a Market-compatibility warning. The property
//--- is OPTIONAL metadata with no effect on the compiled EA, so it is omitted
//--- rather than distorted into a Market-shaped value. The authoritative
//--- version lives in SPA_VERSION below and is shown on the chart panel.
//--- For Market publication, add:  #property version "001.000"

//--- INCLUDE ORDER IS A DEPENDENCY ORDER, NOT A STYLE CHOICE.
//--- SPA_Zones.mqh takes CSpaStructure& parameters, so Structure MUST be
//--- declared first. Getting this wrong produces ~58 cascading errors that
//--- all read "declaration without type" on the same few lines.
#include "Include/SPA_Config.mqh"
#include "Include/SPA_Symbol.mqh"
#include "Include/SPA_Structure.mqh"
#include "Include/SPA_Zones.mqh"

#define SPA_VERSION   "0.18.0"

//+------------------------------------------------------------------+
//| Inputs                                                            |
//+------------------------------------------------------------------+
input group           "=== 1. Profile ==="
input string          InpProfileFile      = "symbol_profiles.csv";  // Profile file (MQL5/Files)
input bool            InpOverrideEnabled  = false;                  // Force-enable this symbol (testing only)

input group           "=== 2. Risk overrides (0 = use profile) ==="
input double          InpRiskPctOverride  = 0.0;                    // Risk % per trade
input double          InpMinRROverride    = 0.0;                    // Minimum reward:risk

input group           "=== 3. Structure engine ==="
input double          InpMinSwingATR      = 4.0;                    // Min swing size (x ATR) - significance filter
input double          InpArrowSpreadATR   = 0.70;                   // Vertical gap between TFs (x ATR)
input int             InpStructBars       = 600;                    // Structure history depth (bars)
input int             InpConsolBars       = 20;                     // Consolidation threshold (RB 2.1)
input bool            InpDrawStructure    = false;                   // Draw detected swings on chart
input int             InpDrawMaxPivots    = 12;                     // Max swings drawn per timeframe
//--- which timeframe's structure creates the entry zone. D-E: the zone is
//--- the last candle before the impulse on a HIGHER timeframe than the entry.
enum ENUM_SPA_ZONETF
  {
   SPA_ZONE_EXEC    = 0,   // EXEC  - finest, most zones
   SPA_ZONE_CONFIRM = 1,   // CONFIRM - default
   SPA_ZONE_BIAS    = 2    // BIAS  - widest, fewest zones
  };

input ENUM_SPA_ZONETF  InpZoneTF          = SPA_ZONE_CONFIRM;        // Timeframe that creates the zone
input bool            InpZonesLatestOnly = true;                   // Only the newest impulse per direction
input bool            InpShowZones        = true;                   // Draw order-block zones
input int             InpDrawZonesMax      = 40;                     // Max zones drawn
input int             InpZoneBoxBars     = 40;                     // How far an outline box runs right
input color           InpColImbalance    = clrDimGray;             // Imbalance outline colour
input color           InpColFreshTxt     = clrMediumSeaGreen;      // Demand label text
input color           InpColSupplyTxt    = clrIndianRed;           // Supply label text
input int             InpImbalanceLookback = 200;                  // Bars back to list imbalances
input int             InpZoneLookbackBars  = 300;                  // Bars back to show blocks
input bool            InpMTF               = false;                 // Draw every structure timeframe at once
input bool            InpShowBiasZone      = true;                  // Mark the timeframe the bias came from
input color           InpColBias           = clrDeepSkyBlue;        // Bias-zone colour
input bool            InpPanelStartFull    = false;                 // Panel opens expanded
input bool            InpLogDiag           = false;                 // Log the 30-second [DIAG] block
input bool            InpShowTarget       = false;                  // Draw the dotted target level
input bool            InpClean            = true;                   // CLEAN: draw only the trade - box, entry, stop, target
input bool            InpZoneAudit        = false;                  // Verification mode: draw every zone in history
input int             InpAuditMax         = 60;                     // How many historical zones / rejects to draw
input bool            InpZoneFill         = true;                   // Draw the zone as a faint box as well as two levels
input bool            InpAuditRejected    = false;                  // Draw refused imbalances (verification only - noisy)
input double          InpMinRiskATR       = 0.5;                    // Min stop distance (x exec ATR) before a zone is skipped
input int             InpZoneMaxAge       = 200;                    // Bars before an untouched zone is abandoned
input double          InpFvgMinATR        = 0.10;                    // Min imbalance size inside the impulse (x ATR) - RB D-06

input color           InpColFresh          = clrDarkGreen;           // Demand zone box (dark = faint)
input color           InpColUsed           = clrSilver;            // Used or tapped zone box
input color           InpColSupply         = clrDarkRed;            // Supply zone box (dark = faint)
input color           InpColGap            = clrGold;              // Imbalance band

input group           "=== 4. Display ==="
input bool            InpShowPanel        = true;                   // Show live panel on chart
input int             InpPanelX           = 12;                      // Panel X (pixels from left)
input int             InpPanelY           = 22;                     // Panel Y (pixels from top)
input int             InpPanelFontSize    = 9;                      // Panel font size
input color           InpPanelOK          = clrLime;                // Colour: gate PASS
input color           InpPanelBlock       = clrOrangeRed;           // Colour: gate BLOCK
input color           InpPanelText        = clrWhite;               // Colour: normal text

input group           "=== 5. Logging ==="
input bool            InpDiagnostics      = true;                   // Print diagnostics to Experts log
input int             InpDiagEverySeconds = 60;                     // Log interval (seconds)
input double          InpDiagSlPips       = 20.0;                   // Illustrative SL (pips) for lot preview

//+------------------------------------------------------------------+
//| Globals                                                           |
//+------------------------------------------------------------------+
CSpaProfiles          g_profiles;
CSpaSymbol            g_symbol;
CSpaStructure         g_bias;
CSpaStructure         g_confirm;
CSpaStructure         g_exec;
SpaProfile            g_profile;

int                   g_h_atr_confirm = INVALID_HANDLE;
bool                  g_config_ok     = false;

//--- cached metrics -------------------------------------------------
double                g_bid       = 0.0;
double                g_ask       = 0.0;
double                g_sp_price  = 0.0;
double                g_sp_pips   = 0.0;
double                g_med_pips  = 0.0;
double                g_ratio     = 0.0;
double                g_atr_conf  = 0.0;
double                g_sl_px     = 0.0;
double                g_lots      = 0.0;
int                   g_sp_samples= 0;
string                g_regime    = "UNKNOWN";
bool                  g_coarse_ok = false;
bool                  g_risk_ok   = false;
bool                  g_perm_ok   = false;
string                g_coarse_reason = "";
string                g_risk_reason   = "";
string                g_perm_reason   = "";

datetime              g_last_refresh   = 0;
datetime              g_last_diag      = 0;
datetime              g_last_bias_bar  = 0;
datetime              g_last_chart_bar = 0;
string                g_refine_text   = "refinement not run";
string                g_zone_line     = "";
string                g_state_line    = "";
int                   g_refine_idx    = -1;
bool                  g_panel_full    = false;
datetime              g_last_conf_bar  = 0;
datetime              g_last_exec_bar  = 0;
int                   g_arrow_count    = 0;
bool                  g_arrows_hidden  = false;   // all structure TFs finer than the chart
CSpaZones             g_zones;    // primary: the one signals will use
CSpaZones             g_zonesB;   // bias timeframe, drawn only
CSpaZones             g_zonesC;   // confirm timeframe, drawn only
CSpaZones             g_zonesE;   // exec timeframe, drawn only
CSpaStructure         g_chart;    // the timeframe the chart is on
CSpaZones             g_zonesChart;// zones of the chart's own timeframe
SpaPlan               g_plan;
SpaZone               g_plan_zone;
string                g_signal_note     = "NO SIGNAL";
int                   g_tick_count     = 0;

//--- spread self-calibration ----------------------------------------
//--- iSpread() is not available on every MetaEditor build (it failed to
//--- compile on the user's build with "wrong parameters count"). The
//--- regime line is diagnostics only, so rather than depend on an
//--- indicator that may not exist, the EA samples the live spread once
//--- per M1 bar and builds its own baseline. Self-calibrating, no
//--- external dependency, and it measures the spread this account
//--- actually pays rather than a nominal series.
#define SPA_SP_CAP        1440     // one sample per M1 bar -> 24h of history
#define SPA_SP_MIN_SAMPLES  30     // below this the regime is CALIBRATING

double                g_sp_buf[];
int                   g_sp_n            = 0;
datetime              g_sp_last_bar     = 0;

//--- panel geometry -------------------------------------------------
#define SPA_PANEL_ROWS 26
#define SPA_PANEL_COMMENT_PAD 22
#define SPA_SW_PREFIX  "SPA_SW_"

//+------------------------------------------------------------------+
double AtrValue(const int handle,const int shift=1)
  {
   if(handle==INVALID_HANDLE)
      return(0.0);
   double buf[];
   ArraySetAsSeries(buf,true);
   if(CopyBuffer(handle,0,shift,1,buf)!=1)
      return(0.0);
   return(buf[0]);
  }

//+------------------------------------------------------------------+
void SampleSpread()
  {
   datetime m1 = iTime(_Symbol,PERIOD_M1,0);
   if(m1==g_sp_last_bar)
      return;
   g_sp_last_bar = m1;

   double sp = g_symbol.SpreadPrice();
   if(sp<=0.0)
      return;

   if(g_sp_n>=SPA_SP_CAP)
     {
      //--- manual shift instead of ArrayRemove(): one less built-in whose
      //--- availability we have to assume. 1440 iterations once a minute
      //--- is free.
      for(int i=1;i<g_sp_n;i++)
         g_sp_buf[i-1] = g_sp_buf[i];
      g_sp_n--;
     }
   ArrayResize(g_sp_buf,g_sp_n+1);
   g_sp_buf[g_sp_n] = sp;
   g_sp_n++;
  }

//+------------------------------------------------------------------+
double SpreadMedianPips(int &samples_out)
  {
   samples_out = g_sp_n;
   if(g_sp_n<=0)
      return(0.0);

   double tmp[];
   ArrayResize(tmp,g_sp_n);
   for(int i=0;i<g_sp_n;i++)
      tmp[i] = g_sp_buf[i];
   ArraySort(tmp);

   int    n   = g_sp_n;
   double med = (n%2==1) ? tmp[n/2] : 0.5*(tmp[n/2-1]+tmp[n/2]);
   return(med/g_symbol.Pip());
  }

//+------------------------------------------------------------------+
void RefreshMetrics()
  {
   g_bid        = g_symbol.Bid();
   g_ask        = g_symbol.Ask();
   g_sp_price   = g_symbol.SpreadPrice();
   g_sp_pips    = g_symbol.SpreadPips();
   g_atr_conf   = AtrValue(g_h_atr_confirm);
   g_sl_px      = InpDiagSlPips*g_symbol.Pip();
   g_lots       = g_symbol.LotsForRisk(
                     AccountInfoDouble(ACCOUNT_EQUITY)*g_profile.risk_pct/100.0,g_sl_px);

   g_coarse_ok  = g_symbol.SpreadOKCoarse(g_coarse_reason);
   g_risk_ok    = g_symbol.SpreadOKAtRisk(g_sl_px,g_risk_reason);
   g_perm_ok    = g_symbol.TradingPermitted(g_perm_reason);

   SampleSpread();

   g_med_pips   = SpreadMedianPips(g_sp_samples);
   g_ratio      = (g_med_pips>0.0) ? g_sp_pips/g_med_pips : 0.0;

   if(g_sp_samples<SPA_SP_MIN_SAMPLES) g_regime = "CALIBRATING";
   else if(g_ratio<1.5)                g_regime = "NORMAL";
   else if(g_ratio<3.0)                g_regime = "ELEVATED";
   else                                g_regime = "BLOWOUT";
  }

//+------------------------------------------------------------------+
//| Compact one-line structure summary for the panel                  |
//+------------------------------------------------------------------+
string StructureLine(CSpaStructure &st,const string tag)
  {
   if(!st.IsReady())
      return(StringFormat("%-4s  no data",tag));

   SpaPivot hi, lo;
   string sh = st.LastPivot(true,hi)  ? StringFormat("%s %.5g",hi.label,hi.price) : "n/a";
   string sl = st.LastPivot(false,lo) ? StringFormat("%s %.5g",lo.label,lo.price) : "n/a";

   return(StringFormat("%-4s  %-5s  %s  %s  cons:%-3s  brk:%s",
                       tag,st.TrendText(),sh,sl,
                       st.IsConsolidating() ? "YES" : "no",
                       st.IsValidShift(true) ? "BEAR" : "-"));
  }

//+------------------------------------------------------------------+
//| Draw detected swings so the user can audit them visually          |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| How far above/below the actual swing price each timeframe draws.  |
//| Without this, three timeframes detecting a swing on the same bar  |
//| print three arrows on top of each other and you cannot tell which |
//| arrow belongs to which timeframe. EXEC sits closest to price      |
//| because it is the timeframe you actually trade.                   |
//+------------------------------------------------------------------+
double SlotOffsetATR(const int slot)
  {
   if(slot==0) return(2.0*InpArrowSpreadATR);   // BIAS   - furthest out
   if(slot==1) return(1.0*InpArrowSpreadATR);   // CONFIRM
   return(0.0);                                 // EXEC   - on the price
  }

void DrawSwings(CSpaStructure &st,const int slot,const color col,const double ref_atr)
  {
   if(!InpDrawStructure)
      return;

   //--- all three timeframes are offset using the SAME atr, so the gaps
   //--- look identical on screen instead of scaling with each TF's own
   //--- volatility (an H4 atr would fling the bias arrows off the candles).
   double off = SlotOffsetATR(slot)*ref_atr;

   int cnt  = st.PivotCount();
   int from = cnt-InpDrawMaxPivots;
   if(from<0)
      from = 0;

   for(int i=from;i<cnt;i++)
     {
      SpaPivot p;
      if(!st.GetPivot(i,p))
         continue;

      string nm = StringFormat("%s%d_%d",SPA_SW_PREFIX,slot,i);

      //--- push the arrow away from price in the direction it points, so
      //--- arrows from different timeframes never overprint.
      double draw_px = p.is_high ? (p.price+off) : (p.price-off);

      if(ObjectFind(0,nm)<0)
        {
         if(!ObjectCreate(0,nm,OBJ_ARROW,0,p.time,draw_px))
           {
            //--- never fail silently: the whole point of this build is
            //--- that you can SEE what the engine detected.
            PrintFormat("[OBJ] ERROR creating arrow %-18s err=%d (t=%s p=%.5g)",
                        nm,GetLastError(),TimeToString(p.time),p.price);
            continue;
           }
        }
      if(!ObjectSetInteger(0,nm,OBJPROP_ARROWCODE,p.is_high ? 234 : 233) ||
         !ObjectSetDouble(0,nm,OBJPROP_PRICE,draw_px) ||
         !ObjectSetInteger(0,nm,OBJPROP_TIME,p.time))
        {
         PrintFormat("[OBJ] ERROR configuring arrow %s err=%d",nm,GetLastError());
         continue;
        }
      ObjectSetInteger(0,nm,OBJPROP_COLOR,col);
      ObjectSetInteger(0,nm,OBJPROP_WIDTH,1);
      ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
      ObjectSetInteger(0,nm,OBJPROP_ANCHOR,p.is_high ? ANCHOR_BOTTOM : ANCHOR_TOP);
      g_arrow_count++;
     }
  }

//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| ZONE ENGINE - runs once per new exec bar                          |
//| Computes: zones -> best plan -> the note shown on the panel.      |
//+------------------------------------------------------------------+
ENUM_TIMEFRAMES ZoneTF()
  {
   if(InpZoneTF==SPA_ZONE_BIAS)    return(g_profile.tf_bias);
   if(InpZoneTF==SPA_ZONE_EXEC)    return(g_profile.tf_exec);
   return(g_profile.tf_confirm);
  }

//+------------------------------------------------------------------+
//| Reason codes are for the log. On screen, say what it MEANS.       |
//+------------------------------------------------------------------+
string PlainReason(const string r)
  {
   if(r=="REJ_NO_TREND")      return("bias timeframe is ranging - no trade");
   if(r=="REJ_NO_ZONE")       return("no order block with an imbalance yet");
   if(r=="REJ_NO_FRESH_ZONE") return("newest zones already tapped - wait for the next impulse");
   if(r=="REJ_RR")            return("first target ahead is under 3x the risk");
   if(r=="REJ_SL_TOO_TIGHT")  return("order block too small - stop would sit inside the noise");
   if(r=="REJ_NO_TARGET")     return("no structural level ahead to aim at");
   if(r=="REJ_NO_LOT")        return("lot size rounds to zero at this risk");
   return(r);
  }

void RefreshSignal()
  {
   //--- zones are built from the chosen structure, not always from exec --
   //--- Audit mode exists so the user can check the engine's reading of the
   //--- chart. It changes what is DRAWN, never what would be traded.
   g_zones.SetLatestOnly(InpZonesLatestOnly && !InpZoneAudit);
   g_zones.SetImbalance(InpFvgMinATR,0);
   if(InpZoneTF==SPA_ZONE_BIAS)         g_zones.FindFVGZones(g_bias);
   else if(InpZoneTF==SPA_ZONE_EXEC)    g_zones.FindFVGZones(g_exec);
   else                                 g_zones.FindFVGZones(g_confirm);

   //--- the whole inventory, one set per timeframe. These are for DRAWING
   //--- only: a signal still comes from the primary set, so adding a
   //--- timeframe cannot change what would be traded.
   //--- zones of whatever timeframe this chart is on
   g_chart.Refresh();
   g_zonesChart.SetLatestOnly(InpZonesLatestOnly && !InpZoneAudit);
   g_zonesChart.SetImbalance(InpFvgMinATR,0);
   g_zonesChart.FindFVGZones(g_chart);
   //--- one move = one block. Collapse each run to its extreme before
   //--- anything else looks at the list.
   g_zonesChart.CompressRuns(g_chart);

   //--- RULE BOOK 3.3: rank this timeframe's zones and pick the extreme one.
   //--- This is the engine's choice. The chart does not change because of it;
   //--- the panel and the log say what it chose and why.
   {
      string rsn;
      string tr = g_bias.TrendText();
      if(tr=="UP" || tr=="DOWN")
         g_refine_idx = g_zonesChart.SelectExtreme(g_chart,tr=="UP",
                        (g_symbol.Bid()+g_symbol.Ask())/2.0,rsn);
      else
        {
         g_refine_idx = -1;
         rsn = "bias is RANGE - nothing to rank";
        }
      g_refine_text = rsn;

      SpaZone sel;
      if(g_refine_idx>=0 && g_zonesChart.Get(g_refine_idx,sel))
         g_state_line = StringFormat("candidate %s %s  at %s",
                        TFName(PERIOD_CURRENT),
                        sel.demand ? "DEMAND" : "SUPPLY",
                        TimeToString(sel.t_ob,TIME_DATE|TIME_MINUTES));
      else
         g_state_line = "no candidate zone";

      g_zone_line = StringFormat("%d blocks on this %s chart",g_zonesChart.Count(),
                                 TFName(PERIOD_CURRENT));
      PrintFormat("== REFINE == %s",rsn);
   }

   if(InpMTF)
     {
      g_zonesB.SetLatestOnly(InpZonesLatestOnly && !InpZoneAudit);
      g_zonesB.SetImbalance(InpFvgMinATR,0);
      g_zonesB.FindFVGZones(g_bias);
      g_zonesC.SetLatestOnly(InpZonesLatestOnly && !InpZoneAudit);
      g_zonesC.SetImbalance(InpFvgMinATR,0);
      g_zonesC.FindFVGZones(g_confirm);
      g_zonesE.SetLatestOnly(InpZonesLatestOnly && !InpZoneAudit);
      g_zonesE.SetImbalance(InpFvgMinATR,0);
      g_zonesE.FindFVGZones(g_exec);
     }

   double pip   = g_symbol.Pip();
   double sp_px = g_symbol.SpreadPrice();
   double rr_min= g_profile.min_rr;

   bool have = g_zones.BestPlan(g_bias,g_confirm,g_bias.TrendText(),
                                sp_px,pip,rr_min,InpMinRiskATR*g_exec.ATR(),InpZoneMaxAge,
                                g_plan,g_plan_zone);

   if(have)
     {
      double risk_money = AccountInfoDouble(ACCOUNT_EQUITY)*g_profile.risk_pct/100.0;
      g_plan.lots = g_symbol.LotsForRisk(risk_money,MathAbs(g_plan.entry-g_plan.sl));
      if(g_plan.lots<=0.0)
        {
         g_plan.valid  = false;
         g_plan.reason = "REJ_NO_LOT";
         g_signal_note = StringFormat("NO TRADE: %s  [%s]",PlainReason(g_plan.reason),g_plan.reason);
         return;
        }
      g_signal_note = StringFormat("%s LIMIT %.5g  SL %.5g  TP %.5g  %.2f lots  %.2fR",
                                   g_plan.is_buy ? "BUY" : "SELL",
                                   g_plan.entry,g_plan.sl,g_plan.tp,
                                   g_plan.lots,g_plan.rr);
     }
   else
      g_signal_note = StringFormat("NO TRADE: %s  [%s]",PlainReason(g_plan.reason),g_plan.reason);
  }

//+------------------------------------------------------------------+
//| Should this timeframe's swings be drawn on the current chart?     |
//|                                                                   |
//| Only structure at or ABOVE the chart's own timeframe. Drawing M5  |
//| swings on a Weekly chart squeezes a day of pivots into one candle |
//| and produces the pile of overlapping arrows seen in review.       |
//+------------------------------------------------------------------+
bool ShouldDrawTF(const ENUM_TIMEFRAMES st_tf)
  {
   return(PeriodSeconds(st_tf)>=PeriodSeconds((ENUM_TIMEFRAMES)_Period));
  }

//+------------------------------------------------------------------+
//| Draw the zones the engine is watching, and the exact order it     |
//| WOULD place. No order is sent by this build.                      |
//+------------------------------------------------------------------+
#define SPA_ZONE_PREFIX "SPA_Z_"

void HLevel(const string nm,const datetime t1,const datetime t2,const double price,
            const color clr,const int width,const int style)
  {
   if(ObjectFind(0,nm)>=0)
      ObjectDelete(0,nm);
   if(!ObjectCreate(0,nm,OBJ_TREND,0,t1,price,t2,price))
      return;
   ObjectSetInteger(0,nm,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,nm,OBJPROP_WIDTH,width);
   ObjectSetInteger(0,nm,OBJPROP_STYLE,style);
   ObjectSetInteger(0,nm,OBJPROP_RAY_LEFT,false);
   ObjectSetInteger(0,nm,OBJPROP_RAY_RIGHT,false);
   ObjectSetInteger(0,nm,OBJPROP_BACK,false);
   ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
  }

//+------------------------------------------------------------------+
//| CLEAN MODE (v0.8.1)                                              |
//|                                                                  |
//| "Remove everything. I want you to draw the zones... the zones    |
//|  where I enter and the stop loss, and then the TP, where the     |
//|  other zone is."                                                 |
//|                                                                  |
//| One box on the block, two dotted levels for entry and stop, one   |
//| dotted level for the target. No labels, no numbers, no           |
//| imbalances, no refusals. If it cannot be read at a glance it is   |
//| not doing its job.                                               |
//+------------------------------------------------------------------+

string TFName(const ENUM_TIMEFRAMES tf)
  {
   string t = EnumToString(tf);
   if(StringFind(t,"PERIOD_")==0)
      t = StringSubstr(t,7);
   return(t);
  }

//+------------------------------------------------------------------+
//| One zone: the block candle, its imbalance, and the levels.        |
//| The tag keeps objects from different timeframes apart.            |
//+------------------------------------------------------------------+
void DrawCleanOne(CSpaZones &zs,const int idx,const color clr,
                  const ENUM_TIMEFRAMES tf,const string tag,const bool fillit)
  {
   SpaZone z;
   if(!zs.Get(idx,z))
      return;

   string   tfname = TFName(tf);
   string   base   = SPA_ZONE_PREFIX+tag+"c"+IntegerToString(idx);
   int      secs   = PeriodSeconds(tf);
   datetime t1     = z.t_ob;
   datetime tnow   = iTime(_Symbol,_Period,0);

   //--- a live zone reaches the current bar because that is the area being
   //--- watched. A used zone stops soon after its impulse.
   //--- a FILLED box is the timeframe you chose: it runs to the live bar.
   //--- An OUTLINE box is a context zone: it stops 40 bars after its block,
   //--- because a high-timeframe box stretched to "now" reads as a wall.
   datetime tzone;
   if(fillit)
      tzone = z.fresh ? tnow : t1+(datetime)(20*secs);
   else
      tzone = t1+(datetime)(InpZoneBoxBars*secs);
   if(tzone>tnow)
      tzone = tnow;

   string bn = base+"_box";
   if(ObjectCreate(0,bn,OBJ_RECTANGLE,0,t1,z.top,tzone,z.bottom))
     {
      ObjectSetInteger(0,bn,OBJPROP_COLOR,clr);
      ObjectSetInteger(0,bn,OBJPROP_FILL,fillit);
      ObjectSetInteger(0,bn,OBJPROP_BACK,true);
      ObjectSetInteger(0,bn,OBJPROP_WIDTH,fillit?1:1);
      ObjectSetInteger(0,bn,OBJPROP_STYLE,STYLE_SOLID);
      ObjectSetInteger(0,bn,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,bn,OBJPROP_HIDDEN,true);
     }

   //--- the label sits INSIDE the box, vertically centred. Anchored at the top
   //--- edge it collided with the label of the box above it, which is the one
   //--- thing that made three timeframes look cluttered.
   string zn = base+"_zl";
   if(ObjectCreate(0,zn,OBJ_TEXT,0,t1,(z.top+z.bottom)/2.0))
     {
      //--- ONLY the timeframe. No "ZONE", no "this block's gap", no numbers:
      //--- the colour already says buy or sell, the height already says the
      //--- level, and the only thing you cannot see is which timeframe it is.
      ObjectSetString(0,zn,OBJPROP_TEXT,StringFormat(" %s",tfname));
      ObjectSetString(0,zn,OBJPROP_FONT,"Consolas");
      ObjectSetInteger(0,zn,OBJPROP_FONTSIZE,8);
      ObjectSetInteger(0,zn,OBJPROP_COLOR,z.demand ? InpColFreshTxt : InpColSupplyTxt);
      ObjectSetInteger(0,zn,OBJPROP_ANCHOR,ANCHOR_LEFT);
      ObjectSetInteger(0,zn,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,zn,OBJPROP_HIDDEN,true);
     }

   double entry = z.demand ? z.top    : z.bottom;
   double stop  = z.demand ? z.bottom : z.top;
   HLevel(base+"_e",t1,tzone,entry,clr,1,STYLE_DOT);
   HLevel(base+"_s",t1,tzone,stop, clr,1,STYLE_DOT);

   double tp   = 0.0;
   bool   have = false;
   int    n    = zs.Count();
   for(int i=n-1;i>=0;i--)
     {
      SpaZone o;
      if(!zs.Get(i,o))
         continue;
      if(o.demand==z.demand)
         continue;
      double lvl = z.demand ? o.bottom : o.top;
      if(z.demand  && lvl<=entry) continue;
      if(!z.demand && lvl>=entry) continue;
      if(!have || (z.demand ? (lvl<tp) : (lvl>tp)))
        {
         tp   = lvl;
         have = true;
        }
     }
   if(have && InpShowTarget)
      HLevel(base+"_tp",t1,tnow,tp,InpColGap,1,STYLE_DOT);
  }

//+------------------------------------------------------------------+
//| Draw one timeframe's set. Freshness prefers a live block but      |
//| never leaves the chart empty - about 2 of 315 M15 blocks are      |
//| untouched at any moment, so "fresh only" blanks the chart.        |
//+------------------------------------------------------------------+
void DrawCleanSet(CSpaZones &zs,const ENUM_TIMEFRAMES tf,const string tag,const bool fillit)
  {
   int n = zs.Count();
   if(n<=0)
      return;

   int freshDemand=-1, freshSupply=-1, anyDemand=-1, anySupply=-1;
   for(int i=n-1;i>=0 && (freshDemand<0 || freshSupply<0 || anyDemand<0 || anySupply<0);i--)
     {
      SpaZone z;
      if(!zs.Get(i,z))
         continue;
      if(z.demand)
        {
         if(anyDemand<0)              anyDemand   = i;
         if(z.fresh && freshDemand<0) freshDemand = i;
        }
      else
        {
         if(anySupply<0)              anySupply   = i;
         if(z.fresh && freshSupply<0) freshSupply = i;
        }
     }

   int demandIdx = (freshDemand>=0) ? freshDemand : anyDemand;
   int supplyIdx = (freshSupply>=0) ? freshSupply : anySupply;

   if(demandIdx>=0) DrawCleanOne(zs,demandIdx,InpColFresh, tf,tag,fillit);
   if(supplyIdx>=0) DrawCleanOne(zs,supplyIdx,InpColSupply,tf,tag,fillit);

   SpaZone dz, sz;
   string dt = (demandIdx>=0 && zs.Get(demandIdx,dz))
                ? TimeToString(dz.t_ob,TIME_DATE|TIME_MINUTES) : "none";
   string st = (supplyIdx>=0 && zs.Get(supplyIdx,sz))
                ? TimeToString(sz.t_ob,TIME_DATE|TIME_MINUTES) : "none";
   PrintFormat("[ZONE] %s clean: found=%d  BUY block=%s  SELL block=%s",
               TFName(tf),n,dt,st);
  }

//+------------------------------------------------------------------+
//| Multi-timeframe: the chart shows the inventory of EVERY structure |
//| timeframe at once, each labelled, so an M5 chart still shows the  |
//| H4 and M15 zones above it.                                        |
//+------------------------------------------------------------------+
void DrawBlock(const int idx,const SpaZone &z,const bool selected,
               const int secs,const datetime tnow)
  {
   color    clr = z.demand ? InpColFresh : InpColSupply;
   datetime t1  = z.t_ob;
   datetime t2  = t1+(datetime)(InpZoneBoxBars*secs);
   if(t2>tnow)
      t2 = tnow;
   if(t2<=t1)
      return;

   string bn = SPA_ZONE_PREFIX+"k"+IntegerToString(idx);
   if(!ObjectCreate(0,bn,OBJ_RECTANGLE,0,t1,z.top,t2,z.bottom))
      return;
   ObjectSetInteger(0,bn,OBJPROP_COLOR,clr);
   //--- the block the engine currently ranks highest is the only filled one.
   //--- Everything else is a thin outline: visible, selectable, not shouting.
   ObjectSetInteger(0,bn,OBJPROP_FILL,selected);
   ObjectSetInteger(0,bn,OBJPROP_BACK,true);
   ObjectSetInteger(0,bn,OBJPROP_WIDTH,1);
   ObjectSetInteger(0,bn,OBJPROP_STYLE,STYLE_SOLID);
   ObjectSetInteger(0,bn,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,bn,OBJPROP_HIDDEN,true);
  }

//+------------------------------------------------------------------+
//| The block that gave us the bias: the newest one on the bias       |
//| timeframe, in the direction the bias points.                      |
//+------------------------------------------------------------------+
void DrawBiasZone()
  {
   int      n    = g_zonesB.Count();
   int      secs = PeriodSeconds(g_profile.tf_bias);
   datetime tnow = iTime(_Symbol,_Period,0);
   string   want = g_bias.TrendText();
   bool     sell = (want=="DOWN");
   bool     buy  = (want=="UP");
   if(!sell && !buy)
      return;                       // no directional bias: nothing to mark

   int     found = -1;
   SpaZone z;
   for(int i=n-1;i>=0;i--)
     {
      SpaZone c;
      if(!g_zonesB.Get(i,c))
         continue;
      if(c.demand==sell)             // DOWN bias wants the supply block
         continue;
      found = i;
      break;
     }
   if(found<0 || !g_zonesB.Get(found,z))
      return;

   datetime t1 = z.t_ob;
   datetime t2 = t1+(datetime)(InpZoneBoxBars*secs);
   if(t2>tnow)
      t2 = tnow;
   if(t2<=t1)
      return;

   string bn = SPA_ZONE_PREFIX+"bias_box";
   if(ObjectCreate(0,bn,OBJ_RECTANGLE,0,t1,z.top,t2,z.bottom))
     {
      ObjectSetInteger(0,bn,OBJPROP_COLOR,InpColBias);
      ObjectSetInteger(0,bn,OBJPROP_FILL,false);
      ObjectSetInteger(0,bn,OBJPROP_BACK,true);
      ObjectSetInteger(0,bn,OBJPROP_WIDTH,1);
      ObjectSetInteger(0,bn,OBJPROP_STYLE,STYLE_SOLID);
      ObjectSetInteger(0,bn,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,bn,OBJPROP_HIDDEN,true);
     }
   string ln = SPA_ZONE_PREFIX+"bias_lbl";
   if(ObjectCreate(0,ln,OBJ_TEXT,0,t1,(z.top+z.bottom)/2.0))
     {
      ObjectSetString(0,ln,OBJPROP_TEXT," "+TFName(g_profile.tf_bias));
      ObjectSetString(0,ln,OBJPROP_FONT,"Consolas");
      ObjectSetInteger(0,ln,OBJPROP_FONTSIZE,8);
      ObjectSetInteger(0,ln,OBJPROP_COLOR,InpColBias);
      ObjectSetInteger(0,ln,OBJPROP_ANCHOR,ANCHOR_LEFT);
      ObjectSetInteger(0,ln,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,ln,OBJPROP_HIDDEN,true);
     }
  }

void DrawClean()
  {
   //--- SHOW EVERY LAST CANDLE BEFORE THE IMPULSE, not one per direction.
   //--- Picking one was my rule, and it hid the block at the top of the range
   //--- that price tapped cleanly. Nothing is chosen here; the inventory is
   //--- laid out and the choosing happens later, on confirmation.
   int      n    = g_zonesChart.Count();
   //--- The block index is an index into the STRUCTURE's arrays, not into the
   //--- terminal's whole history. Using Bars() here compared a 600-bar array
   //--- against 7,500 daily bars and rejected every block: that is why a Daily
   //--- chart showed no zones at all.
   int      nb   = g_chart.Bars();
   int      secs = PeriodSeconds(PERIOD_CURRENT);
   datetime tnow = iTime(_Symbol,_Period,0);
   int      drawn= 0;

   for(int i=n-1;i>=0 && drawn<InpDrawZonesMax;i--)
     {
      SpaZone z;
      if(!g_zonesChart.Get(i,z))
         continue;
      //--- The user, 2026-11-03, reverses the earlier "must be filled all the
      //--- way" reading: "the moment the box is touched the imbalance is
      //--- already filled." A block price has come back into AT ALL - a dip or
      //--- a tap - is spent and comes off the chart.
      if(z.retested)
         continue;
      if(z.ob_idx < nb-InpZoneLookbackBars)
         continue;
      DrawBlock(i,z,(i==g_refine_idx),secs,tnow);
      drawn++;
     }

   if(InpShowBiasZone && Period()!=g_profile.tf_bias)
      DrawBiasZone();

   //--- say WHERE the blocks were lost, not just how many survived. Without
   //--- this the only number available was "32 known", which cannot tell you
   //--- whether the imbalances were never found or were found and rejected.
   int cand=0,none=0,small=0,filled=0,ok=0;
   g_zonesChart.Diag(cand,none,small,filled,ok);
   PrintFormat("== ZONE == %s: %d shown of %d known | found=%d  ok=%d  too-small=%d  atr=%.5f  bars=%d  lookback=%d",
               TFName(PERIOD_CURRENT),drawn,n,cand,ok,small,g_chart.ATR(),
               g_chart.Bars(),InpZoneLookbackBars);
  }

void DrawZones()
  {
   if(!InpShowZones)
      return;

   ObjectsDeleteAll(0,SPA_ZONE_PREFIX);

   if(InpClean)
     {
      DrawClean();
      return;
     }

   int n       = g_zones.Count();
   int shown   = 0;
   int maxdraw = InpZoneAudit ? InpAuditMax : InpDrawZonesMax;
   int secs    = PeriodSeconds(ZoneTF());

   for(int i=n-1;i>=0 && shown<maxdraw;i--)
     {
      SpaZone z;
      if(!g_zones.Get(i,z))
         continue;

      bool live    = z.fresh;
      bool expired = (z.age>InpZoneMaxAge);
      color zc     = live ? (z.demand ? InpColFresh : InpColSupply) : InpColUsed;

      //--- A ZONE IS TWO HORIZONTAL LEVELS, not a filled box.
      //--- MQL5 has no alpha on OBJ_RECTANGLE, so a "transparent" box is an
      //--- opaque box - it either hides the candles or is hidden by them.
      //--- Their 70%-transparent box becomes two levels here: the candles
      //--- stay readable, and there is no left or right border to read as a
      //--- vertical line.
      int      span = (int)MathMin((double)MathMax(z.break_idx-z.ob_idx+2,6),40.0);
      datetime t1   = z.t_ob;
      datetime t2   = z.t_ob+(datetime)(span*secs);
      string   base = SPA_ZONE_PREFIX+IntegerToString(i);

      //--- a faint box behind the candles, the way their boxes read, plus the
      //--- exact top and bottom as two levels. The box is drawn in the
      //--- background so the candles stay fully visible.
      if(InpZoneFill)
        {
         string bn = base+"_box";
         if(ObjectCreate(0,bn,OBJ_RECTANGLE,0,t1,z.top,t2,z.bottom))
           {
            ObjectSetInteger(0,bn,OBJPROP_COLOR,zc);
            ObjectSetInteger(0,bn,OBJPROP_FILL,true);
            ObjectSetInteger(0,bn,OBJPROP_BACK,true);
            ObjectSetInteger(0,bn,OBJPROP_WIDTH,0);
            ObjectSetInteger(0,bn,OBJPROP_STYLE,STYLE_SOLID);
            ObjectSetInteger(0,bn,OBJPROP_SELECTABLE,false);
            ObjectSetInteger(0,bn,OBJPROP_HIDDEN,true);
           }
        }
      HLevel(base+"_t",t1,t2,z.top,   zc,live?2:1,STYLE_SOLID);
      HLevel(base+"_b",t1,t2,z.bottom,zc,live?2:1,STYLE_SOLID);

      string on = base+"_tag";
      if(ObjectCreate(0,on,OBJ_TEXT,0,t2,z.top))
        {
         ObjectSetString(0,on,OBJPROP_TEXT,
            StringFormat("%s %s%s",
                         EnumToString(ZoneTF()),
                         z.demand ? "DEMAND" : "SUPPLY",
                         live ? "" : (expired ? " used" : " tapped")));
         ObjectSetString(0,on,OBJPROP_FONT,"Consolas");
         ObjectSetInteger(0,on,OBJPROP_FONTSIZE,7);
         ObjectSetInteger(0,on,OBJPROP_COLOR,zc);
         ObjectSetInteger(0,on,OBJPROP_ANCHOR,ANCHOR_LEFT_LOWER);
         ObjectSetInteger(0,on,OBJPROP_SELECTABLE,false);
         ObjectSetInteger(0,on,OBJPROP_HIDDEN,true);
        }

      //--- the imbalance that validates the zone: two dotted levels inside
      //--- the impulse, so the gap is visible without covering anything.
      //--- the imbalance itself: a faint box only while it is still untouched.
      //--- Once price has traded into it, it is spent and it comes off the
      //--- chart. No label - the point of interest is the block, not the gap.
      if(InpZoneAudit && !z.gap_filled && z.gap_high>z.gap_low)
        {
         string gn = base+"_imb";
         int    gspan = (int)MathMin((double)MathMax(z.break_idx-z.gap_idx+3,8),26.0);
         datetime g1 = z.t_gap;
         datetime g2 = z.t_gap+(datetime)(gspan*secs);
         if(ObjectCreate(0,gn,OBJ_RECTANGLE,0,g1,z.gap_high,g2,z.gap_low))
           {
            ObjectSetInteger(0,gn,OBJPROP_COLOR,InpColGap);
            ObjectSetInteger(0,gn,OBJPROP_FILL,true);
            ObjectSetInteger(0,gn,OBJPROP_BACK,true);
            ObjectSetInteger(0,gn,OBJPROP_WIDTH,0);
            ObjectSetInteger(0,gn,OBJPROP_STYLE,STYLE_SOLID);
            ObjectSetInteger(0,gn,OBJPROP_SELECTABLE,false);
            ObjectSetInteger(0,gn,OBJPROP_HIDDEN,true);
           }
        }

      shown++;
     }

   //--- AUDIT: order blocks the engine looked at and refused. Two short
   //--- levels, so a refusal is visible without becoming noise.
   if(InpZoneAudit && InpAuditRejected)
     {
      int rn = g_zones.RejectCount();
      int rshown = 0;
      for(int i=rn-1;i>=0 && rshown<InpAuditMax;i--)
        {
         SpaReject r;
         if(!g_zones.GetReject(i,r))
            continue;
         string   base = SPA_ZONE_PREFIX+"rej"+IntegerToString(i);
         datetime r1   = r.t_ob;
         datetime r2   = r.t_ob+(datetime)(12*secs);
         HLevel(base+"_t",r1,r2,r.top,   InpColUsed,1,STYLE_DASH);
         HLevel(base+"_b",r1,r2,r.bottom,InpColUsed,1,STYLE_DASH);

         string why = (r.why==2) ? "gap too small"
                    : (r.why==3) ? "gap closed by the impulse"
                                 : "no 3-candle gap";
         string on = base+"_tag";
         if(ObjectCreate(0,on,OBJ_TEXT,0,r2,r.top))
           {
            ObjectSetString(0,on,OBJPROP_TEXT,
                            StringFormat("OB %s REJECTED: %s",r.demand ? "demand" : "supply",why));
            ObjectSetString(0,on,OBJPROP_FONT,"Consolas");
            ObjectSetInteger(0,on,OBJPROP_FONTSIZE,6);
            ObjectSetInteger(0,on,OBJPROP_COLOR,InpColUsed);
            ObjectSetInteger(0,on,OBJPROP_ANCHOR,ANCHOR_LEFT_LOWER);
            ObjectSetInteger(0,on,OBJPROP_SELECTABLE,false);
            ObjectSetInteger(0,on,OBJPROP_HIDDEN,true);
           }
         rshown++;
        }
     }
  }

void DrawAllSwings()
  {
   if(!InpDrawStructure)
      return;

   //--- clear first: positional names would otherwise leave stale arrows
   //--- behind whenever a pivot index shifts.
   ObjectsDeleteAll(0,SPA_SW_PREFIX);

   g_arrow_count = 0;

   double ref_atr = (g_exec.ATR()>0.0) ? g_exec.ATR() : g_confirm.ATR();

   int drawn = 0;
   if(ShouldDrawTF(g_bias.Timeframe()))    { DrawSwings(g_bias,   0,clrGold,        ref_atr); drawn++; }
   if(ShouldDrawTF(g_confirm.Timeframe())) { DrawSwings(g_confirm,1,clrDeepSkyBlue, ref_atr); drawn++; }
   if(ShouldDrawTF(g_exec.Timeframe()))    { DrawSwings(g_exec,   2,clrSilver,      ref_atr); drawn++; }
   g_arrows_hidden = (drawn==0);

   if(g_arrows_hidden)
      PrintFormat("[OBJ] arrows suppressed: chart TF %s is coarser than bias %s / confirm %s / exec %s",
                  EnumToString((ENUM_TIMEFRAMES)_Period),
                  EnumToString(g_profile.tf_bias),EnumToString(g_profile.tf_confirm),
                  EnumToString(g_profile.tf_exec));

   PrintFormat("[OBJ] %d swing arrows drawn (bias=%d/%d conf=%d/%d exec=%d/%d)",
               g_arrow_count,
               g_bias.PivotCount(),   InpDrawMaxPivots,
               g_confirm.PivotCount(),InpDrawMaxPivots,
               g_exec.PivotCount(),   InpDrawMaxPivots);
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| HEARTBEAT - drawn with Comment(), which the terminal renders      |
//| itself and which survives anything that breaks chart objects.     |
//| If you can see this line, the EA is running. Period.              |
//+------------------------------------------------------------------+
void UpdateHeartbeat()
  {
   string hb = StringFormat(
      "SPA v%s ALIVE  |  %s  |  swings  B:%d C:%d E:%d  |  arrows:%d  |  ticks:%d  |  NO TRADING",
      SPA_VERSION,g_symbol.Symbol(),
      g_bias.PivotCount(),g_confirm.PivotCount(),g_exec.PivotCount(),
      g_arrow_count,g_tick_count);
   Comment(hb);
  }

//+------------------------------------------------------------------+
//| Live panel                                                        |
//+------------------------------------------------------------------+
void DrawPanel()
  {
   if(!InpShowPanel)
      return;

   int    x  = InpPanelX;
   int    y  = InpPanelY+SPA_PANEL_COMMENT_PAD;   // never print over the heartbeat Comment
   int    lh = InpPanelFontSize+6;
   string fn = "Consolas";

   string rows[];
   color  cols[];
   ArrayResize(rows,SPA_PANEL_ROWS);
   ArrayResize(cols,SPA_PANEL_ROWS);

   rows[0]  = StringFormat("SOVEREIGN PA  v%s",SPA_VERSION);
   cols[0]  = InpPanelText;
   rows[1]  = "STRUCTURE BUILD - PLACES NO ORDERS";
   cols[1]  = InpPanelBlock;
   rows[2]  = StringFormat("%s  profile %s (%s)  enabled:%s",
                           g_symbol.Symbol(),g_profile.pattern,g_profile.asset_class,
                           g_profile.enabled ? "YES" : "NO");
   cols[2]  = g_profile.enabled ? InpPanelText : InpPanelBlock;
   rows[3]  = StringFormat("server %s  GMT %s  ticks %d",
                           TimeToString(TimeCurrent(),TIME_MINUTES),
                           TimeToString(TimeGMT(),TIME_MINUTES),g_tick_count);
   cols[3]  = InpPanelText;
   rows[4]  = StringFormat("bid %.5g  ask %.5g  spread %.2f pips",
                           g_bid,g_ask,g_sp_pips);
   cols[4]  = InpPanelText;
   rows[5]  = (g_sp_samples<SPA_SP_MIN_SAMPLES)
              ? StringFormat("regime CALIBRATING (%d/%d samples)  ATR14 %.5g",
                             g_sp_samples,SPA_SP_MIN_SAMPLES,g_atr_conf)
              : StringFormat("regime %s (x%.2f vs median %.2f, n=%d)  ATR14 %.5g",
                             g_regime,g_ratio,g_med_pips,g_sp_samples,g_atr_conf);
   cols[5]  = (g_sp_samples>=SPA_SP_MIN_SAMPLES && g_ratio>=3.0) ? InpPanelBlock : InpPanelText;
   rows[6]  = StringFormat("R-10a %s   R-10b %s (%.1f%% of %.0fp SL, limit %.1f%%)",
                           g_coarse_ok ? "PASS" : "BLOCK",
                           g_risk_ok ? "PASS" : "BLOCK",
                           g_sl_px>0.0 ? (g_sp_price/g_sl_px)*100.0 : 0.0,
                           InpDiagSlPips,g_profile.max_spread_of_risk*100.0);
   cols[6]  = (g_coarse_ok && g_risk_ok) ? InpPanelOK : InpPanelBlock;
   rows[7]  = StringFormat("lots @ %.0fp SL %.2f   risk %.2f%%   minRR %.1f:1",
                           InpDiagSlPips,g_lots,g_profile.risk_pct,g_profile.min_rr);
   cols[7]  = (g_lots>0.0) ? InpPanelText : InpPanelBlock;
   rows[8]  = " ";
   cols[8]  = InpPanelText;
   rows[9]  = StringFormat("STRUCTURE  (swing >= %.2fx ATR)",InpMinSwingATR);
   cols[9]  = InpPanelText;
   rows[10] = StructureLine(g_bias,   "BIAS");
   cols[10] = (g_bias.Trend()==SPA_TREND_RANGE) ? InpPanelBlock : InpPanelOK;
   rows[11] = StructureLine(g_confirm,"CONF");
   cols[11] = (g_confirm.Trend()==SPA_TREND_RANGE) ? InpPanelBlock : InpPanelOK;
   rows[12] = StructureLine(g_exec,   "EXEC");
   cols[12] = (g_exec.Trend()==SPA_TREND_RANGE) ? InpPanelBlock : InpPanelOK;
   rows[13] = " ";
   cols[13] = InpPanelText;
   rows[14] = (g_bias.Trend()==SPA_TREND_RANGE || g_bias.IsConsolidating())
              ? "BIAS NOT DIRECTIONAL - no trades would be considered"
              : "BIAS DIRECTIONAL - waiting for entry engine (v0.6.0)";
   cols[14] = (g_bias.Trend()==SPA_TREND_RANGE || g_bias.IsConsolidating())
              ? InpPanelBlock : InpPanelOK;
   rows[15] = " ";
   cols[15] = InpPanelText;
   rows[16] = StringFormat("swings detected: bias=%d conf=%d exec=%d  (arrows:%d)",
                           g_bias.PivotCount(),g_confirm.PivotCount(),g_exec.PivotCount(),
                           g_arrow_count);
   cols[16] = InpPanelText;
   int d_cand, d_none, d_small, d_filled, d_ok;
   g_zones.Diag(d_cand,d_none,d_small,d_filled,d_ok);
   //--- this must describe what is DRAWN, which is the chart's timeframe,
   //--- not the configured zone timeframe. Saying "PERIOD_M15" on a Daily
   //--- chart while drawing Daily blocks was its own kind of lie.
   rows[17] = StringFormat("BLOCKS on %s  found=%d  shown up to %d  window %d bars",
                           TFName(PERIOD_CURRENT),g_zonesChart.Count(),
                           InpDrawZonesMax,InpZoneLookbackBars);
   cols[17] = g_zones.Count()>0 ? InpPanelOK : InpPanelBlock;
   rows[18] = g_signal_note;
   cols[18] = g_plan.valid ? InpPanelOK : InpPanelBlock;
   rows[19] = StringFormat("v%s DRAWS THE TRADE ONLY - NO ORDERS ARE SENT",SPA_VERSION);
   cols[19] = InpPanelBlock;

   if(g_arrows_hidden)
     {
      rows[20] = StringFormat("ARROWS HIDDEN - this %s chart is coarser than every structure TF",
                              EnumToString((ENUM_TIMEFRAMES)_Period));
      cols[20] = InpPanelBlock;
      rows[21] = StringFormat("structure TFs are %s / %s / %s - open an M5 to M15 chart",
                              EnumToString(g_profile.tf_bias),
                              EnumToString(g_profile.tf_confirm),
                              EnumToString(g_profile.tf_exec));
      cols[21] = InpPanelBlock;
     }
   else
     {
      rows[20] = "LEGEND  gold = BIAS TF   blue = CONFIRM TF   silver = EXEC TF";
      cols[20] = InpPanelText;
      rows[21] = "green box = demand (buy)   red box = supply (sell)   dotted = entry / stop   gold dotted = target";
      cols[21] = InpPanelText;
     }
   //--- WHY found=0. Every order-block candidate is counted against the gate
   //--- that rejected it, so a blank chart can be read instead of guessed at.
   rows[22] = StringFormat("IMPULSES  blocks=%d  -> no gap in leg=%d  gap < %.2fxATR=%d  with a valid gap=%d",
                           d_cand,d_none,d_small,InpFvgMinATR,d_ok);
   cols[22] = d_cand>0 ? InpPanelText : InpPanelBlock;
   rows[23] = StringFormat("%s: imbalance >= %.2fx ATR, block = the candle just before it (wick to wick)",
                           EnumToString(ZoneTF()),InpFvgMinATR);
   cols[23] = InpPanelText;
   rows[24] = "Next: zones for each timeframe, then sweep + MSS before entry";
   cols[22] = InpPanelText;

   //--- COMPACT BY DEFAULT. Six lines say what is happening. Everything the
   //--- engine knows is one click away, so nothing is lost and the chart is
   //--- not a wall of text.
   int nrows = SPA_PANEL_ROWS;
   if(!g_panel_full)
     {
      string c[6];
      color  cc[6];
      c[0] = rows[0];  cc[0] = cols[0];
      c[1] = StringFormat("%s %s   BIAS %s   regime %s",
                          g_symbol.Symbol(),TFName(PERIOD_CURRENT),
                          g_bias.TrendText(),
                          g_bias.IsConsolidating() ? "RANGE" : "TREND");
      cc[1] = InpPanelText;
      c[2] = g_zone_line;   cc[2] = InpPanelText;
      c[3] = g_refine_text; cc[3] = InpPanelText;
      c[4] = g_state_line;  cc[4] = InpPanelBlock;
      c[5] = "click MORE for the full readout"; cc[5] = InpPanelText;
      for(int i=0;i<6;i++)
        {
         rows[i] = c[i];
         cols[i] = cc[i];
        }
      nrows = 6;
     }

   for(int i=0;i<SPA_PANEL_ROWS;i++)
     {
      string nm = "SPA_L"+IntegerToString(i);
      if(ObjectFind(0,nm)<0)
        {
         ObjectCreate(0,nm,OBJ_LABEL,0,0,0);
         ObjectSetInteger(0,nm,OBJPROP_CORNER,CORNER_LEFT_UPPER);
         ObjectSetInteger(0,nm,OBJPROP_XDISTANCE,x);
         ObjectSetInteger(0,nm,OBJPROP_YDISTANCE,y+i*lh);
         ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
         ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
         ObjectSetString(0,nm,OBJPROP_FONT,fn);
         ObjectSetInteger(0,nm,OBJPROP_FONTSIZE,InpPanelFontSize);
        }
      //--- an empty string does NOT clear an OBJ_LABEL: MT5 falls back to the
      //--- object's default description and the panel shows the word "Label"
      //--- once per hidden row. A single space clears it.
      ObjectSetString(0,nm,OBJPROP_TEXT,(i<nrows ? rows[i] : " "));
      ObjectSetInteger(0,nm,OBJPROP_COLOR,cols[i]);
     }

   //--- one small button, no menu system
   string bt = "SPA_TOGGLE";
   if(ObjectFind(0,bt)<0)
     {
      ObjectCreate(0,bt,OBJ_BUTTON,0,0,0);
      ObjectSetInteger(0,bt,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,bt,OBJPROP_XDISTANCE,InpPanelX+330);
      ObjectSetInteger(0,bt,OBJPROP_YDISTANCE,InpPanelY+SPA_PANEL_COMMENT_PAD);
      ObjectSetInteger(0,bt,OBJPROP_XSIZE,52);
      ObjectSetInteger(0,bt,OBJPROP_YSIZE,16);
      ObjectSetString(0,bt,OBJPROP_FONT,"Consolas");
      ObjectSetInteger(0,bt,OBJPROP_FONTSIZE,8);
      ObjectSetInteger(0,bt,OBJPROP_BGCOLOR,clrBlack);
      ObjectSetInteger(0,bt,OBJPROP_COLOR,InpPanelText);
      ObjectSetInteger(0,bt,OBJPROP_BORDER_COLOR,InpPanelText);
      ObjectSetInteger(0,bt,OBJPROP_STATE,false);
      ObjectSetInteger(0,bt,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,bt,OBJPROP_ZORDER,10);
     }
   ObjectSetString(0,bt,OBJPROP_TEXT,g_panel_full ? "LESS" : "MORE");
   ChartRedraw();
  }

//+------------------------------------------------------------------+
void DestroyObjects()
  {
   Comment("");
   for(int i=0;i<SPA_PANEL_ROWS;i++)
      ObjectDelete(0,"SPA_L"+IntegerToString(i));
   ObjectsDeleteAll(0,SPA_SW_PREFIX);
   ObjectsDeleteAll(0,SPA_ZONE_PREFIX);
   ObjectDelete(0,"SPA_TOGGLE");
   ChartRedraw();
  }

//+------------------------------------------------------------------+
void PrintConfig()
  {
   Print("==================================================================");
   PrintFormat("[SPA] SovereignPA v%s - STRUCTURE ENGINE (no trading)",SPA_VERSION);
   Print("==================================================================");
   PrintFormat("[SPA] Chart symbol      : %s",_Symbol);
   PrintFormat("[SPA] Profile matched   : %s  (asset class: %s)",g_profile.pattern,g_profile.asset_class);
   PrintFormat("[SPA] Profile enabled   : %s",g_profile.enabled ? "YES" : "NO  <-- no trades will be placed");
   PrintFormat("[SPA] Timeframes        : bias=%s  confirm=%s  exec=%s",
               EnumToString(g_profile.tf_bias),
               EnumToString(g_profile.tf_confirm),
               EnumToString(g_profile.tf_exec));
   PrintFormat("[SPA] Symbol metrics    : %s",g_symbol.Describe());
   PrintFormat("[SPA] Risk              : %.2f%% per trade | min RR %.2f : 1",
               g_profile.risk_pct,g_profile.min_rr);
   PrintFormat("[SPA] Structure settings: minSwing=%.2fxATR  bars=%d  consolidationBars=%d",
               InpMinSwingATR,InpStructBars,InpConsolBars);
   Print("==================================================================");
  }

//+------------------------------------------------------------------+
void PrintStructure()
  {
   Print("------------------------------------------------------------------");
   PrintFormat("[STR] %s",TimeToString(TimeCurrent(),TIME_DATE|TIME_MINUTES));
   PrintFormat("[STR] BIAS  %s",g_bias.Describe());
   PrintFormat("[STR] CONF  %s",g_confirm.Describe());
   PrintFormat("[STR] EXEC  %s",g_exec.Describe());

   //--- D-14 verdict, stated explicitly ---------------------------
   string verdict;
   if(g_bias.IsConsolidating())
      verdict = "SUSPENDED - no new extreme for " +
                IntegerToString(g_bias.BarsSinceExtreme()) + " bars (RB 2.1)";
   else if(g_bias.Trend()==SPA_TREND_RANGE)
      verdict = "NO BIAS - structure not directional";
   else
      verdict = "BIAS " + g_bias.TrendText() + " - entry engine not yet active";

   PrintFormat("[STR] D-14  bearish-shift=%s  bullish-shift=%s",
               g_bias.IsValidShift(true)  ? "VALID" : "not valid",
               g_bias.IsValidShift(false) ? "VALID" : "not valid");
   PrintFormat("[STR] STATE %s",verdict);
  }

//+------------------------------------------------------------------+
void PrintDiagnostics()
  {
   //--- The periodic block is off by default. On five charts it produced a
   //--- [DIAG] block every 30 seconds and buried the one line that matters.
   //--- Findings about zones ([ZONE], [REFINE]) always print.
   if(!InpLogDiag)
      return;
   PrintFormat("[DIAG] %s | bid=%.5g ask=%.5g spread=%.2f pips",
               TimeToString(TimeCurrent(),TIME_DATE|TIME_MINUTES),g_bid,g_ask,g_sp_pips);
   if(g_sp_samples<SPA_SP_MIN_SAMPLES)
      PrintFormat("[DIAG] Spread regime CALIBRATING (%d/%d samples collected)",
                  g_sp_samples,SPA_SP_MIN_SAMPLES);
   else
      PrintFormat("[DIAG] Spread regime %s (x%.2f vs median %.2f pips, n=%d)",
                  g_regime,g_ratio,g_med_pips,g_sp_samples);
   PrintFormat("[DIAG] R-10a coarse  : %s %s",g_coarse_ok ? "PASS" : "BLOCK",g_coarse_reason);
   PrintFormat("[DIAG] R-10b of risk : %s  (spread is %.1f%% of the %.0f-pip SL; limit %.1f%%) %s",
               g_risk_ok ? "PASS" : "BLOCK",
               g_sl_px>0.0 ? (g_sp_price/g_sl_px)*100.0 : 0.0,InpDiagSlPips,
               g_profile.max_spread_of_risk*100.0,g_risk_reason);
   PrintFormat("[DIAG] lots@%.0fp SL : %.2f | ticks %d",InpDiagSlPips,g_lots,g_tick_count);
  }

//+------------------------------------------------------------------+
//| A fatal init error must be visible on the CHART, not only in a    |
//| log tab the user may never open. Silent failure is the enemy.     |
//+------------------------------------------------------------------+
void FatalComment(const string reason)
  {
   string msg = StringFormat("SPA v%s INITIALISATION FAILED\n%s\nOpen Toolbox > Experts tab for detail.",
                             SPA_VERSION,reason);
   Comment(msg);
   PrintFormat("[SPA] FATAL: %s",reason);
  }

//+------------------------------------------------------------------+
int OnInit()
  {
   Comment("SPA initialising...");
   g_config_ok = false;

   if(!g_profiles.Load(InpProfileFile))
     {
      FatalComment("cannot open profile file: "+g_profiles.LastError()+
                   "  -> put symbol_profiles.csv in MQL5/Files");
      return(INIT_FAILED);
     }
   PrintFormat("[SPA] Profile file loaded: %d rows from '%s'",g_profiles.Count(),InpProfileFile);

   if(!g_profiles.Resolve(_Symbol,g_profile))
     {
      FatalComment("no profile row matched symbol '"+_Symbol+"'  -> add a row to symbol_profiles.csv");
      return(INIT_FAILED);
     }

   if(InpRiskPctOverride>0.0)
     {
      if(InpRiskPctOverride>1.0)
        {
         FatalComment(StringFormat("risk override %.2f%% exceeds the 1.0%% ceiling (R-01)",InpRiskPctOverride));
         return(INIT_FAILED);
        }
      g_profile.risk_pct = InpRiskPctOverride;
     }
   if(InpMinRROverride>0.0)
     {
      if(InpMinRROverride<3.0)
        {
         FatalComment(StringFormat("min RR override %.2f is below the 3.0 floor (R-06)",InpMinRROverride));
         return(INIT_FAILED);
        }
      g_profile.min_rr = InpMinRROverride;
     }
   if(InpOverrideEnabled)
     {
      g_profile.enabled = true;
      Print("[SPA] WARNING: profile force-enabled by input. Testing only.");
     }

   if(!g_symbol.Init(_Symbol,g_profile))
     {
      FatalComment("symbol init failed: "+g_symbol.LastError());
      return(INIT_FAILED);
     }

   g_h_atr_confirm = iATR(_Symbol,g_profile.tf_confirm,14);
   if(g_h_atr_confirm==INVALID_HANDLE)
     {
      FatalComment(StringFormat("iATR(%s) failed err=%d",
                                EnumToString(g_profile.tf_confirm),GetLastError()));
      return(INIT_FAILED);
     }

//--- structure engines -------------------------------------------
   g_bias.Init(_Symbol,g_profile.tf_bias,InpMinSwingATR,InpStructBars,InpConsolBars);
   g_confirm.Init(_Symbol,g_profile.tf_confirm,InpMinSwingATR,InpStructBars,InpConsolBars);
   g_exec.Init(_Symbol,g_profile.tf_exec,InpMinSwingATR,InpStructBars,InpConsolBars);
   //--- the chart's own timeframe, whatever it is. Change the timeframe and
   //--- the zones change with it: M1 shows M1 zones, H1 shows H1 zones.
   g_chart.Init(_Symbol,PERIOD_CURRENT,InpMinSwingATR,InpStructBars,InpConsolBars);

   if(!g_bias.Refresh())
      PrintFormat("[SPA] WARNING: bias structure unavailable - %s",g_bias.LastError());
   if(!g_confirm.Refresh())
      PrintFormat("[SPA] WARNING: confirm structure unavailable - %s",g_confirm.LastError());
   if(!g_exec.Refresh())
      PrintFormat("[SPA] WARNING: exec structure unavailable - %s",g_exec.LastError());

//--- explain an empty chart instead of leaving the user guessing -----
   PrintFormat("[HIST] bars loaded: bias=%d confirm=%d exec=%d  |  swing threshold bias=%.5g conf=%.5g exec=%.5g",
               g_bias.Bars(),g_confirm.Bars(),g_exec.Bars(),
               g_bias.SwingThreshold(),g_confirm.SwingThreshold(),g_exec.SwingThreshold());
   if(g_bias.PivotCount()==0)
      Print("[HIST] No bias swings detected. Usual cause: timeframe history still downloading.");
   if(g_confirm.PivotCount()==0)
      Print("[HIST] No confirm swings detected. Open that timeframe's chart once so MT5 caches it,");
   g_last_chart_bar = iTime(_Symbol,_Period,0);
   if(g_exec.PivotCount()==0)
      Print("[HIST] No exec swings detected. Lower InpMinSwingATR (e.g. 1.0) or raise InpStructBars.");

   PrintConfig();

   g_config_ok = true;
   g_panel_full = InpPanelStartFull;

   RefreshMetrics();
   RefreshSignal();
   DrawAllSwings();
   DrawZones();
   DrawPanel();
   UpdateHeartbeat();

   PrintStructure();
   if(InpDiagnostics)
      PrintDiagnostics();

   Print("[SPA] READY. No orders will be placed. Check that the arrows on the chart");
   Print("[SPA] mark the same swing highs and lows that you would mark yourself.");
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   DestroyObjects();

   if(g_h_atr_confirm!=INVALID_HANDLE)
     {
      IndicatorRelease(g_h_atr_confirm);
      g_h_atr_confirm = INVALID_HANDLE;
     }
   PrintFormat("[SPA] Deinitialised (reason %d). No orders were ever placed by this build.",reason);
  }

//+------------------------------------------------------------------+
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
  {
   if(id!=CHARTEVENT_OBJECT_CLICK)
      return;
   if(sparam!="SPA_TOGGLE")
      return;
   g_panel_full = !g_panel_full;
   DrawPanel();
  }

void OnTick()
  {
   if(!g_config_ok)
      return;

   g_tick_count++;

//--- structure refresh (internally cached per bar) ---------------
   g_bias.Refresh();
   g_confirm.Refresh();
   g_exec.Refresh();

//--- redraw when ANY of the three timeframes closes a new bar ----
   datetime bias_bar = iTime(_Symbol,g_profile.tf_bias,0);
   datetime conf_bar = iTime(_Symbol,g_profile.tf_confirm,0);
   datetime exec_bar = iTime(_Symbol,g_profile.tf_exec,0);

   bool new_bias = (bias_bar!=g_last_bias_bar);
   //--- the chart's own timeframe must also trigger a rebuild, otherwise an
   //--- M1 chart would keep drawing M15-era zones until a structure bar closed
   datetime chart_bar = iTime(_Symbol,_Period,0);
   bool new_chart = (chart_bar!=g_last_chart_bar);
   bool any_bar  = new_bias || new_chart || (conf_bar!=g_last_conf_bar) || (exec_bar!=g_last_exec_bar);

   if(any_bar)
     {
      g_last_bias_bar = bias_bar;
      g_last_chart_bar= chart_bar;
      g_last_conf_bar = conf_bar;
      g_last_exec_bar = exec_bar;
      RefreshSignal();
      DrawAllSwings();
      DrawZones();
     }
   if(new_bias)
      PrintStructure();

//--- refresh the panel at most once per second -------------------
   if(TimeCurrent()!=g_last_refresh)
     {
      g_last_refresh = TimeCurrent();
      RefreshMetrics();
      DrawPanel();
      UpdateHeartbeat();
     }

   if(!InpDiagnostics)
      return;
   if(TimeCurrent()-g_last_diag < InpDiagEverySeconds)
      return;
   g_last_diag = TimeCurrent();
   PrintDiagnostics();
  }
//+------------------------------------------------------------------+
