"""
Unit tests for the SPA structure engine reference implementation.

These tests are the contract the MQL5 port must satisfy. Every case is a
hand-built price series where the correct answer is known by construction,
so a failure is unambiguous.
"""

import unittest

from spa_structure_ref import (
    EventType,
    PivotType,
    Trend,
    analyse,
    alternation,
    bars_since_new_extreme,
    classify_events,
    classify_labels,
    classify_trend,
    find_pivots,
    is_valid_shift,
    Pivot,
)


def flat_open(close):
    return list(close)


class TestPivotDetection(unittest.TestCase):
    def test_zigzag_pivots_k1(self):
        H = [10, 12, 11, 14, 13, 15, 12]
        L = [8, 9, 8, 11, 10, 12, 9]
        C = [9, 11, 9.5, 12.5, 11.5, 13.5, 10]
        p = find_pivots(H, L, k=1)
        got = [(x.idx, x.kind.value, x.price) for x in p]
        self.assertEqual(got, [(1, "H", 12.0), (2, "L", 8.0), (3, "H", 14.0),
                               (4, "L", 10.0), (5, "H", 15.0)])
        self.assertEqual(classify_trend(p), Trend.UP)

    def test_plateau_takes_last_occurrence(self):
        # Flat double top: the pivot must be the LAST bar of the plateau.
        # Otherwise scan direction decides the answer, which is not a spec.
        H = [10, 12, 12, 12, 9]
        L = [8, 10, 10, 10, 7]
        p = [x for x in find_pivots(H, L, k=1) if x.kind == PivotType.HIGH]
        self.assertEqual(len(p), 1)
        self.assertEqual(p[0].idx, 3)      # last bar of the 12,12,12 plateau
        self.assertEqual(p[0].price, 12.0)

    def test_alternation_collapses_consecutive_highs(self):
        piv = [Pivot(1, 12.0, PivotType.HIGH), Pivot(3, 13.0, PivotType.HIGH)]
        out = alternation(piv)
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0].price, 13.0)   # keep the more extreme

    def test_alternation_collapses_consecutive_lows(self):
        piv = [Pivot(1, 9.0, PivotType.LOW), Pivot(3, 8.0, PivotType.LOW)]
        out = alternation(piv)
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0].price, 8.0)    # keep the LOWER


class TestLabelsAndTrend(unittest.TestCase):
    def test_labels(self):
        p = [Pivot(1, 12.0, PivotType.HIGH), Pivot(2, 8.0, PivotType.LOW),
             Pivot(3, 14.0, PivotType.HIGH), Pivot(4, 10.0, PivotType.LOW),
             Pivot(5, 13.0, PivotType.HIGH), Pivot(6, 9.0, PivotType.LOW)]
        classify_labels(p)
        self.assertEqual([x.label for x in p], ["H", "L", "HH", "HL", "LH", "LL"])
        # The sequence was HH/HL then LH/LL: the CURRENT state is a downtrend.
        self.assertEqual(classify_trend(p), Trend.DOWN)

    def test_uptrend(self):
        p = [Pivot(1, 12.0, PivotType.HIGH), Pivot(2, 8.0, PivotType.LOW),
             Pivot(3, 14.0, PivotType.HIGH), Pivot(4, 10.0, PivotType.LOW)]
        self.assertEqual(classify_trend(p), Trend.UP)

    def test_downtrend(self):
        p = [Pivot(1, 14.0, PivotType.HIGH), Pivot(2, 10.0, PivotType.LOW),
             Pivot(3, 12.0, PivotType.HIGH), Pivot(4, 8.0, PivotType.LOW)]
        self.assertEqual(classify_trend(p), Trend.DOWN)

    def test_insufficient_pivots_is_range(self):
        self.assertEqual(classify_trend([]), Trend.RANGE)
        self.assertEqual(classify_trend([Pivot(1, 12.0, PivotType.HIGH)]), Trend.RANGE)


class TestBOSversusSweep(unittest.TestCase):
    """The single most important distinction in the whole methodology."""

    def _series(self, event_close):
        H = [10.0, 11.0, 10.0, 9.0, 9.5, 11.0]
        L = [9.0, 10.0, 8.0, 8.5, 7.5, 10.0]
        C = [9.5, 10.5, 8.5, 8.7, event_close, 10.5]
        return flat_open(C), H, L, C

    # The level is supplied explicitly here: these tests isolate the EVENT
    # classifier, while pivot detection has its own test class above.
    LEVEL = Pivot(2, 8.0, PivotType.LOW)

    def test_wick_below_close_back_inside_is_a_sweep(self):
        O, H, L, C = self._series(event_close=8.6)   # low 7.5 pierces 8, closes 8.6 > 8
        level = self.LEVEL
        ev = [e for e in classify_events(O, H, L, C, [level]) if e.level_idx == level.idx]
        self.assertEqual(len(ev), 1)
        self.assertEqual(ev[0].event, EventType.SWEEP)
        self.assertEqual(ev[0].event_idx, 4)

    def test_body_close_below_is_a_break_of_structure(self):
        O, H, L, C = self._series(event_close=7.8)   # closes 7.8 < 8 -> real break
        level = self.LEVEL
        ev = [e for e in classify_events(O, H, L, C, [level]) if e.level_idx == level.idx]
        self.assertEqual(len(ev), 1)
        self.assertEqual(ev[0].event, EventType.BOS)

    def test_level_resolves_exactly_once(self):
        O, H, L, C = self._series(event_close=8.6)
        level = self.LEVEL
        ev = [e for e in classify_events(O, H, L, C, [level]) if e.level_idx == level.idx]
        self.assertEqual(len(ev), 1)   # never both a sweep and a BOS


class TestInternalStructureFilter(unittest.TestCase):
    """D-14: a break inside a corrective leg is noise, not a reversal."""

    def test_bearish_shift_invalid_when_no_higher_high(self):
        # Highs: 12 -> 13 -> 12.5 (a LOWER high). Then the low breaks.
        # This is the classic trap the transcript warns about.
        H = [10.0, 12.0, 11.0, 13.0, 12.0, 12.5, 11.0]
        L = [9.0, 11.0, 10.0, 12.0, 11.0, 10.5, 9.5]
        C = [9.5, 11.5, 10.5, 12.5, 11.5, 10.6, 9.6]
        s = analyse(flat_open(C), H, L, C, k=1, swing_mode="fractal")
        self.assertFalse(is_valid_shift(s.pivots, s.events, "bearish"))

    def test_bearish_shift_valid_when_higher_high_then_break(self):
        # HH printed (14.5 > 13), then a body close below the last low (11).
        H = [10.0, 12.0, 11.0, 13.0, 12.0, 14.5, 13.0]
        L = [9.0, 11.0, 10.0, 12.0, 11.0, 13.0, 10.0]
        C = [9.5, 11.5, 10.5, 12.5, 11.5, 14.0, 9.9]
        s = analyse(flat_open(C), H, L, C, k=1, swing_mode="fractal")
        self.assertTrue(is_valid_shift(s.pivots, s.events, "bearish"))


class TestAlternationMustNotAffectSignals(unittest.TestCase):
    """Regression for the defect found while porting: applying alternation
    before signal logic deletes lower highs and manufactures false shifts."""

    def test_raw_pivots_keep_the_lower_high(self):
        H = [10.0, 12.0, 11.0, 13.0, 12.0, 12.5, 11.0]
        L = [9.0, 11.0, 10.0, 12.0, 11.0, 10.5, 9.5]
        raw = find_pivots(H, L, k=1)
        highs = [p.price for p in raw if p.kind == PivotType.HIGH]
        self.assertIn(12.5, highs, "the lower high must survive for signal logic")

        alt = alternation(raw)
        alt_highs = [p.price for p in alt if p.kind == PivotType.HIGH]
        self.assertNotIn(12.5, alt_highs, "alternation is expected to drop it - drawing view")


class TestConsolidationFilter(unittest.TestCase):
    def test_bars_since_extreme(self):
        p = [Pivot(1, 12.0, PivotType.HIGH), Pivot(2, 8.0, PivotType.LOW),
             Pivot(3, 14.0, PivotType.HIGH)]     # 14 > 12 -> new extreme at idx 3
        self.assertEqual(bars_since_new_extreme(p, 10), 9 - 3)

    def test_consolidating_when_extreme_is_old(self):
        # Long flat series: no new extreme for far more than 20 bars.
        n = 40
        H = [12.0 + (0.1 if i % 2 else 0.0) for i in range(n)]
        L = [8.0 - (0.1 if i % 2 else 0.0) for i in range(n)]
        C = [(h + l) / 2 for h, l in zip(H, L)]
        s = analyse(flat_open(C), H, L, C, k=2, consolidation_bars=20, swing_mode="fractal")
        # Either no new extreme at all, or one very far back.
        self.assertGreaterEqual(s.bars_since_extreme, 20)


class TestNoRepaint(unittest.TestCase):
    """Decisions must be stable: adding new bars may not rewrite old pivots."""

    def test_historical_pivots_are_stable(self):
        H = [10, 12, 11, 14, 13, 15, 12, 13, 11, 16, 14, 15]
        L = [8, 9, 8, 11, 10, 12, 9, 10, 8, 13, 11, 12]
        C = [(h + l) / 2 for h, l in zip(H, L)]
        O = flat_open(C)

        short = analyse(O[:8], H[:8], L[:8], C[:8], k=2, swing_mode="fractal")
        long_ = analyse(O, H, L, C, k=2, swing_mode="fractal")

        # Any pivot that was at least k bars from the end of the short run
        # must appear identically in the longer run.
        cutoff = 8 - 1 - 2
        stable = {(p.idx, p.kind, p.price) for p in short.pivots if p.idx <= cutoff}
        later = {(p.idx, p.kind, p.price) for p in long_.pivots}
        self.assertTrue(stable.issubset(later), stable - later)




# --------------------------------------------------------------------------
# D-08b : significance-filtered swings
# --------------------------------------------------------------------------
from spa_structure_ref import find_pivots_zigzag, atr_sma


def _series_from_values(vals, pad=0.20):
    H = [v + pad for v in vals]
    L = [v - pad for v in vals]
    C = list(vals)
    return H, L, C


class TestZigZagSignificance(unittest.TestCase):
    """D-08b: a swing must go SOMEWHERE before it counts as structure."""

    def _choppy(self):
        # flat with 2-bar wiggles, then a real 10-unit rally, a real 10-unit
        # drop, then flat again. Exactly two genuine turning points exist.
        vals, v = [], 100.0
        for i in range(20):
            vals.append(100.0 + (0.2 if i % 2 == 0 else -0.2))
        for _ in range(10):
            v = vals[-1] + 1.0; vals.append(v)
        for _ in range(10):
            v = vals[-1] - 1.0; vals.append(v)
        for i in range(20):
            vals.append(vals[-1] + (0.2 if i % 2 == 0 else -0.2))
        H = [x + 0.15 for x in vals]
        L = [x - 0.15 for x in vals]
        return H, L, list(vals)

    def test_only_genuine_turning_points_survive(self):
        H, L, C = self._choppy()
        atr = atr_sma(H, L, C, 14)
        piv = find_pivots_zigzag(H, L, atr=atr, mult=1.5)
        self.assertEqual(len(piv), 2, f"expected the 2 real turns, got {[(p.idx, round(p.price,2)) for p in piv]}")
        self.assertEqual(piv[0].kind, PivotType.LOW)
        self.assertAlmostEqual(piv[0].price, 99.65, places=2)     # the real low
        self.assertEqual(piv[1].kind, PivotType.HIGH)
        self.assertAlmostEqual(piv[1].price, 109.95, places=2)    # the real high

    def test_lower_multiplier_follows_more_noise(self):
        """Sensitivity: the threshold is the knob that controls significance."""
        H, L, C = self._choppy()
        atr = atr_sma(H, L, C, 14)
        tight = find_pivots_zigzag(H, L, atr=atr, mult=0.5)
        loose = find_pivots_zigzag(H, L, atr=atr, mult=1.5)
        self.assertGreater(len(tight), len(loose) * 3,
                           f"mult 0.5 gave {len(tight)}, mult 1.5 gave {len(loose)}")

    def test_output_always_alternates(self):
        H, L, C = self._choppy()
        piv = find_pivots_zigzag(H, L, atr=atr_sma(H, L, C, 14), mult=0.5)
        for a, b in zip(piv, piv[1:]):
            self.assertNotEqual(a.kind, b.kind, "consecutive pivots must alternate")

    def test_pivots_are_monotonic_in_time(self):
        H, L, C = self._choppy()
        piv = find_pivots_zigzag(H, L, atr=atr_sma(H, L, C, 14), mult=0.5)
        idx = [p.idx for p in piv]
        self.assertEqual(idx, sorted(idx))

    def test_non_repainting(self):
        """A confirmed swing must never move or vanish as new bars arrive."""
        H, L, C = self._choppy()
        cut = 35
        short = find_pivots_zigzag(H[:cut], L[:cut], atr_sma(H[:cut], L[:cut], C[:cut], 14), 1.5)
        long_ = find_pivots_zigzag(H, L, atr_sma(H, L, C, 14), 1.5)
        stable = {(a.idx, a.price, a.kind) for a in short}
        later  = {(b.idx, b.price, b.kind) for b in long_}
        self.assertTrue(stable.issubset(later), stable - later)

    def test_zero_atr_returns_nothing(self):
        H, L, C = self._choppy()
        self.assertEqual(find_pivots_zigzag(H, L, atr=0.0, mult=1.5), [])



# --------------------------------------------------------------------------
# PARITY: this is a line-by-line transliteration of BuildPivotsZigZag() and
# WilderATR() as they are written in SPA_Structure.mqh. If the MQL5 and the
# Python reference ever drift apart, this test fails.
# --------------------------------------------------------------------------
def _mql5_atr(H, L, C, period=14):
    n = len(H)
    if n < period + 1:
        return 0.0
    atr = 0.0
    for i in range(1, period + 1):
        tr = H[i] - L[i]
        a = abs(H[i] - C[i - 1])
        b = abs(L[i] - C[i - 1])
        if a > tr: tr = a
        if b > tr: tr = b
        atr += tr
    atr /= period
    for i in range(period + 1, n):
        tr = H[i] - L[i]
        a = abs(H[i] - C[i - 1])
        b = abs(L[i] - C[i - 1])
        if a > tr: tr = a
        if b > tr: tr = b
        atr = (atr * (period - 1) + tr) / period
    return atr


def _mql5_zigzag(H, L, atr, min_swing_atr):
    out = []
    n = len(H)
    if n < 3 or atr <= 0.0 or min_swing_atr <= 0.0:
        return out
    th = min_swing_atr * atr
    hi_i, lo_i = 0, 0
    hi_p, lo_p = H[0], L[0]
    d = 0
    for i in range(1, n):
        if d == 0:
            if H[i] > hi_p: hi_i, hi_p = i, H[i]
            if L[i] < lo_p: lo_i, lo_p = i, L[i]
            if hi_p - lo_p >= th:
                if hi_i > lo_i:
                    out.append(Pivot(lo_i, lo_p, PivotType.LOW)); d = 1
                    hi_i, hi_p = i, H[i]
                else:
                    out.append(Pivot(hi_i, hi_p, PivotType.HIGH)); d = -1
                    lo_i, lo_p = i, L[i]
            continue
        if d == 1:
            if H[i] > hi_p: hi_i, hi_p = i, H[i]
            if hi_p - L[i] >= th:
                out.append(Pivot(hi_i, hi_p, PivotType.HIGH)); d = -1
                lo_i, lo_p = i, L[i]
        else:
            if L[i] < lo_p: lo_i, lo_p = i, L[i]
            if H[i] - lo_p >= th:
                out.append(Pivot(lo_i, lo_p, PivotType.LOW)); d = 1
                hi_i, hi_p = i, H[i]
    return out


class TestMQL5Parity(unittest.TestCase):
    def test_mql5_and_python_reference_agree(self):
        import random
        rng = random.Random(20261102)
        for trial in range(40):
            n = rng.randint(60, 220)
            px, H, L, C = 1.1000, [], [], []
            for _ in range(n):
                px += rng.gauss(0, 0.0006)
                hi = px + abs(rng.gauss(0, 0.0004))
                lo = px - abs(rng.gauss(0, 0.0004))
                H.append(hi); L.append(lo); C.append(px)
            for mult in (0.5, 1.0, 1.5, 2.0, 3.0):
                ref = [(p.idx, round(p.price, 10), p.kind) for p in find_pivots_zigzag(H, L, _mql5_atr(H, L, C), mult)]
                mql = [(p.idx, round(p.price, 10), p.kind) for p in _mql5_zigzag(H, L, _mql5_atr(H, L, C), mult)]
                self.assertEqual(ref, mql, f"MQL5/Python divergence on trial {trial} mult {mult}")

if __name__ == "__main__":
    unittest.main(verbosity=2)
