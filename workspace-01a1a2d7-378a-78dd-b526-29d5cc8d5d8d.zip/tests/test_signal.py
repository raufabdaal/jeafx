import unittest
from spa_structure_ref import analyse, atr_sma
from spa_signal_ref import (find_zones, zone_is_fresh, first_obstacle, build_plan, select_best, Zone, gap_filled_since, imbalance_reason, find_fvg_zones)

# --------------------------------------------------------------------------
# A hand-built bullish sequence on realistic FX prices:
#   decline -> swing low -> impulse that CLOSES through the last swing high,
#   leaving a 3-candle gap. Bar 7 is the last bearish candle before the
#   impulse: the order block. Bar 8 closes the break.
#
#   2  swing high 1.1018
#   5  swing low  1.0980
#   7  ORDER BLOCK (bearish)  high 1.1010  low 1.1003
#   8  impulse, low 1.1009 > high[6] 1.1008  -> imbalance
# --------------------------------------------------------------------------
RAW = [
    (99.0, 99.8, 98.8, 99.6),
    (99.6, 100.6, 99.5, 100.4),
    (100.4, 100.8, 99.8, 100.0),   # swing high
    (100.0, 100.2, 98.6, 98.8),
    (98.8, 99.2, 97.6, 97.8),
    (97.8, 98.6, 97.0, 98.4),      # swing low
    (98.4, 99.8, 98.3, 99.6),
    (99.9, 100.0, 99.3, 99.4),     # ORDER BLOCK
    (99.95, 101.6, 99.9, 101.4),   # impulse / break
    (101.4, 103.0, 101.3, 102.8),
    (102.8, 103.2, 102.2, 102.4),
    (102.4, 102.8, 101.9, 102.0),
]

# Four further bars push the next unresolved swing high to 1.1056 so the
# structural target is genuinely beyond 3R. Without them the honest target is
# 1.1042 - only 2.9R - and the trade is correctly REJECTED.
RAW_EXT = RAW + [
    (102.0, 102.4, 101.8, 102.2),
    (102.2, 104.5, 102.1, 104.3),
    (104.3, 104.6, 103.8, 104.0),
    (104.0, 104.2, 103.4, 103.6),   # swing high 1.1056
]

BASE = 1.1000
PIP = 0.0001


def scale(rows):
    """Map the 99-103 design grid onto 1.0998-1.1042 (EURUSD-like)."""
    out = []
    for o, h, l, c in rows:
        out.append(tuple(BASE + (x - 99.0) * 0.001 for x in (o, h, l, c)))
    return out


def mirror(rows):
    """Reflect through BASE and swap high/low: bullish becomes bearish."""
    out = []
    for o, h, l, c in rows:
        o2, c2 = 2 * 99.8 - o, 2 * 99.8 - c
        h2, l2 = 2 * 99.8 - l, 2 * 99.8 - h
        out.append((o2, h2, l2, c2))
    return out


def split(rows):
    O = [r[0] for r in rows]
    H = [r[1] for r in rows]
    L = [r[2] for r in rows]
    C = [r[3] for r in rows]
    return O, H, L, C


def snapshot(rows):
    O, H, L, C = split(rows)
    return analyse(O, H, L, C, swing_mode="fractal", k=1), O, H, L, C


class TestOrderBlocks(unittest.TestCase):

    def test_demand_zone_is_the_last_candle_before_the_impulse(self):
        s, O, H, L, C = snapshot(scale(RAW))
        zs = find_zones(O, H, L, C, s.events)
        self.assertEqual(len(zs), 1)
        z = zs[0]
        self.assertEqual(z.kind, "demand")
        self.assertEqual(z.ob_idx, 7, "order block must be the last bearish candle before the impulse")
        self.assertAlmostEqual(z.top, 1.1010, places=6)
        self.assertAlmostEqual(z.bottom, 1.1003, places=6)
        self.assertAlmostEqual(z.entry, z.top, places=6, msg="entry is the near edge (first touch)")

    def test_no_imbalance_means_no_zone(self):
        """D-A: the order block MUST be followed by a clear imbalance."""
        rows = list(RAW)
        # close the gap: pull the impulse low down to the pre-impulse high
        o, h, l, c = rows[8]
        rows[8] = (o, h, 99.8, c)
        s, O, H, L, C = snapshot(scale(rows))
        self.assertEqual(find_zones(O, H, L, C, s.events), [])

    def test_gap_below_the_size_threshold_is_not_an_imbalance(self):
        """A 0.1-pip sliver is not a gap. With ATR 0.001 the required gap is
        0.15 x 0.001 = 0.00015, and this fixture's gap is only 0.0001."""
        s, O, H, L, C = snapshot(scale(RAW))
        self.assertEqual(find_zones(O, H, L, C, s.events, 0.001), [])
        self.assertEqual(len(find_zones(O, H, L, C, s.events, 0.0004)), 1)

    def test_validity_is_judged_at_birth_not_today(self):
        """The same gap reads 'filled' against the whole series and 'ok' at the
        moment the zone was born. Using today's state as the creation filter
        is what made tapped zones vanish from history."""
        rows = list(RAW)
        rows.append((101.0, 101.2, 99.6, 100.6))
        s, O, H, L, C = snapshot(scale(rows))
        H2, L2 = H, L
        born = imbalance_reason(H2, L2, 7, 8, True, 0.0, 0.0, 3, len(C), fill_to=8)
        now = imbalance_reason(H2, L2, 7, 8, True, 0.0, 0.0, 3, len(C))
        self.assertEqual(born, "ok")
        self.assertEqual(now, "filled")

    def test_gap_closed_later_keeps_the_zone_but_marks_it_used(self):
        """Price returning to the zone closes the gap - that is the tap, not a
        reason to erase the zone from history. The audit view needs it."""
        rows = list(RAW)
        rows.append((101.0, 101.2, 99.6, 100.6))   # trades all the way through the gap
        s, O, H, L, C = snapshot(scale(rows))
        zs = find_zones(O, H, L, C, s.events)
        self.assertEqual(len(zs), 1)
        self.assertFalse(zs[0].fresh)
        self.assertTrue(gap_filled_since(H, L, zs[0].top, zs[0].bottom,
                                         zs[0].break_idx + 1, len(C), True))

    def test_gap_must_sit_in_the_displacement(self):
        """The gap has to belong to the impulse, not to a bar much later."""
        s, O, H, L, C = snapshot(scale(RAW))
        self.assertEqual(len(find_zones(O, H, L, C, s.events, fvg_window=1)), 1)
        self.assertEqual(find_zones(O, H, L, C, s.events, fvg_window=0), [])
        # window=1 still contains bar 8 (ob+1); window=0 does not

    def test_supply_zone_is_the_mirror_image(self):
        s, O, H, L, C = snapshot(scale(mirror(RAW)))
        zs = find_zones(O, H, L, C, s.events)
        self.assertEqual(len(zs), 1)
        z = zs[0]
        self.assertEqual(z.kind, "supply")
        self.assertAlmostEqual(z.entry, z.bottom, places=6,
                               msg="for supply the near edge is the BOTTOM")

    def test_zone_goes_stale_once_price_returns(self):
        rows = list(RAW)
        # a later wick back down into the zone
        rows.append((102.0, 102.2, 99.9, 100.6))   # touches the zone, gap stays intact
        s, O, H, L, C = snapshot(scale(rows))
        zs = find_zones(O, H, L, C, s.events)
        self.assertEqual(len(zs), 1)
        self.assertFalse(zs[0].fresh, "a zone price has already traded back into is not fresh")

    def test_fresh_zone_stays_fresh(self):
        s, O, H, L, C = snapshot(scale(RAW))
        zs = find_zones(O, H, L, C, s.events)
        self.assertTrue(zs[0].fresh)


class TestObstacles(unittest.TestCase):

    def test_already_broken_level_is_not_an_obstacle(self):
        """The swing high at 1.1018 was closed through by the impulse - it is
        behind us. The target must be the next level still standing."""
        s, O, H, L, C = snapshot(scale(RAW))
        obst = first_obstacle(s.pivots, s.events, BASE, bullish=True)
        self.assertAlmostEqual(obst, 1.1042, places=6)

    def test_nearest_level_wins(self):
        from spa_structure_ref import Pivot, PivotType
        piv = [Pivot(1, 1.1100, PivotType.HIGH, "H"),
               Pivot(2, 1.1050, PivotType.HIGH, "H")]
        self.assertAlmostEqual(first_obstacle(piv, [], 1.1000, True), 1.1050, places=6)

    def test_no_level_above_means_no_target(self):
        from spa_structure_ref import Pivot, PivotType
        piv = [Pivot(1, 1.0900, PivotType.HIGH, "H")]
        self.assertIsNone(first_obstacle(piv, [], 1.1000, True))


class TestTradePlan(unittest.TestCase):

    def setUp(self):
        s, O, H, L, C = snapshot(scale(RAW_EXT))
        self.s = s
        self.z = find_zones(O, H, L, C, s.events)[0]

    def plan(self, obstacle=1.1056, risk=75.0, min_rr=3.0, min_sl_px=0.0):
        return build_plan(self.z, obstacle, spread_px=PIP, pip=PIP,
                          risk_money=risk, money_per_lot_per_pip=10.0,
                          min_rr=min_rr, min_sl_px=min_sl_px)

    def test_full_plan_arithmetic(self):
        p = self.plan()
        self.assertTrue(p.ok, p.reason)
        self.assertEqual(p.direction, "BUY")
        self.assertAlmostEqual(p.entry, 1.1010, places=6)
        # SL = zone low - (2 x spread + 2 pips)
        self.assertAlmostEqual(p.sl, 1.1003 - 0.0004, places=6)
        self.assertAlmostEqual(p.sl_pips, 11.0, places=4)
        self.assertAlmostEqual(p.tp_pips, 46.0, places=4)
        self.assertAlmostEqual(p.rr, 46.0 / 11.0, places=4)
        # $75 / (11 pips x $10 per pip per lot) = 0.681 -> 0.68 (rounded DOWN)
        self.assertAlmostEqual(p.lots, 0.68, places=2)

    def test_under_three_r_is_rejected(self):
        p = self.plan(obstacle=1.1025)          # only 15 pips of room
        self.assertFalse(p.ok)
        self.assertEqual(p.reason, "REJ_RR")
        self.assertLess(p.rr, 3.0)

    def test_lots_always_round_down(self):
        p = self.plan(risk=76.0)                # 76/110 = 0.6909 -> 0.69
        self.assertAlmostEqual(p.lots, 0.69, places=2)
        self.assertLessEqual(p.lots * p.sl_pips * 10.0, 76.0)

    def test_no_target_is_rejected(self):
        p = self.plan(obstacle=None)
        self.assertFalse(p.ok)
        self.assertEqual(p.reason, "REJ_NO_TARGET")

    def test_stop_inside_the_noise_is_rejected_not_widened(self):
        """A stop tighter than the market's own range is a guaranteed loss.
        We skip the zone; we never widen the stop to make it fit."""
        p = self.plan(min_sl_px=0.0020)      # demand 20 pips of clear air
        self.assertFalse(p.ok)
        self.assertEqual(p.reason, "REJ_SL_TOO_TIGHT")
        self.assertAlmostEqual(p.sl, 1.0999, places=6)   # unchanged

    def test_stop_above_the_floor_passes(self):
        p = self.plan(min_sl_px=0.0005)      # 5 pips of clear air
        self.assertTrue(p.ok, p.reason)

    def test_zero_risk_money_is_rejected(self):
        p = self.plan(risk=0.0)
        self.assertFalse(p.ok)
        self.assertEqual(p.reason, "REJ_NO_LOT")


class TestZoneRecency(unittest.TestCase):

    def test_only_the_newest_impulse_per_direction_survives(self):
        """D-E: you trade the zone the LATEST impulse created. An ancient
        untouched zone is not an opportunity, it is a level the market has
        already walked past."""
        s, O, H, L, C = snapshot(scale(RAW_EXT))
        allz = find_zones(O, H, L, C, s.events, latest_only=False)
        latest = find_zones(O, H, L, C, s.events, latest_only=True)

        expect = {}
        for z in allz:
            if z.kind not in expect or z.break_idx > expect[z.kind].break_idx:
                expect[z.kind] = z

        self.assertEqual({z.ob_idx for z in latest}, {z.ob_idx for z in expect.values()})
        self.assertLessEqual(len(latest), len(allz))

    def test_one_zone_per_direction_at_most(self):
        s, O, H, L, C = snapshot(scale(RAW_EXT))
        latest = find_zones(O, H, L, C, s.events)
        kinds = [z.kind for z in latest]
        self.assertEqual(len(kinds), len(set(kinds)))


class TestZoneAge(unittest.TestCase):

    def test_zone_reports_its_age(self):
        s, O, H, L, C = snapshot(scale(RAW_EXT))
        z = find_zones(O, H, L, C, s.events)[0]
        self.assertEqual(z.age, (len(C) - 1) - z.break_idx)

    def test_fresh_but_abandoned_zone_is_not_traded(self):
        """Fresh means price never came back. That is not the same as current:
        an untouched zone 400 bars old is abandoned, not fresh."""
        s, O, H, L, C = snapshot(scale(RAW_EXT))
        z = find_zones(O, H, L, C, s.events)[0]
        self.assertTrue(z.fresh)
        self.assertIsNone(
            select_best([z], s.pivots, s.events, PIP, PIP, 75.0, 10.0, "UP", max_age=5))

    def test_recent_zone_passes_the_age_limit(self):
        s, O, H, L, C = snapshot(scale(RAW_EXT))
        z = find_zones(O, H, L, C, s.events)[0]
        self.assertIsNotNone(
            select_best([z], s.pivots, s.events, PIP, PIP, 75.0, 10.0, "UP", max_age=200))


class TestNearestObstacle(unittest.TestCase):

    def test_the_closer_level_wins(self):
        from spa_signal_ref import nearest_obstacle
        self.assertAlmostEqual(nearest_obstacle(1.1200, 1.1080, 1.1000), 1.1080, places=6)
        self.assertAlmostEqual(nearest_obstacle(1.1080, 1.1200, 1.1000), 1.1080, places=6)

    def test_missing_side_falls_back(self):
        from spa_signal_ref import nearest_obstacle
        self.assertAlmostEqual(nearest_obstacle(None, 1.1080, 1.1000), 1.1080, places=6)
        self.assertIsNone(nearest_obstacle(None, None, 1.1000))


class TestZoneSelection(unittest.TestCase):

    def test_picks_the_zone_with_the_better_target(self):
        s, O, H, L, C = snapshot(scale(RAW_EXT))
        z = find_zones(O, H, L, C, s.events)[0]
        best = select_best([z], s.pivots, s.events, PIP, PIP, 75.0, 10.0, "UP")
        self.assertIsNotNone(best)
        self.assertTrue(best[0].ok)
        self.assertAlmostEqual(best[0].rr, 46.0 / 11.0, places=4)

    def test_wrong_direction_zone_is_ignored(self):
        s, O, H, L, C = snapshot(scale(RAW))
        z = find_zones(O, H, L, C, s.events)[0]     # demand
        self.assertIsNone(select_best([z], s.pivots, s.events, PIP, PIP, 75.0, 10.0, "DOWN"))

    def test_zones_come_back_chronological(self):
        s, O, H, L, C = snapshot(scale(RAW_EXT))
        zs = find_zones(O, H, L, C, s.events)
        self.assertEqual([z.ob_idx for z in zs], sorted(z.ob_idx for z in zs))

    def test_range_trend_trades_nothing(self):
        s, O, H, L, C = snapshot(scale(RAW))
        z = find_zones(O, H, L, C, s.events)[0]
        self.assertIsNone(select_best([z], s.pivots, s.events, PIP, PIP, 75.0, 10.0, "RANGE"))




# --------------------------------------------------------------------------
# PARITY: line-by-line transliteration of CSpaZones::Find() and
# CSpaZones::HasImbalance() as written in SPA_Zones.mqh.
# --------------------------------------------------------------------------
def _mql5_find_imbalance(H, L, start, end, bullish, min_gap, window, n, fill_to=-1):
    last = end
    if start + window < last:
        last = start + window
    fill_end = n
    if fill_to >= 0 and fill_to + 1 < n:
        fill_end = fill_to + 1
    lo = start + 1
    if lo < 2:
        lo = 2
    for k in range(lo, last + 1):
        if bullish:
            gap_low, gap_high = H[k - 2], L[k]
        else:
            gap_low, gap_high = H[k], L[k - 2]
        if (gap_high - gap_low) < min_gap or gap_high <= gap_low:
            continue
        filled = False
        for j in range(k + 1, fill_end):
            if bullish and L[j] <= gap_low:
                filled = True
                break
            if (not bullish) and H[j] >= gap_high:
                filled = True
                break
        if not filled:
            return k
    return -1


def _mql5_find_zones(O, H, L, C, pivots, events, lookback=20, latest_only=True,
                     fvg_min_atr=0.15, fvg_window=3, atr=0.0):
    # key by (bar, side): one bar can be BOTH a swing high and a swing low,
    # and each side resolves independently.
    res = {}
    for e in events:
        res.setdefault((e.level_idx, e.kind), (e.event, e.event_idx))

    nb = len(C)
    out, ob_used = [], []
    for p in pivots:
        got = res.get((p.idx, p.kind))
        if got is None or got[0].value != "BOS":
            continue
        b = got[1]
        if b < 2 or b >= nb:
            continue
        bullish = (p.kind.value == "H")

        ob = -1
        floor_i = max(b - lookback, 0)
        for j in range(b, floor_i - 1, -1):
            if bullish and C[j] < O[j]:
                ob = j
                break
            if (not bullish) and C[j] > O[j]:
                ob = j
                break
        if ob < 0 or ob >= b:
            continue
        if ob in ob_used:
            continue
        if _mql5_find_imbalance(H, L, ob, b, bullish, fvg_min_atr * atr,
                                fvg_window, nb, b) < 0:
            continue
        ob_used.append(ob)

        top, bottom = H[ob], L[ob]
        entry = top if bullish else bottom
        stop_ref = bottom if bullish else top
        fresh = True
        for j in range(b + 1, nb):
            if bullish and L[j] <= top:
                fresh = False
                break
            if (not bullish) and H[j] >= bottom:
                fresh = False
                break
        out.append(("demand" if bullish else "supply", ob, top, bottom, fresh, b))
    out.sort(key=lambda r: r[1])

    # latest impulse per direction only (D-E)
    newest = {}
    for r in out:
        k = r[0]
        if k not in newest or r[5] > newest[k][5]:
            newest[k] = r
    if not latest_only:
        return out
    return [r for r in out if newest.get(r[0]) is r]


class TestMQL5ZoneParity(unittest.TestCase):
    def _compare(self, rows):
        s, O, H, L, C = snapshot(rows)
        atr_v = atr_sma(H, L, C, 14)
        py = [(z.kind, z.ob_idx, round(z.top, 10), round(z.bottom, 10), z.fresh)
              for z in find_zones(O, H, L, C, s.events, atr_v)]
        mq = [(k, ob, round(t, 10), round(b, 10), f)
              for k, ob, t, b, f, _brk in _mql5_find_zones(O, H, L, C, s.pivots, s.events,
                                                          atr=atr_v)]
        self.assertEqual(py, mq)

    def test_fixture_parity(self):
        self._compare(scale(RAW))
        self._compare(scale(RAW_EXT))
        self._compare(scale(mirror(RAW)))

    def test_random_series_parity(self):
        import random
        rng = random.Random(4242)
        for _ in range(30):
            n = rng.randint(40, 160)
            px, rows = 1.1000, []
            for _ in range(n):
                o = px
                c = o + rng.gauss(0, 0.0005)
                h = max(o, c) + abs(rng.gauss(0, 0.0003))
                l = min(o, c) - abs(rng.gauss(0, 0.0003))
                rows.append((o, h, l, c))
                px = c
            self._compare(rows)


class TestImpulseFirst(unittest.TestCase):
    """v0.7.0: the impulse is primary, the order block is derived from it."""

    def test_last_opposing_candle_before_the_leg_is_the_block(self):
        from spa_signal_ref import find_impulse_zones
        from spa_structure_ref import Pivot, PivotType
        O = [100, 100, 100, 100, 100, 100]
        H = [101, 101, 100, 104, 105, 105]
        L = [99, 99, 98, 99, 100, 101.5]
        C = [100, 99, 99, 101, 104, 105]
        piv = [Pivot(idx=2, price=98, kind=PivotType.LOW),
               Pivot(idx=5, price=105, kind=PivotType.HIGH)]
        zs = find_impulse_zones(H, L, C, O, piv, atr=1.0, fvg_min_atr=0.0)
        self.assertEqual(len(zs), 1)
        self.assertEqual(zs[0].kind, "demand")
        self.assertEqual(zs[0].ob_idx, 2)      # the last down candle

    def test_leg_must_travel_far_enough_to_be_an_impulse(self):
        from spa_signal_ref import find_impulse_zones
        from spa_structure_ref import Pivot, PivotType
        O = [100, 100, 99, 100, 100, 100]
        H = [101, 101, 100, 101, 101, 101]
        L = [99, 99, 98, 99, 99, 99]
        C = [100, 99, 99, 100, 100, 100]
        piv = [Pivot(idx=2, price=98, kind=PivotType.LOW),
               Pivot(idx=5, price=100, kind=PivotType.HIGH)]
        self.assertEqual(find_impulse_zones(H, L, C, O, piv, atr=5.0), [])

    def test_imbalance_is_found_inside_the_leg_not_beside_the_block(self):
        """The gap the user marks sits several candles into the impulse."""
        from spa_signal_ref import find_impulse_zones
        from spa_structure_ref import Pivot, PivotType
        n = 9
        O = [100] * n
        H = [101, 101, 100, 101, 101, 101, 104.0, 106.0, 106.0]
        L = [99, 99, 98, 99, 99.5, 100, 102.0, 105.0, 105.5]
        C = [100, 100, 99, 100, 101, 101, 103.5, 105.5, 106.0]
        piv = [Pivot(idx=2, price=98, kind=PivotType.LOW),
               Pivot(idx=8, price=106, kind=PivotType.HIGH)]
        zs = find_impulse_zones(H, L, C, O, piv, atr=1.0, fvg_min_atr=0.5)
        self.assertEqual(len(zs), 1)
        # gap at k=7: low[7]=105.0 vs high[5]=101.0 -> 4.0 wide, far from the block
        self.assertEqual(zs[0].gap_idx, 7)
        self.assertGreater(zs[0].gap_atr, 1.0)


class TestFvgFirstZones(unittest.TestCase):
    """v0.8.0: the block is the candle immediately before the imbalanced one."""

    def _series(self):
        # 6 bars; bar 3 opens a bullish gap over bar 1's high
        O = [100, 100, 100, 100, 100, 100]
        H = [101, 101, 101, 104, 105, 105]
        L = [ 99,  99,  99, 102, 103, 103]
        C = [100, 100, 100, 103, 104, 104]
        return O, H, L, C

    def test_block_is_the_candle_before_the_imbalanced_candle(self):
        from spa_signal_ref import find_fvg_zones
        O, H, L, C = self._series()
        zs = find_fvg_zones(H, L, C, O, atr=1.0, min_atr=0.0)
        bullish = [z for z in zs if z.bullish]
        self.assertTrue(bullish)
        z = bullish[0]
        self.assertEqual(z.gap_idx, 3)     # low[3]=102 > high[1]=101
        # bar 2 is the displacement candle; the block is bar 1, in front of it
        self.assertEqual(z.ob_idx, 1)
        self.assertEqual(z.top, H[1])
        self.assertEqual(z.bottom, L[1])

    def test_a_wick_that_leaves_a_sliver_does_not_kill_the_zone(self):
        """The user reversed this rule on 2026-11-02:
            "a tiny bit of an imbalance that the wick did not really get
             retested ... that zone is still valid, and then we shift the
             last candle before the impulse to the top candle"
        Touching the gap no longer fills it. Crossing all of it does."""
        H = [101.0, 101.5, 102.5, 103.0, 103.0, 103.0]
        L = [100.5, 101.0, 101.6, 102.2, 102.2, 101.7]
        O = [100.8, 101.2, 102.0, 102.6, 102.6, 102.2]
        C = [101.0, 101.4, 102.4, 102.8, 102.6, 101.9]
        zs = find_fvg_zones(H, L, C, O, 1.0)
        hits = [x for x in zs if x.bullish and x.gap_idx == 3]
        self.assertEqual(len(hits), 1, "a wick to 101.7 leaves a gap [101.5, 101.7] open")
        self.assertFalse(hits[0].touched)

    def test_crossing_the_whole_gap_uses_the_zone_up(self):
        H = [101.0, 101.5, 102.5, 103.0, 103.0, 103.0]
        L = [100.5, 101.0, 101.6, 102.2, 102.2, 100.8]
        O = [100.8, 101.2, 102.0, 102.6, 102.6, 102.2]
        C = [101.0, 101.4, 102.4, 102.8, 102.6, 101.0]
        zs = find_fvg_zones(H, L, C, O, 1.0)
        z = [x for x in zs if x.bullish and x.gap_idx == 3][0]
        self.assertTrue(z.touched, "the gap is used up")
        self.assertTrue(z.tapped, "the block is fully consumed")

    def test_the_box_is_always_the_block_candle(self):
        """REGRESSION, 2026-11-02: v0.13.0 shrank the box to a 'live
        remainder', which moved every zone on the chart. The box must always
        be the block candle, wick to wick, however much of it price has taken."""
        H = [101.0, 101.5, 102.5, 103.0, 103.0, 103.0]
        L = [100.5, 101.0, 101.6, 102.2, 102.2, 101.1]
        O = [100.8, 101.2, 102.0, 102.6, 102.6, 102.2]
        C = [101.0, 101.4, 102.4, 102.8, 102.6, 101.5]
        zs = find_fvg_zones(H, L, C, O, 1.0)
        z = [x for x in zs if x.bullish and x.gap_idx == 3][0]
        self.assertAlmostEqual(z.top, H[1], msg="top is the block candle's high")
        self.assertAlmostEqual(z.bottom, L[1], msg="bottom is the block candle's low")

    def test_gap_below_threshold_is_not_a_zone(self):
        from spa_signal_ref import find_fvg_zones
        O = [100, 100, 100, 100]; H = [101, 101, 101, 101.1]
        L = [ 99,  99,  99, 101.05]; C = [100, 100, 100, 101.08]
        # gap between high[1]=101 and low[3]=101.05 is 0.05 wide
        self.assertEqual(find_fvg_zones(H, L, C, O, atr=1.0, min_atr=0.5), [])

class TestExtremeZonePriority(unittest.TestCase):
    """Rule book 3.3, applied literally."""

    def _z(self, bullish, top, bottom, gap_idx=5, fresh=True, closed=False):
        """fresh  -> the block has not been tapped
           closed -> a wick has entered the gap, so the imbalance is filled"""
        from spa_signal_ref import FvgZone
        return FvgZone(bullish=bullish, gap_idx=gap_idx, ob_idx=gap_idx - 2,
                       gap_low=top, gap_high=top + 1, gap_atr=1.0,
                       top=top, bottom=bottom, tapped=not fresh, touched=closed)

    def test_furthest_zone_wins_not_nearest(self):
        from spa_signal_ref import select_extreme_zone
        near = self._z(True, 110.0, 109.0)
        far  = self._z(True, 100.0, 99.0)
        z, why = select_extreme_zone([near, far], price=111.0, demand=True)
        self.assertIs(z, far, "3.3 selects the FURTHEST zone from price")

    def test_zone_whose_imbalance_is_filled_is_skipped(self):
        from spa_signal_ref import select_extreme_zone
        filled = self._z(True, 100.0, 99.0, closed=True)
        open_  = self._z(True, 108.0, 107.0)
        z, why = select_extreme_zone([filled, open_], price=111.0, demand=True)
        self.assertIs(z, open_)
        self.assertIn("1 with an open imbalance", why)

    def test_zone_price_has_already_tapped_is_invalid(self):
        from spa_signal_ref import select_extreme_zone
        used = self._z(True, 100.0, 99.0, fresh=False)
        z, why = select_extreme_zone([used], price=111.0, demand=True)
        self.assertIsNone(z)
        self.assertEqual(why, "no fresh demand zone")

    def test_block_from_a_previous_leg_is_not_a_candidate(self):
        from spa_signal_ref import select_extreme_zone
        old = self._z(True, 100.0, 99.0, gap_idx=3)
        new = self._z(True, 108.0, 107.0, gap_idx=40)
        z, why = select_extreme_zone([old, new], price=111.0, demand=True, leg_start_idx=30)
        self.assertIs(z, new, "a block from the previous leg is not in this swing leg")

    def test_direction_is_respected(self):
        from spa_signal_ref import select_extreme_zone
        d = self._z(True, 108.0, 107.0)
        s = self._z(False, 120.0, 119.0)
        z, why = select_extreme_zone([d, s], price=111.0, demand=False)
        self.assertIs(z, s)

    def test_no_bias_direction_returns_nothing(self):
        from spa_signal_ref import select_extreme_zone
        z, why = select_extreme_zone([], price=111.0, demand=True)
        self.assertIsNone(z)


class TestBlockSorting(unittest.TestCase):
    """One move = one block. The extreme of the run is the one that counts."""

    def _z(self, bullish, top, bottom, ob_idx):
        from spa_signal_ref import FvgZone
        return FvgZone(bullish=bullish, gap_idx=ob_idx + 2, ob_idx=ob_idx,
                       gap_low=top, gap_high=top + 0.1, gap_atr=1.0,
                       top=top, bottom=bottom)

    def test_consecutive_blocks_in_one_move_collapse_to_the_extreme(self):
        from spa_signal_ref import compress_runs
        # price runs up, three blocks in a row, nothing comes back
        high = [1.0]*20
        low  = [1.0]*20
        zs = [self._z(False, 10.0, 9.5, 3),
              self._z(False, 11.0, 10.5, 6),
              self._z(False, 12.0, 11.5, 9)]
        out = compress_runs(zs, high, low, [1.0]*20)   # nothing closes back in
        self.assertEqual(len(out), 1, "one move = one block")
        self.assertAlmostEqual(out[0].top, 12.0, msg="the extreme top wins")

    def test_demand_run_keeps_the_lowest_block(self):
        from spa_signal_ref import compress_runs
        high = [99.0]*20
        low  = [99.0]*20
        zs = [self._z(True, 10.0, 9.5, 3),
              self._z(True, 9.0, 8.5, 6),
              self._z(True, 8.0, 7.5, 9)]
        out = compress_runs(zs, high, low, [99.0]*20)
        self.assertEqual(len(out), 1)
        self.assertAlmostEqual(out[0].bottom, 7.5, msg="the extreme low wins")

    def test_a_retest_ends_the_run(self):
        from spa_signal_ref import compress_runs
        high = [99.0]*20
        low  = [99.0]*20
        close = [99.0]*20
        close[5] = 9.9         # a candle CLOSES back inside the first block (top 10.0)
        zs = [self._z(True, 10.0, 9.5, 3),
              self._z(True, 9.0, 8.5, 6)]
        out = compress_runs(zs, high, low, close)
        self.assertEqual(len(out), 2, "a retest starts a new run")

    def test_direction_change_ends_the_run(self):
        from spa_signal_ref import compress_runs
        high = [99.0]*20
        low  = [99.0]*20
        zs = [self._z(False, 12.0, 11.5, 3),
              self._z(True, 10.0, 9.5, 6)]
        out = compress_runs(zs, high, low, [99.0]*20)
        self.assertEqual(len(out), 2)

    def test_a_wick_back_in_does_not_end_the_move(self):
        """The case the user marked with an X on 2026-11-03."""
        from spa_signal_ref import compress_runs
        high = [99.0]*20
        low  = [99.0]*20
        close = [99.0]*20
        low[5] = 9.9           # a WICK pokes into the first block
        close[5] = 10.05       # but the candle CLOSES back above it
        zs = [self._z(True, 10.0, 9.5, 3),
              self._z(True, 9.0, 8.5, 6)]
        out = compress_runs(zs, high, low, close)
        self.assertEqual(len(out), 1, "a wick is not a pullback; one move, one block")
        self.assertAlmostEqual(out[0].bottom, 8.5, msg="the extreme still wins")

    def test_retested_block_is_flagged(self):
        from spa_signal_ref import ever_retested
        high = [99.0]*12
        low  = [99.0]*12
        z = self._z(True, 10.0, 9.5, 3)
        high[8] = 9.8
        low[8]  = 9.6          # price traded inside the block
        self.assertTrue(ever_retested(z, high, low))


if __name__ == "__main__":
    unittest.main(verbosity=2)
