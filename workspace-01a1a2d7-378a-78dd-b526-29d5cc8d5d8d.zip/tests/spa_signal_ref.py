"""
Zone construction + trade planning reference for v0.6.0.

Mirrors what will become Include/SPA_Zones.mqh and Include/SPA_Signal.mqh.
Every function here has a corresponding unit test in test_signal.py and a
line-for-line MQL5 counterpart. Divergence is a release blocker.

D-A (user decision, 2026-11-02): the entry zone is the LAST CANDLE BEFORE THE
IMPULSE (order block), and that candle MUST be followed by a clear imbalance.
No imbalance -> no zone. The order block is not optional and the FVG is a
validity filter, not an alternative.
"""
from dataclasses import dataclass, field
from typing import List, Optional, Callable

from spa_structure_ref import (
    Pivot, LevelEvent, PivotType, EventType,
)


# --------------------------------------------------------------------------
@dataclass
class Zone:
    kind: str            # "demand" (bullish) or "supply" (bearish)
    ob_idx: int          # the order-block candle
    break_idx: int       # the candle that closed through structure
    top: float
    bottom: float
    entry: float         # near edge - first touch
    stop_ref: float      # far edge - zone invalidation
    fresh: bool = True
    age: int = 0         # bars since the break - a zone can be fresh yet stale

    @property
    def bullish(self) -> bool:
        return self.kind == "demand"


# --------------------------------------------------------------------------
def find_imbalance(high: List[float], low: List[float], start: int, end: int,
                   bullish: bool, atr: float = 0.0, min_atr: float = 0.15,
                   window: int = 3, n: int = None, fill_to: int = None) -> int:
    """
    Return the index of a VALID, UNFILLED imbalance created by the impulse that
    left the order block, or -1.

    Three things the previous version got wrong, all of them visible on a chart:

    1. SIZE. A gap must be worth something. RB D-06 sets it at
       `Low[3] - High[1] >= 0.5 x ATR14`. Without a threshold a 0.1-pip sliver
       counted, so zones appeared on perfectly efficient price action.
    2. PLACE. The gap must be part of the DISPLACEMENT - within `window` bars
       of the order block - not anywhere in the next twenty.
    3. FILL. "a gap that has not been filled" - if price has since traded all
       the way back through it, it is not an imbalance any more, it is history.
    """
    n = len(high) if n is None else n
    # `fill_to` limits how far forward we look for the gap being closed. At
    # BIRTH we only care whether the impulse itself ate the gap; whether price
    # closes it later is the zone's freshness, not its validity. Using the
    # whole series here deleted a zone the moment it was tapped - which is
    # exactly the history the audit view exists to show.
    fill_end = n if fill_to is None else min(n, fill_to + 1)
    min_gap = max(0.0, min_atr * atr)
    last = min(end, start + window)

    for k in range(max(start + 1, 2), last + 1):
        if bullish:
            gap_low, gap_high = high[k - 2], low[k]
            if gap_high - gap_low < min_gap or gap_high <= gap_low:
                continue
            filled = any(low[j] <= gap_low for j in range(k + 1, fill_end))
        else:
            gap_low, gap_high = high[k], low[k - 2]
            if gap_high - gap_low < min_gap or gap_high <= gap_low:
                continue
            filled = any(high[j] >= gap_high for j in range(k + 1, fill_end))
        if not filled:
            return k
    return -1


def has_imbalance(high, low, start, end, bullish, atr=0.0, min_atr=0.5,
                  window=3, n=None) -> bool:
    return find_imbalance(high, low, start, end, bullish, atr, min_atr, window, n) >= 0


# --------------------------------------------------------------------------
DIAG_KEYS = ("cand", "none", "small", "filled", "ok")


def gap_filled_since(high, low, zone_top, zone_bottom, from_idx, n, bullish):
    """Has price closed the gap that validated this zone, after it was born?"""
    if bullish:
        return any(low[j] <= zone_top for j in range(from_idx, n))
    return any(high[j] >= zone_bottom for j in range(from_idx, n))


def imbalance_reason(high, low, start, end, bullish, atr, min_atr, window, n,
                     fill_to=None):
    """Why FindImbalance() accepted or rejected this order block.

    Mirrors CSpaZones::FindImbalance's `why` out-parameter so the panel's
    counter line can be tested. Returns "ok" | "none" | "small" | "filled".
    """
    min_gap = max(0.0, min_atr * atr)
    fill_end = n if fill_to is None else min(n, fill_to + 1)
    last = min(end, start + window)
    why = "none"
    for k in range(max(start + 1, 2), last + 1):
        if bullish:
            gap_low, gap_high = high[k - 2], low[k]
            filled = any(low[j] <= gap_low for j in range(k + 1, fill_end))
        else:
            gap_low, gap_high = high[k], low[k - 2]
            filled = any(high[j] >= gap_high for j in range(k + 1, fill_end))
        if gap_high - gap_low < min_gap or gap_high <= gap_low:
            if why == "none":
                why = "small"
            continue
        if filled:
            why = "filled"
            continue
        return "ok"
    return why


def find_zones(open_: List[float], high: List[float], low: List[float],
               close: List[float], events: List[LevelEvent],
               atr: float = 0.0, lookback: int = 20, latest_only: bool = True,
               fvg_min_atr: float = 0.15, fvg_window: int = 3,
               diag: dict = None) -> List[Zone]:
    """
    One zone per structural break that produced a valid order block.

    A break is a BOS event (body close beyond a swing). The order block is the
    last candle that closed AGAINST the breaking move, searching back from the
    break bar. That candle's range becomes the zone.

    Zones sharing an order-block candle are de-duplicated: the same candle
    cannot be two different zones.
    """
    n = len(close)
    zones: List[Zone] = []
    seen_ob = set()

    for e in events:
        if e.event != EventType.BOS:
            continue
        bullish = (e.kind == PivotType.HIGH)   # close above a swing high
        b = e.event_idx
        if b < 2 or b >= n:
            continue

        ob = -1
        floor_i = max(b - lookback, 0)
        for j in range(b, floor_i - 1, -1):
            if bullish and close[j] < open_[j]:
                ob = j
                break
            if (not bullish) and close[j] > open_[j]:
                ob = j
                break
        if ob < 0 or ob >= b:
            continue
        if ob in seen_ob:
            continue

        # D-A + D-06: the order block MUST be followed by a real, unfilled,
        # adequately-sized imbalance within the displacement itself.
        why = imbalance_reason(high, low, ob, b, bullish, atr, fvg_min_atr,
                               fvg_window, n, fill_to=b)
        if diag is not None:
            diag["cand"] += 1
            diag[why if why != "ok" else "ok"] += 1
        if why != "ok":
            continue

        seen_ob.add(ob)

        bottom, top = low[ob], high[ob]
        z = Zone(
            kind="demand" if bullish else "supply",
            ob_idx=ob,
            break_idx=b,
            top=top,
            bottom=bottom,
            entry=top if bullish else bottom,
            stop_ref=bottom if bullish else top,
        )
        z.fresh = zone_is_fresh(high, low, z, b, n)
        z.age = (n - 1) - b
        zones.append(z)

    # chronological, so "the most recent zones" is a simple tail
    zones.sort(key=lambda zz: zz.ob_idx)

    # D-E: only the most RECENT impulse in each direction is live.
    #
    # "Another pullback, it retests the last candle before the impulse... then
    #  it goes down to our zone" - the zone you trade is the one the LATEST
    # impulse created, not the last one that happens to be untouched. An
    # ancient untouched zone is not an opportunity, it is a level the market
    # has walked past.
    if latest_only:
        newest = {}
        for z in zones:
            k = z.kind
            if k not in newest or z.break_idx > newest[k].break_idx:
                newest[k] = z
        keep = {id(v) for v in newest.values()}
        zones = [z for z in zones if id(z) in keep]

    return zones


def zone_is_fresh(high: List[float], low: List[float], z: Zone,
                  from_idx: int, n: int) -> bool:
    """
    Fresh = price has NOT traded back into the zone since it was created.
    The first return into the zone is the entry (D-12, one-touch rule).
    """
    for j in range(from_idx + 1, n):
        if z.bullish:
            if low[j] <= z.top:          # wick reached the near edge
                return False
        else:
            if high[j] >= z.bottom:
                return False
    return True


# --------------------------------------------------------------------------
def first_obstacle(pivots: List[Pivot], events: List[LevelEvent],
                   entry: float, bullish: bool) -> Optional[float]:
    """
    The first structural level in front of the trade.

    Long : the NEAREST swing high above the entry.
    Short: the NEAREST swing low below the entry.

    Deliberately the nearest, not the furthest: it is the first place price is
    likely to stall, so it is the honest target and the honest R:R.
    """
    # A level that has already been closed through is not an obstacle - it is
    # behind us. Only levels still standing can cap the trade.
    resolved = {e.level_idx for e in events if e.event == EventType.BOS}

    best = None
    for p in pivots:
        if p.idx in resolved:
            continue
        if bullish and p.kind == PivotType.HIGH and p.price > entry:
            if best is None or p.price < best:
                best = p.price
        if (not bullish) and p.kind == PivotType.LOW and p.price < entry:
            if p.price > best if best is not None else True:
                if best is None or p.price > best:
                    best = p.price
    return best


# --------------------------------------------------------------------------
@dataclass
class TradePlan:
    direction: str = ""          # "BUY" / "SELL"
    entry: float = 0.0
    sl: float = 0.0
    tp: float = 0.0
    sl_pips: float = 0.0
    tp_pips: float = 0.0
    lots: float = 0.0
    rr: float = 0.0
    ok: bool = False
    reason: str = ""


def nearest_obstacle(a: Optional[float], b: Optional[float],
                     entry: float) -> Optional[float]:
    """The closer of two structural levels. A target is only honest if it is
    the FIRST thing in the way, whichever timeframe it came from."""
    if a is None:
        return b
    if b is None:
        return a
    return a if abs(a - entry) <= abs(b - entry) else b


def build_plan(z: Zone, obstacle: Optional[float], spread_px: float, pip: float,
               risk_money: float, money_per_lot_per_pip: float,
               min_rr: float = 3.0, lot_step: float = 0.01,
               min_sl_px: float = 0.0) -> TradePlan:
    """
    Turn a zone into an exact order: entry, stop, target, lots, R:R.

    Stop placement follows the transcript - where the trade becomes INVALID -
    which at zone stage is the far edge of the order block, plus the rule book's
    2 x spread + 2 pips buffer so a spread spike does not stop out a valid trade.
    (v0.6.1 will tighten this to the sweep low once confirmation gating exists.)

    Rejection is explicit: under 3R there is no trade, full stop.
    """
    plan = TradePlan(direction="BUY" if z.bullish else "SELL", entry=z.entry)

    if obstacle is None:
        plan.reason = "REJ_NO_TARGET"
        return plan

    buffer = 2.0 * spread_px + 2.0 * pip
    plan.sl = (z.bottom - buffer) if z.bullish else (z.top + buffer)
    plan.tp = obstacle

    plan.sl_pips = abs(plan.entry - plan.sl) / pip
    plan.tp_pips = abs(plan.tp - plan.entry) / pip

    if plan.sl_pips <= 0.0:
        plan.reason = "REJ_NO_SL"
        return plan

    # A stop closer than the market's own noise is not a tight stop, it is a
    # guaranteed loss. Never widen it - reject the zone instead.
    if min_sl_px > 0.0 and (plan.sl_pips * pip) < min_sl_px:
        plan.reason = "REJ_SL_TOO_TIGHT"
        return plan

    plan.rr = plan.tp_pips / plan.sl_pips
    if plan.rr < min_rr:
        plan.reason = "REJ_RR"
        return plan

    if money_per_lot_per_pip <= 0.0 or risk_money <= 0.0:
        plan.reason = "REJ_NO_LOT"
        return plan

    raw = risk_money / (plan.sl_pips * money_per_lot_per_pip)
    steps = int(raw / lot_step + 1e-9)          # always round DOWN
    plan.lots = round(steps * lot_step, 2)
    if plan.lots <= 0.0:
        plan.reason = "REJ_NO_LOT"
        return plan

    plan.ok = True
    plan.reason = "OK"
    return plan


# --------------------------------------------------------------------------
def select_best(zones: List[Zone], pivots_obstacle: List[Pivot],
                events: List[LevelEvent], spread_px: float,
                pip: float, risk_money: float, money_per_lot_per_pip: float,
                trend: str, min_rr: float = 3.0,
                near: Optional[tuple] = None, min_sl_px: float = 0.0,
                max_age: int = 200) -> Optional[tuple]:
    """
    Among fresh zones in the direction of the bias trend, pick the one with the
    best reward-to-risk to its first obstacle.

    This is the user's D-A tie-break made mechanical: "we use the zone with
    that magnet" - a zone only wins if there is actually liquidity worth
    travelling to behind it.
    """
    if trend not in ("UP", "DOWN"):
        return None        # caller reports REJ_NO_TREND

    best = None            # (plan, zone)
    for z in zones:
        if not z.fresh:
            continue
        # A zone untouched for 200 bars is not "fresh", it is abandoned: the
        # order flow that created it has long since gone.
        if max_age > 0 and z.age > max_age:
            continue
        if trend == "UP" and not z.bullish:
            continue
        if trend == "DOWN" and z.bullish:
            continue

        obst = first_obstacle(pivots_obstacle, events, z.entry, z.bullish)
        if near is not None:
            obst = nearest_obstacle(
                obst, first_obstacle(near[0], near[1], z.entry, z.bullish), z.entry)
        plan = build_plan(z, obst, spread_px, pip, risk_money,
                          money_per_lot_per_pip, min_rr, min_sl_px=min_sl_px)
        if not plan.ok:
            continue
        if best is None or plan.rr > best[0].rr:
            best = (plan, z)
    return best


# --------------------------------------------------------------------------
# IMPULSE-FIRST ORDER BLOCKS (v0.7.0)
#
# The user's instruction, 2026-11-02:
#   "First of all, we should first nail that thing of identifying the last
#    candles before the impulses, because those are where we enter from."
#
# So the impulse is the primary object and the order block is derived from it.
# The earlier engine did the reverse: it started from a structural break and
# searched backwards for a candle, which meant an order block could only exist
# where a BOS happened - and most impulses do not break structure.
#
# The second correction: the imbalance does NOT have to sit next to the order
# block. It forms INSIDE the impulse leg. Requiring it within 3 bars of the
# order block rejected visibly huge gaps. Measured on EUR/USD M15, scanning the
# whole leg finds a gap >= 0.5 x ATR for 109 of 162 impulses; a 3-bar window
# found 8.
# --------------------------------------------------------------------------
@dataclass
class ImpulseZone:
    kind: str            # "demand" or "supply"
    ob_idx: int          # last candle before the impulse
    pivot_idx: int       # the swing the impulse left from
    leg_end: int         # the swing it arrived at
    top: float
    bottom: float
    bullish: bool
    leg_atr: float = 0.0
    gap_idx: int = -1    # best unfilled imbalance inside the leg
    gap_low: float = 0.0
    gap_high: float = 0.0
    gap_atr: float = 0.0
    gap_filled: bool = False
    fresh: bool = True
    age: int = 0


def find_impulse_zones(high, low, close, open_, pivots, atr,
                       min_leg_atr: float = 1.5, ob_scan: int = 6,
                       fvg_min_atr: float = 0.5, require_gap: bool = True):
    """One order block per impulse leg: the last candle against the move."""
    zones = []
    n = len(close)
    if atr <= 0 or len(pivots) < 2:
        return zones

    for a, b in zip(pivots, pivots[1:]):
        leg = abs(b.price - a.price)
        if leg < min_leg_atr * atr:
            continue
        bullish = b.price > a.price

        ob = -1
        for j in range(a.idx, max(a.idx - ob_scan, 0) - 1, -1):
            if bullish and close[j] < open_[j]:
                ob = j
                break
            if (not bullish) and close[j] > open_[j]:
                ob = j
                break
        if ob < 0 or ob >= b.idx:
            continue

        z = ImpulseZone(
            kind="demand" if bullish else "supply",
            ob_idx=ob,
            pivot_idx=a.idx,
            leg_end=b.idx,
            top=high[ob],
            bottom=low[ob],
            bullish=bullish,
            leg_atr=leg / atr,
        )

        # largest imbalance inside the leg that the leg itself did not close
        best, best_k = -1.0, -1
        for k in range(max(ob + 2, 2), b.idx + 1):
            if bullish:
                gap_low, gap_high = high[k - 2], low[k]
                filled = any(low[j] <= gap_low for j in range(k + 1, b.idx + 1))
            else:
                gap_low, gap_high = high[k], low[k - 2]
                filled = any(high[j] >= gap_high for j in range(k + 1, b.idx + 1))
            g = gap_high - gap_low
            if g > best and not filled:
                best, best_k = g, k
                z.gap_low, z.gap_high = gap_low, gap_high

        if best_k >= 0 and best >= fvg_min_atr * atr:
            z.gap_idx = best_k
            z.gap_atr = best / atr
        elif require_gap:
            continue

        # has price come back into the block since the leg ended?
        z.fresh = True
        for j in range(b.idx + 1, n):
            if low[j] <= z.top and high[j] >= z.bottom:
                z.fresh = False
                break
        z.age = (n - 1) - b.idx

        # did price close the gap afterwards?
        if z.gap_idx >= 0:
            for j in range(b.idx + 1, n):
                if bullish and low[j] <= z.gap_low:
                    z.gap_filled = True
                    break
                if (not bullish) and high[j] >= z.gap_high:
                    z.gap_filled = True
                    break

        zones.append(z)

    return zones


# --------------------------------------------------------------------------
# FVG-FIRST ORDER BLOCKS (v0.8.0)
#
# The user's correction, 2026-11-02:
#   "When there is a candle that has an imbalance, the candle BEFORE that
#    candle is what I would call the last candle before an impulse."
#
# So the imbalance is the primary object. Steps:
#   1. find every 3-candle imbalance, wick to wick
#   2. the order block is the candle immediately BEFORE the imbalanced candle
#   3. the zone is that candle's wick-to-wick range
#
# This also removes the swing/ZigZag dependency: a zone exists wherever price
# left a gap, which is what the user marks by eye. And because the block is the
# quiet candle before the impulse rather than the impulse candle itself, the
# wild-bar problem (45% of blocks were range >= 2 x ATR) disappears by
# construction rather than by a filter.
#
# Fill rule, confirmed by the user: "even a wick taps into that imbalanced
# area, that is already filled. It does not need to be a body." -> touch-based.
# --------------------------------------------------------------------------
@dataclass
class FvgZone:
    bullish: bool
    gap_idx: int         # the imbalanced candle
    ob_idx: int          # the last candle before the impulse
    gap_low: float
    gap_high: float
    gap_atr: float
    top: float           # order block high, wick to wick
    bottom: float        # order block low,  wick to wick
    touched: bool = False   # a wick has entered the gap
    closed: bool = False    # price traded through the far edge
    tapped: bool = False    # price has been back into the order block
    age: int = 0

    @property
    def kind(self):
        return "demand" if self.bullish else "supply"


def find_fvg_zones(high, low, close, open_, atr, min_atr: float = 0.5,
                   require_untouched: bool = False):
    out = []
    n = len(close)
    if atr <= 0 or n < 4:
        return out
    min_gap = min_atr * atr

    for k in range(2, n):
        bullish = False
        found = False
        gap_low = gap_high = 0.0

        if low[k] > high[k - 2]:
            gap_low, gap_high = high[k - 2], low[k]
            bullish, found = True, True
        elif high[k] < low[k - 2]:
            gap_low, gap_high = high[k], low[k - 2]
            bullish, found = False, True
        if not found:
            continue
        if gap_high - gap_low < min_gap:
            continue

        # the block is the candle BEFORE the displacement candle (k-1 is the
        # displacement itself; k-2 is the quiet candle in front of it)
        ob = k - 2
        if ob < 0:
            continue
        z = FvgZone(
            bullish=bullish, gap_idx=k, ob_idx=ob,
            gap_low=gap_low, gap_high=gap_high,
            gap_atr=(gap_high - gap_low) / atr,
            top=high[ob], bottom=low[ob],
            age=(n - 1) - k,
        )

        # The user's correction, 2026-11-02: an imbalance is USED UP, not
        # merely TOUCHED. A wick that leaves a sliver leaves the zone valid,
        # and the valid zone is the part of the block still untouched.
        lo_since = min(low[k + 1:]) if k + 1 < n else low[k]
        hi_since = max(high[k + 1:]) if k + 1 < n else high[k]

        # VALIDITY ONLY - the box stays the block candle, wick to wick.
        if bullish:
            z.closed = lo_since <= gap_low
            z.tapped = lo_since <= z.bottom        # fully consumed
        else:
            z.closed = hi_since >= gap_high
            z.tapped = hi_since >= z.top
        z.touched = z.closed


        if require_untouched and z.touched:
            continue
        out.append(z)

    return out


# --------------------------------------------------------------------------
# §3.3 EXTREME ZONE PRIORITY  (v0.12.0)
#
# The user's rule book, Section 3, word for word:
#
#   "If multiple valid zones exist within a single swing leg, the algorithm
#    ranks them by proximity to the swing extreme. The bot selects the Extreme
#    Zone (the furthest valid zone from the current market price that still
#    possesses an Unfilled Imbalance)."
#
# Three tests follow from that sentence, and nothing else does:
#   valid   -> price has not been back into the block      (rule 3.2)
#   unfilled -> the gap that validated it is still open    (rule 3.3)
#   leg     -> the block was created after the swing extreme it belongs to
# The winner is the FURTHEST of those from price, not the nearest.
# --------------------------------------------------------------------------

def select_extreme_zone(zones, price, demand, leg_start_idx=-1):
    """
    Return (zone_or_None, reason_text).

    `demand=True` selects a buy-side zone, False a sell-side zone.
    `leg_start_idx` is the bar of the swing extreme the leg left from; blocks
    older than that belong to a previous leg and are not candidates.
    """
    want = "demand" if demand else "supply"
    valid = unused_gap = inleg = 0
    best = None

    for z in zones:
        if z.bullish != demand:
            continue
        if z.tapped:                    # price has already been back in it
            continue
        valid += 1
        if z.touched:                   # a wick has entered the gap: filled
            continue
        unused_gap += 1
        if leg_start_idx >= 0 and z.gap_idx < leg_start_idx:
            continue
        inleg += 1
        if best is None:
            best = z
            continue
        # furthest from price wins
        if abs(_ref_entry(z) - price) > abs(_ref_entry(best) - price):
            best = z

    if best is None:
        if valid == 0:
            return None, "no fresh %s zone" % want
        if unused_gap == 0:
            return None, "%d fresh %s zone(s), every imbalance already filled" % (valid, want)
        return None, "%d fresh %s zone(s) with an open imbalance, none inside the current leg" % (
            unused_gap, want)

    return best, "%d valid, %d with an open imbalance, %d in the leg - extreme %s chosen" % (
        valid, unused_gap, inleg, want)


def _ref_entry(z):
    return z.top if z.bullish else z.bottom


# --------------------------------------------------------------------------
# SORTING THE BLOCKS  (v0.16.0)
#
# The user, 2026-11-03:
#   "we cannot get the last candle before the impulse again immediately after
#    it... we are going to be considering the extreme, the last candle at the
#    top, which brought all of these inefficient candles... Unless there is
#    maybe a break of structure, maybe a pullback, after that pullback we can
#    consider that also."
#
# One move = a run of same-direction blocks with no retest between them.
# Inside a run only the EXTREME survives: the highest block for supply, the
# lowest block for demand. A retest ends the run and a new one may begin.
# --------------------------------------------------------------------------

def compress_runs(zones, high, low, close):
    """Collapse each run of same-direction blocks into its extreme block."""
    out = []
    run = None
    for z in zones:
        if run is None:
            run = z
            continue
        if z.bullish == run.bullish:
            # A wick poking back into the block does NOT end the move - only a
            # candle that CLOSES back inside it does. (User, 2026-11-03: the
            # block immediately after the first one in a move is not counted.)
            retested = False
            for b in range(run.ob_idx + 1, z.ob_idx + 1):
                if run.bullish:
                    if close[b] <= run.top:
                        retested = True
                        break
                else:
                    if close[b] >= run.bottom:
                        retested = True
                        break
            if not retested:
                # one move: keep the extreme
                if z.bullish:
                    if z.bottom < run.bottom:
                        run = z
                else:
                    if z.top > run.top:
                        run = z
                continue
        out.append(run)
        run = z
    if run is not None:
        out.append(run)
    return out


def ever_retested(z, high, low):
    """Has price been back into this block at any time since it formed?

    The scan starts AFTER the gap candle: the bars that build the imbalance
    are not a retest. (Scanning from ob_idx+1 flagged 153 of 184 blocks as
    touched one bar after they formed - that was the bug, not the rule.)
    """
    for b in range(z.gap_idx + 1, len(high)):
        if low[b] <= z.top and high[b] >= z.bottom:
            return True
    return False
