"""
Reference implementation of the SPA structure engine (SPEC-001 D-08..D-14).

This is the Python twin of `experts/SovereignPA/Include/SPA_Structure.mqh`.
It exists so the detection logic can be proven against hand-built price series
BEFORE it is compiled into the EA. Any divergence between this file and the MQL5
module is a release blocker (SPEC-001 8.6).

Conventions
-----------
Python arrays are CHRONOLOGICAL: index 0 = oldest bar, index n-1 = newest bar.
MQL5 uses SERIES order (index 0 = newest). Mapping:

        mql_index = n - 1 - py_index

Every function here takes chronological arrays; the MQL5 module does the
mirroring internally. All decisions use CLOSED bars only (D-09).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class Trend(Enum):
    UP = "UP"
    DOWN = "DOWN"
    RANGE = "RANGE"


class PivotType(Enum):
    HIGH = "H"
    LOW = "L"


class EventType(Enum):
    BOS = "BOS"        # body close beyond the level  (D-09)
    SWEEP = "SWEEP"    # wick beyond, close back inside (D-10)


@dataclass
class Pivot:
    idx: int           # chronological index of the pivot bar
    price: float
    kind: PivotType
    label: str = ""    # HH / HL / LH / LL, filled by classify_labels()


@dataclass
class LevelEvent:
    level_idx: int     # index of the pivot that formed the level
    level_price: float
    kind: PivotType    # which side the level sits on
    event: EventType
    event_idx: int     # index of the bar that produced the event


@dataclass
class StructureSnapshot:
    trend: Trend = Trend.RANGE
    pivots: List[Pivot] = field(default_factory=list)
    events: List[LevelEvent] = field(default_factory=list)
    consolidating: bool = False
    bars_since_extreme: int = 0


# --------------------------------------------------------------------------
# D-08 : fractal pivots
# --------------------------------------------------------------------------
def find_pivots(high: List[float], low: List[float], k: int = 2) -> List[Pivot]:
    """
    A bar is a swing high if its high equals the maximum of the
    2k+1 window centred on it, AND it is the LAST bar in that window to
    achieve the maximum (plateau tie-break -> most recent rejection wins).
    Swing lows mirror this.

    The "last occurrence" rule matters: a flat double-top otherwise
    produces either zero or two pivots depending on scan direction.
    """
    n = len(high)
    pivots: List[Pivot] = []

    for i in range(k, n - k):
        win_h = high[i - k:i + k + 1]
        mx = max(win_h)
        if high[i] == mx:
            last = max(j for j in range(i - k, i + k + 1) if high[j] == mx)
            if last == i:
                pivots.append(Pivot(i, high[i], PivotType.HIGH))

        win_l = low[i - k:i + k + 1]
        mn = min(win_l)
        if low[i] == mn:
            last = max(j for j in range(i - k, i + k + 1) if low[j] == mn)
            if last == i:
                pivots.append(Pivot(i, low[i], PivotType.LOW))

    pivots.sort(key=lambda p: (p.idx, p.kind.value))
    return pivots


def alternation(pivots: List[Pivot]) -> List[Pivot]:
    """
    PRESENTATION ONLY - never feed this into signal logic.

    Collapses consecutive same-type pivots to the more extreme one, giving a
    clean H-L-H-L leg sequence for drawing.

    It must NOT be applied before trend / shift detection, because "keep the
    more extreme" DELETES the information that a lower high formed. In this
    series:

        H(12)  L(10)  H(13)  H(12.5)   -> alternation yields H(12) L(10) H(13)

    the 12.5 lower high vanishes, so the engine sees an intact higher high and
    validates a bearish shift that the source methodology explicitly rejects.
    Raw pivots are the input to every decision; alternation is the drawing view.
    """
    out: List[Pivot] = []
    for p in pivots:
        if out and out[-1].kind == p.kind:
            if p.kind == PivotType.HIGH and p.price > out[-1].price:
                out[-1] = p
            elif p.kind == PivotType.LOW and p.price < out[-1].price:
                out[-1] = p
            # else: keep the existing, more extreme pivot
        else:
            out.append(p)
    return out


# --------------------------------------------------------------------------
# D-08b : ATR-ZigZag swings (significance-filtered)
# --------------------------------------------------------------------------
def find_pivots_zigzag(high: List[float], low: List[float],
                       atr: float, mult: float = 4.0) -> List[Pivot]:
    """
    Fractal pivots fire on ANY local extremum. On M5 that is a pivot every
    ~4 bars - every minor wiggle - which is not market structure.

    This detector requires the market to actually GO somewhere before it
    records a swing: a pivot is only emitted once price has retraced at
    least `mult * atr` from the extreme. That single rule collapses the
    pivot count by roughly 4-8x and keeps only swings a human would mark.

    NON-REPAINTING: a swing is emitted only after the retrace that
    confirms it. The current (still-running) extreme is never drawn.
    """
    n = len(high)
    piv: List[Pivot] = []
    if n < 3 or atr <= 0.0 or mult <= 0.0:
        return piv

    th = mult * atr

    hi_i, hi_p = 0, high[0]
    lo_i, lo_p = 0, low[0]
    direction = 0                      # +1 up-leg, -1 down-leg, 0 undefined

    for i in range(1, n):
        if direction == 0:
            if high[i] > hi_p: hi_i, hi_p = i, high[i]
            if low[i]  < lo_p: lo_i, lo_p = i, low[i]
            if hi_p - lo_p >= th:
                # whichever extreme printed LAST tells us the current leg
                if hi_i > lo_i:
                    piv.append(Pivot(lo_i, lo_p, PivotType.LOW))
                    direction = 1
                    hi_i, hi_p = i, high[i]
                else:
                    piv.append(Pivot(hi_i, hi_p, PivotType.HIGH))
                    direction = -1
                    lo_i, lo_p = i, low[i]
            continue

        if direction == 1:
            if high[i] > hi_p:
                hi_i, hi_p = i, high[i]
            if hi_p - low[i] >= th:
                piv.append(Pivot(hi_i, hi_p, PivotType.HIGH))
                direction = -1
                lo_i, lo_p = i, low[i]
        else:
            if low[i] < lo_p:
                lo_i, lo_p = i, low[i]
            if high[i] - lo_p >= th:
                piv.append(Pivot(lo_i, lo_p, PivotType.LOW))
                direction = 1
                hi_i, hi_p = i, high[i]

    return piv


def atr_sma(high: List[float], low: List[float], close: List[float], period: int = 14) -> float:
    """Wilder ATR, returned at the most recent bar."""
    n = len(high)
    if n < period + 1:
        return 0.0
    trs = []
    for i in range(1, n):
        tr = max(high[i] - low[i], abs(high[i] - close[i - 1]), abs(low[i] - close[i - 1]))
        trs.append(tr)
    atr = sum(trs[:period]) / period
    for tr in trs[period:]:
        atr = (atr * (period - 1) + tr) / period
    return atr


# --------------------------------------------------------------------------
# HH / HL / LH / LL labelling (RB 2.1)
# --------------------------------------------------------------------------
def classify_labels(pivots: List[Pivot]) -> List[Pivot]:
    prev_by_kind = {PivotType.HIGH: None, PivotType.LOW: None}
    for p in pivots:
        prev = prev_by_kind[p.kind]
        if prev is None:
            p.label = "H" if p.kind == PivotType.HIGH else "L"
        elif p.kind == PivotType.HIGH:
            p.label = "HH" if p.price > prev.price else "LH"
        else:
            p.label = "HL" if p.price > prev.price else "LL"
        prev_by_kind[p.kind] = p
    return pivots


# --------------------------------------------------------------------------
# Trend classification (RB 2.1)
# --------------------------------------------------------------------------
def classify_trend(pivots: List[Pivot]) -> Trend:
    highs = [p for p in pivots if p.kind == PivotType.HIGH]
    lows = [p for p in pivots if p.kind == PivotType.LOW]
    if len(highs) < 2 or len(lows) < 2:
        return Trend.RANGE

    h1, h2 = highs[-2].price, highs[-1].price
    l1, l2 = lows[-2].price, lows[-1].price

    if h2 > h1 and l2 > l1:
        return Trend.UP
    if h2 < h1 and l2 < l1:
        return Trend.DOWN
    return Trend.RANGE


def bars_since_new_extreme(pivots: List[Pivot], n: int) -> int:
    """
    Bars since the most recent pivot that set a NEW extreme versus the
    previous pivot of the same kind. RB 2.1 suspends trading after 20 bars
    without a new HH or LL — this is the raw input to that filter.
    """
    last_extreme_idx: Optional[int] = None
    prev = {PivotType.HIGH: None, PivotType.LOW: None}
    for p in pivots:
        pp = prev[p.kind]
        if pp is not None:
            if p.kind == PivotType.HIGH and p.price > pp.price:
                last_extreme_idx = p.idx
            elif p.kind == PivotType.LOW and p.price < pp.price:
                last_extreme_idx = p.idx
        prev[p.kind] = p
    if last_extreme_idx is None:
        return n
    return (n - 1) - last_extreme_idx


# --------------------------------------------------------------------------
# D-09 / D-10 : classify what happened to each level
# --------------------------------------------------------------------------
def classify_events(open_, high, low, close, pivots: List[Pivot]) -> List[LevelEvent]:
    """
    For every pivot level, the FIRST thing that happens to it afterwards is
    either:
      * BOS   - a candle BODY closes beyond the level, or
      * SWEEP - a wick pierces the level and the close returns inside.

    A level is resolved exactly once. This single rule is what separates
    a market-structure shift from a liquidity sweep, and the whole entry
    engine keys off it (D-09 vs D-10).
    """
    n = len(close)
    events: List[LevelEvent] = []

    for p in pivots:
        for j in range(p.idx + 1, n):
            if p.kind == PivotType.HIGH:
                if close[j] > p.price:                       # body close above
                    events.append(LevelEvent(p.idx, p.price, p.kind, EventType.BOS, j))
                    break
                if high[j] > p.price and close[j] < p.price:  # wick above, close inside
                    events.append(LevelEvent(p.idx, p.price, p.kind, EventType.SWEEP, j))
                    break
            else:
                if close[j] < p.price:
                    events.append(LevelEvent(p.idx, p.price, p.kind, EventType.BOS, j))
                    break
                if low[j] < p.price and close[j] > p.price:
                    events.append(LevelEvent(p.idx, p.price, p.kind, EventType.SWEEP, j))
                    break
    return events


# --------------------------------------------------------------------------
# D-14 : is a break of an internal low/high actually tradable?
# --------------------------------------------------------------------------
def is_valid_shift(pivots: List[Pivot], events: List[LevelEvent], direction: str) -> bool:
    """
    The transcript's internal-structure filter.

    A bearish shift is ONLY valid if a HIGHER HIGH was printed first and then
    the structural low broke with a body close (HH -> LL). If the preceding
    high failed to exceed the prior high, the down-move is merely a corrective
    leg inside the uptrend and must not be sold:

        "they will treat this break as a place to sell from... But it's not,
         because this in itself is still not a valid structural move."

    direction: "bearish" (expect HH then break of low) or "bullish" (LL then
    break of high).
    """
    if direction == "bearish":
        want_break = PivotType.LOW
        highs = [p for p in pivots if p.kind == PivotType.HIGH]
        if len(highs) < 2:
            return False
        hh_printed = highs[-1].price > highs[-2].price
        if not hh_printed:
            return False
        last_low = next((p for p in reversed(pivots) if p.kind == PivotType.LOW), None)
        if last_low is None:
            return False
        for e in events:
            if e.level_idx == last_low.idx and e.kind == want_break and e.event == EventType.BOS:
                return True
        return False

    if direction == "bullish":
        want_break = PivotType.HIGH
        lows = [p for p in pivots if p.kind == PivotType.LOW]
        if len(lows) < 2:
            return False
        ll_printed = lows[-1].price < lows[-2].price
        if not ll_printed:
            return False
        last_high = next((p for p in reversed(pivots) if p.kind == PivotType.HIGH), None)
        if last_high is None:
            return False
        for e in events:
            if e.level_idx == last_high.idx and e.kind == want_break and e.event == EventType.BOS:
                return True
        return False

    return False


# --------------------------------------------------------------------------
# One-shot snapshot used by the EA and by the tests
# --------------------------------------------------------------------------
def analyse(open_, high, low, close, k: int = 2, consolidation_bars: int = 20,
            swing_mode: str = "zigzag", min_swing_atr: float = 4.0) -> StructureSnapshot:
    # NOTE: raw pivots (no alternation) - see alternation() docstring.
    if swing_mode == "zigzag":
        atr = atr_sma(high, low, close, 14)
        pivots = find_pivots_zigzag(high, low, atr, min_swing_atr)
    else:
        pivots = find_pivots(high, low, k)
    classify_labels(pivots)
    events = classify_events(open_, high, low, close, pivots)
    since = bars_since_new_extreme(pivots, len(close))
    return StructureSnapshot(
        trend=classify_trend(pivots),
        pivots=pivots,
        events=events,
        consolidating=since >= consolidation_bars,
        bars_since_extreme=since,
    )
