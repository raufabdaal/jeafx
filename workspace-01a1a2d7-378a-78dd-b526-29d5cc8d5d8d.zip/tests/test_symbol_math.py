"""
SPEC-001 §8.6 — Python parity harness for the symbol/risk arithmetic.

MQL5 cannot be compiled in this environment, so the *arithmetic* of
SPA_Symbol.mqh is mirrored here and exercised against representative broker
tick specifications. If a lot size or a spread gate disagrees between this
file and the EA, the EA is wrong.

Mirrored functions:  pip derivation, MoneyPerLotPerPrice, LotsForRisk,
FitToFreeMargin (scaling only), dual spread ceiling, profile resolution.
"""
from __future__ import annotations

import csv
import math
import os
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(HERE, "..", "data", "symbol_profiles.csv")


# --------------------------------------------------------------------------
# Broker tick specs (representative 5-digit ECN / typical gold & crypto)
# --------------------------------------------------------------------------
class Spec:
    def __init__(self, name, digits, point, tick_size, tick_value,
                 vol_min, vol_max, vol_step, stops_pts=0.0, freeze_pts=0.0):
        self.name = name
        self.digits = digits
        self.point = point
        self.tick_size = tick_size
        self.tick_value = tick_value
        self.vol_min = vol_min
        self.vol_max = vol_max
        self.vol_step = vol_step
        self.stops_pts = stops_pts
        self.freeze_pts = freeze_pts


SPECS = {
    "EURUSD": Spec("EURUSD", 5, 0.00001, 0.00001, 1.0, 0.01, 100.0, 0.01),
    "USDJPY": Spec("USDJPY", 3, 0.001, 0.001, 0.68, 0.01, 100.0, 0.01),
    "XAUUSD": Spec("XAUUSD", 2, 0.01, 0.01, 1.0, 0.01, 50.0, 0.01),
    "BTCUSD": Spec("BTCUSD", 2, 0.01, 0.01, 0.01, 0.01, 10.0, 0.01),
    "EURUSD4": Spec("EURUSD", 4, 0.0001, 0.0001, 10.0, 0.01, 100.0, 0.01),
}


# --------------------------------------------------------------------------
# Mirrors SPA_Symbol::Init  (pip derivation)
# --------------------------------------------------------------------------
def derive_pip(spec: Spec, profile_pip: float) -> float:
    if profile_pip > 0.0:
        return profile_pip
    if spec.digits in (3, 5):
        return 10.0 * spec.point
    return spec.point


# --------------------------------------------------------------------------
# Mirrors SPA_Symbol::MoneyPerLotPerPrice
# --------------------------------------------------------------------------
def money_per_lot_per_price(spec: Spec, price_distance: float) -> float:
    if spec.tick_size <= 0.0:
        return 0.0
    return (price_distance / spec.tick_size) * spec.tick_value


# --------------------------------------------------------------------------
# Mirrors SPA_Symbol::LotsForRisk
# --------------------------------------------------------------------------
def lots_for_risk(spec: Spec, risk_money: float, sl_distance: float) -> float:
    if sl_distance <= 0.0 or risk_money <= 0.0:
        return 0.0
    per_lot = money_per_lot_per_price(spec, sl_distance)
    if per_lot <= 0.0:
        return 0.0
    raw = risk_money / per_lot
    steps = math.floor(raw / spec.vol_step + 1e-9)
    vol = steps * spec.vol_step
    if vol < spec.vol_min:
        min_risk = money_per_lot_per_price(spec, sl_distance) * spec.vol_min
        if min_risk > risk_money * 1.001:
            return 0.0
        vol = spec.vol_min
    if vol > spec.vol_max:
        vol = spec.vol_max
    return round(vol, 8)


# --------------------------------------------------------------------------
# Mirrors SPA_Symbol::SpreadOKCoarse  (R-10a, pip ceiling)
# --------------------------------------------------------------------------
def spread_ok_coarse(spread_price, pip, cap_pips):
    if cap_pips <= 0.0:
        return True, ""
    if spread_price > cap_pips * pip:
        return False, "REJ_SPREAD_PIPS"
    return True, ""


# --------------------------------------------------------------------------
# Mirrors SPA_Symbol::SpreadOKAtRisk  (R-10b, fraction of SL distance)
# --------------------------------------------------------------------------
def spread_ok_at_risk(spread_price, sl_distance, max_frac):
    if sl_distance <= 0.0:
        return False, "REJ_NO_SL"
    if max_frac <= 0.0:
        return True, ""
    if spread_price > max_frac * sl_distance:
        return False, "REJ_SPREAD_OF_RISK"
    return True, ""


# --------------------------------------------------------------------------
# Representative live-market conditions per enabled profile row.
# pip_eff, normal_spread(price), typical_sl(price), spike_multiple
# --------------------------------------------------------------------------
MARKET = {
    "EURUSD*":  (0.0001, 0.00008, 0.0020, 4.0),
    "GBPUSD*":  (0.0001, 0.00012, 0.0020, 3.5),
    "AUDUSD*":  (0.0001, 0.00012, 0.0020, 3.5),
    "NZDUSD*":  (0.0001, 0.00015, 0.0020, 3.0),
    "USDCAD*":  (0.0001, 0.00012, 0.0020, 3.5),
    "USDCHF*":  (0.0001, 0.00012, 0.0020, 3.5),
    "USDJPY*":  (0.01,   0.010,   0.2500, 3.5),
    "EURJPY*":  (0.01,   0.015,   0.2500, 3.0),
    "GBPJPY*":  (0.01,   0.018,   0.2500, 3.0),
    "EURGBP*":  (0.0001, 0.00015, 0.0020, 3.0),
    "XAUUSD*":  (0.1,    0.25,    3.00,   3.0),
}


# --------------------------------------------------------------------------
# Mirrors CSpaProfiles::Specificity / Resolve
# --------------------------------------------------------------------------
def specificity(pattern: str, symbol: str) -> int:
    p, s = pattern.upper(), symbol.upper()
    if p == "*":
        return 1
    if p.endswith("*"):
        return 2 if s.startswith(p[:-1]) else 0
    return 3 if p == s else 0


def load_profiles():
    rows = []
    with open(CSV_PATH, newline="", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("symbol_pattern"):
                continue
            rows.append(next(csv.reader([line])))
    return rows


def resolve(symbol: str):
    best, best_score = None, 0
    for r in load_profiles():
        sc = specificity(r[0], symbol)
        if sc > best_score:
            best, best_score = r, sc
    return best


# --------------------------------------------------------------------------
# Tests
# --------------------------------------------------------------------------
class TestPipDerivation(unittest.TestCase):
    def test_fractional_pip_fx(self):
        self.assertAlmostEqual(derive_pip(SPECS["EURUSD"], 0.0), 0.0001, places=10)
        self.assertAlmostEqual(derive_pip(SPECS["USDJPY"], 0.0), 0.01, places=10)

    def test_legacy_4_digit_fx(self):
        self.assertAlmostEqual(derive_pip(SPECS["EURUSD4"], 0.0), 0.0001, places=10)

    def test_explicit_wins_for_gold_and_crypto(self):
        # A 2-digit XAU feed would auto-derive pip=0.01 -> 100x error in every
        # pip-denominated threshold. The explicit profile value prevents it.
        self.assertAlmostEqual(derive_pip(SPECS["XAUUSD"], 0.1), 0.1, places=10)
        self.assertNotAlmostEqual(derive_pip(SPECS["XAUUSD"], 0.0), 0.1, places=10)


class TestLotSizing(unittest.TestCase):
    def test_eurusd_075pct_20pip(self):
        # $10,000 * 0.75% = $75 risk; SL 20 pips = 0.0020 price
        vol = lots_for_risk(SPECS["EURUSD"], 75.0, 0.0020)
        self.assertAlmostEqual(vol, 0.37, places=8)          # 0.375 floored to step
        realised = money_per_lot_per_price(SPECS["EURUSD"], 0.0020) * vol
        self.assertLessEqual(realised, 75.0 + 1e-9)          # never exceeds budget

    def test_xauusd_3dollar_stop(self):
        # $10,000 * 0.5% = $50 risk; SL $3.00 -> $300/lot
        vol = lots_for_risk(SPECS["XAUUSD"], 50.0, 3.00)
        self.assertAlmostEqual(vol, 0.16, places=8)
        self.assertLessEqual(money_per_lot_per_price(SPECS["XAUUSD"], 3.00) * vol, 50.0 + 1e-9)

    def test_usdjpy_tick_value_is_not_one(self):
        # JPY pairs settle in JPY: 1 lot per 0.001 move is ~0.68 USD, not 1.00.
        # A naive "10 USD per pip" assumption oversizes by ~47%.
        vol = lots_for_risk(SPECS["USDJPY"], 75.0, 0.20)   # 20 pips = 0.20
        per_lot = money_per_lot_per_price(SPECS["USDJPY"], 0.20)
        self.assertAlmostEqual(per_lot, 136.0, places=6)
        self.assertAlmostEqual(vol, 0.55, places=8)

    def test_min_lot_rejection_small_account(self):
        # $500 account, 1% = $5 risk, SL 40 pips. Min lot 0.01 risks $4 -> fits.
        self.assertGreater(lots_for_risk(SPECS["EURUSD"], 5.0, 0.0040), 0.0)
        # Same account, SL 100 pips: min lot risks $10 > $5 budget -> REJECT.
        self.assertEqual(lots_for_risk(SPECS["EURUSD"], 5.0, 0.0100), 0.0)

    def test_zero_and_negative_guards(self):
        self.assertEqual(lots_for_risk(SPECS["EURUSD"], 0.0, 0.0020), 0.0)
        self.assertEqual(lots_for_risk(SPECS["EURUSD"], 75.0, 0.0), 0.0)
        self.assertEqual(lots_for_risk(SPECS["EURUSD"], 75.0, -0.0020), 0.0)

    def test_cap_at_volume_max(self):
        vol = lots_for_risk(SPECS["EURUSD"], 10_000_000.0, 0.0005)
        self.assertEqual(vol, SPECS["EURUSD"].vol_max)

    def test_btc_small_tick_value(self):
        # 1 BTC, tick 0.01 -> $0.01 per tick. SL $500.
        per_lot = money_per_lot_per_price(SPECS["BTCUSD"], 500.0)
        self.assertAlmostEqual(per_lot, 500.0, places=6)
        self.assertAlmostEqual(lots_for_risk(SPECS["BTCUSD"], 50.0, 500.0), 0.10, places=8)


class TestSpreadGate(unittest.TestCase):
    def test_eurusd_normal_spread_passes_coarse(self):
        ok, why = spread_ok_coarse(0.000008 + 0.00007, 0.0001, 1.5)
        self.assertTrue(ok, why)

    def test_eurusd_news_spike_fails_coarse(self):
        ok, why = spread_ok_coarse(0.00025, 0.0001, 1.5)
        self.assertFalse(ok)
        self.assertEqual(why, "REJ_SPREAD_PIPS")

    def test_cost_of_risk_is_the_meaningful_gate(self):
        # 1.5-pip spread vs a 20-pip stop = 7.5% of risk -> acceptable.
        ok, _ = spread_ok_at_risk(0.00015, 0.0020, 0.15)
        self.assertTrue(ok)
        # Same spread vs a 6-pip stop = 25% of risk -> rejected.
        ok, why = spread_ok_at_risk(0.00015, 0.0006, 0.15)
        self.assertFalse(ok)
        self.assertEqual(why, "REJ_SPREAD_OF_RISK")

    def test_zero_sl_is_a_hard_reject(self):
        ok, why = spread_ok_at_risk(0.0001, 0.0, 0.15)
        self.assertFalse(ok)
        self.assertEqual(why, "REJ_NO_SL")


class TestEnabledProfilesSurviveNormalMarket(unittest.TestCase):
    """Regression: every symbol we ship enabled must clear both gates under
    realistic broker conditions. This is the test that would have caught the
    ATR-ratio defect (see debug_log D-002) before it reached MetaEditor."""

    def test_all_enabled_rows_pass_normal_conditions(self):
        checked = 0
        for r in load_profiles():
            if r[17] != "1":
                continue
            self.assertIn(r[0], MARKET, f"no market spec for enabled row {r[0]}")
            pip, spread, sl, _ = MARKET[r[0]]
            ok, why = spread_ok_coarse(spread, pip, float(r[7]))
            self.assertTrue(ok, f"{r[0]} coarse: {why}")
            ok, why = spread_ok_at_risk(spread, sl, float(r[8]))
            self.assertTrue(ok, f"{r[0]} at-risk: {why}")
            checked += 1
        self.assertGreaterEqual(checked, 10)

    def test_all_enabled_rows_reject_news_spikes(self):
        # A 10x spread blow-out (NFP / CPI / rate decision) must be rejected on
        # every symbol. Note that a 3.5x spike on USDJPY is *legitimately*
        # acceptable (3.5 pips against a 25-pip stop = 14% of risk), which is
        # exactly why a blanket multiplier is the wrong test - and why the gate
        # is expressed as a fraction of risk rather than a multiple of spread.
        for r in load_profiles():
            if r[17] != "1":
                continue
            pip, spread, sl, _ = MARKET[r[0]]
            ok, why = spread_ok_at_risk(spread * 10.0, sl, float(r[8]))
            self.assertFalse(ok, f"{r[0]} accepted a 10x spread spike")
            self.assertEqual(why, "REJ_SPREAD_OF_RISK")


class TestProfileFile(unittest.TestCase):
    def test_every_row_has_18_columns(self):
        rows = load_profiles()
        self.assertGreater(len(rows), 10)
        for r in rows:
            self.assertEqual(len(r), 18, f"{r[0]} has {len(r)} columns")

    def test_resolution_specificity(self):
        self.assertEqual(resolve("EURUSD")[0], "EURUSD*")
        self.assertEqual(resolve("EURUSD.pro")[0], "EURUSD*")   # suffix broker naming
        self.assertEqual(resolve("USDJPY")[0], "USDJPY*")
        self.assertEqual(resolve("XAUUSD")[0], "XAUUSD*")
        self.assertEqual(resolve("SOMEUNKNOWN")[0], "*")        # falls to safe default

    def test_default_row_is_disabled(self):
        self.assertEqual(resolve("SOMEUNKNOWN")[17], "0")

    def test_risk_pct_within_rule_book_bounds(self):
        # R-01: 0.5% - 1.0% per trade. The csv may never exceed this.
        for r in load_profiles():
            if r[17] == "1":
                self.assertLessEqual(float(r[6]), 1.0, r[0])
                self.assertGreaterEqual(float(r[6]), 0.10, r[0])

    def test_min_rr_never_below_rule_book_in_3(self):
        for r in load_profiles():
            self.assertGreaterEqual(float(r[14]), 3.0, r[0])


if __name__ == "__main__":
    unittest.main(verbosity=2)
