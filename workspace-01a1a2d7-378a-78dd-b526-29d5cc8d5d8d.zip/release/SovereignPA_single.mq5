//+------------------------------------------------------------------+
//|  GENERATED FILE — DO NOT EDIT BY HAND                            |
//|  Built by tools/build_single_file.py                             |
//|  Source  : experts/SovereignPA/SovereignPA.mq5
//|  Modules : 5
//|                                                                   |
//|  Edit the modular sources in experts/SovereignPA/ and re-run the  |
//|  build. Hand-edits to this file are lost on the next build.       |
//+------------------------------------------------------------------+

//==========================================================================
//  BEGIN MODULE: experts/SovereignPA/SovereignPA.mq5
//==========================================================================
//+------------------------------------------------------------------+
//|                                                  SovereignPA.mq5 |
//|      Sovereign Price-Action EA - main Expert Advisor              |
//|      SPEC-001 v0.4.0                                              |
//|                                                                   |
//|  v0.5.0 SCOPE - SIGNIFICANT STRUCTURE. Still places NO orders.    |
//|                                                                   |
//|  The EA now reads the market: swing highs/lows, HH/HL vs LL/LH    |
//|  trend, body-close breaks vs wick sweeps, and the D-14 filter     |
//|  that rejects breaks occurring inside a corrective leg.           |
//|                                                                   |
//|  Every swing it detects is DRAWN ON THE CHART. That is the point: |
//|  you must be able to look at the chart and agree with what the    |
//|  EA sees before any of it is allowed to drive an order.          |
//+------------------------------------------------------------------+
#property copyright   "ApexQuant-Engine"
#property description "Sovereign Price-Action EA - v0.4.3 structure engine (no trading)"
//--- NOTE on #property version:
//--- MetaEditor validates it against the MQL5 Market format "xxx.yyy" (three
//--- digits, dot, three digits). Our semantic version "0.4.0" is one digit
//--- before the dot, so it raises a Market-compatibility warning. The property
//--- is OPTIONAL metadata with no effect on the compiled EA, so it is omitted
//--- rather than distorted into a Market-shaped value. The authoritative
//--- version lives in SPA_VERSION below and is shown on the chart panel.
//--- For Market publication, add:  #property version "001.000"

//--- INCLUDE ORDER IS A DEPENDENCY ORDER, NOT A STYLE CHOICE.
//--- SPA_Zones.mqh takes CSpaStructure& parameters, so Structure MUST be
//--- declared first. Getting this wrong produces ~58 cascading errors that
//--- all read "declaration without type" on the same few lines.

//==========================================================================
//  BEGIN MODULE: experts/SovereignPA/Include/SPA_Config.mqh
//==========================================================================
//+------------------------------------------------------------------+
//|                                                   SPA_Config.mqh |
//|      Sovereign Price-Action EA — symbol profiles & configuration  |
//|      SPEC-001 v0.2.0  §7.3                                        |
//|                                                                   |
//|  Loads data/symbol_profiles.csv and resolves the most specific    |
//|  profile for the chart symbol (exact > prefix wildcard > "*").    |
//+------------------------------------------------------------------+
#define __SPA_CONFIG_MQH__

//--- entry arithmetic mode (Decision Q4) -----------------------------
enum ENUM_SPA_ENTRY_MODE
  {
   SPA_ENTRY_BOUNDARY = 0,   // JeaFX-faithful: proximal zone edge
   SPA_ENTRY_MIDPOINT = 1    // 50% refinement (Rule Book 4.3)
  };

//--- liquidity window mode (Decision Q3) -----------------------------
enum ENUM_SPA_WINDOW_MODE
  {
   SPA_WINDOW_DYNAMIC = 0,   // empirical hour-of-day volume percentile (default)
   SPA_WINDOW_FIXED   = 1,   // Rule Book 4.1 GMT windows — A/B testing only
   SPA_WINDOW_OFF     = 2    // no window filter — diagnostic only, never live
  };

//+------------------------------------------------------------------+
//| One row of the profile table.                                     |
//| Every field is overrideable from the EA Inputs tab at run time.    |
//+------------------------------------------------------------------+
struct SpaProfile
  {
   string               pattern;
   string               asset_class;
   double               pip_size;            // 0 = auto-derive
   ENUM_TIMEFRAMES      tf_bias;
   ENUM_TIMEFRAMES      tf_confirm;
   ENUM_TIMEFRAMES      tf_exec;
   double               risk_pct;            // R-01
   double               spread_pips_ceiling; // R-10a (coarse, pip-denominated)
   double               max_spread_of_risk;  // R-10b (spread as fraction of SL distance)
   double               min_atr_floor_atr;   // dead-market guard
   double               liquidity_pct_min;   // §7.2 window strength
   int                  swing_k;             // D-08
   double               sl_spread_mult;      // R-04
   double               sl_buffer_atr;       // R-04 floor
   double               min_rr;              // R-06
   double               max_zone_width_atr;  // §4.2
   ENUM_SPA_ENTRY_MODE  entry_mode;
   bool                 enabled;
  };

//+------------------------------------------------------------------+
//| Hard-coded safety defaults. Used ONLY if a profile cannot load.   |
//| Deliberately conservative: disabled + minimum risk.               |
//+------------------------------------------------------------------+
void SpaProfileDefaults(SpaProfile &p)
  {
   p.pattern             = "*";
   p.asset_class         = "DEFAULT";
   p.pip_size            = 0.0;
   p.tf_bias             = PERIOD_H4;
   p.tf_confirm          = PERIOD_M15;
   p.tf_exec             = PERIOD_M5;
   p.risk_pct            = 0.25;
   p.spread_pips_ceiling = 3.0;
   p.max_spread_of_risk  = 0.20;
   p.min_atr_floor_atr   = 0.65;
   p.liquidity_pct_min   = 50.0;
   p.swing_k             = 2;
   p.sl_spread_mult      = 2.0;
   p.sl_buffer_atr       = 0.15;
   p.min_rr              = 3.5;
   p.max_zone_width_atr  = 1.5;
   p.entry_mode          = SPA_ENTRY_BOUNDARY;
   p.enabled             = false;   // fail closed
  }

//+------------------------------------------------------------------+
//| Profile table                                                     |
//+------------------------------------------------------------------+
class CSpaProfiles
  {
private:
   SpaProfile        m_rows[];
   int               m_count;
   string            m_last_error;

   //--- timeframe string -> enum (MQL5 has no StringToEnum) --------
   ENUM_TIMEFRAMES   ParseTF(const string s)
     {
      string u = s;
      StringToUpper(u);
      if(u=="PERIOD_M1")  return(PERIOD_M1);
      if(u=="PERIOD_M5")  return(PERIOD_M5);
      if(u=="PERIOD_M15") return(PERIOD_M15);
      if(u=="PERIOD_M30") return(PERIOD_M30);
      if(u=="PERIOD_H1")  return(PERIOD_H1);
      if(u=="PERIOD_H4")  return(PERIOD_H4);
      if(u=="PERIOD_D1")  return(PERIOD_D1);
      if(u=="PERIOD_W1")  return(PERIOD_W1);
      return(PERIOD_CURRENT);
     }

   bool              ParseBool(const string s)
     {
      return(s=="1" || s=="true" || s=="TRUE" || s=="yes");
     }

   double            ParseD(const string s)
     {
      return(StringToDouble(s));
     }

   //--- wildcard match: "EURUSD*" -> prefix ; "*" -> all -----------
   bool              Match(const string pattern,const string symbol)
     {
      string p = pattern;
      string s = symbol;
      StringToUpper(p);
      StringToUpper(s);
      int len = StringLen(p);
      if(len==0)
         return(false);
      if(p=="*")
         return(true);
      if(StringGetCharacter(p,len-1)=='*')
        {
         string head = StringSubstr(p,0,len-1);
         return(StringFind(s,head)==0);
        }
      return(p==s);
     }

   //--- specificity score: exact 3, prefix 2, "*" 1, none 0 --------
   int               Specificity(const string pattern,const string symbol)
     {
      if(!Match(pattern,symbol))
         return(0);
      if(pattern=="*")
         return(1);
      if(StringGetCharacter(pattern,StringLen(pattern)-1)=='*')
         return(2);
      return(3);
     }

public:
                     CSpaProfiles(): m_count(0), m_last_error("") {}
   string            LastError() const { return(m_last_error); }
   int               Count()     const { return(m_count); }

   //--- Load CSV. Tries shared folder first, then terminal folder. --
   bool              Load(const string filename="symbol_profiles.csv")
     {
      m_count = 0;
      ArrayResize(m_rows,0);
      m_last_error = "";

      int h = FileOpen(filename,FILE_READ|FILE_TXT|FILE_ANSI|FILE_COMMON);
      if(h==INVALID_HANDLE)
         h = FileOpen(filename,FILE_READ|FILE_TXT|FILE_ANSI);
      if(h==INVALID_HANDLE)
        {
         int err = GetLastError();
         m_last_error = StringFormat("cannot open '%s' (err %d) - place the file in "
                                     "MQL5/Files (or Common\\Files)",filename,err);
         return(false);
        }

      int    line_no = 0;
      string line    = "";

      while(!FileIsEnding(h))
        {
         line = FileReadString(h);
         line_no++;
         StringTrimLeft(line);
         StringTrimRight(line);

         //--- skip blanks, comments, header -------------------------
         if(StringLen(line)<10)
            continue;
         if(StringGetCharacter(line,0)=='#')
            continue;
         if(StringFind(line,"symbol_pattern")>=0)
            continue;

         string parts[];
         int n = StringSplit(line,',',parts);
         if(n<18)
           {
            m_last_error = StringFormat("line %d: expected 18 columns, got %d",line_no,n);
            continue;
           }
         for(int i=0;i<n;i++)
           {
            StringTrimLeft(parts[i]);
            StringTrimRight(parts[i]);
           }

         SpaProfile p;
         SpaProfileDefaults(p);
         p.pattern             = parts[0];
         p.asset_class         = parts[1];
         p.pip_size            = ParseD(parts[2]);
         p.tf_bias             = ParseTF(parts[3]);
         p.tf_confirm          = ParseTF(parts[4]);
         p.tf_exec             = ParseTF(parts[5]);
         p.risk_pct            = ParseD(parts[6]);
         p.spread_pips_ceiling = ParseD(parts[7]);
         p.max_spread_of_risk  = ParseD(parts[8]);
         p.min_atr_floor_atr   = ParseD(parts[9]);
         p.liquidity_pct_min   = ParseD(parts[10]);
         p.swing_k             = (int)ParseD(parts[11]);
         p.sl_spread_mult      = ParseD(parts[12]);
         p.sl_buffer_atr       = ParseD(parts[13]);
         p.min_rr              = ParseD(parts[14]);
         p.max_zone_width_atr  = ParseD(parts[15]);
         StringToUpper(parts[16]);
         p.entry_mode          = (parts[16]=="MIDPOINT") ? SPA_ENTRY_MIDPOINT : SPA_ENTRY_BOUNDARY;
         p.enabled             = ParseBool(parts[17]);

         ArrayResize(m_rows,m_count+1);
         m_rows[m_count] = p;
         m_count++;
        }
      FileClose(h);

      if(m_count==0)
        {
         m_last_error = "profile file contained no valid rows";
         return(false);
        }
      return(true);
     }

   //--- Resolve most specific profile for a symbol ----------------
   bool              Resolve(const string symbol,SpaProfile &out)
     {
      int best_score = 0;
      int best_idx   = -1;
      for(int i=0;i<m_count;i++)
        {
         int sc = Specificity(m_rows[i].pattern,symbol);
         if(sc>best_score)
           {
            best_score = sc;
            best_idx   = i;
           }
        }
      if(best_idx<0)
         return(false);
      out = m_rows[best_idx];
      return(true);
     }

   //--- diagnostics ------------------------------------------------
   bool              Get(int i,SpaProfile &out)
     {
      if(i<0||i>=m_count)
         return(false);
      out = m_rows[i];
      return(true);
     }
  };

//+------------------------------------------------------------------+

//  END MODULE: experts/SovereignPA/Include/SPA_Config.mqh


//==========================================================================
//  BEGIN MODULE: experts/SovereignPA/Include/SPA_Symbol.mqh
//==========================================================================
//+------------------------------------------------------------------+
//|                                                   SPA_Symbol.mqh |
//|   Sovereign Price-Action EA — multi-asset symbol abstraction      |
//|   SPEC-001 v0.2.0  §3.1 (cross-asset normalisation) / §7.3 / R-01..R-04 |
//|                                                                   |
//|   PURPOSE                                                         |
//|   Every downstream module talks to the market through this class  |
//|   ONLY. No other file may touch SymbolInfo*, point, digits, or    |
//|   tick value directly. That single choke-point is what makes one  |
//|   parameter set behave identically on EURUSD, XAUUSD, USDJPY and  |
//|   BTCUSD, and it is where all lot-sizing risk arithmetic lives.   |
//+------------------------------------------------------------------+
#define __SPA_SYMBOL_MQH__


//+------------------------------------------------------------------+
class CSpaSymbol
  {
private:
   string            m_symbol;
   SpaProfile        m_prof;
   bool              m_ready;

   int               m_digits;
   double            m_point;
   double            m_tick_size;
   double            m_tick_value;
   double            m_contract;
   double            m_vol_min;
   double            m_vol_max;
   double            m_vol_step;
   double            m_stops_pts;      // SYMBOL_TRADE_STOPS_LEVEL, in points
   double            m_freeze_pts;     // SYMBOL_TRADE_FREEZE_LEVEL, in points
   long              m_fill_flags;
   double            m_pip;
   string            m_last_error;

public:
                     CSpaSymbol(): m_symbol(""), m_ready(false), m_digits(0), m_point(0.0),
                                   m_tick_size(0.0), m_tick_value(0.0), m_contract(0.0),
                                   m_vol_min(0.0), m_vol_max(0.0), m_vol_step(0.0),
                                   m_stops_pts(0.0), m_freeze_pts(0.0),
                                   m_fill_flags(0), m_pip(0.0), m_last_error("") {}

   //----------------------------------------------------------------+
   //| Init — reads everything the EA will ever need about the symbol |
   //----------------------------------------------------------------+
   bool              Init(const string symbol,const SpaProfile &prof)
     {
      m_symbol  = symbol;
      m_prof    = prof;
      m_ready   = false;
      m_last_error = "";

      if(!SymbolSelect(symbol,true))
        {
         m_last_error = "SymbolSelect failed (symbol not in Market Watch)";
         return(false);
        }

      m_digits     = (int)SymbolInfoInteger(symbol,SYMBOL_DIGITS);
      m_point      = SymbolInfoDouble(symbol,SYMBOL_POINT);
      m_tick_size  = SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_SIZE);
      m_tick_value = SymbolInfoDouble(symbol,SYMBOL_TRADE_TICK_VALUE);
      m_contract   = SymbolInfoDouble(symbol,SYMBOL_TRADE_CONTRACT_SIZE);
      m_vol_min    = SymbolInfoDouble(symbol,SYMBOL_VOLUME_MIN);
      m_vol_max    = SymbolInfoDouble(symbol,SYMBOL_VOLUME_MAX);
      m_vol_step   = SymbolInfoDouble(symbol,SYMBOL_VOLUME_STEP);
      m_stops_pts  = (double)SymbolInfoInteger(symbol,SYMBOL_TRADE_STOPS_LEVEL);
      m_freeze_pts = (double)SymbolInfoInteger(symbol,SYMBOL_TRADE_FREEZE_LEVEL);
      m_fill_flags = (long)SymbolInfoInteger(symbol,SYMBOL_FILLING_MODE);

      //--- structural sanity: refuse to trade on a symbol we do not
      //--- fully understand. Silent defaults here cause lot-size bugs
      //--- that only surface as account damage. -------------------
      if(m_point<=0.0)     { m_last_error="SYMBOL_POINT is zero";     return(false); }
      if(m_tick_size<=0.0) { m_last_error="SYMBOL_TRADE_TICK_SIZE<=0"; return(false); }
      if(m_tick_value<=0.0){ m_last_error="SYMBOL_TRADE_TICK_VALUE<=0"; return(false); }
      if(m_vol_step<=0.0)  { m_last_error="SYMBOL_VOLUME_STEP<=0";     return(false); }
      if(m_vol_min<=0.0)   { m_last_error="SYMBOL_VOLUME_MIN<=0";      return(false); }

      //--- pip definition ----------------------------------------
      //--- 0 in the profile = auto.                                    |
      //--- FX fractional-pip brokers (5 or 3 digits): pip = 10 points.  |
      //--- Legacy FX (4 or 2 digits):                 pip = 1 point.    |
      //--- Gold/BTC/indices MUST specify explicitly (see csv) because   |
      //--- a 2-digit XAU feed would otherwise be read as "pip = 0.01".  |
      if(prof.pip_size>0.0)
         m_pip = prof.pip_size;
      else
        {
         if(m_digits==3 || m_digits==5)
            m_pip = 10.0*m_point;
         else
            m_pip = m_point;
        }

      m_ready = true;
      return(true);
     }

   //----------------------------------------------------------------+
   //| Accessors                                                      |
   //----------------------------------------------------------------+
   string            Symbol()      const { return(m_symbol); }
   SpaProfile        Profile()     const { return(m_prof); }
   bool              IsReady()     const { return(m_ready); }
   string            LastError()   const { return(m_last_error); }
   int               Digits()      const { return(m_digits); }
   double            Point()       const { return(m_point); }
   double            Pip()         const { return(m_pip); }
   double            TickSize()    const { return(m_tick_size); }
   double            TickValue()   const { return(m_tick_value); }
   double            VolMin()      const { return(m_vol_min); }
   double            VolMax()      const { return(m_vol_max); }
   double            VolStep()     const { return(m_vol_step); }
   ENUM_TIMEFRAMES   TfBias()      const { return(m_prof.tf_bias); }
   ENUM_TIMEFRAMES   TfConfirm()   const { return(m_prof.tf_confirm); }
   ENUM_TIMEFRAMES   TfExec()      const { return(m_prof.tf_exec); }
   ENUM_SPA_ENTRY_MODE EntryMode() const { return(m_prof.entry_mode); }

   double            NormalizePrice(const double price) const
     {
      return(NormalizeDouble(price,m_digits));
     }

   //--- minimum permitted distance for SL/TP, in price units ------
   double            MinStopDistance() const
     {
      return((m_stops_pts+m_freeze_pts)*m_point);
     }

   //----------------------------------------------------------------+
   //| Bid / Ask / Spread                                             |
   //----------------------------------------------------------------+
   double            Bid() const { return(SymbolInfoDouble(m_symbol,SYMBOL_BID)); }
   double            Ask() const { return(SymbolInfoDouble(m_symbol,SYMBOL_ASK)); }

   double            SpreadPrice() const
     {
      double ask = Ask();
      double bid = Bid();
      double sp  = ask-bid;
      if(sp<=0.0)   // tick not yet updated in tester
         sp = (double)SymbolInfoInteger(m_symbol,SYMBOL_SPREAD)*m_point;
      if(sp<0.0)
         sp = 0.0;
      return(sp);
     }

   double            SpreadPips() const
     {
      return(m_pip>0.0 ? SpreadPrice()/m_pip : 0.0);
     }

   //----------------------------------------------------------------+
   //| R-10a : COARSE spread gate (pre-filter, called every tick)      |
   //| Pure pip ceiling. Cheap, and catches news spikes / Asian close. |
   //| It is deliberately NOT an ATR ratio: spread/ATR differs by 10x  |
   //| between asset classes, so any single ratio rejects whole        |
   //| classes or passes everything. (See debug_log D-002.)            |
   //----------------------------------------------------------------+
   bool              SpreadOKCoarse(string &reason)
     {
      reason = "";
      double sp_price = SpreadPrice();
      double cap      = m_prof.spread_pips_ceiling*m_pip;

      if(cap<=0.0)
         return(true);          // 0 disables the coarse gate

      if(sp_price>cap)
        {
         reason = StringFormat("REJ_SPREAD_PIPS %.2f>%.2f",sp_price/m_pip,m_prof.spread_pips_ceiling);
         return(false);
        }
      return(true);
     }

   //----------------------------------------------------------------+
   //| R-10b : COST-OF-RISK spread gate (final gate, SL already known) |
   //|                                                                 |
   //|   spread_cost <= max_spread_of_risk * SL_distance               |
   //|                                                                 |
   //| This is the economically correct formulation: the spread only   |
   //| matters relative to what is being risked. 1.5 pips of spread    |
   //| against a 20-pip stop is 7.5% of risk (fine); against a 6-pip   |
   //| stop it is 25% (the edge is gone and the 3R target is fiction). |
   //| Symbol-agnostic, because both terms are in price units.         |
   //----------------------------------------------------------------+
   bool              SpreadOKAtRisk(const double sl_distance,string &reason)
     {
      reason = "";
      if(sl_distance<=0.0)
        {
         reason = "REJ_NO_SL";
         return(false);
        }

      double sp  = SpreadPrice();
      double max = m_prof.max_spread_of_risk*sl_distance;

      if(m_prof.max_spread_of_risk<=0.0)
         return(true);

      if(sp>max)
        {
         reason = StringFormat("REJ_SPREAD_OF_RISK %.1f%%>%.1f%% (spread %.5g / SL %.5g)",
                               (sp/sl_distance)*100.0,
                               m_prof.max_spread_of_risk*100.0,sp,sl_distance);
         return(false);
        }
      return(true);
     }

   //----------------------------------------------------------------+
   //| Money maths                                                    |
   //| value of a 1.0-lot position per 1.0 unit of price movement      |
   //----------------------------------------------------------------+
   double            MoneyPerLotPerPrice(const double price_distance) const
     {
      if(m_tick_size<=0.0)
         return(0.0);
      return((price_distance/m_tick_size)*m_tick_value);
     }

   //----------------------------------------------------------------+
   //| R-02 : dynamic lot sizing                                      |
   //|   Lots = risk_money / (SL_distance * money_per_lot_per_price)  |
   //| Rounded DOWN to volume step (never up: rounding up is an       |
   //| unrequested risk increase). Clamped to broker min/max.         |
   //| Returns 0.0 when the trade is not placeable — caller must      |
   //| treat 0.0 as a hard rejection, never as "use the minimum".     |
   //----------------------------------------------------------------+
   double            LotsForRisk(const double risk_money,const double sl_distance)
     {
      if(sl_distance<=0.0 || risk_money<=0.0)
         return(0.0);

      double per_lot = MoneyPerLotPerPrice(sl_distance);
      if(per_lot<=0.0)
         return(0.0);

      double raw = risk_money/per_lot;

      //--- floor to step (with a small epsilon so 0.2999999 -> 0.30) -
      double steps = MathFloor(raw/m_vol_step + 1e-9);
      double vol   = steps*m_vol_step;

      if(vol<m_vol_min)
        {
         //--- the minimum lot would exceed the risk budget: reject.
         //--- We do NOT silently take the minimum lot. That is how a
         //--- 0.5% rule becomes a 4% loss on a small account.
         double min_risk = MoneyPerLotPerPrice(sl_distance)*m_vol_min;
         if(min_risk>risk_money*1.001)
            return(0.0);
         vol = m_vol_min;
        }
      if(vol>m_vol_max)
         vol = m_vol_max;

      vol = NormalizeDouble(vol,8);
      return(vol);
     }

   //----------------------------------------------------------------+
   //| Free-margin guard: shrink volume until it fits with a buffer.  |
   //| Prevents the "no money" OrderSend error on correlated baskets. |
   //----------------------------------------------------------------+
   double            FitToFreeMargin(const ENUM_ORDER_TYPE type,const double price,
                                     const double volume,const double buffer_pct=30.0)
     {
      if(volume<=0.0)
         return(0.0);

      double need  = 0.0;
      if(!OrderCalcMargin(type,m_symbol,volume,price,need))
         return(0.0);

      double free  = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
      double avail = free*(1.0-buffer_pct/100.0);
      if(need<=avail)
         return(volume);

      if(need<=0.0)
         return(0.0);

      double scaled = volume*(avail/need);
      double steps  = MathFloor(scaled/m_vol_step + 1e-9);
      double out    = steps*m_vol_step;
      if(out<m_vol_min)
         return(0.0);
      out = NormalizeDouble(out,8);
      return(out);
     }

   //----------------------------------------------------------------+
   //| Broker capability / permission gates                          |
   //----------------------------------------------------------------+
   bool              TradingPermitted(string &reason)
     {
      reason = "";
      if(!m_ready) { reason="SYMBOL_NOT_READY"; return(false); }

      ENUM_SYMBOL_TRADE_MODE mode =
         (ENUM_SYMBOL_TRADE_MODE)SymbolInfoInteger(m_symbol,SYMBOL_TRADE_MODE);
      if(mode==SYMBOL_TRADE_MODE_DISABLED || mode==SYMBOL_TRADE_MODE_CLOSEONLY)
        { reason="SYMBOL_DISABLED"; return(false); }

      //--- explicit ==0 comparisons: keeps the build free of implicit
      //--- long->bool conversion warnings on stricter compiler builds.
      if(TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)==0) { reason="TERMINAL_NOT_ALLOWED"; return(false); }
      if(MQLInfoInteger(MQL_TRADE_ALLOWED)==0)           { reason="EA_TRADE_NOT_ALLOWED";  return(false); }
      if(AccountInfoInteger(ACCOUNT_TRADE_ALLOWED)==0)   { reason="ACCOUNT_NOT_ALLOWED";   return(false); }
      if(AccountInfoInteger(ACCOUNT_TRADE_EXPERT)==0)    { reason="ACCOUNT_EXPERT_OFF";    return(false); }
      return(true);
     }

   //----------------------------------------------------------------+
   //| Filling mode: the #1 cause of silent OrderSend failures on MT5 |
   //----------------------------------------------------------------+
   ENUM_ORDER_TYPE_FILLING FillingMode()
     {
      //--- prefer IOC, then FOK, then RETURN (market/pending limits) -
      int flags = (int)m_fill_flags;
      if((flags & (int)SYMBOL_FILLING_IOC)!=0)
         return(ORDER_FILLING_IOC);
      if((flags & (int)SYMBOL_FILLING_FOK)!=0)
         return(ORDER_FILLING_FOK);
      return(ORDER_FILLING_RETURN);
     }

   //----------------------------------------------------------------+
   //| Diagnostics — one-line dump used at OnInit and in journals     |
   //----------------------------------------------------------------+
   string            Describe()
     {
      return(StringFormat("%s [%s] digits=%d point=%.8g pip=%.8g tick=%.8g/%.5g vol=%.2f..%.2f step=%.2f stops=%.0fpts fill=%d",
                          m_symbol,m_prof.asset_class,m_digits,m_point,m_pip,
                          m_tick_size,m_tick_value,m_vol_min,m_vol_max,m_vol_step,
                          m_stops_pts,(int)FillingMode()));
     }
  };

//+------------------------------------------------------------------+

//  END MODULE: experts/SovereignPA/Include/SPA_Symbol.mqh


//==========================================================================
//  BEGIN MODULE: experts/SovereignPA/Include/SPA_Structure.mqh
//==========================================================================
//+------------------------------------------------------------------+
//|                                                SPA_Structure.mqh |
//|   Sovereign Price-Action EA - market structure engine             |
//|   SPEC-001 v0.4.0  (D-08, D-09, D-10, D-14, RB 2.1)               |
//|                                                                   |
//|   WHAT THIS MODULE ANSWERS                                         |
//|     1. Where are the swing highs and lows?                         |
//|     2. Which way is the market actually going? (HH/HL vs LL/LH)    |
//|     3. Has a level been BROKEN (body close) or SWEPT (wick)?       |
//|     4. Is the current break a real shift, or noise inside a        |
//|        corrective leg?                                             |
//|     5. Is the market consolidating (no new extreme for N bars)?    |
//|                                                                   |
//|   VERIFICATION                                                     |
//|   The arithmetic in this file mirrors tests/spa_structure_ref.py   |
//|   one-for-one. 17 unit tests pass against hand-built price series. |
//|   Any divergence between these two files is a release blocker.     |
//|                                                                   |
//|   ARRAY CONVENTION                                                 |
//|   Data is copied CHRONOLOGICALLY: index 0 = oldest closed bar,     |
//|   index m_n-1 = most recent closed bar. This matches the Python    |
//|   reference exactly. The forming bar is excluded at copy time      |
//|   (start_pos = 1), which is what makes the engine non-repainting.  |
//+------------------------------------------------------------------+
#define __SPA_STRUCTURE_MQH__

//--- trend classification (RB 2.1)
enum ENUM_SPA_TREND
  {
   SPA_TREND_UP   = 0,   // higher highs AND higher lows
   SPA_TREND_DOWN = 1,   // lower highs AND lower lows
   SPA_TREND_RANGE= 2    // anything else - do not trade
  };

//--- how a level resolved (D-09 vs D-10)
enum ENUM_SPA_RESOLUTION
  {
   SPA_RES_NONE  = 0,    // level still untested
   SPA_RES_BOS   = 1,    // candle BODY closed beyond the level
   SPA_RES_SWEEP = 2     // wick pierced, closed back inside
  };

//+------------------------------------------------------------------+
struct SpaPivot
  {
   int      idx;          // chronological index of the pivot bar
   double   price;
   bool     is_high;
   string   label;        // H / L / HH / HL / LH / LL
   datetime time;
  };

//+------------------------------------------------------------------+
class CSpaStructure
  {
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;
   double            m_min_swing_atr;  // significance threshold (x ATR)
   int               m_atr_period;     // Wilder ATR period
   double            m_atr;            // ATR at the most recent closed bar
   int               m_bars;           // history depth requested
   int               m_consol_bars;    // consolidation threshold

//--- chronological price arrays (index 0 = oldest closed bar) -----
   double            m_h[];
   double            m_l[];
   double            m_o[];
   double            m_c[];
   datetime          m_t[];
   int               m_n;              // number of closed bars actually held

//--- results ------------------------------------------------------
   SpaPivot          m_pivots[];
   int               m_pivot_count;
   ENUM_SPA_TREND    m_trend;
   int               m_bars_since_extreme;
   bool              m_ready;
   datetime          m_last_bar_time;
   string            m_last_error;

   void              AddPivot(const int idx,const double price,const bool is_high)
     {
      ArrayResize(m_pivots,m_pivot_count+1);
      m_pivots[m_pivot_count].idx     = idx;
      m_pivots[m_pivot_count].price   = price;
      m_pivots[m_pivot_count].is_high = is_high;
      m_pivots[m_pivot_count].label   = is_high ? "H" : "L";
      m_pivots[m_pivot_count].time    = (idx>=0 && idx<m_n) ? m_t[idx] : 0;
      m_pivot_count++;
     }

   //----------------------------------------------------------------+
   //| Wilder ATR over the closed-bar series held in this object.    |
   //| Computed by hand rather than via iATR() so the structure      |
   //| engine has no indicator-handle dependency at all.             |
   //----------------------------------------------------------------+
   double            WilderATR()
     {
      if(m_n<m_atr_period+1)
         return(0.0);

      double atr = 0.0;
      for(int i=1;i<=m_atr_period;i++)
        {
         double tr = m_h[i]-m_l[i];
         double a  = MathAbs(m_h[i]-m_c[i-1]);
         double b  = MathAbs(m_l[i]-m_c[i-1]);
         if(a>tr) tr = a;
         if(b>tr) tr = b;
         atr += tr;
        }
      atr /= (double)m_atr_period;

      for(int i=m_atr_period+1;i<m_n;i++)
        {
         double tr = m_h[i]-m_l[i];
         double a  = MathAbs(m_h[i]-m_c[i-1]);
         double b  = MathAbs(m_l[i]-m_c[i-1]);
         if(a>tr) tr = a;
         if(b>tr) tr = b;
         atr = (atr*(double)(m_atr_period-1)+tr)/(double)m_atr_period;
        }
      return(atr);
     }

   //----------------------------------------------------------------+
   //| D-08b : significance-filtered swing detection (ATR-ZigZag).   |
   //|                                                               |
   //| A k=2 fractal fires on ANY local extremum - on M5 that was a  |
   //| pivot every ~4 bars, i.e. every minor wiggle, which is not    |
   //| market structure. This detector demands that price actually   |
   //| GO somewhere before the swing is recorded: a pivot is emitted |
   //| only once price has retraced at least                       |
   //|     m_min_swing_atr x ATR                                     |
   //| from the extreme.                                             |
   //|                                                               |
   //| NON-REPAINTING: the still-running extreme is never emitted;   |
   //| only the retrace that CONFIRMS a swing can create one.        |
   //|                                                               |
   //| Mirrored one-for-one in tests/spa_structure_ref.py            |
   //| (find_pivots_zigzag) and covered by 6 unit tests.             |
   //----------------------------------------------------------------+
   void              BuildPivotsZigZag()
     {
      if(m_n<3 || m_atr<=0.0 || m_min_swing_atr<=0.0)
         return;

      double th = m_min_swing_atr*m_atr;

      int    hi_i = 0,     lo_i = 0;
      double hi_p = m_h[0], lo_p = m_l[0];
      int    dir  = 0;                 // +1 up-leg, -1 down-leg, 0 undecided

      for(int i=1;i<m_n;i++)
        {
         if(dir==0)
           {
            if(m_h[i]>hi_p) { hi_i=i; hi_p=m_h[i]; }
            if(m_l[i]<lo_p) { lo_i=i; lo_p=m_l[i]; }
            if(hi_p-lo_p>=th)
              {
               //--- whichever extreme printed LAST defines the open leg
               if(hi_i>lo_i)
                 {
                  AddPivot(lo_i,lo_p,false);
                  dir=1;  hi_i=i; hi_p=m_h[i];
                 }
               else
                 {
                  AddPivot(hi_i,hi_p,true);
                  dir=-1; lo_i=i; lo_p=m_l[i];
                 }
              }
            continue;
           }

         if(dir==1)
           {
            if(m_h[i]>hi_p) { hi_i=i; hi_p=m_h[i]; }
            if(hi_p-m_l[i]>=th)
              {
               AddPivot(hi_i,hi_p,true);
               dir=-1; lo_i=i; lo_p=m_l[i];
              }
           }
         else
           {
            if(m_l[i]<lo_p) { lo_i=i; lo_p=m_l[i]; }
            if(m_h[i]-lo_p>=th)
              {
               AddPivot(lo_i,lo_p,false);
               dir=1;  hi_i=i; hi_p=m_h[i];
              }
           }
        }
     }

   //----------------------------------------------------------------+
   //| Trend from the last two highs and last two lows (RB 2.1).     |
   //| Deliberately uses RAW pivots - see the warning below.         |
   //----------------------------------------------------------------+
   ENUM_SPA_TREND    ComputeTrend()
     {
      int hi[2], lo[2];
      int hc = 0, lc = 0;

      for(int i=m_pivot_count-1;i>=0 && (hc<2 || lc<2);i--)
        {
         if(m_pivots[i].is_high)
           {
            if(hc<2) { hi[hc]=i; hc++; }
           }
         else
           {
            if(lc<2) { lo[lc]=i; lc++; }
           }
        }
      if(hc<2 || lc<2)
         return(SPA_TREND_RANGE);

      //--- hi[0] = most recent high, hi[1] = the one before it -----
      double h_new = m_pivots[hi[0]].price, h_old = m_pivots[hi[1]].price;
      double l_new = m_pivots[lo[0]].price, l_old = m_pivots[lo[1]].price;

      if(h_new>h_old && l_new>l_old) return(SPA_TREND_UP);
      if(h_new<h_old && l_new<l_old) return(SPA_TREND_DOWN);
      return(SPA_TREND_RANGE);
     }

   //----------------------------------------------------------------+
   //| Bars since the most recent pivot that set a NEW extreme.      |
   //| Input to the RB 2.1 consolidation suspension.                 |
   //----------------------------------------------------------------+
   int               ComputeBarsSinceExtreme()
     {
      int last_extreme = -1;
      double prev_high = 0.0, prev_low = 0.0;
      bool   have_high = false, have_low = false;

      for(int i=0;i<m_pivot_count;i++)
        {
         if(m_pivots[i].is_high)
           {
            if(have_high && m_pivots[i].price>prev_high)
               last_extreme = m_pivots[i].idx;
            prev_high = m_pivots[i].price;
            have_high = true;
           }
         else
           {
            if(have_low && m_pivots[i].price<prev_low)
               last_extreme = m_pivots[i].idx;
            prev_low = m_pivots[i].price;
            have_low = true;
           }
        }
      if(last_extreme<0)
         return(m_n);
      return((m_n-1)-last_extreme);
     }

public:
                     CSpaStructure(): m_symbol(""), m_tf(PERIOD_CURRENT), m_min_swing_atr(4.0),
                                      m_atr_period(14), m_atr(0.0), m_bars(600),
                                      m_consol_bars(20), m_n(0), m_pivot_count(0),
                                      m_trend(SPA_TREND_RANGE), m_bars_since_extreme(0),
                                      m_ready(false), m_last_bar_time(0), m_last_error("") {}

   //----------------------------------------------------------------+
   bool              Init(const string symbol,const ENUM_TIMEFRAMES tf,
                          const double min_swing_atr,const int bars,
                          const int consolidation_bars)
     {
      m_symbol        = symbol;
      m_tf            = tf;
      m_min_swing_atr = (min_swing_atr<0.5) ? 0.5 : min_swing_atr;
      m_bars          = (bars<100) ? 100 : bars;
      m_consol_bars   = consolidation_bars;
      m_ready         = false;
      m_last_bar_time = 0;
      return(true);
     }

   //----------------------------------------------------------------+
   //| Refresh - recompute from closed bars only.                    |
   //| Cached: recomputation happens at most once per new TF bar.    |
   //----------------------------------------------------------------+
   bool              Refresh()
     {
      datetime cur = iTime(m_symbol,m_tf,0);
      if(m_ready && cur==m_last_bar_time)
         return(true);            // nothing new to do

      m_last_error = "";

      //--- copy CHRONOLOGICAL data, starting at bar 1 (skip forming) -
      //--- as_series = false -> index 0 is the OLDEST bar ------------
      ArraySetAsSeries(m_h,false);
      ArraySetAsSeries(m_l,false);
      ArraySetAsSeries(m_o,false);
      ArraySetAsSeries(m_c,false);
      ArraySetAsSeries(m_t,false);

      int got = CopyHigh(m_symbol,m_tf,1,m_bars,m_h);
      if(got<=0)
        {
         m_last_error = StringFormat("CopyHigh failed (%s %s) err=%d",
                                     m_symbol,EnumToString(m_tf),GetLastError());
         m_ready = false;
         return(false);
        }
      m_n = got;

      if(CopyLow(m_symbol,m_tf,1,m_bars,m_l)!=m_n ||
         CopyOpen(m_symbol,m_tf,1,m_bars,m_o)!=m_n ||
         CopyClose(m_symbol,m_tf,1,m_bars,m_c)!=m_n ||
         CopyTime(m_symbol,m_tf,1,m_bars,m_t)!=m_n)
        {
         m_last_error = StringFormat("price series out of sync (%s %s)",
                                     m_symbol,EnumToString(m_tf));
         m_ready = false;
         return(false);
        }

      //--- 1. pivots (D-08b: significance-filtered) ------------------
      m_pivot_count = 0;
      ArrayResize(m_pivots,0);

      m_atr = WilderATR();
      BuildPivotsZigZag();

      //--- 2. HH / HL / LH / LL labels ------------------------------
      double prev_high = 0.0, prev_low = 0.0;
      bool   have_high = false, have_low = false;
      for(int i=0;i<m_pivot_count;i++)
        {
         if(m_pivots[i].is_high)
           {
            if(!have_high)      m_pivots[i].label = "H";
            else                m_pivots[i].label = (m_pivots[i].price>prev_high) ? "HH" : "LH";
            prev_high = m_pivots[i].price;
            have_high = true;
           }
         else
           {
            if(!have_low)       m_pivots[i].label = "L";
            else                m_pivots[i].label = (m_pivots[i].price>prev_low) ? "HL" : "LL";
            prev_low = m_pivots[i].price;
            have_low = true;
           }
        }

      //--- 3. results ------------------------------------------------
      m_trend              = ComputeTrend();
      m_bars_since_extreme = ComputeBarsSinceExtreme();

      m_ready         = true;
      m_last_bar_time = cur;
      return(true);
     }

   //----------------------------------------------------------------+
   //| Resolve a level: what happened to it FIRST? (D-09 / D-10)     |
   //|   body close beyond  -> BOS                                   |
   //|   wick beyond, close back inside -> SWEEP                     |
   //| Returns SPA_RES_NONE if the level is still untouched.         |
   //----------------------------------------------------------------+
   ENUM_SPA_RESOLUTION ResolveLevel(const int level_idx,const double level_price,
                                    const bool high_side,int &event_idx)
     {
      event_idx = -1;
      for(int j=level_idx+1;j<m_n;j++)
        {
         if(high_side)
           {
            if(m_c[j]>level_price)                       { event_idx=j; return(SPA_RES_BOS);   }
            if(m_h[j]>level_price && m_c[j]<level_price) { event_idx=j; return(SPA_RES_SWEEP); }
           }
         else
           {
            if(m_c[j]<level_price)                       { event_idx=j; return(SPA_RES_BOS);   }
            if(m_l[j]<level_price && m_c[j]>level_price) { event_idx=j; return(SPA_RES_SWEEP); }
           }
        }
      return(SPA_RES_NONE);
     }

   //----------------------------------------------------------------+
   //| D-14 : is a break actually tradable, or is it a correction?    |
   //|                                                               |
   //| A bearish shift is valid ONLY if a HIGHER HIGH printed first   |
   //| and then the last structural low broke on a BODY close.        |
   //| If the preceding high was a LOWER high, the down-move is just  |
   //| a corrective leg inside the uptrend:                          |
   //|                                                               |
   //|   "they will treat this break as a place to sell from... But   |
   //|    it's not, because this in itself is still not a valid       |
   //|    structural move."  - JeaFX                                 |
   //+------------------------------------------------------------------+
   bool              IsValidShift(const bool bearish)
     {
      if(!m_ready || m_pivot_count<3)
         return(false);

      if(bearish)
        {
         //--- did the last high exceed the previous high? -----------
         double h_new = 0.0, h_old = 0.0;
         int    n_h   = 0;
         int    low_idx = -1;
         double low_px  = 0.0;

         for(int i=m_pivot_count-1;i>=0;i--)
           {
            if(m_pivots[i].is_high && n_h<2)
              {
               if(n_h==0) h_new = m_pivots[i].price;
               else       h_old = m_pivots[i].price;
               n_h++;
              }
            if(!m_pivots[i].is_high && low_idx<0)
              {
               low_idx = m_pivots[i].idx;
               low_px  = m_pivots[i].price;
              }
            if(n_h>=2 && low_idx>=0)
               break;
           }
         if(n_h<2 || low_idx<0)
            return(false);
         if(!(h_new>h_old))
            return(false);

         int ev_idx = -1;
         return(ResolveLevel(low_idx,low_px,false,ev_idx)==SPA_RES_BOS);
        }

      //--- bullish mirror -------------------------------------------
      double l_new = 0.0, l_old = 0.0;
      int    n_l   = 0;
      int    high_idx = -1;
      double high_px  = 0.0;

      for(int i=m_pivot_count-1;i>=0;i--)
        {
         if(!m_pivots[i].is_high && n_l<2)
           {
            if(n_l==0) l_new = m_pivots[i].price;
            else       l_old = m_pivots[i].price;
            n_l++;
           }
         if(m_pivots[i].is_high && high_idx<0)
           {
            high_idx = m_pivots[i].idx;
            high_px  = m_pivots[i].price;
           }
         if(n_l>=2 && high_idx>=0)
            break;
        }
      if(n_l<2 || high_idx<0)
         return(false);
      if(!(l_new<l_old))
         return(false);

      int evb = -1;
      return(ResolveLevel(high_idx,high_px,true,evb)==SPA_RES_BOS);
     }

   //----------------------------------------------------------------+
   //| Accessors                                                      |
   //----------------------------------------------------------------+
   bool              IsReady()             const { return(m_ready); }
   string            LastError()           const { return(m_last_error); }
   int               Bars()                const { return(m_n); }
   int               PivotCount()          const { return(m_pivot_count); }
   double            ATR()                 const { return(m_atr); }
   double            MinSwingATR()         const { return(m_min_swing_atr); }
   double            SwingThreshold()      const { return(m_min_swing_atr*m_atr); }
   ENUM_SPA_TREND    Trend()               const { return(m_trend); }
   int               BarsSinceExtreme()    const { return(m_bars_since_extreme); }
   bool              IsConsolidating()     const { return(m_bars_since_extreme>=m_consol_bars); }
   ENUM_TIMEFRAMES   Timeframe()           const { return(m_tf); }

   string            TrendText()           const
     {
      if(m_trend==SPA_TREND_UP)   return("UP");
      if(m_trend==SPA_TREND_DOWN) return("DOWN");
      return("RANGE");
     }

   //--- read-only bar access for downstream modules (zones, signal) ----
   double            BarOpen(const int i)  const { if(i<0 || i>=m_n) return(0.0); return(m_o[i]); }
   double            BarHigh(const int i)  const { if(i<0 || i>=m_n) return(0.0); return(m_h[i]); }
   double            BarLow(const int i)   const { if(i<0 || i>=m_n) return(0.0); return(m_l[i]); }
   double            BarClose(const int i) const { if(i<0 || i>=m_n) return(0.0); return(m_c[i]); }
   datetime          BarTime(const int i)  const { if(i<0 || i>=m_n) return(0);   return(m_t[i]); }

   bool              GetPivot(const int i,SpaPivot &out) const
     {
      if(i<0 || i>=m_pivot_count)
         return(false);
      out = m_pivots[i];
      return(true);
     }

   //--- most recent pivot of a given side (searching backwards) ----
   bool              LastPivot(const bool is_high,SpaPivot &out) const
     {
      for(int i=m_pivot_count-1;i>=0;i--)
        {
         if(m_pivots[i].is_high==is_high)
           {
            out = m_pivots[i];
            return(true);
           }
        }
      return(false);
     }

   //----------------------------------------------------------------+
   //| One-line summary for logs and the chart panel                  |
   //----------------------------------------------------------------+
   string            Describe()
     {
      SpaPivot lh, ll;
      string sh = LastPivot(true,lh)  ? StringFormat("lastHigh %.5g (%s) @%s",lh.price,lh.label,TimeToString(lh.time,TIME_DATE|TIME_MINUTES)) : "lastHigh n/a";
      string sl = LastPivot(false,ll) ? StringFormat("lastLow  %.5g (%s) @%s",ll.price,ll.label,TimeToString(ll.time,TIME_DATE|TIME_MINUTES)) : "lastLow  n/a";

      return(StringFormat("%s %-3s | pivots=%d | %s | %s | sinceExtreme=%d | consolidating=%s | shiftBear=%s shiftBull=%s",
                          EnumToString(m_tf),TrendText(),m_pivot_count,sh,sl,
                          m_bars_since_extreme,
                          IsConsolidating() ? "YES" : "no",
                          IsValidShift(true) ? "VALID" : "-",
                          IsValidShift(false)? "VALID" : "-"));
     }
  };

//+------------------------------------------------------------------+

//  END MODULE: experts/SovereignPA/Include/SPA_Structure.mqh


//==========================================================================
//  BEGIN MODULE: experts/SovereignPA/Include/SPA_Zones.mqh
//==========================================================================
//--- A candidate order block that did NOT become a zone, kept so the audit
//--- view can show what the engine looked at and why it said no.
struct SpaReject
  {
   datetime  t_ob;
   double    top;
   double    bottom;
   bool      demand;
   int       why;      // 1 = no 3-candle gap, 2 = gap too small, 3 = gap closed
  };

#define SPA_MAX_REJECT 300

//+------------------------------------------------------------------+
//|                                                  SPA_Zones.mqh   |
//|   Sovereign Price-Action EA - zone construction & trade planning  |
//|   SPEC-001 v0.6.0  (D-A, D-B, D-D, R-06, R-07)                     |
//|                                                                   |
//|   WHAT THIS MODULE ANSWERS                                        |
//|     1. Where is the ORDER BLOCK that the breaking move came from? |
//|     2. Did that candle leave a CLEAR IMBALANCE behind it?         |
//|     3. Has price already traded back into it (fresh or stale)?    |
//|     4. What is the first structural level still standing ahead?   |
//|     5. Does the resulting reward:risk clear 3.0?                  |
//|                                                                   |
//|   USER DECISION D-A (2026-11-02)                                  |
//|   "we look and see the last candle before the impulse, but this   |
//|    candle has to have a clear imbalance that comes after it"      |
//|   -> the order block is mandatory AND the imbalance is a filter.  |
//|      Neither alone is a zone.                                     |
//|                                                                   |
//|   USER DECISION D-B                                               |
//|   Entry at the FIRST TOUCH (near edge). Stop beyond the far edge  |
//|   plus the rule book's 2 x spread + 2 pips buffer.                |
//|                                                                   |
//|   VERIFICATION                                                    |
//|   Mirrors tests/spa_signal_ref.py one-for-one. 16 unit tests.     |
//|   Any divergence between the two is a release blocker.            |
//+------------------------------------------------------------------+
#define __SPA_ZONES_MQH__

//+------------------------------------------------------------------+
struct SpaZone
  {
   bool      demand;        // true = demand (buy), false = supply (sell)
   int       ob_idx;        // order-block bar
   int       break_idx;     // bar that closed through structure
   double    top;
   double    bottom;
   double    entry;         // near edge = first touch
   double    stop_ref;      // far edge = zone invalidation
   bool      fresh;         // price has not returned into it yet
   int       age;            // bars since the break: fresh is not the same as current
   datetime  t_ob;
   int       gap_idx;        // bar of the imbalance that validates this zone
   double    gap_low;
   double    gap_high;
   double    gap_atr;        // gap size in ATR - what the threshold is measured against
   int       pivot_idx;      // the swing the impulse left from
   double    leg_atr;        // how far the impulse travelled, in ATR
   bool      gap_filled;     // the gap has been USED UP, not merely touched
   bool      retested;       // price has been back into the block at any time
   datetime  t_gap;
  };

//+------------------------------------------------------------------+
struct SpaPlan
  {
   bool      valid;
   bool      is_buy;
   double    entry;
   double    sl;
   double    tp;
   double    sl_pips;
   double    tp_pips;
   double    lots;
   double    rr;
   string    reason;
  };

//+------------------------------------------------------------------+
class CSpaZones
  {
private:
   SpaZone           m_z[];
   int               m_n;
   int               m_lookback;
   bool              m_latest_only;   // D-E: only the newest impulse per direction
   double            m_fvg_min_atr;   // D-06: minimum gap size, x ATR
   //--- audit counters: why did candidate order blocks not become zones?
   int               m_cand, m_why_none, m_why_small, m_why_filled, m_ok;
   SpaReject         m_rej[SPA_MAX_REJECT];
   int               m_rejc;
   int               m_fvg_window;    // gap must sit within N bars of the OB
   //--- impulse-first parameters (v0.7.0)
   double            m_min_leg_atr;   // a leg must travel this far to be an impulse
   int               m_ob_scan;       // how far back to look for the opposing candle

   //----------------------------------------------------------------+
   //| D-A + RB D-06: a VALID, UNFILLED, ADEQUATELY-SIZED imbalance  |
   //| created by the displacement that left the order block.        |
   //|                                                               |
   //| Three rules, each one visible on a chart:                     |
   //|   1. SIZE  - at least m_fvg_min_atr x ATR (RB D-06: 0.5).     |
   //|              Without it a 0.1-pip sliver counts as a "gap".   |
   //|   2. PLACE - within m_fvg_window bars of the order block, so  |
   //|              the gap belongs to the impulse, not to some      |
   //|              unrelated bar twenty candles later.              |
   //|   3. FILL  - price must not have traded all the way back      |
   //|              through it. A filled gap is history, not         |
   //|              imbalance.                                       |
   //|                                                               |
   //| Returns the bar of the gap, or -1.                            |
   //----------------------------------------------------------------+
   int               FindImbalance(CSpaStructure &st,const int start,const int end,
                                   const bool bullish,const double min_gap,
                                   const int window,const int n,int &why,
                                   const int fill_to=-1)
     {
      //--- fill_to limits the fill scan. At BIRTH we only ask whether the
      //--- impulse itself closed the gap; whether price closes it later is
      //--- the zone's freshness, not its validity.
      int fill_end = n;
      if(fill_to>=0 && fill_to+1<n)
         fill_end = fill_to+1;
      why = 1;   // 1 = no 3-candle geometry at all in the window
      int last = end;
      if(start+window<last)
         last = start+window;

      int lo = start+1;
      if(lo<2)
         lo = 2;

      for(int k=lo;k<=last;k++)
        {
         double gap_low, gap_high;
         if(bullish)
           {
            gap_low  = st.BarHigh(k-2);
            gap_high = st.BarLow(k);
           }
         else
           {
            gap_low  = st.BarHigh(k);
            gap_high = st.BarLow(k-2);
           }
         if((gap_high-gap_low)<min_gap || gap_high<=gap_low)
           {
            if(why<2)
               why = 2;      // 2 = a gap exists but it is too small
            continue;
           }

         bool filled = false;
         for(int j=k+1;j<fill_end;j++)
           {
            if(bullish && st.BarLow(j)<=gap_low)   { filled=true; break; }
            if(!bullish && st.BarHigh(j)>=gap_high) { filled=true; break; }
           }
         if(!filled)
           {
            why = 0;         // 0 = accepted
            return(k);
           }
         why = 3;             // 3 = a real gap, but price already closed it
        }
      return(-1);
     }

public:
   //----------------------------------------------------------------+
   //| IMPULSE-FIRST ORDER BLOCKS (v0.7.0)                           |
   //|                                                               |
   //| "First of all, we should first nail that thing of identifying  |
   //|  the last candles before the impulses, because those are       |
   //|  where we enter from."                                        |
   //|                                                               |
   //| The impulse is the primary object; the order block is derived  |
   //| from it. The previous engine started from a structural break   |
   //| and searched backwards, so an order block could only exist     |
   //| where a BOS happened - and most impulses never break structure.|
   //|                                                               |
   //| The imbalance is searched across the WHOLE leg, not within a   |
   //| few bars of the block: it forms inside the impulse. Measured   |
   //| on EUR/USD M15 that is 109 of 162 impulses instead of 8.       |
   //----------------------------------------------------------------+
   void              FindFVGZones(CSpaStructure &st)
     {
      m_n    = 0;
      m_rejc = 0;
      m_cand = 0; m_why_none = 0; m_why_small = 0; m_why_filled = 0; m_ok = 0;

      int nb = st.Bars();
      if(nb<5)
         return;
      double atr = st.ATR();
      if(atr<=0.0)
         return;

      double min_gap = m_fvg_min_atr*atr;

      for(int k=2;k<nb;k++)
        {
         bool   bullish  = false;
         bool   found    = false;
         double gap_low  = 0.0;
         double gap_high = 0.0;

         if(st.BarLow(k)>st.BarHigh(k-2))
           {
            gap_low  = st.BarHigh(k-2);
            gap_high = st.BarLow(k);
            bullish  = true;
            found    = true;
           }
         else if(st.BarHigh(k)<st.BarLow(k-2))
           {
            gap_low  = st.BarHigh(k);
            gap_high = st.BarLow(k-2);
            bullish  = false;
            found    = true;
           }
         if(!found)
            continue;

         m_cand++;
         if((gap_high-gap_low)<min_gap)
           {
            m_why_small++;
            if(m_rejc<SPA_MAX_REJECT)
              {
               int obr = k-2;
               m_rej[m_rejc].t_ob   = st.BarTime(obr);
               m_rej[m_rejc].top    = st.BarHigh(obr);
               m_rej[m_rejc].bottom = st.BarLow(obr);
               m_rej[m_rejc].demand = bullish;
               m_rej[m_rejc].why    = 2;
               m_rejc++;
              }
            continue;
           }

         //--- THE ORDER BLOCK IS THE CANDLE BEFORE THE DISPLACEMENT CANDLE.
         //--- In a 3-candle imbalance (k-2, k-1, k) the MIDDLE candle k-1 is
         //--- the one that "has the imbalance" - the displacement. The block
         //--- is the quiet candle in front of it, which is k-2.
         //--- Using k-1 marked the displacement candle itself: measured on
         //--- M15 that is 1.97 x ATR wide instead of 1.19, and 74% of blocks
         //--- came out wider than 1.5 ATR. That was the giant boxes.
         int ob = k-2;

         int sz = ArraySize(m_z);
         if(m_n>=sz)
            ArrayResize(m_z,sz+128);

         SpaZone z;
         z.demand    = bullish;
         z.ob_idx    = ob;
         z.pivot_idx = k;
         z.break_idx = k;
         z.top       = st.BarHigh(ob);
         z.bottom    = st.BarLow(ob);
         z.entry     = bullish ? z.top : z.bottom;
         z.stop_ref  = bullish ? z.bottom : z.top;
         z.t_ob      = st.BarTime(ob);
         z.t_gap     = st.BarTime(k);
         z.gap_idx   = k;
         z.gap_low   = gap_low;
         z.gap_high  = gap_high;
         z.gap_atr   = (gap_high-gap_low)/atr;
         z.leg_atr   = 0.0;
         z.age       = (nb-1)-k;

         //--- HOW FAR HAS PRICE COME BACK? One pass, both bounds.
         //--- The user's correction, 2026-11-02:
         //---   "when an imbalance is there, it's there ... a tiny bit of an
         //---    imbalance that the wick did not retest ... that zone is
         //---    still valid, and then we shift the last candle before the
         //---    impulse to the top candle"
         //--- So an imbalance is USED UP, never merely TOUCHED. Validity
         //--- is used up, never merely touched.
         double lo_since = 1e100;
         double hi_since =-1e100;
         for(int j=k+1;j<nb;j++)
           {
            double lo = st.BarLow(j);
            double hi = st.BarHigh(j);
            if(lo<lo_since) lo_since = lo;
            if(hi>hi_since) hi_since = hi;
           }

         //--- VALIDITY ONLY. The box geometry is NOT touched: the zone is
         //--- always the block candle, wick to wick, exactly as approved in
         //--- v0.12.0. Shrinking the box to a "live" remainder was my
         //--- invention and it moved every zone on the chart. Reverted.
         if(bullish)
            z.gap_filled = (lo_since<=gap_low);   // crossed the whole gap
         else
            z.gap_filled = (hi_since>=gap_high);

         //--- has price been back into the block AT ALL? A block that has
         //--- been retested has served its purpose and comes off the chart.
         if(bullish)
            z.retested = (lo_since<=z.top);
         else
            z.retested = (hi_since>=z.bottom);

         //--- "fresh" now means NOT FULLY CONSUMED, not "never wicked once".
         if(bullish)
            z.fresh = (lo_since>z.bottom);
         else
            z.fresh = (hi_since<z.top);

         m_z[m_n] = z;
         m_n++;
         m_ok++;
        }
     }

public:
                     CSpaZones(): m_n(0), m_lookback(20), m_latest_only(true),
                                  m_fvg_min_atr(0.15), m_fvg_window(3),
                                  m_min_leg_atr(1.5), m_ob_scan(6),
                                  m_cand(0), m_why_none(0), m_why_small(0),
                                  m_why_filled(0), m_ok(0), m_rejc(0) {}

   void              SetLatestOnly(const bool v) { m_latest_only = v; }
   int               RejectCount() const { return(m_rejc); }
   bool              GetReject(const int i,SpaReject &r) const
     {
      if(i<0 || i>=m_rejc)
         return(false);
      r = m_rej[i];
      return(true);
     }

   void              Diag(int &cand,int &none,int &small,int &filled,int &ok) const
     {
      cand=none=small=filled=ok;
      cand   = m_cand;
      none   = m_why_none;
      small  = m_why_small;
      filled = m_why_filled;
      ok     = m_ok;
     }

   void              SetImpulse(const double min_leg_atr,const int ob_scan)
     {
      m_min_leg_atr = (min_leg_atr<0.0) ? 0.0 : min_leg_atr;
      m_ob_scan     = (ob_scan<1) ? 1 : ob_scan;
     }
   void              SetImbalance(const double min_atr,const int window)
     {
      m_fvg_min_atr = (min_atr<0.0) ? 0.0 : min_atr;
      m_fvg_window  = (window<1) ? 1 : window;
     }

   //----------------------------------------------------------------+
   //| Scan the structure for valid zones. Returns the zone count.   |
   //| A zone needs: a BOS, an order block, and an imbalance.         |
   //----------------------------------------------------------------+
   int               Find(CSpaStructure &st)
     {
      m_n = 0;
      m_cand = m_why_none = m_why_small = m_why_filled = m_ok = 0;
      m_rejc = 0;
      ArrayResize(m_z,0);

      int nb = st.Bars();
      if(nb<5 || st.PivotCount()<1)
         return(0);

      int ob_used[];
      ArrayResize(ob_used,0);

      for(int i=0;i<st.PivotCount();i++)
        {
         SpaPivot p;
         if(!st.GetPivot(i,p))
            continue;

         int ev_idx = -1;
         if(st.ResolveLevel(p.idx,p.price,p.is_high,ev_idx)!=SPA_RES_BOS)
            continue;                       // wick-only = sweep, not a break

         int b = ev_idx;
         if(b<2 || b>=nb)
            continue;

         bool bullish = p.is_high;

         //--- last candle that closed AGAINST the breaking move ------
         int ob = -1;
         int floor_i = b-m_lookback;
         if(floor_i<0)
            floor_i = 0;
         for(int j=b;j>=floor_i;j--)
           {
            if(bullish && st.BarClose(j)<st.BarOpen(j)) { ob=j; break; }
            if(!bullish && st.BarClose(j)>st.BarOpen(j)) { ob=j; break; }
           }
         if(ob<0 || ob>=b)
            continue;

         //--- one candle cannot be two zones -------------------------
         bool seen = false;
         for(int q=0;q<ArraySize(ob_used);q++)
            if(ob_used[q]==ob) { seen=true; break; }
         if(seen)
            continue;

         int why  = 0;
         int gapk = FindImbalance(st,ob,b,bullish,m_fvg_min_atr*st.ATR(),
                                  m_fvg_window,nb,why,b);
         m_cand++;
         if(gapk<0)
           {
            if(why==2)      m_why_small++;
            else if(why==3) m_why_filled++;
            else            m_why_none++;
            if(m_rejc<SPA_MAX_REJECT)
              {
               m_rej[m_rejc].t_ob   = st.BarTime(ob);
               m_rej[m_rejc].top    = st.BarHigh(ob);
               m_rej[m_rejc].bottom = st.BarLow(ob);
               m_rej[m_rejc].demand = bullish;
               m_rej[m_rejc].why    = why;
               m_rejc++;
              }
            continue;
           }
         m_ok++;

         ArrayResize(ob_used,ArraySize(ob_used)+1);
         ob_used[ArraySize(ob_used)-1] = ob;

         SpaZone z;
         z.demand    = bullish;
         z.ob_idx    = ob;
         z.break_idx = b;
         z.top       = st.BarHigh(ob);
         z.bottom    = st.BarLow(ob);
         z.entry     = bullish ? z.top    : z.bottom;
         z.stop_ref  = bullish ? z.bottom : z.top;
         z.t_ob      = st.BarTime(ob);
         z.age       = (nb-1)-b;
         z.gap_idx   = gapk;
         z.t_gap     = st.BarTime(gapk);
         if(bullish)
           {
            z.gap_low  = st.BarHigh(gapk-2);
            z.gap_high = st.BarLow(gapk);
           }
         else
           {
            z.gap_low  = st.BarHigh(gapk);
            z.gap_high = st.BarLow(gapk-2);
           }
         z.gap_atr   = (st.ATR()>0.0) ? (z.gap_high-z.gap_low)/st.ATR() : 0.0;
         //--- did price close this gap AFTER the zone was born?
         z.gap_filled = false;
         for(int j=b+1;j<nb;j++)
           {
            if(bullish && st.BarLow(j)<=z.gap_low)      { z.gap_filled=true; break; }
            if(!bullish && st.BarHigh(j)>=z.gap_high)   { z.gap_filled=true; break; }
           }
         z.fresh     = true;

         for(int j=b+1;j<nb;j++)
           {
            if(bullish && st.BarLow(j)<=z.top)       { z.fresh=false; break; }
            if(!bullish && st.BarHigh(j)>=z.bottom)  { z.fresh=false; break; }
           }

         ArrayResize(m_z,m_n+1);
         m_z[m_n] = z;
         m_n++;
        }

      //--- chronological, so "most recent zone" is a simple tail ----
      for(int a=1;a<m_n;a++)
        {
         SpaZone key = m_z[a];
         int b2 = a-1;
         while(b2>=0 && m_z[b2].ob_idx>key.ob_idx)
           {
            m_z[b2+1] = m_z[b2];
            b2--;
           }
         m_z[b2+1] = key;
        }

      //--- D-E: only the most RECENT impulse in each direction is live.
      //--- "Another pullback, it retests the last candle before the impulse,
      //---  then it goes down to our zone." The zone you trade is the one the
      //--- LATEST impulse created - not the last one that happens to be
      //--- untouched. An ancient untouched zone is a level the market has
      //--- already walked past, not an opportunity.
      if(m_latest_only && m_n>1)
        {
         int best_d = -1, best_s = -1;
         for(int i=0;i<m_n;i++)
           {
            if(m_z[i].demand) { if(m_z[i].break_idx>best_d) best_d = m_z[i].break_idx; }
            else              { if(m_z[i].break_idx>best_s) best_s = m_z[i].break_idx; }
           }
         int k = 0;
         for(int i=0;i<m_n;i++)
           {
            int want = m_z[i].demand ? best_d : best_s;
            if(m_z[i].break_idx==want)
              {
               m_z[k] = m_z[i];
               k++;
              }
           }
         m_n = k;
         ArrayResize(m_z,m_n);
        }
      return(m_n);
     }

   //----------------------------------------------------------------+
   //| The first structural level STILL STANDING in front of the     |
   //| trade. A level already closed through is behind us, not a     |
   //| target.                                                       |
   //----------------------------------------------------------------+
   bool              FirstObstacle(CSpaStructure &st,const double entry,
                                   const bool bullish,double &out)
     {
      out = 0.0;
      bool found = false;

      for(int i=0;i<st.PivotCount();i++)
        {
         SpaPivot p;
         if(!st.GetPivot(i,p))
            continue;

         int ev = -1;
         if(st.ResolveLevel(p.idx,p.price,p.is_high,ev)==SPA_RES_BOS)
            continue;                       // already broken

         if(bullish && p.is_high && p.price>entry)
           {
            if(!found || p.price<out) { out=p.price; found=true; }
           }
         else if(!bullish && !p.is_high && p.price<entry)
           {
            if(!found || p.price>out) { out=p.price; found=true; }
           }
        }
      return(found);
     }

   //----------------------------------------------------------------+
   //| Turn a zone into an exact order.                              |
   //|                                                               |
   //| Rejection is explicit and never silent: under min_rr there is |
   //| no trade, full stop. The target is NOT stretched to fit.      |
   //----------------------------------------------------------------+
   //--- output by reference: MQL5 cannot return a struct that holds a
   //--- string by value, and SpaPlan carries a reason code.
   void              BuildPlan(const SpaZone &z,const bool have_tp,const double tp,
                               const double spread_px,const double pip,const double min_rr,
                               const double min_sl_px,SpaPlan &pl)
     {
      pl.valid   = false;
      pl.is_buy  = z.demand;
      pl.entry   = z.entry;
      pl.sl      = 0.0;
      pl.tp      = 0.0;
      pl.sl_pips = 0.0;
      pl.tp_pips = 0.0;
      pl.lots    = 0.0;
      pl.rr      = 0.0;
      pl.reason  = "";

      if(!have_tp)
        {
         pl.reason = "REJ_NO_TARGET";
         return;
        }

      //--- rule book 5.3 buffer: 2 x spread + 2 pips -----------------
      double buffer = 2.0*spread_px + 2.0*pip;
      pl.sl = z.demand ? (z.bottom-buffer) : (z.top+buffer);
      pl.tp = tp;

      pl.sl_pips = MathAbs(pl.entry-pl.sl)/pip;
      pl.tp_pips = MathAbs(pl.tp-pl.entry)/pip;

      if(pl.sl_pips<=0.0)
        {
         pl.reason = "REJ_NO_SL";
         return;
        }

      //--- a stop closer than the market's own noise is not a tight stop,
      //--- it is a guaranteed loss. Reject the zone; NEVER widen the stop.
      if(min_sl_px>0.0 && (pl.sl_pips*pip)<min_sl_px)
        {
         pl.reason = "REJ_SL_TOO_TIGHT";
         return;
        }

      pl.rr = pl.tp_pips/pl.sl_pips;
      if(pl.rr<min_rr)
        {
         pl.reason = "REJ_RR";
         return;
        }

      pl.valid  = true;
      pl.reason = "OK";
     }

   //----------------------------------------------------------------+
   //| Best tradable zone: direction must agree with the bias trend, |
   //| zone must be fresh, and the highest reward:risk wins.         |
   //| This is the user's "we use the zone with that magnet" made    |
   //| mechanical - a zone only wins if there is liquidity worth     |
   //| travelling to behind it.                                      |
   //----------------------------------------------------------------+
   bool              BestPlan(CSpaStructure &bias_st,CSpaStructure &confirm_st,
                              const string trend,const double spread_px,const double pip,
                              const double min_rr,const double min_sl_px,const int max_age,
                              SpaPlan &out,SpaZone &out_zone)
     {
      //--- no bias = no trade. Say so plainly instead of blaming zones.
      if(trend!="UP" && trend!="DOWN")
        {
         out.valid  = false;
         out.reason = "REJ_NO_TREND";
         return(false);
        }

      bool have = false;
      double best_rr = -1.0;
      string last_reason = "REJ_NO_ZONE";
      int    in_dir = 0;

      for(int i=0;i<m_n;i++)
        {
         if(!m_z[i].fresh)
            continue;
         //--- untouched for too long is abandoned, not fresh -------
         if(max_age>0 && m_z[i].age>max_age)
            continue;
         if(trend=="UP"   && !m_z[i].demand) continue;
         if(trend=="DOWN" &&  m_z[i].demand) continue;
         in_dir++;

         double obst = 0.0;
         bool have_obst = NearestObstacle(bias_st,confirm_st,
                                          m_z[i].entry,m_z[i].demand,obst);

         SpaPlan pl;
         BuildPlan(m_z[i],have_obst,obst,spread_px,pip,min_rr,min_sl_px,pl);
         if(!pl.valid)
           {
            last_reason = pl.reason;
            continue;
           }
         if(!have || pl.rr>best_rr)
           {
            best_rr  = pl.rr;
            out      = pl;
            out_zone = m_z[i];
            have     = true;
           }
        }

      if(!have)
        {
         out.valid  = false;
         if(m_n<=0)          out.reason = "REJ_NO_ZONE";
         else if(in_dir<=0)  out.reason = "REJ_NO_FRESH_ZONE";
         else                out.reason = last_reason;
        }
      return(have);
     }

   //----------------------------------------------------------------+
   //| The nearer of the two structures' first obstacles. A target is |
   //| only honest if it is the FIRST thing in the way, whichever      |
   //| timeframe it came from.                                        |
   //----------------------------------------------------------------+
   bool              NearestObstacle(CSpaStructure &a,CSpaStructure &b,
                                     const double entry,const bool bullish,double &out)
     {
      double pa=0.0, pb=0.0;
      bool ha = FirstObstacle(a,entry,bullish,pa);
      bool hb = FirstObstacle(b,entry,bullish,pb);

      if(ha && hb)
        {
         out = (MathAbs(pa-entry)<=MathAbs(pb-entry)) ? pa : pb;
         return(true);
        }
      if(ha) { out=pa; return(true); }
      if(hb) { out=pb; return(true); }
      out = 0.0;
      return(false);
     }

   //--- accessors ---------------------------------------------------
   //----------------------------------------------------------------+
   //| RULE BOOK 3.3 - EXTREME ZONE PRIORITY, word for word:         |
   //|                                                               |
   //|   "If multiple valid zones exist within a single swing leg,   |
   //|    the algorithm ranks them by proximity to the swing extreme.|
   //|    The bot selects the Extreme Zone (the furthest valid zone   |
   //|    from the current market price that still possesses an      |
   //|    Unfilled Imbalance)."                                      |
   //|                                                               |
   //| Three filters, and the winner is the FURTHEST, not the        |
   //| nearest:                                                      |
   //|   valid    - price has not been back into the block  (3.2)    |
   //|   unfilled - a wick has not entered the gap          (3.3)    |
   //|   leg      - the block was born after the swing extreme       |
   //|                                                               |
   //| Returns the index into this set, or -1, and always fills      |
   //| `reason` with a sentence that can be shown to the user.       |
   //----------------------------------------------------------------+
   //----------------------------------------------------------------+
   //| SORTING THE BLOCKS (v0.16.0)                                  |
   //|                                                               |
   //| The user, 2026-11-03:                                         |
   //|   "we cannot get the last candle before the impulse again     |
   //|    immediately after it... we are going to be considering the |
   //|    extreme, the last candle at the top, which brought all of  |
   //|    these inefficient candles... unless there is a break of    |
   //|    structure, maybe a pullback, after that pullback we can    |
   //|    consider that also."                                       |
   //|                                                               |
   //| One move = a run of same-direction blocks with no retest      |
   //| between them. Inside a run only the EXTREME survives: the     |
   //| highest top for supply, the lowest bottom for demand. A       |
   //| retest ends the run and a new one may begin.                  |
   //----------------------------------------------------------------+
   void              CompressRuns(CSpaStructure &st)
     {
      if(m_n<2)
         return;

      int     out  = 0;
      SpaZone run;
      ZeroMemory(run);          // silence "possibly uninitialised"
      bool    have = false;

      for(int i=0;i<m_n;i++)
        {
         SpaZone z = m_z[i];
         if(!have)
           {
            run  = z;
            have = true;
            continue;
           }

         if(z.demand==run.demand)
           {
            //--- a wick poking back into the block does NOT end the move -
            //--- only a candle that CLOSES back inside it does. This is what
            //--- the user marked with an X: the block immediately after the
            //--- first one in a move is not a block of its own.
            bool ret = false;
            for(int b=run.ob_idx+1;b<=z.ob_idx && !ret;b++)
              {
               if(run.demand)
                 {
                  if(st.BarClose(b)<=run.top)     ret = true;
                 }
               else
                 {
                  if(st.BarClose(b)>=run.bottom) ret = true;
                 }
              }
            if(!ret)
              {
               //--- same move: keep the extreme, discard the rest
               if(z.demand)
                 {
                  if(z.bottom<run.bottom) run = z;
                 }
               else
                 {
                  if(z.top>run.top) run = z;
                 }
               continue;
              }
           }

         m_z[out++] = run;
         run = z;
        }
      if(have)
         m_z[out++] = run;

      m_n = out;
     }

   int               SelectExtreme(CSpaStructure &st,const bool demand,
                                   const double price,string &reason)
     {
      reason = "";

      //--- the leg starts at the last swing in the opposite direction:
      //--- for a demand zone that is the last swing LOW, for supply the
      //--- last swing HIGH. Blocks older than that belong to an older leg.
      int leg_start = -1;
      for(int i=st.PivotCount()-1;i>=0;i--)
        {
         SpaPivot p;
         if(!st.GetPivot(i,p))
            continue;
         if(demand ? (!p.is_high) : p.is_high)
           {
            leg_start = p.idx;
            break;
           }
        }

      string want   = demand ? "demand" : "supply";
      int    valid  = 0;
      int    open   = 0;
      int    inleg  = 0;
      int    best   = -1;
      double bestd  = -1.0;

      for(int i=m_n-1;i>=0;i--)
        {
         if(m_z[i].demand!=demand)
            continue;
         if(!m_z[i].fresh)                  // 3.2: already tapped = invalid
            continue;
         valid++;
         if(m_z[i].gap_filled)              // 3.3: the imbalance is used up
            continue;
         open++;
         if(leg_start>=0 && m_z[i].gap_idx<leg_start)
            continue;
         inleg++;
         double d = MathAbs((demand ? m_z[i].top : m_z[i].bottom)-price);
         if(d>bestd)
           {
            bestd = d;
            best  = i;
           }
        }

      if(best<0)
        {
         if(valid==0)
            reason = StringFormat("no fresh %s zone yet",want);
         else if(open==0)
            reason = StringFormat("%d fresh %s zone(s), every imbalance already filled",valid,want);
         else
            reason = StringFormat("%d %s zone(s) with an open imbalance, none in this leg",open,want);
         return(-1);
        }

      reason = StringFormat("%d valid, %d with an open imbalance, %d in this leg - extreme %s chosen",
                            valid,open,inleg,want);
      return(best);
     }

   int               Count()               const { return(m_n); }
   bool              Get(const int i,SpaZone &out) const
     {
      if(i<0 || i>=m_n)
         return(false);
      out = m_z[i];
      return(true);
     }
   int               FreshCount()          const
     {
      int c=0;
      for(int i=0;i<m_n;i++) if(m_z[i].fresh) c++;
      return(c);
     }
  };

//+------------------------------------------------------------------+

//  END MODULE: experts/SovereignPA/Include/SPA_Zones.mqh


#define SPA_VERSION   "0.18.0"

//+------------------------------------------------------------------+
//| Inputs                                                            |
//+------------------------------------------------------------------+
input group           "=== 1. Profile ==="
input string          InpProfileFile      = "symbol_profiles.csv";  // Profile file (MQL5/Files)
input bool            InpOverrideEnabled  = false;                  // Force-enable this symbol (testing only)

input group           "=== 2. Risk overrides (0 = use profile) ==="
input double          InpRiskPctOverride  = 0.0;                    // Risk % per trade
input double          InpMinRROverride    = 0.0;                    // Minimum reward:risk

input group           "=== 3. Structure engine ==="
input double          InpMinSwingATR      = 4.0;                    // Min swing size (x ATR) - significance filter
input double          InpArrowSpreadATR   = 0.70;                   // Vertical gap between TFs (x ATR)
input int             InpStructBars       = 600;                    // Structure history depth (bars)
input int             InpConsolBars       = 20;                     // Consolidation threshold (RB 2.1)
input bool            InpDrawStructure    = false;                   // Draw detected swings on chart
input int             InpDrawMaxPivots    = 12;                     // Max swings drawn per timeframe
//--- which timeframe's structure creates the entry zone. D-E: the zone is
//--- the last candle before the impulse on a HIGHER timeframe than the entry.
enum ENUM_SPA_ZONETF
  {
   SPA_ZONE_EXEC    = 0,   // EXEC  - finest, most zones
   SPA_ZONE_CONFIRM = 1,   // CONFIRM - default
   SPA_ZONE_BIAS    = 2    // BIAS  - widest, fewest zones
  };

input ENUM_SPA_ZONETF  InpZoneTF          = SPA_ZONE_CONFIRM;        // Timeframe that creates the zone
input bool            InpZonesLatestOnly = true;                   // Only the newest impulse per direction
input bool            InpShowZones        = true;                   // Draw order-block zones
input int             InpDrawZonesMax      = 40;                     // Max zones drawn
input int             InpZoneBoxBars     = 40;                     // How far an outline box runs right
input color           InpColImbalance    = clrDimGray;             // Imbalance outline colour
input color           InpColFreshTxt     = clrMediumSeaGreen;      // Demand label text
input color           InpColSupplyTxt    = clrIndianRed;           // Supply label text
input int             InpImbalanceLookback = 200;                  // Bars back to list imbalances
input int             InpZoneLookbackBars  = 300;                  // Bars back to show blocks
input bool            InpMTF               = false;                 // Draw every structure timeframe at once
input bool            InpShowBiasZone      = true;                  // Mark the timeframe the bias came from
input color           InpColBias           = clrDeepSkyBlue;        // Bias-zone colour
input bool            InpPanelStartFull    = false;                 // Panel opens expanded
input bool            InpLogDiag           = false;                 // Log the 30-second [DIAG] block
input bool            InpShowTarget       = false;                  // Draw the dotted target level
input bool            InpClean            = true;                   // CLEAN: draw only the trade - box, entry, stop, target
input bool            InpZoneAudit        = false;                  // Verification mode: draw every zone in history
input int             InpAuditMax         = 60;                     // How many historical zones / rejects to draw
input bool            InpZoneFill         = true;                   // Draw the zone as a faint box as well as two levels
input bool            InpAuditRejected    = false;                  // Draw refused imbalances (verification only - noisy)
input double          InpMinRiskATR       = 0.5;                    // Min stop distance (x exec ATR) before a zone is skipped
input int             InpZoneMaxAge       = 200;                    // Bars before an untouched zone is abandoned
input double          InpFvgMinATR        = 0.10;                    // Min imbalance size inside the impulse (x ATR) - RB D-06

input color           InpColFresh          = clrDarkGreen;           // Demand zone box (dark = faint)
input color           InpColUsed           = clrSilver;            // Used or tapped zone box
input color           InpColSupply         = clrDarkRed;            // Supply zone box (dark = faint)
input color           InpColGap            = clrGold;              // Imbalance band

input group           "=== 4. Display ==="
input bool            InpShowPanel        = true;                   // Show live panel on chart
input int             InpPanelX           = 12;                      // Panel X (pixels from left)
input int             InpPanelY           = 22;                     // Panel Y (pixels from top)
input int             InpPanelFontSize    = 9;                      // Panel font size
input color           InpPanelOK          = clrLime;                // Colour: gate PASS
input color           InpPanelBlock       = clrOrangeRed;           // Colour: gate BLOCK
input color           InpPanelText        = clrWhite;               // Colour: normal text

input group           "=== 5. Logging ==="
input bool            InpDiagnostics      = true;                   // Print diagnostics to Experts log
input int             InpDiagEverySeconds = 60;                     // Log interval (seconds)
input double          InpDiagSlPips       = 20.0;                   // Illustrative SL (pips) for lot preview

//+------------------------------------------------------------------+
//| Globals                                                           |
//+------------------------------------------------------------------+
CSpaProfiles          g_profiles;
CSpaSymbol            g_symbol;
CSpaStructure         g_bias;
CSpaStructure         g_confirm;
CSpaStructure         g_exec;
SpaProfile            g_profile;

int                   g_h_atr_confirm = INVALID_HANDLE;
bool                  g_config_ok     = false;

//--- cached metrics -------------------------------------------------
double                g_bid       = 0.0;
double                g_ask       = 0.0;
double                g_sp_price  = 0.0;
double                g_sp_pips   = 0.0;
double                g_med_pips  = 0.0;
double                g_ratio     = 0.0;
double                g_atr_conf  = 0.0;
double                g_sl_px     = 0.0;
double                g_lots      = 0.0;
int                   g_sp_samples= 0;
string                g_regime    = "UNKNOWN";
bool                  g_coarse_ok = false;
bool                  g_risk_ok   = false;
bool                  g_perm_ok   = false;
string                g_coarse_reason = "";
string                g_risk_reason   = "";
string                g_perm_reason   = "";

datetime              g_last_refresh   = 0;
datetime              g_last_diag      = 0;
datetime              g_last_bias_bar  = 0;
datetime              g_last_chart_bar = 0;
string                g_refine_text   = "refinement not run";
string                g_zone_line     = "";
string                g_state_line    = "";
int                   g_refine_idx    = -1;
bool                  g_panel_full    = false;
datetime              g_last_conf_bar  = 0;
datetime              g_last_exec_bar  = 0;
int                   g_arrow_count    = 0;
bool                  g_arrows_hidden  = false;   // all structure TFs finer than the chart
CSpaZones             g_zones;    // primary: the one signals will use
CSpaZones             g_zonesB;   // bias timeframe, drawn only
CSpaZones             g_zonesC;   // confirm timeframe, drawn only
CSpaZones             g_zonesE;   // exec timeframe, drawn only
CSpaStructure         g_chart;    // the timeframe the chart is on
CSpaZones             g_zonesChart;// zones of the chart's own timeframe
SpaPlan               g_plan;
SpaZone               g_plan_zone;
string                g_signal_note     = "NO SIGNAL";
int                   g_tick_count     = 0;

//--- spread self-calibration ----------------------------------------
//--- iSpread() is not available on every MetaEditor build (it failed to
//--- compile on the user's build with "wrong parameters count"). The
//--- regime line is diagnostics only, so rather than depend on an
//--- indicator that may not exist, the EA samples the live spread once
//--- per M1 bar and builds its own baseline. Self-calibrating, no
//--- external dependency, and it measures the spread this account
//--- actually pays rather than a nominal series.
#define SPA_SP_CAP        1440     // one sample per M1 bar -> 24h of history
#define SPA_SP_MIN_SAMPLES  30     // below this the regime is CALIBRATING

double                g_sp_buf[];
int                   g_sp_n            = 0;
datetime              g_sp_last_bar     = 0;

//--- panel geometry -------------------------------------------------
#define SPA_PANEL_ROWS 26
#define SPA_PANEL_COMMENT_PAD 22
#define SPA_SW_PREFIX  "SPA_SW_"

//+------------------------------------------------------------------+
double AtrValue(const int handle,const int shift=1)
  {
   if(handle==INVALID_HANDLE)
      return(0.0);
   double buf[];
   ArraySetAsSeries(buf,true);
   if(CopyBuffer(handle,0,shift,1,buf)!=1)
      return(0.0);
   return(buf[0]);
  }

//+------------------------------------------------------------------+
void SampleSpread()
  {
   datetime m1 = iTime(_Symbol,PERIOD_M1,0);
   if(m1==g_sp_last_bar)
      return;
   g_sp_last_bar = m1;

   double sp = g_symbol.SpreadPrice();
   if(sp<=0.0)
      return;

   if(g_sp_n>=SPA_SP_CAP)
     {
      //--- manual shift instead of ArrayRemove(): one less built-in whose
      //--- availability we have to assume. 1440 iterations once a minute
      //--- is free.
      for(int i=1;i<g_sp_n;i++)
         g_sp_buf[i-1] = g_sp_buf[i];
      g_sp_n--;
     }
   ArrayResize(g_sp_buf,g_sp_n+1);
   g_sp_buf[g_sp_n] = sp;
   g_sp_n++;
  }

//+------------------------------------------------------------------+
double SpreadMedianPips(int &samples_out)
  {
   samples_out = g_sp_n;
   if(g_sp_n<=0)
      return(0.0);

   double tmp[];
   ArrayResize(tmp,g_sp_n);
   for(int i=0;i<g_sp_n;i++)
      tmp[i] = g_sp_buf[i];
   ArraySort(tmp);

   int    n   = g_sp_n;
   double med = (n%2==1) ? tmp[n/2] : 0.5*(tmp[n/2-1]+tmp[n/2]);
   return(med/g_symbol.Pip());
  }

//+------------------------------------------------------------------+
void RefreshMetrics()
  {
   g_bid        = g_symbol.Bid();
   g_ask        = g_symbol.Ask();
   g_sp_price   = g_symbol.SpreadPrice();
   g_sp_pips    = g_symbol.SpreadPips();
   g_atr_conf   = AtrValue(g_h_atr_confirm);
   g_sl_px      = InpDiagSlPips*g_symbol.Pip();
   g_lots       = g_symbol.LotsForRisk(
                     AccountInfoDouble(ACCOUNT_EQUITY)*g_profile.risk_pct/100.0,g_sl_px);

   g_coarse_ok  = g_symbol.SpreadOKCoarse(g_coarse_reason);
   g_risk_ok    = g_symbol.SpreadOKAtRisk(g_sl_px,g_risk_reason);
   g_perm_ok    = g_symbol.TradingPermitted(g_perm_reason);

   SampleSpread();

   g_med_pips   = SpreadMedianPips(g_sp_samples);
   g_ratio      = (g_med_pips>0.0) ? g_sp_pips/g_med_pips : 0.0;

   if(g_sp_samples<SPA_SP_MIN_SAMPLES) g_regime = "CALIBRATING";
   else if(g_ratio<1.5)                g_regime = "NORMAL";
   else if(g_ratio<3.0)                g_regime = "ELEVATED";
   else                                g_regime = "BLOWOUT";
  }

//+------------------------------------------------------------------+
//| Compact one-line structure summary for the panel                  |
//+------------------------------------------------------------------+
string StructureLine(CSpaStructure &st,const string tag)
  {
   if(!st.IsReady())
      return(StringFormat("%-4s  no data",tag));

   SpaPivot hi, lo;
   string sh = st.LastPivot(true,hi)  ? StringFormat("%s %.5g",hi.label,hi.price) : "n/a";
   string sl = st.LastPivot(false,lo) ? StringFormat("%s %.5g",lo.label,lo.price) : "n/a";

   return(StringFormat("%-4s  %-5s  %s  %s  cons:%-3s  brk:%s",
                       tag,st.TrendText(),sh,sl,
                       st.IsConsolidating() ? "YES" : "no",
                       st.IsValidShift(true) ? "BEAR" : "-"));
  }

//+------------------------------------------------------------------+
//| Draw detected swings so the user can audit them visually          |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| How far above/below the actual swing price each timeframe draws.  |
//| Without this, three timeframes detecting a swing on the same bar  |
//| print three arrows on top of each other and you cannot tell which |
//| arrow belongs to which timeframe. EXEC sits closest to price      |
//| because it is the timeframe you actually trade.                   |
//+------------------------------------------------------------------+
double SlotOffsetATR(const int slot)
  {
   if(slot==0) return(2.0*InpArrowSpreadATR);   // BIAS   - furthest out
   if(slot==1) return(1.0*InpArrowSpreadATR);   // CONFIRM
   return(0.0);                                 // EXEC   - on the price
  }

void DrawSwings(CSpaStructure &st,const int slot,const color col,const double ref_atr)
  {
   if(!InpDrawStructure)
      return;

   //--- all three timeframes are offset using the SAME atr, so the gaps
   //--- look identical on screen instead of scaling with each TF's own
   //--- volatility (an H4 atr would fling the bias arrows off the candles).
   double off = SlotOffsetATR(slot)*ref_atr;

   int cnt  = st.PivotCount();
   int from = cnt-InpDrawMaxPivots;
   if(from<0)
      from = 0;

   for(int i=from;i<cnt;i++)
     {
      SpaPivot p;
      if(!st.GetPivot(i,p))
         continue;

      string nm = StringFormat("%s%d_%d",SPA_SW_PREFIX,slot,i);

      //--- push the arrow away from price in the direction it points, so
      //--- arrows from different timeframes never overprint.
      double draw_px = p.is_high ? (p.price+off) : (p.price-off);

      if(ObjectFind(0,nm)<0)
        {
         if(!ObjectCreate(0,nm,OBJ_ARROW,0,p.time,draw_px))
           {
            //--- never fail silently: the whole point of this build is
            //--- that you can SEE what the engine detected.
            PrintFormat("[OBJ] ERROR creating arrow %-18s err=%d (t=%s p=%.5g)",
                        nm,GetLastError(),TimeToString(p.time),p.price);
            continue;
           }
        }
      if(!ObjectSetInteger(0,nm,OBJPROP_ARROWCODE,p.is_high ? 234 : 233) ||
         !ObjectSetDouble(0,nm,OBJPROP_PRICE,draw_px) ||
         !ObjectSetInteger(0,nm,OBJPROP_TIME,p.time))
        {
         PrintFormat("[OBJ] ERROR configuring arrow %s err=%d",nm,GetLastError());
         continue;
        }
      ObjectSetInteger(0,nm,OBJPROP_COLOR,col);
      ObjectSetInteger(0,nm,OBJPROP_WIDTH,1);
      ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
      ObjectSetInteger(0,nm,OBJPROP_ANCHOR,p.is_high ? ANCHOR_BOTTOM : ANCHOR_TOP);
      g_arrow_count++;
     }
  }

//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| ZONE ENGINE - runs once per new exec bar                          |
//| Computes: zones -> best plan -> the note shown on the panel.      |
//+------------------------------------------------------------------+
ENUM_TIMEFRAMES ZoneTF()
  {
   if(InpZoneTF==SPA_ZONE_BIAS)    return(g_profile.tf_bias);
   if(InpZoneTF==SPA_ZONE_EXEC)    return(g_profile.tf_exec);
   return(g_profile.tf_confirm);
  }

//+------------------------------------------------------------------+
//| Reason codes are for the log. On screen, say what it MEANS.       |
//+------------------------------------------------------------------+
string PlainReason(const string r)
  {
   if(r=="REJ_NO_TREND")      return("bias timeframe is ranging - no trade");
   if(r=="REJ_NO_ZONE")       return("no order block with an imbalance yet");
   if(r=="REJ_NO_FRESH_ZONE") return("newest zones already tapped - wait for the next impulse");
   if(r=="REJ_RR")            return("first target ahead is under 3x the risk");
   if(r=="REJ_SL_TOO_TIGHT")  return("order block too small - stop would sit inside the noise");
   if(r=="REJ_NO_TARGET")     return("no structural level ahead to aim at");
   if(r=="REJ_NO_LOT")        return("lot size rounds to zero at this risk");
   return(r);
  }

void RefreshSignal()
  {
   //--- zones are built from the chosen structure, not always from exec --
   //--- Audit mode exists so the user can check the engine's reading of the
   //--- chart. It changes what is DRAWN, never what would be traded.
   g_zones.SetLatestOnly(InpZonesLatestOnly && !InpZoneAudit);
   g_zones.SetImbalance(InpFvgMinATR,0);
   if(InpZoneTF==SPA_ZONE_BIAS)         g_zones.FindFVGZones(g_bias);
   else if(InpZoneTF==SPA_ZONE_EXEC)    g_zones.FindFVGZones(g_exec);
   else                                 g_zones.FindFVGZones(g_confirm);

   //--- the whole inventory, one set per timeframe. These are for DRAWING
   //--- only: a signal still comes from the primary set, so adding a
   //--- timeframe cannot change what would be traded.
   //--- zones of whatever timeframe this chart is on
   g_chart.Refresh();
   g_zonesChart.SetLatestOnly(InpZonesLatestOnly && !InpZoneAudit);
   g_zonesChart.SetImbalance(InpFvgMinATR,0);
   g_zonesChart.FindFVGZones(g_chart);
   //--- one move = one block. Collapse each run to its extreme before
   //--- anything else looks at the list.
   g_zonesChart.CompressRuns(g_chart);

   //--- RULE BOOK 3.3: rank this timeframe's zones and pick the extreme one.
   //--- This is the engine's choice. The chart does not change because of it;
   //--- the panel and the log say what it chose and why.
   {
      string rsn;
      string tr = g_bias.TrendText();
      if(tr=="UP" || tr=="DOWN")
         g_refine_idx = g_zonesChart.SelectExtreme(g_chart,tr=="UP",
                        (g_symbol.Bid()+g_symbol.Ask())/2.0,rsn);
      else
        {
         g_refine_idx = -1;
         rsn = "bias is RANGE - nothing to rank";
        }
      g_refine_text = rsn;

      SpaZone sel;
      if(g_refine_idx>=0 && g_zonesChart.Get(g_refine_idx,sel))
         g_state_line = StringFormat("candidate %s %s  at %s",
                        TFName(PERIOD_CURRENT),
                        sel.demand ? "DEMAND" : "SUPPLY",
                        TimeToString(sel.t_ob,TIME_DATE|TIME_MINUTES));
      else
         g_state_line = "no candidate zone";

      g_zone_line = StringFormat("%d blocks on this %s chart",g_zonesChart.Count(),
                                 TFName(PERIOD_CURRENT));
      PrintFormat("== REFINE == %s",rsn);
   }

   if(InpMTF)
     {
      g_zonesB.SetLatestOnly(InpZonesLatestOnly && !InpZoneAudit);
      g_zonesB.SetImbalance(InpFvgMinATR,0);
      g_zonesB.FindFVGZones(g_bias);
      g_zonesC.SetLatestOnly(InpZonesLatestOnly && !InpZoneAudit);
      g_zonesC.SetImbalance(InpFvgMinATR,0);
      g_zonesC.FindFVGZones(g_confirm);
      g_zonesE.SetLatestOnly(InpZonesLatestOnly && !InpZoneAudit);
      g_zonesE.SetImbalance(InpFvgMinATR,0);
      g_zonesE.FindFVGZones(g_exec);
     }

   double pip   = g_symbol.Pip();
   double sp_px = g_symbol.SpreadPrice();
   double rr_min= g_profile.min_rr;

   bool have = g_zones.BestPlan(g_bias,g_confirm,g_bias.TrendText(),
                                sp_px,pip,rr_min,InpMinRiskATR*g_exec.ATR(),InpZoneMaxAge,
                                g_plan,g_plan_zone);

   if(have)
     {
      double risk_money = AccountInfoDouble(ACCOUNT_EQUITY)*g_profile.risk_pct/100.0;
      g_plan.lots = g_symbol.LotsForRisk(risk_money,MathAbs(g_plan.entry-g_plan.sl));
      if(g_plan.lots<=0.0)
        {
         g_plan.valid  = false;
         g_plan.reason = "REJ_NO_LOT";
         g_signal_note = StringFormat("NO TRADE: %s  [%s]",PlainReason(g_plan.reason),g_plan.reason);
         return;
        }
      g_signal_note = StringFormat("%s LIMIT %.5g  SL %.5g  TP %.5g  %.2f lots  %.2fR",
                                   g_plan.is_buy ? "BUY" : "SELL",
                                   g_plan.entry,g_plan.sl,g_plan.tp,
                                   g_plan.lots,g_plan.rr);
     }
   else
      g_signal_note = StringFormat("NO TRADE: %s  [%s]",PlainReason(g_plan.reason),g_plan.reason);
  }

//+------------------------------------------------------------------+
//| Should this timeframe's swings be drawn on the current chart?     |
//|                                                                   |
//| Only structure at or ABOVE the chart's own timeframe. Drawing M5  |
//| swings on a Weekly chart squeezes a day of pivots into one candle |
//| and produces the pile of overlapping arrows seen in review.       |
//+------------------------------------------------------------------+
bool ShouldDrawTF(const ENUM_TIMEFRAMES st_tf)
  {
   return(PeriodSeconds(st_tf)>=PeriodSeconds((ENUM_TIMEFRAMES)_Period));
  }

//+------------------------------------------------------------------+
//| Draw the zones the engine is watching, and the exact order it     |
//| WOULD place. No order is sent by this build.                      |
//+------------------------------------------------------------------+
#define SPA_ZONE_PREFIX "SPA_Z_"

void HLevel(const string nm,const datetime t1,const datetime t2,const double price,
            const color clr,const int width,const int style)
  {
   if(ObjectFind(0,nm)>=0)
      ObjectDelete(0,nm);
   if(!ObjectCreate(0,nm,OBJ_TREND,0,t1,price,t2,price))
      return;
   ObjectSetInteger(0,nm,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,nm,OBJPROP_WIDTH,width);
   ObjectSetInteger(0,nm,OBJPROP_STYLE,style);
   ObjectSetInteger(0,nm,OBJPROP_RAY_LEFT,false);
   ObjectSetInteger(0,nm,OBJPROP_RAY_RIGHT,false);
   ObjectSetInteger(0,nm,OBJPROP_BACK,false);
   ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
  }

//+------------------------------------------------------------------+
//| CLEAN MODE (v0.8.1)                                              |
//|                                                                  |
//| "Remove everything. I want you to draw the zones... the zones    |
//|  where I enter and the stop loss, and then the TP, where the     |
//|  other zone is."                                                 |
//|                                                                  |
//| One box on the block, two dotted levels for entry and stop, one   |
//| dotted level for the target. No labels, no numbers, no           |
//| imbalances, no refusals. If it cannot be read at a glance it is   |
//| not doing its job.                                               |
//+------------------------------------------------------------------+

string TFName(const ENUM_TIMEFRAMES tf)
  {
   string t = EnumToString(tf);
   if(StringFind(t,"PERIOD_")==0)
      t = StringSubstr(t,7);
   return(t);
  }

//+------------------------------------------------------------------+
//| One zone: the block candle, its imbalance, and the levels.        |
//| The tag keeps objects from different timeframes apart.            |
//+------------------------------------------------------------------+
void DrawCleanOne(CSpaZones &zs,const int idx,const color clr,
                  const ENUM_TIMEFRAMES tf,const string tag,const bool fillit)
  {
   SpaZone z;
   if(!zs.Get(idx,z))
      return;

   string   tfname = TFName(tf);
   string   base   = SPA_ZONE_PREFIX+tag+"c"+IntegerToString(idx);
   int      secs   = PeriodSeconds(tf);
   datetime t1     = z.t_ob;
   datetime tnow   = iTime(_Symbol,_Period,0);

   //--- a live zone reaches the current bar because that is the area being
   //--- watched. A used zone stops soon after its impulse.
   //--- a FILLED box is the timeframe you chose: it runs to the live bar.
   //--- An OUTLINE box is a context zone: it stops 40 bars after its block,
   //--- because a high-timeframe box stretched to "now" reads as a wall.
   datetime tzone;
   if(fillit)
      tzone = z.fresh ? tnow : t1+(datetime)(20*secs);
   else
      tzone = t1+(datetime)(InpZoneBoxBars*secs);
   if(tzone>tnow)
      tzone = tnow;

   string bn = base+"_box";
   if(ObjectCreate(0,bn,OBJ_RECTANGLE,0,t1,z.top,tzone,z.bottom))
     {
      ObjectSetInteger(0,bn,OBJPROP_COLOR,clr);
      ObjectSetInteger(0,bn,OBJPROP_FILL,fillit);
      ObjectSetInteger(0,bn,OBJPROP_BACK,true);
      ObjectSetInteger(0,bn,OBJPROP_WIDTH,fillit?1:1);
      ObjectSetInteger(0,bn,OBJPROP_STYLE,STYLE_SOLID);
      ObjectSetInteger(0,bn,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,bn,OBJPROP_HIDDEN,true);
     }

   //--- the label sits INSIDE the box, vertically centred. Anchored at the top
   //--- edge it collided with the label of the box above it, which is the one
   //--- thing that made three timeframes look cluttered.
   string zn = base+"_zl";
   if(ObjectCreate(0,zn,OBJ_TEXT,0,t1,(z.top+z.bottom)/2.0))
     {
      //--- ONLY the timeframe. No "ZONE", no "this block's gap", no numbers:
      //--- the colour already says buy or sell, the height already says the
      //--- level, and the only thing you cannot see is which timeframe it is.
      ObjectSetString(0,zn,OBJPROP_TEXT,StringFormat(" %s",tfname));
      ObjectSetString(0,zn,OBJPROP_FONT,"Consolas");
      ObjectSetInteger(0,zn,OBJPROP_FONTSIZE,8);
      ObjectSetInteger(0,zn,OBJPROP_COLOR,z.demand ? InpColFreshTxt : InpColSupplyTxt);
      ObjectSetInteger(0,zn,OBJPROP_ANCHOR,ANCHOR_LEFT);
      ObjectSetInteger(0,zn,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,zn,OBJPROP_HIDDEN,true);
     }

   double entry = z.demand ? z.top    : z.bottom;
   double stop  = z.demand ? z.bottom : z.top;
   HLevel(base+"_e",t1,tzone,entry,clr,1,STYLE_DOT);
   HLevel(base+"_s",t1,tzone,stop, clr,1,STYLE_DOT);

   double tp   = 0.0;
   bool   have = false;
   int    n    = zs.Count();
   for(int i=n-1;i>=0;i--)
     {
      SpaZone o;
      if(!zs.Get(i,o))
         continue;
      if(o.demand==z.demand)
         continue;
      double lvl = z.demand ? o.bottom : o.top;
      if(z.demand  && lvl<=entry) continue;
      if(!z.demand && lvl>=entry) continue;
      if(!have || (z.demand ? (lvl<tp) : (lvl>tp)))
        {
         tp   = lvl;
         have = true;
        }
     }
   if(have && InpShowTarget)
      HLevel(base+"_tp",t1,tnow,tp,InpColGap,1,STYLE_DOT);
  }

//+------------------------------------------------------------------+
//| Draw one timeframe's set. Freshness prefers a live block but      |
//| never leaves the chart empty - about 2 of 315 M15 blocks are      |
//| untouched at any moment, so "fresh only" blanks the chart.        |
//+------------------------------------------------------------------+
void DrawCleanSet(CSpaZones &zs,const ENUM_TIMEFRAMES tf,const string tag,const bool fillit)
  {
   int n = zs.Count();
   if(n<=0)
      return;

   int freshDemand=-1, freshSupply=-1, anyDemand=-1, anySupply=-1;
   for(int i=n-1;i>=0 && (freshDemand<0 || freshSupply<0 || anyDemand<0 || anySupply<0);i--)
     {
      SpaZone z;
      if(!zs.Get(i,z))
         continue;
      if(z.demand)
        {
         if(anyDemand<0)              anyDemand   = i;
         if(z.fresh && freshDemand<0) freshDemand = i;
        }
      else
        {
         if(anySupply<0)              anySupply   = i;
         if(z.fresh && freshSupply<0) freshSupply = i;
        }
     }

   int demandIdx = (freshDemand>=0) ? freshDemand : anyDemand;
   int supplyIdx = (freshSupply>=0) ? freshSupply : anySupply;

   if(demandIdx>=0) DrawCleanOne(zs,demandIdx,InpColFresh, tf,tag,fillit);
   if(supplyIdx>=0) DrawCleanOne(zs,supplyIdx,InpColSupply,tf,tag,fillit);

   SpaZone dz, sz;
   string dt = (demandIdx>=0 && zs.Get(demandIdx,dz))
                ? TimeToString(dz.t_ob,TIME_DATE|TIME_MINUTES) : "none";
   string st = (supplyIdx>=0 && zs.Get(supplyIdx,sz))
                ? TimeToString(sz.t_ob,TIME_DATE|TIME_MINUTES) : "none";
   PrintFormat("[ZONE] %s clean: found=%d  BUY block=%s  SELL block=%s",
               TFName(tf),n,dt,st);
  }

//+------------------------------------------------------------------+
//| Multi-timeframe: the chart shows the inventory of EVERY structure |
//| timeframe at once, each labelled, so an M5 chart still shows the  |
//| H4 and M15 zones above it.                                        |
//+------------------------------------------------------------------+
void DrawBlock(const int idx,const SpaZone &z,const bool selected,
               const int secs,const datetime tnow)
  {
   color    clr = z.demand ? InpColFresh : InpColSupply;
   datetime t1  = z.t_ob;
   datetime t2  = t1+(datetime)(InpZoneBoxBars*secs);
   if(t2>tnow)
      t2 = tnow;
   if(t2<=t1)
      return;

   string bn = SPA_ZONE_PREFIX+"k"+IntegerToString(idx);
   if(!ObjectCreate(0,bn,OBJ_RECTANGLE,0,t1,z.top,t2,z.bottom))
      return;
   ObjectSetInteger(0,bn,OBJPROP_COLOR,clr);
   //--- the block the engine currently ranks highest is the only filled one.
   //--- Everything else is a thin outline: visible, selectable, not shouting.
   ObjectSetInteger(0,bn,OBJPROP_FILL,selected);
   ObjectSetInteger(0,bn,OBJPROP_BACK,true);
   ObjectSetInteger(0,bn,OBJPROP_WIDTH,1);
   ObjectSetInteger(0,bn,OBJPROP_STYLE,STYLE_SOLID);
   ObjectSetInteger(0,bn,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,bn,OBJPROP_HIDDEN,true);
  }

//+------------------------------------------------------------------+
//| The block that gave us the bias: the newest one on the bias       |
//| timeframe, in the direction the bias points.                      |
//+------------------------------------------------------------------+
void DrawBiasZone()
  {
   int      n    = g_zonesB.Count();
   int      secs = PeriodSeconds(g_profile.tf_bias);
   datetime tnow = iTime(_Symbol,_Period,0);
   string   want = g_bias.TrendText();
   bool     sell = (want=="DOWN");
   bool     buy  = (want=="UP");
   if(!sell && !buy)
      return;                       // no directional bias: nothing to mark

   int     found = -1;
   SpaZone z;
   for(int i=n-1;i>=0;i--)
     {
      SpaZone c;
      if(!g_zonesB.Get(i,c))
         continue;
      if(c.demand==sell)             // DOWN bias wants the supply block
         continue;
      found = i;
      break;
     }
   if(found<0 || !g_zonesB.Get(found,z))
      return;

   datetime t1 = z.t_ob;
   datetime t2 = t1+(datetime)(InpZoneBoxBars*secs);
   if(t2>tnow)
      t2 = tnow;
   if(t2<=t1)
      return;

   string bn = SPA_ZONE_PREFIX+"bias_box";
   if(ObjectCreate(0,bn,OBJ_RECTANGLE,0,t1,z.top,t2,z.bottom))
     {
      ObjectSetInteger(0,bn,OBJPROP_COLOR,InpColBias);
      ObjectSetInteger(0,bn,OBJPROP_FILL,false);
      ObjectSetInteger(0,bn,OBJPROP_BACK,true);
      ObjectSetInteger(0,bn,OBJPROP_WIDTH,1);
      ObjectSetInteger(0,bn,OBJPROP_STYLE,STYLE_SOLID);
      ObjectSetInteger(0,bn,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,bn,OBJPROP_HIDDEN,true);
     }
   string ln = SPA_ZONE_PREFIX+"bias_lbl";
   if(ObjectCreate(0,ln,OBJ_TEXT,0,t1,(z.top+z.bottom)/2.0))
     {
      ObjectSetString(0,ln,OBJPROP_TEXT," "+TFName(g_profile.tf_bias));
      ObjectSetString(0,ln,OBJPROP_FONT,"Consolas");
      ObjectSetInteger(0,ln,OBJPROP_FONTSIZE,8);
      ObjectSetInteger(0,ln,OBJPROP_COLOR,InpColBias);
      ObjectSetInteger(0,ln,OBJPROP_ANCHOR,ANCHOR_LEFT);
      ObjectSetInteger(0,ln,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,ln,OBJPROP_HIDDEN,true);
     }
  }

void DrawClean()
  {
   //--- SHOW EVERY LAST CANDLE BEFORE THE IMPULSE, not one per direction.
   //--- Picking one was my rule, and it hid the block at the top of the range
   //--- that price tapped cleanly. Nothing is chosen here; the inventory is
   //--- laid out and the choosing happens later, on confirmation.
   int      n    = g_zonesChart.Count();
   //--- The block index is an index into the STRUCTURE's arrays, not into the
   //--- terminal's whole history. Using Bars() here compared a 600-bar array
   //--- against 7,500 daily bars and rejected every block: that is why a Daily
   //--- chart showed no zones at all.
   int      nb   = g_chart.Bars();
   int      secs = PeriodSeconds(PERIOD_CURRENT);
   datetime tnow = iTime(_Symbol,_Period,0);
   int      drawn= 0;

   for(int i=n-1;i>=0 && drawn<InpDrawZonesMax;i--)
     {
      SpaZone z;
      if(!g_zonesChart.Get(i,z))
         continue;
      //--- The user, 2026-11-03, reverses the earlier "must be filled all the
      //--- way" reading: "the moment the box is touched the imbalance is
      //--- already filled." A block price has come back into AT ALL - a dip or
      //--- a tap - is spent and comes off the chart.
      if(z.retested)
         continue;
      if(z.ob_idx < nb-InpZoneLookbackBars)
         continue;
      DrawBlock(i,z,(i==g_refine_idx),secs,tnow);
      drawn++;
     }

   if(InpShowBiasZone && Period()!=g_profile.tf_bias)
      DrawBiasZone();

   //--- say WHERE the blocks were lost, not just how many survived. Without
   //--- this the only number available was "32 known", which cannot tell you
   //--- whether the imbalances were never found or were found and rejected.
   int cand=0,none=0,small=0,filled=0,ok=0;
   g_zonesChart.Diag(cand,none,small,filled,ok);
   PrintFormat("== ZONE == %s: %d shown of %d known | found=%d  ok=%d  too-small=%d  atr=%.5f  bars=%d  lookback=%d",
               TFName(PERIOD_CURRENT),drawn,n,cand,ok,small,g_chart.ATR(),
               g_chart.Bars(),InpZoneLookbackBars);
  }

void DrawZones()
  {
   if(!InpShowZones)
      return;

   ObjectsDeleteAll(0,SPA_ZONE_PREFIX);

   if(InpClean)
     {
      DrawClean();
      return;
     }

   int n       = g_zones.Count();
   int shown   = 0;
   int maxdraw = InpZoneAudit ? InpAuditMax : InpDrawZonesMax;
   int secs    = PeriodSeconds(ZoneTF());

   for(int i=n-1;i>=0 && shown<maxdraw;i--)
     {
      SpaZone z;
      if(!g_zones.Get(i,z))
         continue;

      bool live    = z.fresh;
      bool expired = (z.age>InpZoneMaxAge);
      color zc     = live ? (z.demand ? InpColFresh : InpColSupply) : InpColUsed;

      //--- A ZONE IS TWO HORIZONTAL LEVELS, not a filled box.
      //--- MQL5 has no alpha on OBJ_RECTANGLE, so a "transparent" box is an
      //--- opaque box - it either hides the candles or is hidden by them.
      //--- Their 70%-transparent box becomes two levels here: the candles
      //--- stay readable, and there is no left or right border to read as a
      //--- vertical line.
      int      span = (int)MathMin((double)MathMax(z.break_idx-z.ob_idx+2,6),40.0);
      datetime t1   = z.t_ob;
      datetime t2   = z.t_ob+(datetime)(span*secs);
      string   base = SPA_ZONE_PREFIX+IntegerToString(i);

      //--- a faint box behind the candles, the way their boxes read, plus the
      //--- exact top and bottom as two levels. The box is drawn in the
      //--- background so the candles stay fully visible.
      if(InpZoneFill)
        {
         string bn = base+"_box";
         if(ObjectCreate(0,bn,OBJ_RECTANGLE,0,t1,z.top,t2,z.bottom))
           {
            ObjectSetInteger(0,bn,OBJPROP_COLOR,zc);
            ObjectSetInteger(0,bn,OBJPROP_FILL,true);
            ObjectSetInteger(0,bn,OBJPROP_BACK,true);
            ObjectSetInteger(0,bn,OBJPROP_WIDTH,0);
            ObjectSetInteger(0,bn,OBJPROP_STYLE,STYLE_SOLID);
            ObjectSetInteger(0,bn,OBJPROP_SELECTABLE,false);
            ObjectSetInteger(0,bn,OBJPROP_HIDDEN,true);
           }
        }
      HLevel(base+"_t",t1,t2,z.top,   zc,live?2:1,STYLE_SOLID);
      HLevel(base+"_b",t1,t2,z.bottom,zc,live?2:1,STYLE_SOLID);

      string on = base+"_tag";
      if(ObjectCreate(0,on,OBJ_TEXT,0,t2,z.top))
        {
         ObjectSetString(0,on,OBJPROP_TEXT,
            StringFormat("%s %s%s",
                         EnumToString(ZoneTF()),
                         z.demand ? "DEMAND" : "SUPPLY",
                         live ? "" : (expired ? " used" : " tapped")));
         ObjectSetString(0,on,OBJPROP_FONT,"Consolas");
         ObjectSetInteger(0,on,OBJPROP_FONTSIZE,7);
         ObjectSetInteger(0,on,OBJPROP_COLOR,zc);
         ObjectSetInteger(0,on,OBJPROP_ANCHOR,ANCHOR_LEFT_LOWER);
         ObjectSetInteger(0,on,OBJPROP_SELECTABLE,false);
         ObjectSetInteger(0,on,OBJPROP_HIDDEN,true);
        }

      //--- the imbalance that validates the zone: two dotted levels inside
      //--- the impulse, so the gap is visible without covering anything.
      //--- the imbalance itself: a faint box only while it is still untouched.
      //--- Once price has traded into it, it is spent and it comes off the
      //--- chart. No label - the point of interest is the block, not the gap.
      if(InpZoneAudit && !z.gap_filled && z.gap_high>z.gap_low)
        {
         string gn = base+"_imb";
         int    gspan = (int)MathMin((double)MathMax(z.break_idx-z.gap_idx+3,8),26.0);
         datetime g1 = z.t_gap;
         datetime g2 = z.t_gap+(datetime)(gspan*secs);
         if(ObjectCreate(0,gn,OBJ_RECTANGLE,0,g1,z.gap_high,g2,z.gap_low))
           {
            ObjectSetInteger(0,gn,OBJPROP_COLOR,InpColGap);
            ObjectSetInteger(0,gn,OBJPROP_FILL,true);
            ObjectSetInteger(0,gn,OBJPROP_BACK,true);
            ObjectSetInteger(0,gn,OBJPROP_WIDTH,0);
            ObjectSetInteger(0,gn,OBJPROP_STYLE,STYLE_SOLID);
            ObjectSetInteger(0,gn,OBJPROP_SELECTABLE,false);
            ObjectSetInteger(0,gn,OBJPROP_HIDDEN,true);
           }
        }

      shown++;
     }

   //--- AUDIT: order blocks the engine looked at and refused. Two short
   //--- levels, so a refusal is visible without becoming noise.
   if(InpZoneAudit && InpAuditRejected)
     {
      int rn = g_zones.RejectCount();
      int rshown = 0;
      for(int i=rn-1;i>=0 && rshown<InpAuditMax;i--)
        {
         SpaReject r;
         if(!g_zones.GetReject(i,r))
            continue;
         string   base = SPA_ZONE_PREFIX+"rej"+IntegerToString(i);
         datetime r1   = r.t_ob;
         datetime r2   = r.t_ob+(datetime)(12*secs);
         HLevel(base+"_t",r1,r2,r.top,   InpColUsed,1,STYLE_DASH);
         HLevel(base+"_b",r1,r2,r.bottom,InpColUsed,1,STYLE_DASH);

         string why = (r.why==2) ? "gap too small"
                    : (r.why==3) ? "gap closed by the impulse"
                                 : "no 3-candle gap";
         string on = base+"_tag";
         if(ObjectCreate(0,on,OBJ_TEXT,0,r2,r.top))
           {
            ObjectSetString(0,on,OBJPROP_TEXT,
                            StringFormat("OB %s REJECTED: %s",r.demand ? "demand" : "supply",why));
            ObjectSetString(0,on,OBJPROP_FONT,"Consolas");
            ObjectSetInteger(0,on,OBJPROP_FONTSIZE,6);
            ObjectSetInteger(0,on,OBJPROP_COLOR,InpColUsed);
            ObjectSetInteger(0,on,OBJPROP_ANCHOR,ANCHOR_LEFT_LOWER);
            ObjectSetInteger(0,on,OBJPROP_SELECTABLE,false);
            ObjectSetInteger(0,on,OBJPROP_HIDDEN,true);
           }
         rshown++;
        }
     }
  }

void DrawAllSwings()
  {
   if(!InpDrawStructure)
      return;

   //--- clear first: positional names would otherwise leave stale arrows
   //--- behind whenever a pivot index shifts.
   ObjectsDeleteAll(0,SPA_SW_PREFIX);

   g_arrow_count = 0;

   double ref_atr = (g_exec.ATR()>0.0) ? g_exec.ATR() : g_confirm.ATR();

   int drawn = 0;
   if(ShouldDrawTF(g_bias.Timeframe()))    { DrawSwings(g_bias,   0,clrGold,        ref_atr); drawn++; }
   if(ShouldDrawTF(g_confirm.Timeframe())) { DrawSwings(g_confirm,1,clrDeepSkyBlue, ref_atr); drawn++; }
   if(ShouldDrawTF(g_exec.Timeframe()))    { DrawSwings(g_exec,   2,clrSilver,      ref_atr); drawn++; }
   g_arrows_hidden = (drawn==0);

   if(g_arrows_hidden)
      PrintFormat("[OBJ] arrows suppressed: chart TF %s is coarser than bias %s / confirm %s / exec %s",
                  EnumToString((ENUM_TIMEFRAMES)_Period),
                  EnumToString(g_profile.tf_bias),EnumToString(g_profile.tf_confirm),
                  EnumToString(g_profile.tf_exec));

   PrintFormat("[OBJ] %d swing arrows drawn (bias=%d/%d conf=%d/%d exec=%d/%d)",
               g_arrow_count,
               g_bias.PivotCount(),   InpDrawMaxPivots,
               g_confirm.PivotCount(),InpDrawMaxPivots,
               g_exec.PivotCount(),   InpDrawMaxPivots);
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| HEARTBEAT - drawn with Comment(), which the terminal renders      |
//| itself and which survives anything that breaks chart objects.     |
//| If you can see this line, the EA is running. Period.              |
//+------------------------------------------------------------------+
void UpdateHeartbeat()
  {
   string hb = StringFormat(
      "SPA v%s ALIVE  |  %s  |  swings  B:%d C:%d E:%d  |  arrows:%d  |  ticks:%d  |  NO TRADING",
      SPA_VERSION,g_symbol.Symbol(),
      g_bias.PivotCount(),g_confirm.PivotCount(),g_exec.PivotCount(),
      g_arrow_count,g_tick_count);
   Comment(hb);
  }

//+------------------------------------------------------------------+
//| Live panel                                                        |
//+------------------------------------------------------------------+
void DrawPanel()
  {
   if(!InpShowPanel)
      return;

   int    x  = InpPanelX;
   int    y  = InpPanelY+SPA_PANEL_COMMENT_PAD;   // never print over the heartbeat Comment
   int    lh = InpPanelFontSize+6;
   string fn = "Consolas";

   string rows[];
   color  cols[];
   ArrayResize(rows,SPA_PANEL_ROWS);
   ArrayResize(cols,SPA_PANEL_ROWS);

   rows[0]  = StringFormat("SOVEREIGN PA  v%s",SPA_VERSION);
   cols[0]  = InpPanelText;
   rows[1]  = "STRUCTURE BUILD - PLACES NO ORDERS";
   cols[1]  = InpPanelBlock;
   rows[2]  = StringFormat("%s  profile %s (%s)  enabled:%s",
                           g_symbol.Symbol(),g_profile.pattern,g_profile.asset_class,
                           g_profile.enabled ? "YES" : "NO");
   cols[2]  = g_profile.enabled ? InpPanelText : InpPanelBlock;
   rows[3]  = StringFormat("server %s  GMT %s  ticks %d",
                           TimeToString(TimeCurrent(),TIME_MINUTES),
                           TimeToString(TimeGMT(),TIME_MINUTES),g_tick_count);
   cols[3]  = InpPanelText;
   rows[4]  = StringFormat("bid %.5g  ask %.5g  spread %.2f pips",
                           g_bid,g_ask,g_sp_pips);
   cols[4]  = InpPanelText;
   rows[5]  = (g_sp_samples<SPA_SP_MIN_SAMPLES)
              ? StringFormat("regime CALIBRATING (%d/%d samples)  ATR14 %.5g",
                             g_sp_samples,SPA_SP_MIN_SAMPLES,g_atr_conf)
              : StringFormat("regime %s (x%.2f vs median %.2f, n=%d)  ATR14 %.5g",
                             g_regime,g_ratio,g_med_pips,g_sp_samples,g_atr_conf);
   cols[5]  = (g_sp_samples>=SPA_SP_MIN_SAMPLES && g_ratio>=3.0) ? InpPanelBlock : InpPanelText;
   rows[6]  = StringFormat("R-10a %s   R-10b %s (%.1f%% of %.0fp SL, limit %.1f%%)",
                           g_coarse_ok ? "PASS" : "BLOCK",
                           g_risk_ok ? "PASS" : "BLOCK",
                           g_sl_px>0.0 ? (g_sp_price/g_sl_px)*100.0 : 0.0,
                           InpDiagSlPips,g_profile.max_spread_of_risk*100.0);
   cols[6]  = (g_coarse_ok && g_risk_ok) ? InpPanelOK : InpPanelBlock;
   rows[7]  = StringFormat("lots @ %.0fp SL %.2f   risk %.2f%%   minRR %.1f:1",
                           InpDiagSlPips,g_lots,g_profile.risk_pct,g_profile.min_rr);
   cols[7]  = (g_lots>0.0) ? InpPanelText : InpPanelBlock;
   rows[8]  = " ";
   cols[8]  = InpPanelText;
   rows[9]  = StringFormat("STRUCTURE  (swing >= %.2fx ATR)",InpMinSwingATR);
   cols[9]  = InpPanelText;
   rows[10] = StructureLine(g_bias,   "BIAS");
   cols[10] = (g_bias.Trend()==SPA_TREND_RANGE) ? InpPanelBlock : InpPanelOK;
   rows[11] = StructureLine(g_confirm,"CONF");
   cols[11] = (g_confirm.Trend()==SPA_TREND_RANGE) ? InpPanelBlock : InpPanelOK;
   rows[12] = StructureLine(g_exec,   "EXEC");
   cols[12] = (g_exec.Trend()==SPA_TREND_RANGE) ? InpPanelBlock : InpPanelOK;
   rows[13] = " ";
   cols[13] = InpPanelText;
   rows[14] = (g_bias.Trend()==SPA_TREND_RANGE || g_bias.IsConsolidating())
              ? "BIAS NOT DIRECTIONAL - no trades would be considered"
              : "BIAS DIRECTIONAL - waiting for entry engine (v0.6.0)";
   cols[14] = (g_bias.Trend()==SPA_TREND_RANGE || g_bias.IsConsolidating())
              ? InpPanelBlock : InpPanelOK;
   rows[15] = " ";
   cols[15] = InpPanelText;
   rows[16] = StringFormat("swings detected: bias=%d conf=%d exec=%d  (arrows:%d)",
                           g_bias.PivotCount(),g_confirm.PivotCount(),g_exec.PivotCount(),
                           g_arrow_count);
   cols[16] = InpPanelText;
   int d_cand, d_none, d_small, d_filled, d_ok;
   g_zones.Diag(d_cand,d_none,d_small,d_filled,d_ok);
   //--- this must describe what is DRAWN, which is the chart's timeframe,
   //--- not the configured zone timeframe. Saying "PERIOD_M15" on a Daily
   //--- chart while drawing Daily blocks was its own kind of lie.
   rows[17] = StringFormat("BLOCKS on %s  found=%d  shown up to %d  window %d bars",
                           TFName(PERIOD_CURRENT),g_zonesChart.Count(),
                           InpDrawZonesMax,InpZoneLookbackBars);
   cols[17] = g_zones.Count()>0 ? InpPanelOK : InpPanelBlock;
   rows[18] = g_signal_note;
   cols[18] = g_plan.valid ? InpPanelOK : InpPanelBlock;
   rows[19] = StringFormat("v%s DRAWS THE TRADE ONLY - NO ORDERS ARE SENT",SPA_VERSION);
   cols[19] = InpPanelBlock;

   if(g_arrows_hidden)
     {
      rows[20] = StringFormat("ARROWS HIDDEN - this %s chart is coarser than every structure TF",
                              EnumToString((ENUM_TIMEFRAMES)_Period));
      cols[20] = InpPanelBlock;
      rows[21] = StringFormat("structure TFs are %s / %s / %s - open an M5 to M15 chart",
                              EnumToString(g_profile.tf_bias),
                              EnumToString(g_profile.tf_confirm),
                              EnumToString(g_profile.tf_exec));
      cols[21] = InpPanelBlock;
     }
   else
     {
      rows[20] = "LEGEND  gold = BIAS TF   blue = CONFIRM TF   silver = EXEC TF";
      cols[20] = InpPanelText;
      rows[21] = "green box = demand (buy)   red box = supply (sell)   dotted = entry / stop   gold dotted = target";
      cols[21] = InpPanelText;
     }
   //--- WHY found=0. Every order-block candidate is counted against the gate
   //--- that rejected it, so a blank chart can be read instead of guessed at.
   rows[22] = StringFormat("IMPULSES  blocks=%d  -> no gap in leg=%d  gap < %.2fxATR=%d  with a valid gap=%d",
                           d_cand,d_none,d_small,InpFvgMinATR,d_ok);
   cols[22] = d_cand>0 ? InpPanelText : InpPanelBlock;
   rows[23] = StringFormat("%s: imbalance >= %.2fx ATR, block = the candle just before it (wick to wick)",
                           EnumToString(ZoneTF()),InpFvgMinATR);
   cols[23] = InpPanelText;
   rows[24] = "Next: zones for each timeframe, then sweep + MSS before entry";
   cols[22] = InpPanelText;

   //--- COMPACT BY DEFAULT. Six lines say what is happening. Everything the
   //--- engine knows is one click away, so nothing is lost and the chart is
   //--- not a wall of text.
   int nrows = SPA_PANEL_ROWS;
   if(!g_panel_full)
     {
      string c[6];
      color  cc[6];
      c[0] = rows[0];  cc[0] = cols[0];
      c[1] = StringFormat("%s %s   BIAS %s   regime %s",
                          g_symbol.Symbol(),TFName(PERIOD_CURRENT),
                          g_bias.TrendText(),
                          g_bias.IsConsolidating() ? "RANGE" : "TREND");
      cc[1] = InpPanelText;
      c[2] = g_zone_line;   cc[2] = InpPanelText;
      c[3] = g_refine_text; cc[3] = InpPanelText;
      c[4] = g_state_line;  cc[4] = InpPanelBlock;
      c[5] = "click MORE for the full readout"; cc[5] = InpPanelText;
      for(int i=0;i<6;i++)
        {
         rows[i] = c[i];
         cols[i] = cc[i];
        }
      nrows = 6;
     }

   for(int i=0;i<SPA_PANEL_ROWS;i++)
     {
      string nm = "SPA_L"+IntegerToString(i);
      if(ObjectFind(0,nm)<0)
        {
         ObjectCreate(0,nm,OBJ_LABEL,0,0,0);
         ObjectSetInteger(0,nm,OBJPROP_CORNER,CORNER_LEFT_UPPER);
         ObjectSetInteger(0,nm,OBJPROP_XDISTANCE,x);
         ObjectSetInteger(0,nm,OBJPROP_YDISTANCE,y+i*lh);
         ObjectSetInteger(0,nm,OBJPROP_SELECTABLE,false);
         ObjectSetInteger(0,nm,OBJPROP_HIDDEN,true);
         ObjectSetString(0,nm,OBJPROP_FONT,fn);
         ObjectSetInteger(0,nm,OBJPROP_FONTSIZE,InpPanelFontSize);
        }
      //--- an empty string does NOT clear an OBJ_LABEL: MT5 falls back to the
      //--- object's default description and the panel shows the word "Label"
      //--- once per hidden row. A single space clears it.
      ObjectSetString(0,nm,OBJPROP_TEXT,(i<nrows ? rows[i] : " "));
      ObjectSetInteger(0,nm,OBJPROP_COLOR,cols[i]);
     }

   //--- one small button, no menu system
   string bt = "SPA_TOGGLE";
   if(ObjectFind(0,bt)<0)
     {
      ObjectCreate(0,bt,OBJ_BUTTON,0,0,0);
      ObjectSetInteger(0,bt,OBJPROP_CORNER,CORNER_LEFT_UPPER);
      ObjectSetInteger(0,bt,OBJPROP_XDISTANCE,InpPanelX+330);
      ObjectSetInteger(0,bt,OBJPROP_YDISTANCE,InpPanelY+SPA_PANEL_COMMENT_PAD);
      ObjectSetInteger(0,bt,OBJPROP_XSIZE,52);
      ObjectSetInteger(0,bt,OBJPROP_YSIZE,16);
      ObjectSetString(0,bt,OBJPROP_FONT,"Consolas");
      ObjectSetInteger(0,bt,OBJPROP_FONTSIZE,8);
      ObjectSetInteger(0,bt,OBJPROP_BGCOLOR,clrBlack);
      ObjectSetInteger(0,bt,OBJPROP_COLOR,InpPanelText);
      ObjectSetInteger(0,bt,OBJPROP_BORDER_COLOR,InpPanelText);
      ObjectSetInteger(0,bt,OBJPROP_STATE,false);
      ObjectSetInteger(0,bt,OBJPROP_SELECTABLE,false);
      ObjectSetInteger(0,bt,OBJPROP_ZORDER,10);
     }
   ObjectSetString(0,bt,OBJPROP_TEXT,g_panel_full ? "LESS" : "MORE");
   ChartRedraw();
  }

//+------------------------------------------------------------------+
void DestroyObjects()
  {
   Comment("");
   for(int i=0;i<SPA_PANEL_ROWS;i++)
      ObjectDelete(0,"SPA_L"+IntegerToString(i));
   ObjectsDeleteAll(0,SPA_SW_PREFIX);
   ObjectsDeleteAll(0,SPA_ZONE_PREFIX);
   ObjectDelete(0,"SPA_TOGGLE");
   ChartRedraw();
  }

//+------------------------------------------------------------------+
void PrintConfig()
  {
   Print("==================================================================");
   PrintFormat("[SPA] SovereignPA v%s - STRUCTURE ENGINE (no trading)",SPA_VERSION);
   Print("==================================================================");
   PrintFormat("[SPA] Chart symbol      : %s",_Symbol);
   PrintFormat("[SPA] Profile matched   : %s  (asset class: %s)",g_profile.pattern,g_profile.asset_class);
   PrintFormat("[SPA] Profile enabled   : %s",g_profile.enabled ? "YES" : "NO  <-- no trades will be placed");
   PrintFormat("[SPA] Timeframes        : bias=%s  confirm=%s  exec=%s",
               EnumToString(g_profile.tf_bias),
               EnumToString(g_profile.tf_confirm),
               EnumToString(g_profile.tf_exec));
   PrintFormat("[SPA] Symbol metrics    : %s",g_symbol.Describe());
   PrintFormat("[SPA] Risk              : %.2f%% per trade | min RR %.2f : 1",
               g_profile.risk_pct,g_profile.min_rr);
   PrintFormat("[SPA] Structure settings: minSwing=%.2fxATR  bars=%d  consolidationBars=%d",
               InpMinSwingATR,InpStructBars,InpConsolBars);
   Print("==================================================================");
  }

//+------------------------------------------------------------------+
void PrintStructure()
  {
   Print("------------------------------------------------------------------");
   PrintFormat("[STR] %s",TimeToString(TimeCurrent(),TIME_DATE|TIME_MINUTES));
   PrintFormat("[STR] BIAS  %s",g_bias.Describe());
   PrintFormat("[STR] CONF  %s",g_confirm.Describe());
   PrintFormat("[STR] EXEC  %s",g_exec.Describe());

   //--- D-14 verdict, stated explicitly ---------------------------
   string verdict;
   if(g_bias.IsConsolidating())
      verdict = "SUSPENDED - no new extreme for " +
                IntegerToString(g_bias.BarsSinceExtreme()) + " bars (RB 2.1)";
   else if(g_bias.Trend()==SPA_TREND_RANGE)
      verdict = "NO BIAS - structure not directional";
   else
      verdict = "BIAS " + g_bias.TrendText() + " - entry engine not yet active";

   PrintFormat("[STR] D-14  bearish-shift=%s  bullish-shift=%s",
               g_bias.IsValidShift(true)  ? "VALID" : "not valid",
               g_bias.IsValidShift(false) ? "VALID" : "not valid");
   PrintFormat("[STR] STATE %s",verdict);
  }

//+------------------------------------------------------------------+
void PrintDiagnostics()
  {
   //--- The periodic block is off by default. On five charts it produced a
   //--- [DIAG] block every 30 seconds and buried the one line that matters.
   //--- Findings about zones ([ZONE], [REFINE]) always print.
   if(!InpLogDiag)
      return;
   PrintFormat("[DIAG] %s | bid=%.5g ask=%.5g spread=%.2f pips",
               TimeToString(TimeCurrent(),TIME_DATE|TIME_MINUTES),g_bid,g_ask,g_sp_pips);
   if(g_sp_samples<SPA_SP_MIN_SAMPLES)
      PrintFormat("[DIAG] Spread regime CALIBRATING (%d/%d samples collected)",
                  g_sp_samples,SPA_SP_MIN_SAMPLES);
   else
      PrintFormat("[DIAG] Spread regime %s (x%.2f vs median %.2f pips, n=%d)",
                  g_regime,g_ratio,g_med_pips,g_sp_samples);
   PrintFormat("[DIAG] R-10a coarse  : %s %s",g_coarse_ok ? "PASS" : "BLOCK",g_coarse_reason);
   PrintFormat("[DIAG] R-10b of risk : %s  (spread is %.1f%% of the %.0f-pip SL; limit %.1f%%) %s",
               g_risk_ok ? "PASS" : "BLOCK",
               g_sl_px>0.0 ? (g_sp_price/g_sl_px)*100.0 : 0.0,InpDiagSlPips,
               g_profile.max_spread_of_risk*100.0,g_risk_reason);
   PrintFormat("[DIAG] lots@%.0fp SL : %.2f | ticks %d",InpDiagSlPips,g_lots,g_tick_count);
  }

//+------------------------------------------------------------------+
//| A fatal init error must be visible on the CHART, not only in a    |
//| log tab the user may never open. Silent failure is the enemy.     |
//+------------------------------------------------------------------+
void FatalComment(const string reason)
  {
   string msg = StringFormat("SPA v%s INITIALISATION FAILED\n%s\nOpen Toolbox > Experts tab for detail.",
                             SPA_VERSION,reason);
   Comment(msg);
   PrintFormat("[SPA] FATAL: %s",reason);
  }

//+------------------------------------------------------------------+
int OnInit()
  {
   Comment("SPA initialising...");
   g_config_ok = false;

   if(!g_profiles.Load(InpProfileFile))
     {
      FatalComment("cannot open profile file: "+g_profiles.LastError()+
                   "  -> put symbol_profiles.csv in MQL5/Files");
      return(INIT_FAILED);
     }
   PrintFormat("[SPA] Profile file loaded: %d rows from '%s'",g_profiles.Count(),InpProfileFile);

   if(!g_profiles.Resolve(_Symbol,g_profile))
     {
      FatalComment("no profile row matched symbol '"+_Symbol+"'  -> add a row to symbol_profiles.csv");
      return(INIT_FAILED);
     }

   if(InpRiskPctOverride>0.0)
     {
      if(InpRiskPctOverride>1.0)
        {
         FatalComment(StringFormat("risk override %.2f%% exceeds the 1.0%% ceiling (R-01)",InpRiskPctOverride));
         return(INIT_FAILED);
        }
      g_profile.risk_pct = InpRiskPctOverride;
     }
   if(InpMinRROverride>0.0)
     {
      if(InpMinRROverride<3.0)
        {
         FatalComment(StringFormat("min RR override %.2f is below the 3.0 floor (R-06)",InpMinRROverride));
         return(INIT_FAILED);
        }
      g_profile.min_rr = InpMinRROverride;
     }
   if(InpOverrideEnabled)
     {
      g_profile.enabled = true;
      Print("[SPA] WARNING: profile force-enabled by input. Testing only.");
     }

   if(!g_symbol.Init(_Symbol,g_profile))
     {
      FatalComment("symbol init failed: "+g_symbol.LastError());
      return(INIT_FAILED);
     }

   g_h_atr_confirm = iATR(_Symbol,g_profile.tf_confirm,14);
   if(g_h_atr_confirm==INVALID_HANDLE)
     {
      FatalComment(StringFormat("iATR(%s) failed err=%d",
                                EnumToString(g_profile.tf_confirm),GetLastError()));
      return(INIT_FAILED);
     }

//--- structure engines -------------------------------------------
   g_bias.Init(_Symbol,g_profile.tf_bias,InpMinSwingATR,InpStructBars,InpConsolBars);
   g_confirm.Init(_Symbol,g_profile.tf_confirm,InpMinSwingATR,InpStructBars,InpConsolBars);
   g_exec.Init(_Symbol,g_profile.tf_exec,InpMinSwingATR,InpStructBars,InpConsolBars);
   //--- the chart's own timeframe, whatever it is. Change the timeframe and
   //--- the zones change with it: M1 shows M1 zones, H1 shows H1 zones.
   g_chart.Init(_Symbol,PERIOD_CURRENT,InpMinSwingATR,InpStructBars,InpConsolBars);

   if(!g_bias.Refresh())
      PrintFormat("[SPA] WARNING: bias structure unavailable - %s",g_bias.LastError());
   if(!g_confirm.Refresh())
      PrintFormat("[SPA] WARNING: confirm structure unavailable - %s",g_confirm.LastError());
   if(!g_exec.Refresh())
      PrintFormat("[SPA] WARNING: exec structure unavailable - %s",g_exec.LastError());

//--- explain an empty chart instead of leaving the user guessing -----
   PrintFormat("[HIST] bars loaded: bias=%d confirm=%d exec=%d  |  swing threshold bias=%.5g conf=%.5g exec=%.5g",
               g_bias.Bars(),g_confirm.Bars(),g_exec.Bars(),
               g_bias.SwingThreshold(),g_confirm.SwingThreshold(),g_exec.SwingThreshold());
   if(g_bias.PivotCount()==0)
      Print("[HIST] No bias swings detected. Usual cause: timeframe history still downloading.");
   if(g_confirm.PivotCount()==0)
      Print("[HIST] No confirm swings detected. Open that timeframe's chart once so MT5 caches it,");
   g_last_chart_bar = iTime(_Symbol,_Period,0);
   if(g_exec.PivotCount()==0)
      Print("[HIST] No exec swings detected. Lower InpMinSwingATR (e.g. 1.0) or raise InpStructBars.");

   PrintConfig();

   g_config_ok = true;
   g_panel_full = InpPanelStartFull;

   RefreshMetrics();
   RefreshSignal();
   DrawAllSwings();
   DrawZones();
   DrawPanel();
   UpdateHeartbeat();

   PrintStructure();
   if(InpDiagnostics)
      PrintDiagnostics();

   Print("[SPA] READY. No orders will be placed. Check that the arrows on the chart");
   Print("[SPA] mark the same swing highs and lows that you would mark yourself.");
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   DestroyObjects();

   if(g_h_atr_confirm!=INVALID_HANDLE)
     {
      IndicatorRelease(g_h_atr_confirm);
      g_h_atr_confirm = INVALID_HANDLE;
     }
   PrintFormat("[SPA] Deinitialised (reason %d). No orders were ever placed by this build.",reason);
  }

//+------------------------------------------------------------------+
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
  {
   if(id!=CHARTEVENT_OBJECT_CLICK)
      return;
   if(sparam!="SPA_TOGGLE")
      return;
   g_panel_full = !g_panel_full;
   DrawPanel();
  }

void OnTick()
  {
   if(!g_config_ok)
      return;

   g_tick_count++;

//--- structure refresh (internally cached per bar) ---------------
   g_bias.Refresh();
   g_confirm.Refresh();
   g_exec.Refresh();

//--- redraw when ANY of the three timeframes closes a new bar ----
   datetime bias_bar = iTime(_Symbol,g_profile.tf_bias,0);
   datetime conf_bar = iTime(_Symbol,g_profile.tf_confirm,0);
   datetime exec_bar = iTime(_Symbol,g_profile.tf_exec,0);

   bool new_bias = (bias_bar!=g_last_bias_bar);
   //--- the chart's own timeframe must also trigger a rebuild, otherwise an
   //--- M1 chart would keep drawing M15-era zones until a structure bar closed
   datetime chart_bar = iTime(_Symbol,_Period,0);
   bool new_chart = (chart_bar!=g_last_chart_bar);
   bool any_bar  = new_bias || new_chart || (conf_bar!=g_last_conf_bar) || (exec_bar!=g_last_exec_bar);

   if(any_bar)
     {
      g_last_bias_bar = bias_bar;
      g_last_chart_bar= chart_bar;
      g_last_conf_bar = conf_bar;
      g_last_exec_bar = exec_bar;
      RefreshSignal();
      DrawAllSwings();
      DrawZones();
     }
   if(new_bias)
      PrintStructure();

//--- refresh the panel at most once per second -------------------
   if(TimeCurrent()!=g_last_refresh)
     {
      g_last_refresh = TimeCurrent();
      RefreshMetrics();
      DrawPanel();
      UpdateHeartbeat();
     }

   if(!InpDiagnostics)
      return;
   if(TimeCurrent()-g_last_diag < InpDiagEverySeconds)
      return;
   g_last_diag = TimeCurrent();
   PrintDiagnostics();
  }
//+------------------------------------------------------------------+

//  END MODULE: experts/SovereignPA/SovereignPA.mq5
